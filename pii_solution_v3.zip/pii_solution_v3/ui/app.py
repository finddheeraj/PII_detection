"""
app.py
──────
Gradio UI for the PII Detection Solution.
Three tabs:
  1. Text Input  — paste/type text, see inline highlights + table
  2. File Scan   — upload or specify a file path, scan line by line
  3. Folder Scan — specify folder path, scan all supported files
  4. Accuracy    — run accuracy evaluation & view metrics

Run:  python app.py
"""

import sys, os
from pathlib import Path

# Ensure project root is on path
ROOT = Path(__file__).parent
sys.path.insert(0, str(ROOT))

import gradio as gr
import pandas as pd
from collections import Counter

from core.detector import detect_pii, scan_text, scan_file, scan_folder
from core.pii_patterns import LABEL_COLORS, LABEL_SEVERITY


# ─────────────────────────────────────────────────────────────────
#  Feedback handler (feeds online learning loop)
# ─────────────────────────────────────────────────────────────────

def record_feedback(detected_value: str, label: str,
                    is_fp_str: str, context: str = "") -> str:
    """Record user feedback; updates veto classifier immediately."""
    if not detected_value.strip() or not label.strip():
        return "⚠️ Please enter the detected value and label."
    is_fp = (is_fp_str == "False Positive (FP)")
    try:
        from models.ensemble_model import load_ensemble
        ensemble = load_ensemble()
        ensemble.record_feedback(detected_value.strip(), label.strip(),
                                 is_fp=is_fp, context=context.strip())
        summary = ensemble.feedback_summary()
        fp_or_tp = "🚫 False Positive" if is_fp else "✅ True Positive"
        return (
            f"{fp_or_tp} recorded for **{label}** → '{detected_value[:50]}'\n\n"
            f"Total feedback: {summary['total']} "
            f"(FPs: {summary['fps']}, TPs: {summary['tps']})\n"
            f"Veto classifier active: {'Yes' if summary['veto_trained'] else 'Not yet (need 2+ samples)'}"
        )
    except Exception as e:
        return f"⚠️ Could not record feedback: {e}"


def get_feedback_summary() -> str:
    """Return formatted feedback summary."""
    try:
        from models.ensemble_model import load_ensemble
        ensemble = load_ensemble()
        s = ensemble.feedback_summary()
        if s["total"] == 0:
            return "No feedback recorded yet. Use the form above to flag detections."
        lines = [f"**Total feedback: {s['total']}** (FPs: {s['fps']}, TPs: {s['tps']})\n"]
        for label, counts in sorted(s["by_label"].items()):
            lines.append(f"- **{label}**: {counts['fp']} FPs, {counts['tp']} TPs")
        lines.append(f"\nVeto classifier trained: {'✅ Yes' if s['veto_trained'] else '⏳ Not yet'}")
        return "\n".join(lines)
    except Exception as e:
        return f"Could not load feedback summary: {e}"


# ─────────────────────────────────────────────────────────────────
#  Shared helpers
# ─────────────────────────────────────────────────────────────────

SEVERITY_EMOJI = {
    "CRITICAL": "🔴",
    "HIGH":     "🟠",
    "MEDIUM":   "🟡",
    "LOW":      "🟢",
}

def _highlight_html(text: str, detections: list) -> str:
    """Build inline HTML with coloured PII highlights."""
    if not detections:
        return f'<div style="font-family:monospace;font-size:0.9rem;' \
               f'background:#1e2230;padding:16px;border-radius:8px;' \
               f'color:#e2e8f0;white-space:pre-wrap">' \
               f'{_esc(text)}</div>'

    out  = []
    prev = 0
    for det in sorted(detections, key=lambda x: x["start"]):
        s, e  = det["start"], det["end"]
        color = LABEL_COLORS.get(det["label"], "#ADB5BD")
        conf  = det.get("final_confidence", "MEDIUM")
        sev   = det.get("severity", "MEDIUM")

        out.append(_esc(text[prev:s]))
        out.append(
            f'<mark title="{det["label"]} | {sev} | Confidence: {conf}" '
            f'style="background:{color};border-radius:3px;padding:1px 4px;'
            f'color:#0f1117;font-weight:600;cursor:help">'
            f'{_esc(text[s:e])}'
            f'<sup style="font-size:0.6em;margin-left:2px">{det["label"]}</sup>'
            f'</mark>'
        )
        prev = e

    out.append(_esc(text[prev:]))

    return (
        '<div style="font-family:monospace;font-size:0.9rem;'
        'background:#1e2230;padding:16px;border-radius:8px;'
        'color:#e2e8f0;white-space:pre-wrap;line-height:1.7">'
        + "".join(out) + "</div>"
    )


def _esc(s: str) -> str:
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def _detections_df(detections: list) -> pd.DataFrame:
    if not detections:
        return pd.DataFrame(columns=["Label", "Value", "Severity", "Confidence", "Method"])
    rows = [{
        "Label":      d["label"],
        "Value":      d["text"],
        "Severity":   SEVERITY_EMOJI.get(d.get("severity","MEDIUM"), "") + " " + d.get("severity","MEDIUM"),
        "Confidence": d.get("final_confidence", "MEDIUM"),
        "ML Conf":    f'{d.get("ml_confidence", 0):.0%}',
        "Method":     d.get("method", "REGEX"),
    } for d in detections]
    return pd.DataFrame(rows)


def _summary_html(result: dict) -> str:
    total = result.get("total_pii", 0)
    summ  = result.get("summary", {})
    sev   = result.get("severity_counts", {})

    if not total:
        return '<div style="color:#20C997;font-size:1rem;padding:12px">✅ No PII detected.</div>'

    sev_html = " &nbsp; ".join(
        f'{SEVERITY_EMOJI.get(k,"")}<b>{k}</b>: {v}'
        for k, v in sorted(sev.items())
    )
    label_badges = " ".join(
        f'<span style="background:{LABEL_COLORS.get(lbl,"#aaa")};padding:2px 8px;'
        f'border-radius:4px;font-size:0.8rem;font-weight:600;color:#0f1117">'
        f'{lbl} ({cnt})</span>'
        for lbl, cnt in sorted(summ.items(), key=lambda x: -x[1])
    )
    return (
        f'<div style="background:#1e2230;border-radius:8px;padding:14px 18px">'
        f'<div style="font-size:1.05rem;color:#f8fafc;margin-bottom:8px">'
        f'⚠️ <b>{total}</b> PII item(s) detected</div>'
        f'<div style="font-size:0.85rem;margin-bottom:10px;color:#e2e8f0">{sev_html}</div>'
        f'<div>{label_badges}</div>'
        f'</div>'
    )


# ─────────────────────────────────────────────────────────────────
#  Tab 1: Text Input
# ─────────────────────────────────────────────────────────────────

def process_text(text: str, use_spacy: bool, use_ml: bool, min_conf: str):
    if not text.strip():
        return "<i>Enter some text above.</i>", pd.DataFrame(), "", ""

    result      = scan_text(text, use_spacy=use_spacy, use_ml=use_ml,
                            min_confidence=min_conf)
    detections  = result["detections"]
    highlighted = _highlight_html(text, detections)
    df          = _detections_df(detections)
    summary     = _summary_html(result)
    redacted    = result.get("redacted_text", text)

    return highlighted, df, summary, redacted


# ─────────────────────────────────────────────────────────────────
#  Tab 2: File Scan
# ─────────────────────────────────────────────────────────────────

def process_file(file_obj, file_path_str: str,
                 use_spacy: bool, use_ml: bool, min_conf: str):
    path = None

    if file_obj is not None:
        path = file_obj.name
    elif file_path_str.strip():
        path = file_path_str.strip()

    if not path:
        return "<i>Upload a file or enter a path.</i>", pd.DataFrame(), ""

    if not Path(path).exists():
        return f"<i>File not found: {path}</i>", pd.DataFrame(), ""

    result     = scan_file(path, use_spacy=use_spacy, use_ml=use_ml,
                           min_confidence=min_conf)
    detections = result.get("detections", [])
    summary    = _summary_html(result)

    # Build line-by-line table
    line_results = result.get("line_results", [])
    rows = []
    for lr in line_results:
        if not lr["detections"]:
            continue
        for d in lr["detections"]:
            rows.append({
                "Line":       lr["line_no"],
                "Label":      d["label"],
                "Value":      d["text"],
                "Severity":   SEVERITY_EMOJI.get(d.get("severity",""), "") + " " + d.get("severity",""),
                "Confidence": d.get("final_confidence", ""),
                "Context":    d.get("context", "")[:60] + "...",
            })

    df = pd.DataFrame(rows) if rows else pd.DataFrame(
        columns=["Line","Label","Value","Severity","Confidence","Context"]
    )

    # Save HTML report
    from ui.report_generator import generate_file_report
    report_path = Path(path).parent / f"{Path(path).stem}_pii_report.html"
    generate_file_report(result, str(report_path))

    return summary, df, f"✅ HTML report saved: {report_path}"


# ─────────────────────────────────────────────────────────────────
#  Tab 3: Folder Scan
# ─────────────────────────────────────────────────────────────────

def process_folder(folder_path: str, extensions: str,
                   use_spacy: bool, use_ml: bool, min_conf: str):
    if not folder_path.strip():
        return "<i>Enter a folder path above.</i>", pd.DataFrame(), ""

    exts = [e.strip() for e in extensions.split(",") if e.strip()]
    if not exts:
        exts = [".txt", ".log", ".csv", ".json", ".xml", ".md"]

    result = scan_folder(folder_path.strip(), extensions=exts,
                         use_spacy=use_spacy, use_ml=use_ml,
                         min_confidence=min_conf)

    if "error" in result:
        return f"<i>{result['error']}</i>", pd.DataFrame(), ""

    file_results = result.get("file_results", {})

    rows = []
    for fpath, fres in file_results.items():
        for d in fres.get("detections", []):
            rows.append({
                "File":       Path(fpath).name,
                "Line":       d.get("line_no", ""),
                "Label":      d["label"],
                "Value":      d["text"],
                "Severity":   SEVERITY_EMOJI.get(d.get("severity",""), "") + " " + d.get("severity",""),
                "Confidence": d.get("final_confidence", ""),
            })

    df = pd.DataFrame(rows) if rows else pd.DataFrame(
        columns=["File","Line","Label","Value","Severity","Confidence"]
    )

    # Folder summary
    total_pii   = result["total_pii"]
    files_count = result["files_scanned"]
    all_labels  = Counter(r["Label"] for r in rows)
    badge_html  = " ".join(
        f'<span style="background:{LABEL_COLORS.get(lbl,"#aaa")};padding:2px 8px;'
        f'border-radius:4px;font-size:0.8rem;font-weight:600;color:#0f1117">'
        f'{lbl} ({cnt})</span>'
        for lbl, cnt in sorted(all_labels.items(), key=lambda x: -x[1])
    )
    summary_html = (
        f'<div style="background:#1e2230;border-radius:8px;padding:14px 18px">'
        f'<div style="font-size:1rem;color:#f8fafc;margin-bottom:8px">'
        f'📁 <b>{files_count}</b> files scanned — '
        f'<b style="color:#fb923c">{total_pii}</b> PII items found</div>'
        f'<div>{badge_html}</div></div>'
    )

    return summary_html, df, f"Scanned {files_count} files in {folder_path}"


# ─────────────────────────────────────────────────────────────────
#  Tab 4: Accuracy Evaluation
# ─────────────────────────────────────────────────────────────────

def run_accuracy(use_spacy: bool, use_ml: bool):
    from tests.accuracy import evaluate, generate_accuracy_report

    metrics = evaluate(use_spacy=use_spacy, use_ml=use_ml, verbose=False)
    ov = metrics["overall"]

    # Per-label table
    rows = []
    for lbl, m in sorted(metrics["per_label"].items(), key=lambda x: -x[1]["f1"]):
        rows.append({
            "Label":     lbl,
            "Precision": f'{m["precision"]:.0%}',
            "Recall":    f'{m["recall"]:.0%}',
            "F1":        f'{m["f1"]:.0%}',
            "TP": m["TP"], "FP": m["FP"], "FN": m["FN"],
        })
    df = pd.DataFrame(rows)

    # Overall card
    def badge(v):
        c = "#20C997" if v >= 0.8 else ("#F59F00" if v >= 0.5 else "#F06595")
        return f'<span style="color:{c};font-weight:700;font-size:1.1rem">{v:.1%}</span>'

    dist = metrics["confidence_dist"]
    html = (
        f'<div style="background:#1e2230;border-radius:10px;padding:18px 22px">'
        f'<div style="font-size:1.1rem;color:#f8fafc;margin-bottom:12px">'
        f'📊 Accuracy Results — {metrics["n_passed"]}/{metrics["n_test_cases"]} cases passed</div>'
        f'<table style="border-collapse:collapse;width:340px">'
        f'<tr><td style="color:#94a3b8;padding:4px 12px">Precision</td>'
        f'<td style="padding:4px 12px">{badge(ov["precision"])}</td></tr>'
        f'<tr><td style="color:#94a3b8;padding:4px 12px">Recall</td>'
        f'<td style="padding:4px 12px">{badge(ov["recall"])}</td></tr>'
        f'<tr><td style="color:#94a3b8;padding:4px 12px">F1 Score</td>'
        f'<td style="padding:4px 12px">{badge(ov["f1"])}</td></tr>'
        f'<tr><td style="color:#94a3b8;padding:4px 12px">TP / FP / FN</td>'
        f'<td style="padding:4px 12px;color:#e2e8f0">'
        f'{ov["total_tp"]} / <span style="color:#F59F00">{ov["total_fp"]}</span> / '
        f'<span style="color:#F06595">{ov["total_fn"]}</span></td></tr>'
        f'<tr><td style="color:#94a3b8;padding:4px 12px">Confidence</td>'
        f'<td style="padding:4px 12px;font-size:0.85rem;color:#e2e8f0">'
        f'HIGH:{dist.get("HIGH",0)} MED:{dist.get("MEDIUM",0)} LOW:{dist.get("LOW",0)}</td></tr>'
        f'</table></div>'
    )

    report_path = ROOT / "reports" / "accuracy_report.html"
    report_path.parent.mkdir(exist_ok=True)
    generate_accuracy_report(metrics, str(report_path))

    return html, df, f"✅ Full report saved: {report_path}"


# ─────────────────────────────────────────────────────────────────
#  Build Gradio UI
# ─────────────────────────────────────────────────────────────────

SHARED_OPTIONS = lambda: [
    gr.Checkbox(label="Use spaCy NER (names/locations)", value=True),
    gr.Checkbox(label="Use ML Classifier", value=True),
    gr.Dropdown(["LOW", "MEDIUM", "HIGH"], value="LOW",
                label="Minimum confidence threshold"),
]

CSS = """
.gradio-container { background: #0f1117 !important; }
.tab-nav button { color: #94a3b8 !important; }
.tab-nav button.selected { color: #f8fafc !important; }
footer { display: none !important; }
"""

with gr.Blocks(title="PII Detector", css=CSS, theme=gr.themes.Base()) as demo:

    gr.Markdown("""
# 🔍 PII Detection Solution
**Regex + ML Hybrid** · Region: UK · Jersey · Geneva · Monaco · EU
Based on your PII definition document. Detects 20+ PII types with confidence scoring.
""")

    with gr.Tabs():

        # ── TAB 1: Text ───────────────────────────────────────────
        with gr.Tab("📝 Text Input"):
            with gr.Row():
                with gr.Column(scale=2):
                    txt_input = gr.Textbox(
                        label="Paste or type text",
                        placeholder="Enter any text containing potential PII...",
                        lines=8
                    )
                    with gr.Row():
                        txt_spacy = gr.Checkbox(label="spaCy NER", value=True)
                        txt_ml    = gr.Checkbox(label="ML Classifier", value=True)
                        txt_conf  = gr.Dropdown(["LOW","MEDIUM","HIGH"], value="LOW",
                                                label="Min confidence")
                    txt_btn = gr.Button("🔍 Scan Text", variant="primary")

                with gr.Column(scale=1):
                    txt_summary = gr.HTML(label="Summary")

            txt_highlight = gr.HTML(label="Highlighted Text")
            txt_df        = gr.Dataframe(label="Detections", wrap=True)
            txt_redacted  = gr.Textbox(label="Redacted Text", lines=4)

            txt_btn.click(
                process_text,
                inputs=[txt_input, txt_spacy, txt_ml, txt_conf],
                outputs=[txt_highlight, txt_df, txt_summary, txt_redacted]
            )

            gr.Examples(
                examples=[
                    ["Customer NI number AB123456C email john@test.co.uk DOB 15/08/1985 phone 07911123456.", True, True, "LOW"],
                    ["IBAN GB29NWBK60161331926819 sort code 20-00-00 account 12345678 for bank transfer.", True, True, "LOW"],
                    ["Login from IP 192.168.1.105 for user pierre.dupont@banque.fr CVV: 456.", True, True, "LOW"],
                    ["System health check passed. All 1024 records processed. No errors.", True, True, "LOW"],
                ],
                inputs=[txt_input, txt_spacy, txt_ml, txt_conf],
                label="Example inputs"
            )

        # ── TAB 2: File ───────────────────────────────────────────
        with gr.Tab("📄 File Scan"):
            with gr.Row():
                with gr.Column():
                    file_upload  = gr.File(label="Upload file", file_types=[".txt",".log",".csv",".json",".md",".xml"])
                    file_path_in = gr.Textbox(label="Or enter file path", placeholder="/path/to/your/file.log")
                    with gr.Row():
                        file_spacy = gr.Checkbox(label="spaCy NER", value=True)
                        file_ml    = gr.Checkbox(label="ML Classifier", value=True)
                        file_conf  = gr.Dropdown(["LOW","MEDIUM","HIGH"], value="LOW", label="Min confidence")
                    file_btn = gr.Button("🔍 Scan File", variant="primary")

            file_summary = gr.HTML(label="Summary")
            file_df      = gr.Dataframe(label="PII Found (per line)", wrap=True)
            file_status  = gr.Textbox(label="Status")

            file_btn.click(
                process_file,
                inputs=[file_upload, file_path_in, file_spacy, file_ml, file_conf],
                outputs=[file_summary, file_df, file_status]
            )

        # ── TAB 3: Folder ─────────────────────────────────────────
        with gr.Tab("📁 Folder Scan"):
            folder_path = gr.Textbox(label="Folder path", placeholder="/path/to/logs/")
            with gr.Row():
                folder_exts  = gr.Textbox(label="File extensions (comma-separated)",
                                          value=".txt,.log,.csv,.json,.xml,.md")
                folder_spacy = gr.Checkbox(label="spaCy NER", value=True)
                folder_ml    = gr.Checkbox(label="ML Classifier", value=True)
                folder_conf  = gr.Dropdown(["LOW","MEDIUM","HIGH"], value="LOW", label="Min confidence")
            folder_btn = gr.Button("🔍 Scan Folder", variant="primary")

            folder_summary = gr.HTML(label="Summary")
            folder_df      = gr.Dataframe(label="All PII Found", wrap=True)
            folder_status  = gr.Textbox(label="Status")

            folder_btn.click(
                process_folder,
                inputs=[folder_path, folder_exts, folder_spacy, folder_ml, folder_conf],
                outputs=[folder_summary, folder_df, folder_status]
            )

        # ── TAB 5: Feedback & Online Learning ─────────────────────
        with gr.Tab("🧠 Feedback & Learning"):
            gr.Markdown("""
### Flag False Positives — Train the Veto Classifier
When the scanner incorrectly flags something as PII, record it here.
The **veto classifier** updates *immediately* with each submission and will
suppress similar false positives in future scans — no full retraining needed.

After collecting **50+ feedback samples**, use the retrain button below
to bake all corrections into the full ensemble model permanently.
""")
            with gr.Row():
                with gr.Column():
                    fb_value   = gr.Textbox(label="Detected Value", placeholder="e.g. 7472 Getting Product")
                    fb_label   = gr.Textbox(label="Predicted Label", placeholder="e.g. HOME_ADDRESS")
                    fb_context = gr.Textbox(label="Context (optional)", placeholder="Paste the surrounding log line", lines=2)
                    fb_type    = gr.Radio(
                        choices=["False Positive (FP)", "True Positive (TP — correct)"],
                        value="False Positive (FP)",
                        label="Was this detection correct?"
                    )
                    fb_btn    = gr.Button("📩 Submit Feedback", variant="primary")
                    fb_status = gr.Markdown()

                with gr.Column():
                    gr.Markdown("### Feedback Summary")
                    fb_summary_btn = gr.Button("🔄 Refresh Summary")
                    fb_summary_out = gr.Markdown()

            gr.Markdown("---")
            gr.Markdown("### Retrain Ensemble With All Feedback")
            gr.Markdown(
                "Incorporates all recorded FPs/TPs into the training data and retrains "
                "the full 4-model ensemble + stacker. Recommended after 50+ feedback entries."
            )
            with gr.Row():
                retrain_samples = gr.Slider(1000, 10000, value=5000, step=500,
                                            label="Base training samples")
                retrain_btn     = gr.Button("🔁 Retrain Ensemble", variant="secondary")
            retrain_status = gr.Markdown()

            def do_retrain(n_samples):
                try:
                    from models.ensemble_model import load_ensemble
                    ensemble = load_ensemble()
                    ensemble.retrain_from_feedback(n_base_samples=int(n_samples), verbose=True)
                    return "✅ Ensemble retrained successfully with all feedback incorporated."
                except Exception as e:
                    return f"❌ Retrain failed: {e}"

            fb_btn.click(
                record_feedback,
                inputs=[fb_value, fb_label, fb_type, fb_context],
                outputs=[fb_status]
            )
            fb_summary_btn.click(get_feedback_summary, outputs=[fb_summary_out])
            retrain_btn.click(do_retrain, inputs=[retrain_samples], outputs=[retrain_status])


        with gr.Tab("📊 Accuracy Evaluation"):
            gr.Markdown("""
### Run accuracy evaluation against European ground-truth test cases
Tests 50+ labelled cases covering UK · Jersey · Geneva · Monaco · EU PII types.
Computes **Precision, Recall, F1** per label and overall.
""")
            with gr.Row():
                acc_spacy = gr.Checkbox(label="Use spaCy NER", value=True)
                acc_ml    = gr.Checkbox(label="Use ML Classifier", value=True)
            acc_btn = gr.Button("▶ Run Accuracy Evaluation", variant="primary")

            acc_summary = gr.HTML(label="Overall Metrics")
            acc_df      = gr.Dataframe(label="Per-Label Metrics", wrap=True)
            acc_status  = gr.Textbox(label="Report")

            acc_btn.click(
                run_accuracy,
                inputs=[acc_spacy, acc_ml],
                outputs=[acc_summary, acc_df, acc_status]
            )

if __name__ == "__main__":
    # Train ensemble model on first run if not already trained
    from models.ensemble_model import ENSEMBLE_PATH, EnsembleModel
    if not ENSEMBLE_PATH.exists():
        print("[SETUP] Training Ensemble ML model (first run, ~2 minutes)...")
        m = EnsembleModel()
        m.train(n_samples=5000, verbose=True)
    # Also train legacy model as fallback
    from models.ml_model import MODEL_PATH
    if not MODEL_PATH.exists():
        print("[SETUP] Training legacy ML model as fallback...")
        from models.ml_model import train
        train(n_samples=3000, verbose=False)

    demo.launch(
        server_name="0.0.0.0",
        server_port=7860,
        share=False,
        inbrowser=True
    )
