"""
Flask Application — PII Scanner
"""

import os
import json
import tempfile
import shutil
from pathlib import Path
from flask import Flask, request, jsonify, render_template, send_file

from app.folder_scanner import scan_folder
from app.pii_detector import detect_pii, get_risk_summary, anonymize_text

app = Flask(__name__, template_folder="../templates", static_folder="../static")
app.config["MAX_CONTENT_LENGTH"] = 200 * 1024 * 1024  # 200 MB upload limit


# ── Routes ──────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/scan/folder", methods=["POST"])
def api_scan_folder():
    """Scan a server-side folder path."""
    data = request.get_json(silent=True) or {}
    folder_path = data.get("folder_path", "").strip()
    if not folder_path:
        return jsonify({"error": "folder_path is required"}), 400
    try:
        result = scan_folder(
            folder_path=folder_path,
            use_presidio=data.get("use_presidio", False),
            use_spacy=data.get("use_spacy", False),
            use_regex=data.get("use_regex", True),
            min_score=float(data.get("min_score", 0.5)),
            recursive=data.get("recursive", True),
        )
        return jsonify(result)
    except FileNotFoundError as e:
        return jsonify({"error": str(e)}), 404
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/scan/upload", methods=["POST"])
def api_scan_upload():
    """Upload log files, scan them, return results."""
    if "files" not in request.files:
        return jsonify({"error": "No files uploaded"}), 400

    uploaded = request.files.getlist("files")
    use_presidio = request.form.get("use_presidio", "false").lower() == "true"
    use_spacy    = request.form.get("use_spacy",    "false").lower() == "true"
    use_regex    = request.form.get("use_regex",    "true" ).lower() == "true"
    min_score    = float(request.form.get("min_score", "0.5"))

    tmpdir = tempfile.mkdtemp()
    try:
        for f in uploaded:
            if f.filename:
                safe_name = Path(f.filename).name
                f.save(os.path.join(tmpdir, safe_name))

        result = scan_folder(
            folder_path=tmpdir,
            use_presidio=use_presidio,
            use_spacy=use_spacy,
            use_regex=use_regex,
            min_score=min_score,
            recursive=False,
        )
        result["folder"] = "uploaded_files"
        return jsonify(result)
    finally:
        shutil.rmtree(tmpdir, ignore_errors=True)


@app.route("/api/scan/text", methods=["POST"])
def api_scan_text():
    """Scan a raw text snippet."""
    data = request.get_json(silent=True) or {}
    text = data.get("text", "")
    if not text:
        return jsonify({"error": "text is required"}), 400
    matches = detect_pii(
        text,
        use_presidio=data.get("use_presidio", False),
        use_spacy=data.get("use_spacy", False),
        use_regex=data.get("use_regex", True),
        min_score=float(data.get("min_score", 0.5)),
    )
    summary = get_risk_summary(matches, filename="<inline>")
    summary["anonymized"] = anonymize_text(text, matches)
    return jsonify(summary)


@app.route("/api/health")
def health():
    return jsonify({"status": "ok"})


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
