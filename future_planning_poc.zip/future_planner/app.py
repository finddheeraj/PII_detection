from flask import Flask, render_template, request, jsonify, session
import json
import random
from datetime import datetime, timedelta
import uuid

app = Flask(__name__)
app.secret_key = "barclays-future-planner-poc"

# ─── Mock Data ────────────────────────────────────────────────────────────────

MOCK_CALENDAR_SLOTS = [
    {"id": "s1", "label": "09:15 – 09:30", "duration": 15, "type": "short",  "time": "09:15"},
    {"id": "s2", "label": "10:45 – 11:15", "duration": 30, "type": "medium", "time": "10:45"},
    {"id": "s3", "label": "12:00 – 12:45", "duration": 45, "type": "long",   "time": "12:00"},
    {"id": "s4", "label": "14:00 – 14:10", "duration": 10, "type": "short",  "time": "14:00"},
    {"id": "s5", "label": "15:30 – 16:15", "duration": 45, "type": "long",   "time": "15:30"},
    {"id": "s6", "label": "16:45 – 17:00", "duration": 15, "type": "short",  "time": "16:45"},
]

MOCK_ACTIONS = [
    {
        "id": "a1", "task": "Send KYC reminder to Ananya Sharma",
        "client": "Ananya Sharma", "estimated_minutes": 10,
        "effort": "low", "urgency": 9, "value": 7,
        "tags": ["compliance", "KYC"], "due": "Today",
        "type": "follow-up"
    },
    {
        "id": "a2", "task": "Review portfolio rebalancing proposal – Mehta Family Office",
        "client": "Mehta Family Office", "estimated_minutes": 40,
        "effort": "high", "urgency": 6, "value": 10,
        "tags": ["investment", "proposal"], "due": "Tomorrow",
        "type": "investment"
    },
    {
        "id": "a3", "task": "Approve offshore bond transfer documentation",
        "client": "Chen Wei", "estimated_minutes": 20,
        "effort": "medium", "urgency": 8, "value": 8,
        "tags": ["compliance", "approval"], "due": "Today",
        "type": "approval"
    },
    {
        "id": "a4", "task": "Draft investment memo – Gupta Holdings ESG fund",
        "client": "Gupta Holdings", "estimated_minutes": 50,
        "effort": "high", "urgency": 5, "value": 9,
        "tags": ["investment", "ESG"], "due": "This week",
        "type": "investment"
    },
    {
        "id": "a5", "task": "Send meeting follow-up notes to Al-Rashid family",
        "client": "Al-Rashid Family", "estimated_minutes": 12,
        "effort": "low", "urgency": 7, "value": 6,
        "tags": ["relationship", "follow-up"], "due": "Today",
        "type": "follow-up"
    },
    {
        "id": "a6", "task": "Prepare tailored FX hedging proposal – Nakamura Corp",
        "client": "Nakamura Corp", "estimated_minutes": 45,
        "effort": "high", "urgency": 7, "value": 10,
        "tags": ["investment", "FX"], "due": "Tomorrow",
        "type": "investment"
    },
    {
        "id": "a7", "task": "Confirm R&C sign-off on Patel trust restructure",
        "client": "Patel Trust", "estimated_minutes": 8,
        "effort": "low", "urgency": 10, "value": 8,
        "tags": ["compliance", "R&C"], "due": "Today",
        "type": "compliance"
    },
    {
        "id": "a8", "task": "Call to check in with Okonkwo re: philanthropy goals",
        "client": "James Okonkwo", "estimated_minutes": 30,
        "effort": "medium", "urgency": 4, "value": 7,
        "tags": ["relationship"], "due": "This week",
        "type": "relationship"
    },
]

TAG_COLORS = {
    "compliance": "#ef4444",
    "KYC":        "#f97316",
    "R&C":        "#ef4444",
    "approval":   "#f97316",
    "investment": "#3b82f6",
    "ESG":        "#22c55e",
    "proposal":   "#6366f1",
    "FX":         "#8b5cf6",
    "follow-up":  "#06b6d4",
    "relationship":"#14b8a6",
}

# ─── AI Scoring (rule-assisted + AI explanation via Anthropic) ─────────────

def score_action(action):
    """Hybrid scoring: deterministic urgency/value + effort weighting."""
    urgency = action["urgency"]
    value   = action["value"]
    effort_penalty = {"low": 0, "medium": -0.5, "high": -1.5}[action["effort"]]
    compliance_boost = 2 if any(t in ["compliance","R&C","KYC"] for t in action["tags"]) else 0
    score = (urgency * 0.5) + (value * 0.35) + effort_penalty + compliance_boost
    return round(score, 2)

def match_actions_to_slot(slot, actions, rejected_ids=None, snoozed_ids=None):
    """Rule-based slot matching + score ranking."""
    rejected_ids = rejected_ids or []
    snoozed_ids  = snoozed_ids  or []
    slot_min = slot["duration"]

    eligible = [
        a for a in actions
        if a["id"] not in rejected_ids
        and a["id"] not in snoozed_ids
        and a["estimated_minutes"] <= slot_min + 5  # slight buffer
    ]

    scored = sorted(eligible, key=score_action, reverse=True)
    return scored[:3]  # top 3 per slot

# ─── Routes ────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/api/slots")
def get_slots():
    return jsonify(MOCK_CALENDAR_SLOTS)

@app.route("/api/suggestions")
def get_suggestions():
    rejected = session.get("rejected", [])
    snoozed  = session.get("snoozed",  [])

    result = []
    for slot in MOCK_CALENDAR_SLOTS:
        matched = match_actions_to_slot(slot, MOCK_ACTIONS, rejected, snoozed)
        if matched:
            top = matched[0]
            result.append({
                "slot": slot,
                "action": top,
                "score": score_action(top),
                "alternatives": [{"id": a["id"], "task": a["task"]} for a in matched[1:]],
            })
    return jsonify(result)

@app.route("/api/explain", methods=["POST"])
def explain():
    """Call Anthropic API to generate a natural-language reason for a suggestion."""
    data   = request.json
    action = data.get("action", {})
    slot   = data.get("slot", {})

    prompt = f"""You are an intelligent assistant for a private banker at Barclays Wealth.

Given this available calendar slot and suggested action, write a SHORT (2 sentences max), compelling reason why this action is the best use of this time. Be specific, professional, and concise. No filler words.

Slot: {slot.get('label')} ({slot.get('duration')} minutes, {slot.get('type')} slot)
Action: {action.get('task')}
Client: {action.get('client')}
Tags: {', '.join(action.get('tags', []))}
Urgency score: {action.get('urgency')}/10
Client value score: {action.get('value')}/10
Effort: {action.get('effort')}
Due: {action.get('due')}

Respond with ONLY the reason. No preamble."""

    return jsonify({"prompt": prompt, "action_id": action.get("id"), "slot_id": slot.get("id")})

@app.route("/api/accept", methods=["POST"])
def accept():
    data = request.json
    action_id = data.get("action_id")
    slot_id   = data.get("slot_id")
    # In real app: write to Outlook calendar, update learning model
    accepted = session.get("accepted", [])
    accepted.append({"action_id": action_id, "slot_id": slot_id, "ts": datetime.now().isoformat()})
    session["accepted"] = accepted
    return jsonify({"status": "accepted", "message": "Task scheduled in your Outlook calendar."})

@app.route("/api/reject", methods=["POST"])
def reject():
    data = request.json
    action_id = data.get("action_id")
    rejected = session.get("rejected", [])
    rejected.append(action_id)
    session["rejected"] = rejected
    return jsonify({"status": "rejected"})

@app.route("/api/snooze", methods=["POST"])
def snooze():
    data = request.json
    action_id = data.get("action_id")
    snoozed = session.get("snoozed", [])
    snoozed.append(action_id)
    session["snoozed"] = snoozed
    return jsonify({"status": "snoozed"})

@app.route("/api/reshuffle", methods=["POST"])
def reshuffle():
    """Reshuffle suggestions for a specific slot."""
    data      = request.json
    slot_id   = data.get("slot_id")
    rejected  = session.get("rejected", [])
    snoozed   = session.get("snoozed",  [])

    slot = next((s for s in MOCK_CALENDAR_SLOTS if s["id"] == slot_id), None)
    if not slot:
        return jsonify({"error": "Slot not found"}), 404

    matched = match_actions_to_slot(slot, MOCK_ACTIONS, rejected, snoozed)
    if len(matched) > 1:
        # rotate top suggestion to end → surface next best
        matched = matched[1:] + matched[:1]

    if not matched:
        return jsonify({"action": None})

    top = matched[0]
    return jsonify({
        "action": top,
        "score": score_action(top),
        "alternatives": [{"id": a["id"], "task": a["task"]} for a in matched[1:]],
    })

@app.route("/api/reset", methods=["POST"])
def reset():
    session.clear()
    return jsonify({"status": "reset"})

@app.route("/api/learning_summary")
def learning_summary():
    accepted = session.get("accepted", [])
    rejected = session.get("rejected", [])
    snoozed  = session.get("snoozed",  [])
    return jsonify({
        "accepted_count": len(accepted),
        "rejected_count": len(rejected),
        "snoozed_count":  len(snoozed),
        "accepted": accepted,
    })

if __name__ == "__main__":
    app.run(debug=True, port=5050)
