# Future Planning Tool – POC
## Smart Action List | Sub-requirement 7

A Flask-based proof-of-concept for the Future Planning Tool component of the Barclays Smart Action List.

---

## Architecture

```
┌─────────────────────────────────────────────────────────┐
│  Outlook Calendar API (mocked)                          │
│  → Slot classification: short / medium / long           │
└────────────────────┬────────────────────────────────────┘
                     │
┌────────────────────▼────────────────────────────────────┐
│  Rule Engine (Flask backend)                            │
│  • Slot bucket matching (≤15 / 15-45 / ≥45 min)        │
│  • Compliance floor (R&C/KYC always surfaced first)     │
│  • Effort-to-slot matching                              │
└────────────────────┬────────────────────────────────────┘
                     │
┌────────────────────▼────────────────────────────────────┐
│  AI Scoring Layer                                       │
│  • Urgency × 0.5 + Value × 0.35 + Effort penalty       │
│  • Compliance boost (+2) for R&C/KYC items             │
│  • AI explanation via Anthropic Claude API              │
└────────────────────┬────────────────────────────────────┘
                     │
┌────────────────────▼────────────────────────────────────┐
│  Session-based Learning Loop                            │
│  • Accept / Reject / Snooze tracking                    │
│  • Reshuffle (surfaces next-best alternative)           │
└─────────────────────────────────────────────────────────┘
```

---

## Requirements covered by this POC

| User Story ID | Description | Implementation |
|---|---|---|
| 1 | Future planning view | Main dashboard view |
| 2-5 | Enable/disable toggle | Sidebar toggle (per slot type) |
| 8 | Calendar integration | Mocked Outlook slots |
| 9-11 | Micro-slot detection & classification | Rule-based (short/medium/long) |
| 12-15 | Task-slot matching | Effort-to-slot matching rules |
| 16-17 | Urgency & time-effort scoring | Scoring formula in backend |
| 18 | Ranking logic | Score-sorted suggestions |
| 19-23 | Suggestion display & content | Cards with task/client/duration/reason |
| 24 | Reason for recommendation | Claude AI explanation on demand |
| 25 | Calendar booking on accept | Accept → session record |
| 26 | Reject | Reject → removes from suggestions |
| 27 | Snooze | Snooze → hides temporarily |
| 28-30 | Reshuffle | Surfaces next-best action per slot |
| 31-32 | Learning loop | Accept/reject session tracking |
| 34 | Compliance safeguard | Compliance boost + compliance bar |
| 35 | No auto-booking | Only books on explicit accept |
| 36-38 | Error handling & privacy | Error fallback; no calendar content exposed |

---

## Setup

```bash
pip install flask
python app.py
# → http://localhost:5050
```

---

## Notes for production

- Replace mock calendar slots with **Microsoft Graph API** (Outlook)
- Replace mock actions with **Smart Action List database**
- Replace session storage with **persistent user preferences DB**
- AI explanation calls go server-side (not client-side) with proper API key management
- Learning loop should feed into **ML retraining pipeline** over time
