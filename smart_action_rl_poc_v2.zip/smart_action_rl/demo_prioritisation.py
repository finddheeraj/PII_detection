"""
demo_prioritisation.py  (v2)
------------------------------
Demonstrates all v2 fixes and improvements to the RL engine.
Runs WITHOUT Bedrock by using the deterministic fallback scorer.

Run:  python demo_prioritisation.py
"""

import sys, os
sys.path.insert(0, os.path.dirname(__file__))

# Patch: bypass Bedrock so demo runs anywhere
import app.services.prioritisation_service as ps
ps.score_with_llm = lambda action, ref_date: ps._fallback_score(action, ref_date)

from app.models.schemas import ConfirmedAction, Priority, Category, ActionStatus, ActionState
from app.services.prioritisation_service import PrioritisationService
import uuid

# ── Helpers ───────────────────────────────────────────────────────────────────

def make(title, category, due=None, priority=Priority.MEDIUM):
    return ConfirmedAction(
        id=str(uuid.uuid4()), title=title, description=f"Action: {title}",
        client="Sharma Family Office", due_date=due, priority=priority,
        category=category, status=ActionStatus.NOT_STARTED,
        state=ActionState.CONFIRMED, emoji="📋", source_quote="",
        confirmed_at="2026-03-24T10:00:00+00:00",
    )

def print_ranked(ranked, label):
    print(f"\n{'='*65}")
    print(f"  {label}")
    print(f"{'='*65}")
    for i, pa in enumerate(ranked, 1):
        rule = "🔒 RULE" if pa.hard_rule_fired else f"🤖 LLM={pa.llm_score}"
        adj  = f"  RL:{pa.rl_adjustment:+.2f}" if pa.rl_adjustment is not None else ""
        conf = f"  conf={pa.confidence:.2f}"
        print(f"  #{i} [{pa.final_score:5.1f}] {pa.computed_priority:<6} | {rule:<12}{adj}{conf}")
        print(f"     {pa.action.title}")

def sep(label): print(f"\n--- {label} ---")

# ── Actions ───────────────────────────────────────────────────────────────────

actions = [
    make("File FATCA declaration",        Category.RISK_CONTROL,  "2026-03-28"),  # R&C: hard rule fires
    make("Review AML quarterly report",   Category.RISK_CONTROL,  "2026-06-01"),  # R&C: future, LLM scores
    make("Present Q1 portfolio review",   Category.COMMERCIAL,    "2026-04-05"),
    make("Follow up on ESG mandate",      Category.COMMERCIAL),
    make("Send birthday note to client",  Category.RELATIONSHIP,  "2026-03-25"),
    make("Update CRM contact details",    Category.PERSONAL),
]

svc = PrioritisationService(reference_date="2026-03-24")

# ── DAY 1: No data ────────────────────────────────────────────────────────────

ranked1 = svc.rank(actions, banker_id="chauradh")
print_ranked(ranked1, "DAY 1 — Zero RL data (cold start)")

# ── DAY 1 Feedback ────────────────────────────────────────────────────────────

sep("Banker 'chauradh' interactions — Day 1")

# FIX 1 DEMO: hard-rule R&C action — feedback now correctly updates R&C::High arm
svc.feedback(ranked1[0], "completed", banker_id="chauradh")
print(f"  ✅ Completed: '{ranked1[0].action.title}' (hard-rule action — v2 fix: R&C arm now learns)")

svc.feedback(ranked1[4], "dismissed", banker_id="chauradh")
print(f"  ❌ Dismissed: '{ranked1[4].action.title}'")

svc.feedback(ranked1[2], "clicked", banker_id="chauradh")
print(f"  👆 Clicked:   '{ranked1[2].action.title}'")

# ── DAY 2: RL adjusting ───────────────────────────────────────────────────────

ranked2 = svc.rank(actions, banker_id="chauradh")
print_ranked(ranked2, "DAY 2 — After feedback (RL adjusting, confidence growing)")

sep("Banker 'chauradh' interactions — Day 2")
svc.feedback(ranked2[0], "completed", banker_id="chauradh")   # FATCA done again
svc.feedback(ranked2[1], "completed", banker_id="chauradh")   # AML done
svc.feedback(ranked2[5], "snoozed",   banker_id="chauradh")   # CRM snoozed
svc.feedback(ranked2[3], "clicked",   banker_id="chauradh")   # ESG clicked
print("  Multiple interactions recorded...")

# ── DAY 3: Accumulated learning ───────────────────────────────────────────────

ranked3 = svc.rank(actions, banker_id="chauradh")
print_ranked(ranked3, "DAY 3 — Accumulated RL Learning")

# FIX 2 DEMO: avg_reward uses decayed mean — show it doesn't blow up
sep("FIX 2 DEMO: Decayed mean stays bounded after many signals")
for _ in range(10):
    svc.feedback(ranked3[0], "completed", banker_id="chauradh")
stats = svc.get_rl_stats()
rc_arm = next((v for k,v in stats["arms"].items() if "Risk & Control::High" in k), None)
if rc_arm:
    print(f"  R&C::High after 12 'completed' signals:")
    print(f"    avg_reward = {rc_arm['avg_reward']:.4f}  (decayed, not cumulative sum)")
    print(f"    confidence = {rc_arm['confidence']:.3f}")
    print(f"    rl_adj     = {rc_arm['rl_adj']:+.3f}")

# ── What was learned ──────────────────────────────────────────────────────────

print(f"\n{'='*65}")
print("  WHAT THE RL MODEL LEARNED FOR 'chauradh'")
print(f"{'='*65}")

full_stats = svc.get_rl_stats()
print(f"  Total pulls tracked: {full_stats['total_pulls']}")
print()

for key, v in sorted(full_stats["arms"].items(), key=lambda x: -x[1]["rl_adj"]):
    bar   = "█" * min(abs(round(v["rl_adj"])), 12)
    sign  = "+" if v["rl_adj"] >= 0 else ""
    name  = key.replace("chauradh::", "")
    print(f"  {name:<36} feedback={v['n_feedback']:<3} conf={v['confidence']:.2f}  "
          f"adj={sign}{v['rl_adj']:+.2f}  {bar}")

print()
print("  Key observations:")
print("  → [FIX 1] R&C::High arm has feedback (hard-rule actions now teach the model)")
print("  → [FIX 2] avg_reward is decayed mean, stays in [-1, 1] — no overflow")
print("  → [NEW]   confidence grows with feedback — low conf = uncertain adjustment")
print("  → [NEW]   per-banker_id arms = personalised learning per banker")
print()

# Cleanup
if os.path.exists("rl_bandit_state.json"):
    os.remove("rl_bandit_state.json")
    print("  (demo state cleaned up)")
