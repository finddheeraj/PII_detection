"""
run.py
------
Application entry point.
Run with: python run.py
"""

from app import create_app
from app.config import app_config

app = create_app()

if __name__ == "__main__":
    app.run(
        host=app_config.host,
        port=app_config.port,
        debug=app_config.debug,
    )
