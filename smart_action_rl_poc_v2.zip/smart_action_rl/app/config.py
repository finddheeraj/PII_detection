"""
config.py
---------
Configuration for Smart Action List POC — AWS Bedrock via pbwm_genai_config.
Set these values in your .env file (never hardcode credentials here).
"""

import os
from dataclasses import dataclass


@dataclass
class BedrockConfig:
    aws_region: str = os.getenv("CREDS_DEFAULT_REGION", "eu-west-2")
    model_id: str   = os.getenv("LLM_CHAT_MODEL", "eu.anthropic.claude-sonnet-4-5-20250929-v1:0")
    verify_ssl: str = os.getenv("USER_VERIFY_PEM", "")
    temperature: float = 0.1
    max_tokens: int    = 1024


@dataclass
class AppConfig:
    debug:      bool = os.getenv("FLASK_DEBUG", "true").lower() == "true"
    host:       str  = os.getenv("FLASK_HOST", "0.0.0.0")
    port:       int  = int(os.getenv("FLASK_PORT", "5000"))
    secret_key: str  = os.getenv("SECRET_KEY", "dev-secret-change-in-prod")
    reference_date: str = "2026-03-20"


bedrock_config = BedrockConfig()
app_config     = AppConfig()
