"""
routes/health.py  —  GET /api/health
"""

from flask import Blueprint, jsonify
from app.services.llm_service import LLMService
from app.config import bedrock_config

health_bp = Blueprint("health", __name__, url_prefix="/api")


@health_bp.get("/health")
def health():
    llm = LLMService.get_instance()
    return jsonify({
        "status":       "ok",
        "backend":      "bedrock",
        "model_loaded": llm.is_loaded,
        "model_path":   bedrock_config.model_id,
    }), 200
