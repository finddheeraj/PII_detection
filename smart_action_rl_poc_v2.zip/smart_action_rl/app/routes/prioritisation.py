"""
routes/prioritisation.py  (v2)
--------------------------------
  POST  /api/prioritise            → rank actions (supports banker_id)
  POST  /api/feedback/<action_id>  → record RL signal (works for R&C too)
  GET   /api/rl-stats              → inspect bandit learning state
"""

from __future__ import annotations
import logging

from flask import Blueprint, request, jsonify

from app.services.action_service import action_service
from app.services.prioritisation_service import prioritisation_service

logger = logging.getLogger(__name__)

prioritisation_bp = Blueprint("prioritisation", __name__, url_prefix="/api")


@prioritisation_bp.post("/prioritise")
def prioritise_actions():
    """
    Rank confirmed actions using LLM + RL scoring.

    Request body (all optional):
        {
            "action_ids": ["id1", "id2"],   // default: all confirmed actions
            "banker_id":  "chauradh"        // enables per-banker RL learning
        }

    Response 200:
        {
            "banker_id": "chauradh",
            "ranked_actions": [
                {
                    "action":             { ConfirmedAction },
                    "final_score":        87.3,
                    "llm_score":          82,
                    "rl_adjustment":      +5.3,
                    "computed_priority":  "High",
                    "rationale":          "...",
                    "hard_rule_fired":    false,
                    "confidence":         0.74     // 0-1: how much RL has learned
                }, ...
            ],
            "total": 5
        }
    """
    data       = request.get_json(force=True) or {}
    banker_id  = data.get("banker_id") or None
    action_ids = data.get("action_ids")

    if action_ids:
        actions = [a for a in (action_service.get_by_id(i) for i in action_ids) if a]
    else:
        actions = action_service.get_all()

    if not actions:
        return jsonify({"ranked_actions": [], "total": 0, "banker_id": banker_id}), 200

    ranked = prioritisation_service.rank(actions, banker_id=banker_id)

    return jsonify({
        "banker_id": banker_id,
        "ranked_actions": [
            {
                "action":            pa.action.model_dump(),
                "final_score":       round(pa.final_score, 2),
                "llm_score":         pa.llm_score,
                "rl_adjustment":     pa.rl_adjustment,
                "computed_priority": pa.computed_priority,
                "rationale":         pa.rationale,
                "hard_rule_fired":   pa.hard_rule_fired,
                "confidence":        pa.confidence,
            }
            for pa in ranked
        ],
        "total": len(ranked),
    }), 200


@prioritisation_bp.post("/feedback/<action_id>")
def record_feedback(action_id: str):
    """
    Record banker feedback signal — the RL reward function.

    Request body:
        {
            "signal":    "completed" | "clicked" | "snoozed" | "dismissed",
            "banker_id": "chauradh"   // optional, for per-banker learning
        }

    Works for BOTH hard-rule R&C actions and LLM-scored actions.
    The model updates the correct priority band based on the action's
    last known score, not just the enum value.

    Response 200:
        { "message": "...", "action_id": "...", "signal": "..." }
    """
    data      = request.get_json(force=True) or {}
    signal    = data.get("signal")
    banker_id = data.get("banker_id") or None

    valid = ["completed", "clicked", "snoozed", "dismissed"]
    if signal not in valid:
        return jsonify({"error": f"Invalid signal. Use: {valid}"}), 400

    action = action_service.get_by_id(action_id)
    if not action:
        return jsonify({"error": f"Action {action_id} not found"}), 404

    prioritisation_service.feedback(action, signal, banker_id=banker_id)

    return jsonify({
        "message":   "Feedback recorded. RL model updated.",
        "action_id": action_id,
        "signal":    signal,
        "banker_id": banker_id,
    }), 200


@prioritisation_bp.get("/rl-stats")
def rl_stats():
    """
    View RL bandit arm learning state.

    Query params:
        banker_id = chauradh   // optional filter (shows only that banker's arms)

    Response 200:
        {
            "total_pulls": 42,
            "arms": {
                "Risk & Control::High": {
                    "n_pulls":    12,
                    "n_feedback": 8,
                    "avg_reward": 0.623,
                    "confidence": 0.699,    // 0-1, grows with more feedback
                    "rl_adj":     +4.3
                }, ...
            }
        }
    """
    banker_id = request.args.get("banker_id") or None
    stats     = prioritisation_service.get_rl_stats()

    # Filter by banker_id prefix if supplied
    if banker_id:
        prefix = f"{banker_id}::"
        stats["arms"] = {
            k.replace(prefix, ""): v
            for k, v in stats["arms"].items()
            if k.startswith(prefix)
        }

    return jsonify(stats), 200
