"""
routes/transcript.py
--------------------
POST /api/transcript/analyse
  → Runs the LangGraph agent and returns extracted actions for banker review.
     Nothing is saved to the action store yet — that happens in /api/actions/confirm.
"""

from __future__ import annotations
import logging

from flask import Blueprint, request, jsonify
from pydantic import ValidationError

from app.models.schemas import TranscriptRequest
from app.agents.followup_agent import run_agent

logger = logging.getLogger(__name__)

transcript_bp = Blueprint("transcript", __name__, url_prefix="/api/transcript")


@transcript_bp.post("/analyse")
def analyse_transcript():
    """
    Run AI extraction pipeline on a meeting transcript.

    Request body:
        {
            "transcript": "...",        (required, 50–20000 chars)
            "meeting_ref": "optional"   (optional)
        }

    Response 200:
        {
            "actions": [ ExtractedAction, ... ],
            "agent_log": [ "...", ... ],
            "warnings":  [ "...", ... ],
            "model_used": "llama-local"
        }
    """
    try:
        body = TranscriptRequest(**request.get_json(force=True))
    except (ValidationError, TypeError) as e:
        return jsonify({"error": "Invalid request", "detail": str(e)}), 400

    logger.info(
        f"Analysing transcript ({len(body.transcript)} chars), "
        f"ref={body.meeting_ref}"
    )

    result = run_agent(
        transcript=body.transcript,
        meeting_ref=body.meeting_ref,
    )

    return jsonify(result.model_dump()), 200
