"""
routes/actions.py
-----------------
Action lifecycle endpoints:

  POST   /api/actions/confirm          → Banker confirms one extracted action
  GET    /api/actions                  → Get all confirmed actions (Smart Action List)
  PATCH  /api/actions/<id>/status      → Update action status (started, done, snoozed)
  DELETE /api/actions/<id>             → Delete a manually created action
"""

from __future__ import annotations
import logging

from flask import Blueprint, request, jsonify
from pydantic import ValidationError

from app.models.schemas import (
    ExtractedAction, ConfirmRequest, ActionStatus
)
from app.services.action_service import action_service

logger = logging.getLogger(__name__)

actions_bp = Blueprint("actions", __name__, url_prefix="/api/actions")


@actions_bp.post("/confirm")
def confirm_action():
    """
    Banker confirms a single extracted action (possibly with edits).

    Request body:
        {
            "extracted": { ExtractedAction fields... },
            "edits": { ConfirmRequest fields... },   (optional)
            "meeting_ref": "optional string"
        }

    Response 201:
        { ConfirmedAction }
    """
    data = request.get_json(force=True)

    try:
        extracted = ExtractedAction(**data.get("extracted", {}))
    except (ValidationError, TypeError) as e:
        return jsonify({"error": "Invalid extracted action", "detail": str(e)}), 400

    edits = None
    if data.get("edits"):
        try:
            edits = ConfirmRequest(**data["edits"])
        except (ValidationError, TypeError) as e:
            return jsonify({"error": "Invalid edits", "detail": str(e)}), 400

    # Check for duplicate — expose it but still allow confirmation
    duplicate_of = action_service.exists_similar(
        title=edits.title if (edits and edits.title) else extracted.title,
        client=edits.client if (edits and edits.client) else extracted.client,
    )

    confirmed = action_service.confirm_action(
        extracted=extracted,
        edits=edits,
        meeting_ref=data.get("meeting_ref"),
        duplicate_of=duplicate_of,
    )

    return jsonify(confirmed.model_dump()), 201


@actions_bp.get("")
def get_actions():
    """
    Retrieve the Smart Action List.

    Query params:
        status   = not_started | started | done | snoozed  (optional)
        priority = High | Medium | Low                      (optional)

    Response 200:
        {
            "actions": [ ConfirmedAction, ... ],
            "total": int
        }
    """
    status_raw   = request.args.get("status")
    priority_raw = request.args.get("priority")

    status_filter = None
    if status_raw:
        try:
            status_filter = ActionStatus(status_raw)
        except ValueError:
            return jsonify({"error": f"Invalid status: {status_raw}"}), 400

    actions = action_service.get_all(
        status_filter=status_filter,
        priority_filter=priority_raw,
    )

    return jsonify({
        "actions": [a.model_dump() for a in actions],
        "total":   len(actions),
    }), 200


@actions_bp.patch("/<action_id>/status")
def update_status(action_id: str):
    """
    Update an action's lifecycle status.

    Request body: { "status": "started" | "done" | "snoozed" | "not_started" }

    Response 200: { ConfirmedAction }
    """
    data = request.get_json(force=True)
    status_raw = data.get("status")

    try:
        new_status = ActionStatus(status_raw)
    except (ValueError, TypeError):
        return jsonify({"error": f"Invalid status: {status_raw}"}), 400

    try:
        updated = action_service.update_status(action_id, new_status)
    except KeyError:
        return jsonify({"error": f"Action {action_id} not found"}), 404

    return jsonify(updated.model_dump()), 200


@actions_bp.delete("/<action_id>")
def delete_action(action_id: str):
    """
    Hard delete a manually created action.

    Response 204: No content
    """
    try:
        action_service.delete_action(action_id)
    except KeyError:
        return jsonify({"error": f"Action {action_id} not found"}), 404

    return "", 204
