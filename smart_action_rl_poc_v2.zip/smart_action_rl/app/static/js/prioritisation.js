/**
 * prioritisation.js
 * ------------------
 * Adds smart prioritisation and RL feedback to the Smart Action List.
 *
 * Hooks added:
 *   - "Prioritise Actions" button → POST /api/prioritise
 *   - Action card feedback buttons → POST /api/feedback/<id>
 *   - RL Stats panel → GET /api/rl-stats
 */

// ── API calls ────────────────────────────────────────────────────────────────

async function prioritiseActions() {
    const btn = document.getElementById("btn-prioritise");
    if (btn) { btn.disabled = true; btn.textContent = "Scoring..."; }

    try {
        const resp = await fetch("/api/prioritise", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({})          // ranks all confirmed actions
        });
        const data = await resp.json();
        renderPrioritisedList(data.ranked_actions || []);
    } catch (err) {
        console.error("Prioritisation failed:", err);
        alert("Prioritisation failed: " + err.message);
    } finally {
        if (btn) { btn.disabled = false; btn.textContent = "🧠 Prioritise Actions"; }
    }
}

async function sendFeedback(actionId, signal) {
    try {
        await fetch(`/api/feedback/${actionId}`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ signal })
        });
        console.log(`[RL] Feedback sent: ${signal} for ${actionId}`);
        // Refresh RL stats badge if visible
        if (document.getElementById("rl-stats-panel").style.display !== "none") {
            loadRLStats();
        }
    } catch (err) {
        console.warn("[RL] Feedback failed:", err);
    }
}

async function loadRLStats() {
    try {
        const resp  = await fetch("/api/rl-stats");
        const stats = await resp.json();
        renderRLStats(stats);
    } catch (err) {
        console.warn("RL stats failed:", err);
    }
}

// ── Renderers ────────────────────────────────────────────────────────────────

function renderPrioritisedList(rankedActions) {
    const container = document.getElementById("prioritised-list");
    if (!container) return;

    if (!rankedActions.length) {
        container.innerHTML = "<p style='color:#888'>No confirmed actions to prioritise yet.</p>";
        return;
    }

    container.innerHTML = rankedActions.map((pa, idx) => {
        const a        = pa.action;
        const score    = pa.final_score.toFixed(1);
        const pri      = pa.computed_priority;
        const priColor = pri === "High" ? "#dc3545" : pri === "Medium" ? "#fd7e14" : "#28a745";
        const badge    = pa.hard_rule_fired
            ? `<span style="background:#dc3545;color:#fff;padding:2px 7px;border-radius:4px;font-size:11px;margin-left:6px">🔒 Rule Override</span>`
            : `<span style="background:#0066cc;color:#fff;padding:2px 7px;border-radius:4px;font-size:11px;margin-left:6px">🤖 AI Scored</span>`;

        const rlAdj = pa.rl_adjustment !== null
            ? `<span style="font-size:11px;color:${pa.rl_adjustment >= 0 ? '#28a745' : '#dc3545'}">
                 RL adj: ${pa.rl_adjustment >= 0 ? '+' : ''}${pa.rl_adjustment}
               </span>`
            : "";

        return `
        <div style="border:1px solid #ddd;border-radius:8px;padding:14px;margin-bottom:10px;background:#fff;
                    border-left:4px solid ${priColor}">
            <div style="display:flex;justify-content:space-between;align-items:flex-start">
                <div style="flex:1">
                    <strong style="font-size:15px">#${idx + 1} ${a.emoji || ''} ${a.title}</strong>
                    ${badge}
                    <div style="margin-top:4px;font-size:12px;color:#666">
                        ${a.client} · ${a.category} · Due: ${a.due_date || 'TBD'}
                    </div>
                    <div style="margin-top:6px;font-size:12px;color:#444;font-style:italic">
                        "${pa.rationale}"
                    </div>
                </div>
                <div style="text-align:right;min-width:90px;margin-left:12px">
                    <div style="font-size:22px;font-weight:700;color:${priColor}">${score}</div>
                    <div style="font-size:11px;color:${priColor};font-weight:600">${pri}</div>
                    ${pa.llm_score !== null
                        ? `<div style="font-size:10px;color:#999">LLM: ${pa.llm_score}</div>`
                        : ''}
                    ${rlAdj}
                </div>
            </div>

            <!-- RL Feedback Buttons -->
            <div style="margin-top:10px;display:flex;gap:6px;flex-wrap:wrap">
                <span style="font-size:11px;color:#888;align-self:center">Teach the model:</span>
                <button onclick="handleFeedback('${a.id}', 'completed', this)"
                    style="padding:3px 9px;font-size:11px;background:#28a745;color:#fff;border:none;border-radius:4px;cursor:pointer">
                    ✅ Completed
                </button>
                <button onclick="handleFeedback('${a.id}', 'clicked', this)"
                    style="padding:3px 9px;font-size:11px;background:#0066cc;color:#fff;border:none;border-radius:4px;cursor:pointer">
                    👆 Clicked
                </button>
                <button onclick="handleFeedback('${a.id}', 'snoozed', this)"
                    style="padding:3px 9px;font-size:11px;background:#fd7e14;color:#fff;border:none;border-radius:4px;cursor:pointer">
                    😴 Snoozed
                </button>
                <button onclick="handleFeedback('${a.id}', 'dismissed', this)"
                    style="padding:3px 9px;font-size:11px;background:#6c757d;color:#fff;border:none;border-radius:4px;cursor:pointer">
                    ❌ Dismissed
                </button>
            </div>
        </div>`;
    }).join("");
}

async function handleFeedback(actionId, signal, btn) {
    const original = btn.textContent;
    btn.disabled = true;
    btn.textContent = "✓ Sent!";
    await sendFeedback(actionId, signal);
    setTimeout(() => {
        btn.textContent = original;
        btn.disabled = false;
    }, 1500);
}

function renderRLStats(stats) {
    const panel = document.getElementById("rl-stats-panel");
    if (!panel) return;

    const arms = Object.entries(stats.arms || {});
    if (!arms.length) {
        panel.innerHTML = `<p style='color:#888;font-size:13px'>No interactions recorded yet. 
        Start using feedback buttons to train the model!</p>`;
        return;
    }

    const rows = arms
        .sort((a, b) => b[1].rl_adj - a[1].rl_adj)
        .map(([key, v]) => {
            const adj     = v.rl_adj;
            const adjStr  = `${adj >= 0 ? '+' : ''}${adj.toFixed(2)}`;
            const adjColor = adj >= 0 ? "#28a745" : "#dc3545";
            const bar      = "█".repeat(Math.min(Math.abs(Math.round(adj)), 10));
            return `
            <tr style="border-bottom:1px solid #eee;font-size:12px">
                <td style="padding:5px 8px">${key}</td>
                <td style="padding:5px 8px;text-align:center">${v.pulls}</td>
                <td style="padding:5px 8px;text-align:center">${v.avg_reward.toFixed(3)}</td>
                <td style="padding:5px 8px;text-align:center;color:${adjColor};font-weight:600">
                    ${adjStr} <span style="font-size:9px">${bar}</span>
                </td>
            </tr>`;
        }).join("");

    panel.innerHTML = `
        <div style="font-size:12px;color:#555;margin-bottom:8px">
            Total interactions recorded: <strong>${stats.total_pulls}</strong>
        </div>
        <table style="width:100%;border-collapse:collapse">
            <thead>
                <tr style="background:#f5f5f5;font-size:11px;color:#666">
                    <th style="padding:5px 8px;text-align:left">Category :: Priority</th>
                    <th style="padding:5px 8px">Pulls</th>
                    <th style="padding:5px 8px">Avg Reward</th>
                    <th style="padding:5px 8px">RL Score Adj</th>
                </tr>
            </thead>
            <tbody>${rows}</tbody>
        </table>
        <p style="font-size:10px;color:#aaa;margin-top:8px">
            Positive adj = banker responds well to this type. 
            Negative adj = banker frequently snoozes/dismisses this type.
        </p>`;
}

// ── Init: inject UI panel ─────────────────────────────────────────────────────

document.addEventListener("DOMContentLoaded", () => {
    // Inject the prioritisation section into the page after action list
    const target = document.querySelector(".action-list-section") 
                || document.getElementById("action-list-container")
                || document.body;

    const section = document.createElement("div");
    section.style.cssText = "max-width:900px;margin:30px auto;padding:0 16px";
    section.innerHTML = `
        <!-- Prioritisation Panel -->
        <div style="background:#f8f9ff;border:1px solid #d0d8ff;border-radius:10px;padding:20px;margin-bottom:24px">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px">
                <div>
                    <h3 style="margin:0;color:#1a1a2e;font-size:17px">🧠 Smart Action Prioritisation</h3>
                    <p style="margin:4px 0 0;font-size:12px;color:#666">
                        LLM scoring + Reinforcement Learning · learns from your feedback over time
                    </p>
                </div>
                <button id="btn-prioritise" onclick="prioritiseActions()"
                    style="background:#0066cc;color:#fff;border:none;padding:8px 18px;
                           border-radius:6px;cursor:pointer;font-size:14px;font-weight:600">
                    🧠 Prioritise Actions
                </button>
            </div>
            <div id="prioritised-list" style="min-height:60px">
                <p style="color:#aaa;font-size:13px">
                    Click "Prioritise Actions" to score and rank your confirmed actions.
                </p>
            </div>
        </div>

        <!-- RL Stats Panel -->
        <div style="background:#fff;border:1px solid #e0e0e0;border-radius:10px;padding:20px">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px">
                <div>
                    <h4 style="margin:0;color:#1a1a2e;font-size:15px">📊 What the RL Model Has Learned</h4>
                    <p style="margin:2px 0 0;font-size:11px;color:#888">
                        Score adjustments the model applies per category based on your feedback
                    </p>
                </div>
                <button onclick="loadRLStats()"
                    style="background:#f0f0f0;color:#333;border:1px solid #ddd;
                           padding:5px 12px;border-radius:5px;cursor:pointer;font-size:12px">
                    🔄 Refresh
                </button>
            </div>
            <div id="rl-stats-panel" style="display:block">
                <p style="color:#aaa;font-size:12px">Click Refresh to view RL learning state.</p>
            </div>
        </div>
    `;

    target.appendChild(section);
});
