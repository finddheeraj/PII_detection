"""
services/prioritisation_service.py  (v2)
-----------------------------------------
Smart Action Prioritisation Engine

Architecture:
  Phase 1 (NOW):   LLM reasons about priority using action metadata.
                   Hard rules always override LLM output for R&C items.
  Phase 2 (LATER): Multi-Armed Bandit (UCB1) adjusts per-(category, priority)
                   arm weights based on banker feedback, WITH:
                     - Proper incremental mean (not cumulative sum)
                     - Temporal decay so old behaviour stops dominating
                     - Feedback recorded even for hard-rule actions
                     - Per-banker learning (keyed by banker_id)
                     - Confidence score (how much has the model seen?)

Fixes vs v1:
  [FIX 1] Hard-rule actions now ALSO record RL feedback — R&C arms learn
  [FIX 2] avg_reward uses true decayed mean, not cumulative sum / n
  [FIX 3] feedback() accepts PrioritisedAction directly for correct band lookup
  [FIX 4] Per-banker arm keys when banker_id supplied
  [NEW]   confidence score on each PrioritisedAction (0-1)
  [NEW]   RL adjustment range increased to ±12 (was ±10), configurable
"""

from __future__ import annotations

import json
import logging
import math
import re
from dataclasses import dataclass
from datetime import datetime
from typing import Optional

from app.config import bedrock_config
from app.models.schemas import ConfirmedAction, Category

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# 1. HARD RULE ENGINE  (cannot be overridden by LLM or RL)
# ─────────────────────────────────────────────────────────────────────────────

_RC_ESCALATION_DAYS = 7
_HIGH_SCORE_FLOOR   = 90


def _days_until(due_date: Optional[str], reference: str) -> Optional[int]:
    if not due_date:
        return None
    try:
        ref = datetime.fromisoformat(reference).date()
        due = datetime.fromisoformat(due_date).date()
        return (due - ref).days
    except ValueError:
        return None


def apply_hard_rules(action: ConfirmedAction, reference_date: str) -> Optional[float]:
    """
    Returns a locked score if a hard rule fires, otherwise None.
    Only R&C actions qualify. Returned score >= _HIGH_SCORE_FLOOR.
    """
    if action.category != Category.RISK_CONTROL:
        return None

    days = _days_until(action.due_date, reference_date)

    if days is None:
        return 95.0                                           # R&C, no deadline: always visible
    if days <= 0:
        return 100.0                                          # overdue R&C: maximum urgency
    if days <= _RC_ESCALATION_DAYS:
        return max(float(100 - days), float(_HIGH_SCORE_FLOOR))  # escalating score

    return None   # R&C with time to spare: LLM + RL can score freely


# ─────────────────────────────────────────────────────────────────────────────
# 2. LLM SCORING  (Phase 1)
# ─────────────────────────────────────────────────────────────────────────────

_LLM_SYSTEM_PROMPT = """
You are a prioritisation engine for a private banking smart action list.
Assign a numeric priority score (0-100) to a banker action.

Guidelines:
- 90-100: Urgent. R&C deadline imminent, regulatory risk, overdue.
- 70-89:  High. Important opportunity, deadline within 2 weeks.
- 40-69:  Medium. Valuable but not time-critical.
- 0-39:   Low. Nice-to-do, no deadline, low urgency.

Respond ONLY with valid JSON. No preamble, no markdown.
{"score": <int 0-100>, "priority": "<High|Medium|Low>", "rationale": "<one sentence>"}
"""

_LLM_USER_TEMPLATE = """Score this banker action:
Title:       {title}
Description: {description}
Category:    {category}
Due date:    {due_date}
Days to due: {days_to_due}
Status:      {status}
"""


@dataclass
class LLMScore:
    score: int
    priority: str
    rationale: str


def _call_bedrock(user_prompt: str) -> str:
    """
    Calls Bedrock using the pbwm_genai_config pattern
    from your Jupyter notebook cells [8]-[18].
    """
    try:
        from pbwm_genai_config import Config, logger as pbwm_logger
    except ImportError:
        raise RuntimeError("pbwm_genai_config not installed.")

    config       = Config(logger=pbwm_logger)
    session      = config._aws_session
    botocore_cfg = config._aws_config
    verify       = bedrock_config.verify_ssl if bedrock_config.verify_ssl else True

    client = session.client(
        service_name="bedrock-runtime",
        region_name=bedrock_config.aws_region,
        config=botocore_cfg,
        verify=verify,
    )

    body = {
        "anthropic_version": "bedrock-2023-05-31",
        "max_tokens":  256,
        "temperature": 0.0,
        "system": [{"type": "text", "text": _LLM_SYSTEM_PROMPT}],
        "messages": [{"role": "user", "content": [{"type": "text", "text": user_prompt}]}],
    }

    resp = client.invoke_model(modelId=bedrock_config.model_id, body=json.dumps(body))
    rb   = json.loads(resp["body"].read())
    c    = rb.get("content", [])
    return (c if isinstance(c, str) else "".join(
        b.get("text", "") for b in c if isinstance(b, dict) and b.get("type") == "text"
    )).strip()


def score_with_llm(action: ConfirmedAction, reference_date: str) -> LLMScore:
    days = _days_until(action.due_date, reference_date)
    prompt = _LLM_USER_TEMPLATE.format(
        title=action.title, description=action.description,
        category=action.category.value,
        due_date=action.due_date or "none",
        days_to_due=str(days) if days is not None else "unknown",
        status=action.status.value,
    )
    try:
        raw  = _call_bedrock(prompt)
        raw  = re.sub(r"```(?:json)?", "", raw).strip().rstrip("`").strip()
        data = json.loads(raw)
        return LLMScore(int(data["score"]), data.get("priority","Medium"), data.get("rationale",""))
    except Exception as e:
        logger.warning(f"[LLM] Failed for '{action.title}': {e} — using fallback")
        return _fallback_score(action, reference_date)


def _fallback_score(action: ConfirmedAction, reference_date: str) -> LLMScore:
    days  = _days_until(action.due_date, reference_date)
    score = 50
    if days is not None:
        if days <= 0:    score += 35
        elif days <= 7:  score += 25
        elif days <= 30: score += 10
    score += {
        Category.RISK_CONTROL: 20, Category.COMMERCIAL: 10,
        Category.RELATIONSHIP:  5, Category.PERSONAL:    0,
    }.get(action.category, 0)
    pri = "High" if score >= 70 else "Medium" if score >= 40 else "Low"
    return LLMScore(min(score, 89), pri, "Fallback scoring (LLM unavailable)")


# ─────────────────────────────────────────────────────────────────────────────
# 3. REINFORCEMENT LEARNING — UCB1 Multi-Armed Bandit  (v2)
# ─────────────────────────────────────────────────────────────────────────────

_REWARD_MAP = {
    "completed":  1.0,
    "clicked":    0.5,
    "snoozed":   -0.3,
    "dismissed": -0.7,
}
_UCB_C        = 1.4    # exploration constant
_DECAY        = 0.95   # exponential decay per feedback event
_RL_SCALE     = 12.0   # max absolute RL adjustment


@dataclass
class ArmStats:
    """
    One bandit arm = one (category, priority_band) pair.

    Uses exponential decay so recent signals outweigh old ones.
    Formula on update: mean = λ * mean + (1-λ) * reward
    """
    arm_key:      str
    n_feedback:   int   = 0
    n_pulls:      int   = 0
    _mean_reward: float = 0.0

    def record_feedback(self, reward: float) -> None:
        """Exponentially decayed running mean."""
        if self.n_feedback == 0:
            self._mean_reward = reward
        else:
            self._mean_reward = _DECAY * self._mean_reward + (1 - _DECAY) * reward
        self.n_feedback += 1

    def record_pull(self) -> None:
        self.n_pulls += 1

    @property
    def avg_reward(self) -> float:
        return round(self._mean_reward, 4)

    @property
    def confidence(self) -> float:
        """
        0–1. Reaches ~0.9 after ~15 feedback events.
        Low confidence = RL adjustment should be taken with a pinch of salt.
        """
        return round(1.0 - math.exp(-0.15 * self.n_feedback), 3)

    def ucb1_bonus(self, total_pulls: int) -> float:
        if self.n_pulls == 0 or total_pulls == 0:
            return _UCB_C * 2.0
        return _UCB_C * math.sqrt(math.log(total_pulls) / self.n_pulls)

    def rl_adjustment(self, total_pulls: int) -> float:
        """
        Score delta: reward drives ±9 pts, UCB exploration adds up to +3 pts.
        """
        reward_part  = self._mean_reward * (_RL_SCALE * 0.75)
        explore_part = min(self.ucb1_bonus(total_pulls), _RL_SCALE * 0.25)
        return round(reward_part + explore_part, 2)

    # Serialisation
    def to_dict(self) -> dict:
        return {"n_feedback": self.n_feedback, "n_pulls": self.n_pulls, "_mean_reward": self._mean_reward}

    @classmethod
    def from_dict(cls, key: str, d: dict) -> "ArmStats":
        a = cls(arm_key=key)
        a.n_feedback   = d.get("n_feedback", d.get("total_pulls", 0))
        a.n_pulls      = d.get("n_pulls", a.n_feedback)
        a._mean_reward = d.get("_mean_reward", d.get("total_reward", 0.0))
        return a


def _arm_key(category: Category, band: str, banker_id: Optional[str] = None) -> str:
    base = f"{category.value}::{band}"
    return f"{banker_id}::{base}" if banker_id else base


def _priority_band(score: float) -> str:
    return "High" if score >= 70 else "Medium" if score >= 40 else "Low"


class RLAdjuster:
    """
    Maintains bandit arm state. Persists to JSON across Flask restarts.
    Supports optional per-banker arms via banker_id.
    """

    def __init__(self, store_path: str = "rl_bandit_state.json"):
        self._store_path  = store_path
        self._arms: dict[str, ArmStats] = {}
        self._total_pulls = 0
        self._load()

    def _arm(self, key: str) -> ArmStats:
        if key not in self._arms:
            self._arms[key] = ArmStats(arm_key=key)
        return self._arms[key]

    def adjust(self, action: ConfirmedAction, llm_score: int,
               banker_id: Optional[str] = None) -> float:
        """Record a pull and return RL-adjusted score."""
        key = _arm_key(action.category, _priority_band(llm_score), banker_id)
        arm = self._arm(key)
        arm.record_pull()
        self._total_pulls += 1
        adj   = arm.rl_adjustment(self._total_pulls)
        final = max(0.0, min(100.0, llm_score + adj))
        logger.debug(f"[RL] {key}: llm={llm_score}, adj={adj:+.2f}, final={final:.1f}")
        self._save()
        return final

    def record_feedback(self, action: ConfirmedAction, signal: str,
                        current_score: float, banker_id: Optional[str] = None) -> None:
        """
        [v2 FIX] Uses current_score to determine the correct priority band,
        so hard-rule R&C actions (score=100) update the 'High' arm correctly.
        """
        reward = _REWARD_MAP.get(signal, 0.0)
        key    = _arm_key(action.category, _priority_band(current_score), banker_id)
        self._arm(key).record_feedback(reward)
        arm = self._arm(key)
        logger.info(
            f"[RL feedback] {key}: signal='{signal}', reward={reward:+.1f}, "
            f"mean={arm.avg_reward:.4f}, confidence={arm.confidence:.2f}"
        )
        self._save()

    def get_arm_confidence(self, category: Category, band: str,
                           banker_id: Optional[str] = None) -> float:
        return self._arm(_arm_key(category, band, banker_id)).confidence

    def get_stats(self) -> dict:
        return {
            "total_pulls": self._total_pulls,
            "arms": {
                k: {
                    "n_pulls":    v.n_pulls,
                    "n_feedback": v.n_feedback,
                    "avg_reward": v.avg_reward,
                    "confidence": v.confidence,
                    "rl_adj":     round(v.rl_adjustment(self._total_pulls), 3),
                }
                for k, v in sorted(self._arms.items())
            }
        }

    def _save(self) -> None:
        try:
            with open(self._store_path, "w") as f:
                json.dump({"total_pulls": self._total_pulls,
                           "arms": {k: v.to_dict() for k, v in self._arms.items()}}, f, indent=2)
        except Exception as e:
            logger.warning(f"[RL] Save failed: {e}")

    def _load(self) -> None:
        try:
            with open(self._store_path) as f:
                data = json.load(f)
            self._total_pulls = data.get("total_pulls", 0)
            for k, v in data.get("arms", {}).items():
                self._arms[k] = ArmStats.from_dict(k, v)
            logger.info(f"[RL] Loaded: {self._total_pulls} pulls, {len(self._arms)} arms")
        except FileNotFoundError:
            logger.info("[RL] No saved state — starting fresh.")
        except Exception as e:
            logger.warning(f"[RL] Load failed: {e}")


# ─────────────────────────────────────────────────────────────────────────────
# 4. MAIN FACADE
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class PrioritisedAction:
    action:            ConfirmedAction
    final_score:       float
    llm_score:         Optional[int]
    rl_adjustment:     Optional[float]
    computed_priority: str
    rationale:         str
    hard_rule_fired:   bool
    confidence:        float = 1.0    # RL confidence for this arm (0-1)


class PrioritisationService:
    """
    Orchestrates: Hard Rules → LLM Score → RL Adjustment → Rank.

    rank(actions, banker_id="chauradh")    # per-banker learning
    feedback(pa, "completed", banker_id)   # teach the model
    get_rl_stats()                         # inspect learned weights
    """

    def __init__(self, reference_date: str = "2026-03-24"):
        self.reference_date = reference_date
        self._rl = RLAdjuster()
        self._last_scored: dict[str, PrioritisedAction] = {}

    def rank(self, actions: list[ConfirmedAction],
             banker_id: Optional[str] = None) -> list[PrioritisedAction]:
        results = [self._score_one(a, banker_id) for a in actions]
        self._last_scored = {pa.action.id: pa for pa in results}
        results.sort(key=lambda x: (not x.hard_rule_fired, -x.final_score))
        return results

    def feedback(self, action_or_pa, signal: str,
                 banker_id: Optional[str] = None) -> None:
        """
        Accept ConfirmedAction or PrioritisedAction.
        Looks up cached final_score so the correct band is updated.
        Works for hard-rule actions too (v2 fix).
        """
        if signal not in _REWARD_MAP:
            logger.warning(f"Unknown signal '{signal}'")
            return

        if isinstance(action_or_pa, PrioritisedAction):
            action, score = action_or_pa.action, action_or_pa.final_score
        else:
            action = action_or_pa
            pa     = self._last_scored.get(action.id)
            score  = pa.final_score if pa else 50.0

        self._rl.record_feedback(action, signal, score, banker_id)

    def get_rl_stats(self) -> dict:
        return self._rl.get_stats()

    def _score_one(self, action: ConfirmedAction,
                   banker_id: Optional[str] = None) -> PrioritisedAction:

        # Step 1: Hard rules
        locked = apply_hard_rules(action, self.reference_date)
        if locked is not None:
            # [v2 FIX] Still record the pull so R&C arm confidence grows
            self._rl.adjust(action, int(locked), banker_id)
            conf = self._rl.get_arm_confidence(
                action.category, _priority_band(locked), banker_id)
            return PrioritisedAction(
                action=action, final_score=locked,
                llm_score=None, rl_adjustment=None,
                computed_priority="High",
                rationale=f"🔒 Hard rule: R&C escalation (≤{_RC_ESCALATION_DAYS} days or overdue)",
                hard_rule_fired=True, confidence=conf,
            )

        # Step 2: LLM scores
        llm = score_with_llm(action, self.reference_date)

        # Step 3: RL adjusts
        final = self._rl.adjust(action, llm.score, banker_id)
        conf  = self._rl.get_arm_confidence(
            action.category, _priority_band(llm.score), banker_id)

        return PrioritisedAction(
            action=action, final_score=final,
            llm_score=llm.score, rl_adjustment=round(final - llm.score, 2),
            computed_priority=_priority_band(final),
            rationale=llm.rationale,
            hard_rule_fired=False, confidence=round(conf, 3),
        )


# Singleton
prioritisation_service = PrioritisationService()
