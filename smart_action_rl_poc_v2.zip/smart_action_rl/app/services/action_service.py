"""
services/action_service.py
--------------------------
Business logic layer for confirmed actions.
Uses an in-memory store for POC (swap for DB in production).
Handles: create, read, update, status transitions.
"""

from __future__ import annotations
import uuid
import logging
from datetime import datetime, timezone
from typing import Optional

from app.models.schemas import (
    ConfirmedAction, ExtractedAction, ActionState,
    ActionStatus, ConfirmRequest
)

logger = logging.getLogger(__name__)


class ActionService:
    """
    In-memory action store for POC.

    Production replacement: swap _store for SQLAlchemy ORM calls.
    All public methods stay the same — only the storage backend changes.
    """

    def __init__(self):
        # action_id → ConfirmedAction
        self._store: dict[str, ConfirmedAction] = {}

    # ── Write operations ──────────────────────────────────────────────────────

    def confirm_action(
        self,
        extracted: ExtractedAction,
        edits: Optional[ConfirmRequest] = None,
        meeting_ref: Optional[str] = None,
        duplicate_of: Optional[str] = None,
    ) -> ConfirmedAction:
        """
        Convert a banker-approved ExtractedAction into a ConfirmedAction.
        Applies any inline edits the banker made before confirming.
        """
        # Merge banker edits over extracted data
        data = extracted.model_dump()
        if edits:
            for field, value in edits.model_dump(exclude_none=True).items():
                if field in data and value is not None:
                    data[field] = value

        action = ConfirmedAction(
            **data,
            id=str(uuid.uuid4()),
            state=ActionState.CONFIRMED,
            status=ActionStatus.NOT_STARTED,
            confirmed_at=datetime.now(timezone.utc).isoformat(),
            meeting_ref=meeting_ref or edits.meeting_ref if edits else None,
            is_duplicate=duplicate_of is not None,
            duplicate_of=duplicate_of,
        )
        self._store[action.id] = action
        logger.info(f"Action confirmed: [{action.id}] {action.title}")
        return action

    def update_status(self, action_id: str, status: ActionStatus) -> ConfirmedAction:
        """Update the lifecycle status of an existing action."""
        action = self._get_or_raise(action_id)
        action.status = status
        logger.info(f"Action {action_id} status → {status}")
        return action

    def reject_action(self, action_id: str) -> ConfirmedAction:
        """Mark a confirmed action as rejected (soft delete for POC)."""
        action = self._get_or_raise(action_id)
        action.state = ActionState.REJECTED
        logger.info(f"Action {action_id} rejected.")
        return action

    def delete_action(self, action_id: str) -> None:
        """Hard delete (for manually created tasks per SR-4)."""
        if action_id not in self._store:
            raise KeyError(f"Action {action_id} not found.")
        del self._store[action_id]

    # ── Read operations ───────────────────────────────────────────────────────

    def get_all(
        self,
        status_filter: Optional[ActionStatus] = None,
        priority_filter: Optional[str] = None,
    ) -> list[ConfirmedAction]:
        """Return confirmed actions, with optional filtering."""
        actions = [
            a for a in self._store.values()
            if a.state == ActionState.CONFIRMED
        ]
        if status_filter:
            actions = [a for a in actions if a.status == status_filter]
        if priority_filter:
            actions = [a for a in actions if a.priority.value == priority_filter]

        # Sort: overdue / high priority first
        actions.sort(key=lambda a: (
            0 if a.priority.value == "High" else 1 if a.priority.value == "Medium" else 2,
            a.due_date or "9999-99-99"
        ))
        return actions

    def get_by_id(self, action_id: str) -> Optional[ConfirmedAction]:
        return self._store.get(action_id)

    def exists_similar(self, title: str, client: str) -> Optional[str]:
        """
        Simple duplicate check by title + client similarity.
        Returns the ID of the existing action if a near-match is found.
        Production: use embeddings or fuzzy match.
        """
        title_lower = title.lower().strip()
        client_lower = client.lower().strip()
        for action in self._store.values():
            if (action.state == ActionState.CONFIRMED
                    and action.client.lower().strip() == client_lower
                    and self._title_similar(action.title.lower(), title_lower)):
                return action.id
        return None

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _get_or_raise(self, action_id: str) -> ConfirmedAction:
        if action_id not in self._store:
            raise KeyError(f"Action {action_id} not found.")
        return self._store[action_id]

    @staticmethod
    def _title_similar(a: str, b: str) -> bool:
        """Naive word-overlap similarity (≥ 50% shared words)."""
        words_a = set(a.split())
        words_b = set(b.split())
        if not words_a or not words_b:
            return False
        overlap = words_a & words_b
        return len(overlap) / max(len(words_a), len(words_b)) >= 0.5


# Singleton
action_service = ActionService()
