"""
tools/validator_tool.py
-----------------------
LangGraph Tool: validate_actions
Responsibility: schema-validate and enrich raw LLM output.
Purely deterministic — no LLM calls.

Enrichment applied:
  - Pydantic schema coercion & defaults
  - Emoji assignment by category if missing
  - Due date fallback (+7 days from reference date)
  - Invalid entries filtered out with warning logged
"""

from __future__ import annotations
import logging
from datetime import date, timedelta
from typing import Any

from langchain_core.tools import tool
from pydantic import ValidationError

from app.models.schemas import ExtractedAction, Priority, Category
from app.config import app_config

logger = logging.getLogger(__name__)

REFERENCE_DATE = date.fromisoformat(app_config.reference_date)

CATEGORY_EMOJI_MAP = {
    Category.RISK_CONTROL:  "⚠️",
    Category.COMMERCIAL:    "💼",
    Category.RELATIONSHIP:  "🤝",
    Category.PERSONAL:      "📋",
}

PRIORITY_DEFAULTS = {
    "risk": Priority.HIGH,
    "control": Priority.HIGH,
    "compliance": Priority.HIGH,
    "expir": Priority.HIGH,
    "renew": Priority.HIGH,
    "proposal": Priority.MEDIUM,
    "report": Priority.MEDIUM,
    "send": Priority.MEDIUM,
    "schedule": Priority.LOW,
    "invite": Priority.LOW,
    "call": Priority.LOW,
}


def _infer_priority(title: str, description: str) -> Priority:
    """Heuristic priority inference from action text (fallback only)."""
    text = (title + " " + description).lower()
    for keyword, priority in PRIORITY_DEFAULTS.items():
        if keyword in text:
            return priority
    return Priority.MEDIUM


def _default_due_date(days_ahead: int = 7) -> str:
    return (REFERENCE_DATE + timedelta(days=days_ahead)).isoformat()


def _enrich(raw: dict[str, Any], index: int) -> dict[str, Any]:
    """Apply defaults and enrichment to a raw action dict."""
    # Emoji fallback by category
    cat_str = raw.get("category", "Relationship")
    try:
        cat = Category(cat_str)
    except ValueError:
        cat = Category.RELATIONSHIP
        raw["category"] = cat.value

    if not raw.get("emoji") or raw["emoji"] == "📋":
        raw["emoji"] = CATEGORY_EMOJI_MAP.get(cat, "📋")

    # Due date fallback
    if not raw.get("due_date"):
        raw["due_date"] = _default_due_date(7)

    # Priority inference fallback
    if not raw.get("priority"):
        raw["priority"] = _infer_priority(
            raw.get("title", ""), raw.get("description", "")
        ).value

    # Source quote fallback
    if not raw.get("source_quote"):
        raw["source_quote"] = ""

    return raw


@tool
def validate_actions_tool(raw_actions: list[dict[str, Any]]) -> dict[str, Any]:
    """
    Validate and enrich a list of raw extracted actions.
    Returns valid actions and a list of warning messages.

    Args:
        raw_actions: Output from extract_actions_tool.

    Returns:
        dict with keys:
          - "valid_actions": list[dict] — Pydantic-validated action dicts
          - "warnings": list[str] — validation errors / skipped items
    """
    logger.info(f"validator_tool: validating {len(raw_actions)} raw action(s)...")

    valid_actions: list[dict] = []
    warnings: list[str] = []

    for i, raw in enumerate(raw_actions):
        if not isinstance(raw, dict):
            warnings.append(f"Item {i}: not a dict, skipped.")
            continue

        enriched = _enrich(raw, i)

        try:
            action = ExtractedAction(**enriched)
            valid_actions.append(action.model_dump())
        except ValidationError as e:
            msg = f"Item {i} ('{raw.get('title','?')}'): validation failed — {e.error_count()} error(s)."
            logger.warning(msg)
            warnings.append(msg)

    logger.info(
        f"validator_tool: {len(valid_actions)} valid, {len(warnings)} skipped."
    )
    return {"valid_actions": valid_actions, "warnings": warnings}
