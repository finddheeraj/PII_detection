"""
tools/dedup_tool.py
-------------------
LangGraph Tool: deduplicate_actions
Responsibility: flag actions that likely already exist in the Smart Action List.
Purely deterministic — no LLM calls.

Implements User Story ID 27-31 from Sub-requirement 4 (task duplication avoidance),
applied here to meeting follow-up actions too.
"""

from __future__ import annotations
import logging
from typing import Any

from langchain_core.tools import tool

from app.services.action_service import action_service

logger = logging.getLogger(__name__)


@tool
def dedup_actions_tool(valid_actions: list[dict[str, Any]]) -> dict[str, Any]:
    """
    Check each validated action against the existing confirmed action store.
    Flags duplicates without removing them — banker makes the final call.

    Args:
        valid_actions: Output from validate_actions_tool["valid_actions"].

    Returns:
        dict with keys:
          - "actions": list[dict] — actions with "is_duplicate" and "duplicate_of" set
          - "duplicate_count": int
    """
    logger.info(f"dedup_tool: checking {len(valid_actions)} action(s) for duplicates...")

    duplicate_count = 0

    for action in valid_actions:
        existing_id = action_service.exists_similar(
            title=action.get("title", ""),
            client=action.get("client", ""),
        )
        if existing_id:
            action["is_duplicate"] = True
            action["duplicate_of"] = existing_id
            duplicate_count += 1
            logger.info(
                f"dedup_tool: '{action['title']}' flagged as duplicate of {existing_id}"
            )
        else:
            action["is_duplicate"] = False
            action["duplicate_of"] = None

    logger.info(f"dedup_tool: {duplicate_count} duplicate(s) found.")
    return {"actions": valid_actions, "duplicate_count": duplicate_count}
