"""
tools/extractor_tool.py
-----------------------
LangGraph Tool: extract_actions
Responsibility: call the LLM and return raw extracted actions from a transcript.
This is the ONLY node that calls the LLM.
"""

from __future__ import annotations
import logging
from typing import Any

from langchain_core.tools import tool

from app.services.llm_service import LLMService
from app.config import app_config

logger = logging.getLogger(__name__)

EXTRACTION_SYSTEM_PROMPT = f"""You are an AI assistant for a private banking platform called PRISM.
Your job is to extract follow-up actions from meeting transcripts between bankers and clients.

Today's date is {app_config.reference_date}.

Return ONLY a valid JSON array. No explanation, no markdown fences, no preamble.
Each element must match this exact structure:
{{
  "title": "Short action title (max 10 words)",
  "description": "Clear description of what the banker needs to do",
  "client": "Client or relationship name mentioned in context",
  "due_date": "YYYY-MM-DD (estimate from context, or +7 days from today if unclear)",
  "priority": "High|Medium|Low",
  "category": "Risk & Control|Commercial|Relationship|Personal",
  "source_quote": "Verbatim phrase from transcript that triggered this action",
  "emoji": "Single relevant emoji"
}}

Priority rules:
- High   = compliance deadline, regulatory, expiry within 2 weeks
- Medium = client deliverable, proposal, report
- Low    = scheduling, admin, internal coordination

Category rules:
- Risk & Control  = compliance, regulatory, lending, rate expiry
- Commercial      = product proposals, investment, reinvestment
- Relationship    = follow-ups, meetings, client communications
- Personal        = internal tasks not linked to a specific client

Only extract CLEAR commitments or time-bound next steps.
If no actions are found, return an empty array: []"""


@tool
def extract_actions_tool(transcript: str) -> list[dict[str, Any]]:
    """
    Extract follow-up actions from a meeting transcript using the local LLaMA model.

    Args:
        transcript: Raw meeting transcript text.

    Returns:
        List of raw action dicts (unvalidated — validation happens in validator_tool).
    """
    logger.info("extractor_tool: running LLM extraction...")

    llm = LLMService.get_instance()
    user_prompt = f"Extract follow-up actions from this transcript:\n\n{transcript}"

    try:
        raw_actions = llm.generate_json(
            system=EXTRACTION_SYSTEM_PROMPT,
            user=user_prompt,
        )
        if not isinstance(raw_actions, list):
            logger.warning("extractor_tool: LLM returned non-list. Wrapping.")
            raw_actions = [raw_actions] if isinstance(raw_actions, dict) else []
        logger.info(f"extractor_tool: extracted {len(raw_actions)} raw action(s).")
        return raw_actions
    except ValueError as e:
        logger.error(f"extractor_tool: parse failure — {e}")
        return []
