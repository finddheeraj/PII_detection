"""
tools/extractor_tool.py
-----------------------
LangGraph Tool: extract_actions
Supports both transcript and summary input modes.
No emoji fields — removed from prompt and output.
"""

from __future__ import annotations
import logging
from typing import Any

from langchain_core.tools import tool

from app.services.llm_service import LLMService
from app.config import app_config

logger = logging.getLogger(__name__)

_SYSTEM_TEMPLATE = """You are an AI assistant for a private banking platform called PRISM.
Your job is to extract follow-up actions from meeting {input_type} between bankers and clients.

Today's date is {reference_date}.

Return ONLY a valid JSON array. No explanation, no markdown fences, no preamble.
Each element must match this exact structure:
{{
  "title": "Short action title (max 10 words)",
  "description": "Clear description of what the banker needs to do",
  "client": "Client or relationship name mentioned in context",
  "due_date": "YYYY-MM-DD (estimate from context, or +7 days from today if unclear)",
  "priority": "High|Medium|Low",
  "category": "Risk & Control|Commercial|Relationship|Personal",
  "source_quote": "Verbatim phrase from the {input_type} that triggered this action"
}}

Priority rules:
- High   = compliance deadline, regulatory, expiry within 2 weeks
- Medium = client deliverable, proposal, report
- Low    = scheduling, admin, internal coordination

Category rules:
- Risk & Control  = compliance, regulatory, lending, rate expiry
- Commercial      = product proposals, investment, reinvestment
- Relationship    = follow-ups, meetings, client communications
- Personal        = internal tasks not linked to a specific client

Only extract CLEAR commitments or time-bound next steps.
If no actions are found, return an empty array: []"""


@tool
def extract_actions_tool(content: str, input_mode: str = "transcript") -> list[dict[str, Any]]:
    """
    Extract follow-up actions from meeting content using the LLM.

    Args:
        content:    Raw transcript or summary text.
        input_mode: 'transcript' or 'summary' — controls prompt wording.

    Returns:
        List of raw action dicts (unvalidated).
    """
    input_type = "summary" if input_mode == "summary" else "transcript"
    logger.info(f"extractor_tool: running LLM extraction (input_mode={input_mode})...")

    system_prompt = _SYSTEM_TEMPLATE.format(
        input_type=input_type,
        reference_date=app_config.reference_date,
    )
    user_prompt = f"Extract follow-up actions from this meeting {input_type}:\n\n{content}"

    llm = LLMService.get_instance()
    try:
        raw_actions = llm.generate_json(system=system_prompt, user=user_prompt)
        if not isinstance(raw_actions, list):
            logger.warning("extractor_tool: LLM returned non-list. Wrapping.")
            raw_actions = [raw_actions] if isinstance(raw_actions, dict) else []
        logger.info(f"extractor_tool: extracted {len(raw_actions)} raw action(s).")
        return raw_actions
    except ValueError as e:
        logger.error(f"extractor_tool: parse failure — {e}")
        return []
