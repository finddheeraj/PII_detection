"""
routes/actions.py
-----------------
Action lifecycle endpoints. Unchanged logic, passes input_mode through.
"""

from __future__ import annotations
import logging

from flask import Blueprint, request, jsonify
from pydantic import ValidationError

from app.models.schemas import ExtractedAction, ConfirmRequest, ActionStatus
from app.services.action_service import action_service

logger = logging.getLogger(__name__)

actions_bp = Blueprint("actions", __name__, url_prefix="/api/actions")


@actions_bp.post("/confirm")
def confirm_action():
    data = request.get_json(force=True)

    try:
        extracted = ExtractedAction(**data.get("extracted", {}))
    except (ValidationError, TypeError) as e:
        return jsonify({"error": "Invalid extracted action", "detail": str(e)}), 400

    edits = None
    if data.get("edits"):
        try:
            edits = ConfirmRequest(**data["edits"])
        except (ValidationError, TypeError) as e:
            return jsonify({"error": "Invalid edits", "detail": str(e)}), 400

    input_mode = data.get("input_mode", "transcript")

    duplicate_of = action_service.exists_similar(
        title=edits.title if (edits and edits.title) else extracted.title,
        client=edits.client if (edits and edits.client) else extracted.client,
    )

    confirmed = action_service.confirm_action(
        extracted=extracted,
        edits=edits,
        meeting_ref=data.get("meeting_ref"),
        input_mode=input_mode,
        duplicate_of=duplicate_of,
    )
    return jsonify(confirmed.model_dump()), 201


@actions_bp.get("")
def get_actions():
    status_raw   = request.args.get("status")
    priority_raw = request.args.get("priority")

    status_filter = None
    if status_raw:
        try:
            status_filter = ActionStatus(status_raw)
        except ValueError:
            return jsonify({"error": f"Invalid status: {status_raw}"}), 400

    actions = action_service.get_all(
        status_filter=status_filter,
        priority_filter=priority_raw,
    )
    return jsonify({"actions": [a.model_dump() for a in actions], "total": len(actions)}), 200


@actions_bp.patch("/<action_id>/status")
def update_status(action_id: str):
    data       = request.get_json(force=True)
    status_raw = data.get("status")
    try:
        new_status = ActionStatus(status_raw)
    except (ValueError, TypeError):
        return jsonify({"error": f"Invalid status: {status_raw}"}), 400

    try:
        updated = action_service.update_status(action_id, new_status)
    except KeyError:
        return jsonify({"error": f"Action {action_id} not found"}), 404
    return jsonify(updated.model_dump()), 200


@actions_bp.delete("/<action_id>")
def delete_action(action_id: str):
    try:
        action_service.delete_action(action_id)
    except KeyError:
        return jsonify({"error": f"Action {action_id} not found"}), 404
    return "", 204
