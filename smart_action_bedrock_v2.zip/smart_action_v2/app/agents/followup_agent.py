"""
agents/followup_agent.py
------------------------
LangGraph orchestration graph for meeting follow-up action extraction.
Supports both transcript and summary input modes.

Graph flow:
  START -> extract_actions -> validate_actions -> deduplicate_actions -> format_output -> END
"""

from __future__ import annotations
import logging
from typing import Any, TypedDict

from langgraph.graph import StateGraph, END

from app.tools.extractor_tool import extract_actions_tool
from app.tools.validator_tool import validate_actions_tool
from app.tools.dedup_tool import dedup_actions_tool
from app.models.schemas import ExtractionResult, ExtractedAction

logger = logging.getLogger(__name__)


# ── Graph State ───────────────────────────────────────────────────────────────

class AgentState(TypedDict):
    """Shared state passed between all graph nodes."""
    content:          str
    input_mode:       str        # "transcript" | "summary"
    meeting_ref:      str | None
    raw_actions:      list[dict[str, Any]]
    valid_actions:    list[dict[str, Any]]
    final_actions:    list[dict[str, Any]]
    warnings:         list[str]
    agent_log:        list[str]
    duplicate_count:  int
    error:            str | None


# ── Node functions ────────────────────────────────────────────────────────────

def node_extract(state: AgentState) -> AgentState:
    mode_label = "summary" if state["input_mode"] == "summary" else "transcript"
    logger.info(f"Graph node: extract_actions (mode={state['input_mode']})")
    state["agent_log"].append(f"Node 1/4: Calling LLM for action extraction from {mode_label}...")

    raw = extract_actions_tool.invoke({
        "content":    state["content"],
        "input_mode": state["input_mode"],
    })
    state["raw_actions"] = raw
    state["agent_log"].append(f"  -> {len(raw)} raw action(s) extracted.")
    return state


def node_validate(state: AgentState) -> AgentState:
    logger.info("Graph node: validate_actions")
    state["agent_log"].append("Node 2/4: Validating and enriching actions...")

    result = validate_actions_tool.invoke({"raw_actions": state["raw_actions"]})
    state["valid_actions"] = result["valid_actions"]
    state["warnings"].extend(result["warnings"])
    state["agent_log"].append(
        f"  -> {len(state['valid_actions'])} valid, {len(result['warnings'])} warning(s)."
    )
    return state


def node_dedup(state: AgentState) -> AgentState:
    logger.info("Graph node: deduplicate_actions")
    state["agent_log"].append("Node 3/4: Checking for duplicates...")

    result = dedup_actions_tool.invoke({"valid_actions": state["valid_actions"]})
    state["final_actions"]   = result["actions"]
    state["duplicate_count"] = result["duplicate_count"]
    state["agent_log"].append(f"  -> {result['duplicate_count']} duplicate(s) flagged.")
    return state


def node_format(state: AgentState) -> AgentState:
    logger.info("Graph node: format_output")
    state["agent_log"].append("Node 4/4: Formatting output for banker review...")
    state["agent_log"].append("  -> Done. Awaiting banker confirmation.")
    return state


# ── Graph construction ────────────────────────────────────────────────────────

def _build_graph() -> Any:
    graph = StateGraph(AgentState)
    graph.add_node("extract_actions",     node_extract)
    graph.add_node("validate_actions",    node_validate)
    graph.add_node("deduplicate_actions", node_dedup)
    graph.add_node("format_output",       node_format)
    graph.set_entry_point("extract_actions")
    graph.add_edge("extract_actions",     "validate_actions")
    graph.add_edge("validate_actions",    "deduplicate_actions")
    graph.add_edge("deduplicate_actions", "format_output")
    graph.add_edge("format_output",       END)
    return graph.compile()


_compiled_graph = _build_graph()


# ── Public interface ──────────────────────────────────────────────────────────

def run_agent(
    content:     str,
    input_mode:  str = "transcript",
    meeting_ref: str | None = None,
) -> ExtractionResult:
    initial_state: AgentState = {
        "content":         content,
        "input_mode":      input_mode,
        "meeting_ref":     meeting_ref,
        "raw_actions":     [],
        "valid_actions":   [],
        "final_actions":   [],
        "warnings":        [],
        "agent_log":       [],
        "duplicate_count": 0,
        "error":           None,
    }

    try:
        final_state = _compiled_graph.invoke(initial_state)
    except Exception as e:
        logger.error(f"Agent graph error: {e}", exc_info=True)
        return ExtractionResult(
            actions=[],
            agent_log=[f"Agent failed: {e}"],
            warnings=[str(e)],
            model_used="bedrock",
        )

    actions = [ExtractedAction(**a) for a in final_state.get("final_actions", [])]
    return ExtractionResult(
        actions=actions,
        agent_log=final_state.get("agent_log", []),
        warnings=final_state.get("warnings", []),
        model_used="bedrock",
    )
