/**
 * app.js  —  PRISM Smart Action List
 * Supports both 'transcript' and 'summary' input modes.
 * All emoji removed — icons are SVG only.
 */
"use strict";

/* ═══════════════════════════════════════════════════════════
   API CLIENT
   ═══════════════════════════════════════════════════════════ */
const ApiClient = (() => {
  async function _req(method, path, body) {
    const opts = { method, headers: { "Content-Type": "application/json" } };
    if (body !== undefined) opts.body = JSON.stringify(body);
    const res  = await fetch(path, opts);
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);
    return data;
  }
  return {
    health:   ()                                    => _req("GET",   "/api/health"),
    analyse:  (content, inputMode, meetingRef)      => _req("POST",  "/api/transcript/analyse", {
                                                         content, input_mode: inputMode, meeting_ref: meetingRef }),
    confirm:  (extracted, edits, meetingRef, mode)  => _req("POST",  "/api/actions/confirm", {
                                                         extracted, edits, meeting_ref: meetingRef, input_mode: mode }),
    actions:  (status, priority)                    => _req("GET",   `/api/actions?status=${status}&priority=${priority}`),
    setStatus:(id, status)                          => _req("PATCH", `/api/actions/${id}/status`, { status }),
  };
})();

/* ═══════════════════════════════════════════════════════════
   UI RENDERER
   ═══════════════════════════════════════════════════════════ */
const UI = (() => {

  const esc  = s => String(s||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
  const escA = s => String(s||"").replace(/"/g,"&quot;");
  const fmtDate = d => {
    if (!d) return "TBD";
    try { return new Date(d).toLocaleDateString("en-GB",{day:"numeric",month:"short",year:"numeric"}); }
    catch { return d; }
  };

  function setPipe(step) {
    [1,2,3,4].forEach(n => {
      const el = document.getElementById(`ps${n}`);
      el.classList.remove("active","done");
      if (n < step)  el.classList.add("done");
      if (n === step) el.classList.add("active");
    });
  }

  function setHealth(loaded, path) {
    const dot  = document.getElementById("model-dot");
    const txt  = document.getElementById("model-status-text");
    dot.className  = "status-dot " + (loaded ? "ok" : "err");
    txt.textContent = loaded ? "Bedrock model ready" : `Model not loaded · ${path}`;
  }

  function setAnalyseBtn(loading, modeLabel) {
    const btn = document.getElementById("analyse-btn");
    const lbl = document.getElementById("btn-label");
    btn.disabled = loading;
    if (loading) {
      btn.innerHTML = `<span class="spinner"></span> Analysing...`;
    } else {
      btn.innerHTML = `
        <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor">
          <path d="M6.5 1a5.5 5.5 0 104.383 8.823l3.147 3.147a.75.75 0 001.06-1.06l-3.147-3.147A5.5 5.5 0 006.5 1zm-4 5.5a4 4 0 118 0 4 4 0 01-8 0z"/>
        </svg>
        <span id="btn-label">Analyse ${modeLabel}</span>`;
    }
  }

  function showLog(lines, warnings) {
    const card = document.getElementById("card-log");
    const el   = document.getElementById("agent-log");
    card.style.display = "block";
    el.innerHTML = [
      ...lines.map(l    => `<div class="log-info">&#9658; ${esc(l)}</div>`),
      ...warnings.map(w => `<div class="log-warn">&#9888; ${esc(w)}</div>`),
    ].join("");
  }

  function showReview(actions, meetingRef, inputMode) {
    const card = document.getElementById("card-review");
    const box  = document.getElementById("review-container");
    const meta = document.getElementById("review-meta");
    card.style.display = "block";
    meta.textContent   = `${actions.length} action(s) detected`;
    box.innerHTML = `<div class="review-list">${actions.map((a,i) => reviewCard(a,i,inputMode)).join("")}</div>`;
  }

  function reviewCard(a, i, inputMode) {
    const modeLabel = inputMode === "summary" ? "Summary" : "Transcript";
    const dupHtml   = a.is_duplicate
      ? `<div class="dup-warn">&#9888; Possible duplicate of an existing action</div>` : "";
    const quoteHtml = a.source_quote
      ? `<div class="arc-quote">"${esc(a.source_quote)}"</div>` : "";

    return `
    <div class="arc" id="arc_${i}">
      <div class="arc-head">
        <div class="arc-title-wrap">
          <div class="arc-title">${esc(a.title)}</div>
          <div class="arc-client">${esc(a.client)} &middot; ${esc(a.category)}</div>
        </div>
        <span class="arc-mode">${modeLabel}</span>
        <span class="pri ${a.priority}">${a.priority}</span>
      </div>
      ${quoteHtml}
      ${dupHtml}
      <div class="arc-fields">
        <div class="arc-field" style="grid-column:span 2">
          <label>Task title</label>
          <input type="text" id="arc_title_${i}" value="${escA(a.title)}"/>
        </div>
        <div class="arc-field">
          <label>Client</label>
          <input type="text" id="arc_client_${i}" value="${escA(a.client)}"/>
        </div>
        <div class="arc-field">
          <label>Due date</label>
          <input type="date" id="arc_due_${i}" value="${a.due_date||""}"/>
        </div>
        <div class="arc-field">
          <label>Priority</label>
          <select id="arc_pri_${i}">
            ${["High","Medium","Low"].map(p=>`<option ${p===a.priority?"selected":""}>${p}</option>`).join("")}
          </select>
        </div>
        <div class="arc-field">
          <label>Category</label>
          <select id="arc_cat_${i}">
            ${["Risk & Control","Commercial","Relationship","Personal"].map(c=>
              `<option ${c===a.category?"selected":""}>${c}</option>`).join("")}
          </select>
        </div>
      </div>
      <div class="arc-btns">
        <button class="btn btn-confirm btn-sm" onclick="App.confirmOne(${i})">Confirm &amp; add</button>
        <button class="btn btn-reject  btn-sm" onclick="App.rejectOne(${i})">Reject</button>
      </div>
    </div>`;
  }

  function markConfirmed(i) {
    const el = document.getElementById(`arc_${i}`);
    if (!el) return;
    el.className = "arc confirmed";
    el.querySelector(".arc-btns").innerHTML =
      `<span style="font-size:11px;color:var(--green);font-weight:600">&#10003; Added to Smart Action List</span>`;
  }
  function markRejected(i) {
    const el = document.getElementById(`arc_${i}`);
    if (!el) return;
    el.className = "arc rejected";
    el.querySelector(".arc-btns").innerHTML =
      `<span style="font-size:11px;color:var(--text-3)">Rejected</span>`;
  }

  function renderList(actions) {
    const box = document.getElementById("action-list");
    document.getElementById("list-count").textContent = `${actions.length} action(s)`;

    if (!actions.length) {
      box.innerHTML = `
        <div class="empty-state">
          <div class="empty-icon">
            <svg viewBox="0 0 64 64" width="52" height="52" fill="none">
              <rect x="10" y="8" width="44" height="48" rx="4" stroke="#cbd5e1" stroke-width="2.5"/>
              <path d="M20 22h24M20 30h24M20 38h16" stroke="#cbd5e1" stroke-width="2.5" stroke-linecap="round"/>
            </svg>
          </div>
          <p class="empty-msg">No confirmed actions yet.</p>
          <p class="empty-hint">Process a transcript or summary to get started.</p>
        </div>`;
      return;
    }

    box.innerHTML = actions.map(a => {
      const src = a.input_mode === "summary" ? "Summary" : "Transcript";
      return `
      <div class="a-tile">
        <div class="a-bar ${a.priority}"></div>
        <div class="a-body">
          <div class="a-name">${esc(a.title)}</div>
          <div class="a-meta">
            <span>${esc(a.client)}</span>
            <span>Due: ${fmtDate(a.due_date)}</span>
            <span>${esc(a.category)}</span>
            <span class="src-badge">${src}</span>
            ${a.is_duplicate ? `<span class="dup-badge">Duplicate</span>` : ""}
          </div>
        </div>
        <div class="a-actions">
          <span class="pri ${a.priority}">${a.priority}</span>
          <select class="status-sel" onchange="App.setStatus('${a.id}',this.value)">
            ${["not_started","started","done"].map(s=>
              `<option value="${s}" ${s===a.status?"selected":""}>${s.replace("_"," ")}</option>`).join("")}
          </select>
        </div>
      </div>`;
    }).join("");
  }

  return { setPipe, setHealth, setAnalyseBtn, showLog, showReview, markConfirmed, markRejected, renderList };
})();

/* ═══════════════════════════════════════════════════════════
   APP CONTROLLER
   ═══════════════════════════════════════════════════════════ */
const App = (() => {
  let _actions = [];
  let _states  = {};   // index -> "pending"|"confirmed"|"rejected"
  let _ref     = null;
  let _mode    = "transcript";

  const MODE_DESC = {
    transcript: "Full verbatim transcript — AI extracts commitments and time-bound next steps.",
    summary:    "Pre-written meeting summary — AI extracts actions from condensed notes.",
  };

  const SAMPLE_TRANSCRIPT = `Meeting: Portfolio Review - Harrington Family Office
Date: 20 March 2026
Attendees: James Whitfield (Banker), Sarah Harrington (Client), Tom Harrington (Co-trustee)

James: Good morning Sarah, Tom. Your structured product matures on April 15th — we need to decide on reinvestment by next Friday.

Sarah: Yes, we'd like to roll into something similar. Can you send us a proposal?

James: Absolutely, I'll prepare a structured product proposal by end of this week.

Tom: Also, the bespoke lending rate review is coming up.

James: Correct, it expires April 1st. I'll raise a renewal request with the credit team today.

Sarah: We haven't received the Q4 performance report yet.

James: Apologies — I'll get that over to both of you by tomorrow morning.

Tom: We'd like a follow-up call in two weeks to review reinvestment options.

James: Confirmed. I'll send a calendar invite for around April 3rd.`;

  const SAMPLE_SUMMARY = `Meeting: Harrington Family Office — Portfolio Review (20 Mar 2026)
Banker: James Whitfield | Clients: Sarah & Tom Harrington

Key points:
- Structured product matures 15 Apr 2026. Reinvestment decision needed by 28 Mar.
- Client wishes to roll into similar product. Proposal requested.
- Bespoke lending rate expires 1 Apr 2026. Credit renewal urgent.
- Q4 performance report not yet delivered.
- Follow-up call requested ~3 Apr 2026.

Actions agreed:
- Send structured product proposal by end of week.
- Raise lending rate renewal with credit team immediately.
- Send Q4 performance report by tomorrow morning.
- Send calendar invite for follow-up call on 3 Apr.`;

  async function init() {
    try {
      const h = await ApiClient.health();
      UI.setHealth(h.model_loaded, h.model_path);
    } catch {
      UI.setHealth(false, "unreachable");
    }

    document.getElementById("btn-transcript").addEventListener("click", () => _setMode("transcript"));
    document.getElementById("btn-summary").addEventListener("click",    () => _setMode("summary"));
    document.getElementById("content-input").addEventListener("input",  _updateCount);
    document.getElementById("analyse-btn").addEventListener("click",    analyse);
    document.getElementById("load-sample-btn").addEventListener("click",loadSample);
    document.getElementById("confirm-all-btn").addEventListener("click",confirmAll);
    document.getElementById("reject-all-btn").addEventListener("click", rejectAll);
    document.getElementById("filter-status").addEventListener("change", _refresh);
    document.getElementById("filter-priority").addEventListener("change",_refresh);

    UI.setPipe(1);
    UI.setAnalyseBtn(false, _mode);
    await _refresh();
  }

  function _setMode(m) {
    _mode = m;
    document.getElementById("btn-transcript").classList.toggle("mode-active", m === "transcript");
    document.getElementById("btn-summary").classList.toggle("mode-active",    m === "summary");
    document.getElementById("content-label").textContent = m === "summary" ? "Meeting summary" : "Meeting transcript";
    document.getElementById("mode-desc").textContent     = MODE_DESC[m];
    document.getElementById("content-input").placeholder = m === "summary"
      ? "Paste meeting summary here...\n\nAI will extract action items from your condensed notes."
      : "Paste meeting transcript here...\n\nAI will extract commitments, next steps and time-bound actions.";
    UI.setAnalyseBtn(false, m);
  }

  function loadSample() {
    document.getElementById("content-input").value = _mode === "summary" ? SAMPLE_SUMMARY : SAMPLE_TRANSCRIPT;
    document.getElementById("meeting-ref").value   = "Harrington Portfolio Review 2026-03-20";
    _updateCount();
  }

  function _updateCount() {
    const n = document.getElementById("content-input").value.length;
    document.getElementById("char-count").textContent = `${n.toLocaleString()} characters`;
  }

  async function analyse() {
    const content = document.getElementById("content-input").value.trim();
    if (!content) { alert(`Please enter a meeting ${_mode}.`); return; }

    _ref     = document.getElementById("meeting-ref").value.trim() || null;
    _actions = [];
    _states  = {};

    UI.setAnalyseBtn(true, _mode);
    UI.setPipe(2);
    document.getElementById("card-review").style.display = "none";

    try {
      const res = await ApiClient.analyse(content, _mode, _ref);
      UI.showLog(res.agent_log || [], res.warnings || []);
      _actions = res.actions || [];
      _actions.forEach((_, i) => _states[i] = "pending");
      UI.showReview(_actions, _ref, _mode);
      UI.setPipe(3);
    } catch (err) {
      UI.showLog([`Error: ${err.message}`], []);
      UI.setPipe(1);
    } finally {
      UI.setAnalyseBtn(false, _mode);
    }
  }

  async function confirmOne(i) {
    if (_states[i] !== "pending") return;
    const extracted = _actions[i];
    const edits = {
      title:    document.getElementById(`arc_title_${i}`)?.value,
      client:   document.getElementById(`arc_client_${i}`)?.value,
      due_date: document.getElementById(`arc_due_${i}`)?.value,
      priority: document.getElementById(`arc_pri_${i}`)?.value,
      category: document.getElementById(`arc_cat_${i}`)?.value,
    };
    try {
      await ApiClient.confirm(extracted, edits, _ref, _mode);
      _states[i] = "confirmed";
      UI.markConfirmed(i);
      UI.setPipe(4);
      await _refresh();
    } catch (err) {
      alert(`Could not confirm action: ${err.message}`);
    }
  }

  function rejectOne(i) {
    if (_states[i] !== "pending") return;
    _states[i] = "rejected";
    UI.markRejected(i);
  }

  async function confirmAll() {
    for (const [i, s] of Object.entries(_states))
      if (s === "pending") await confirmOne(Number(i));
  }

  function rejectAll() {
    Object.keys(_states).forEach(i => { if (_states[i] === "pending") rejectOne(Number(i)); });
  }

  async function setStatus(id, status) {
    try { await ApiClient.setStatus(id, status); await _refresh(); }
    catch (err) { alert(`Status update failed: ${err.message}`); }
  }

  async function _refresh() {
    const status   = document.getElementById("filter-status")?.value  || "";
    const priority = document.getElementById("filter-priority")?.value || "";
    try {
      const res = await ApiClient.actions(status, priority);
      UI.renderList(res.actions || []);
    } catch (err) { console.error("List refresh failed:", err); }
  }

  return { init, confirmOne, rejectOne, confirmAll, rejectAll, setStatus };
})();

document.addEventListener("DOMContentLoaded", () => App.init());
