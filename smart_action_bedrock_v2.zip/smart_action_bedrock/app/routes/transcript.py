"""
routes/transcript.py
--------------------
POST /api/transcript/analyse
  -> Runs the LangGraph agent and returns extracted actions for banker review.
     Accepts both 'transcript' and 'summary' input modes.
     Nothing is saved to the action store yet — that happens in /api/actions/confirm.
"""

from __future__ import annotations
import logging

from flask import Blueprint, request, jsonify
from pydantic import ValidationError

from app.models.schemas import MeetingInputRequest
from app.agents.followup_agent import run_agent

logger = logging.getLogger(__name__)

transcript_bp = Blueprint("transcript", __name__, url_prefix="/api/transcript")


@transcript_bp.post("/analyse")
def analyse_transcript():
    """
    Run AI extraction pipeline on meeting content (transcript or summary).

    Request body:
        {
            "content":     "...",           (required, 50-20000 chars)
            "input_mode":  "transcript",    (optional, default: "transcript")
            "meeting_ref": "optional"       (optional)
        }

    Response 200:
        {
            "actions":    [ ExtractedAction, ... ],
            "agent_log":  [ "...", ... ],
            "warnings":   [ "...", ... ],
            "model_used": "bedrock"
        }
    """
    try:
        body = MeetingInputRequest(**request.get_json(force=True))
    except (ValidationError, TypeError) as e:
        return jsonify({"error": "Invalid request", "detail": str(e)}), 400

    logger.info(
        f"Analysing {body.input_mode} ({len(body.content)} chars), "
        f"ref={body.meeting_ref}"
    )

    result = run_agent(
        content=body.content,
        input_mode=body.input_mode.value,
        meeting_ref=body.meeting_ref,
    )

    return jsonify(result.model_dump()), 200
