/**
 * app.js
 * ------
 * Frontend for the PRISM Smart Action List POC.
 * Supports both 'transcript' and 'summary' input modes.
 * No emojis.
 */

"use strict";

/* ═══════════════════════════════════════════════════════════════════════
   MODULE 1: ApiClient
   ═══════════════════════════════════════════════════════════════════════ */
const ApiClient = (() => {
  const BASE = "";

  async function _post(path, body) {
    const res  = await fetch(BASE + path, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);
    return data;
  }

  async function _patch(path, body) {
    const res  = await fetch(BASE + path, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);
    return data;
  }

  async function _get(path) {
    const res  = await fetch(BASE + path);
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);
    return data;
  }

  return {
    checkHealth:   ()                                     => _get("/api/health"),
    analyseContent: (content, inputMode, meetingRef)      => _post("/api/transcript/analyse", {
                                                              content,
                                                              input_mode: inputMode,
                                                              meeting_ref: meetingRef,
                                                            }),
    confirmAction:  (extracted, edits, meetingRef, mode)  => _post("/api/actions/confirm", {
                                                              extracted,
                                                              edits,
                                                              meeting_ref: meetingRef,
                                                              input_mode: mode,
                                                            }),
    getActions:     (status = "", priority = "")           => _get(`/api/actions?status=${status}&priority=${priority}`),
    updateStatus:   (id, status)                           => _patch(`/api/actions/${id}/status`, { status }),
  };
})();


/* ═══════════════════════════════════════════════════════════════════════
   MODULE 2: UIRenderer
   ═══════════════════════════════════════════════════════════════════════ */
const UIRenderer = (() => {

  function setPipelineStep(step) {
    [1, 2, 3, 4].forEach(n => {
      const el = document.getElementById(`ps${n}`);
      el.classList.remove("active", "done");
      if (n < step)  el.classList.add("done");
      if (n === step) el.classList.add("active");
    });
  }

  function setModelStatus(loaded, path) {
    const dot  = document.getElementById("model-dot");
    const text = document.getElementById("model-status-text");
    if (loaded) {
      dot.className    = "status-dot ok";
      text.textContent = "Bedrock model ready";
    } else {
      dot.className    = "status-dot err";
      text.textContent = `Model not loaded · ${path}`;
    }
  }

  function setAnalyseBtn(loading, mode) {
    const btn   = document.getElementById("analyse-btn");
    const label = document.getElementById("analyse-btn-label");
    btn.disabled = loading;
    if (loading) {
      btn.innerHTML = `<span class="spinner"></span> Analysing...`;
    } else {
      const modeLabel = mode === "summary" ? "summary" : "transcript";
      btn.innerHTML = `
        <svg viewBox="0 0 16 16" width="14" height="14" fill="currentColor">
          <path d="M6.5 1a5.5 5.5 0 104.47 8.69l3.17 3.17a.75.75 0 001.06-1.06L12.03 8.63A5.5 5.5 0 006.5 1zm-4 5.5a4 4 0 118 0 4 4 0 01-8 0z"/>
        </svg>
        <span id="analyse-btn-label">Analyse ${modeLabel}</span>`;
    }
  }

  function renderAgentLog(logLines, warnings) {
    const card = document.getElementById("card-log");
    const el   = document.getElementById("agent-log");
    card.style.display = "block";
    el.innerHTML = [
      ...logLines.map(l => `<div class="log-info">&#9658; ${escHtml(l)}</div>`),
      ...warnings.map(w => `<div class="log-warn">&#9888; ${escHtml(w)}</div>`),
    ].join("");
  }

  function renderReviewPanel(actions, meetingRef, inputMode) {
    const card      = document.getElementById("card-review");
    const container = document.getElementById("review-container");
    const meta      = document.getElementById("review-meta");
    card.style.display = "block";
    meta.textContent   = `${actions.length} action(s) detected`;

    container.innerHTML = `<div class="review-actions">${
      actions.map((a, i) => renderReviewCard(a, i, meetingRef, inputMode)).join("")
    }</div>`;
  }

  function renderReviewCard(action, index, meetingRef, inputMode) {
    const modeLabel = inputMode === "summary" ? "Summary" : "Transcript";
    const dupWarn = action.is_duplicate
      ? `<div class="dup-warning">&#9888; Possible duplicate of existing action</div>` : "";

    return `
    <div class="action-review-card" id="arc_${index}" data-index="${index}">
      <div class="arc-header">
        <div class="arc-title-wrap">
          <div class="arc-title">${escHtml(action.title)}</div>
          <div class="arc-client">${escHtml(action.client)} &middot; ${escHtml(action.category)}</div>
        </div>
        <span class="arc-mode-badge">${modeLabel}</span>
        <span class="priority-badge ${action.priority}">${action.priority}</span>
      </div>
      ${action.source_quote ? `<div class="arc-quote">"${escHtml(action.source_quote)}"</div>` : ""}
      ${dupWarn}
      <div class="arc-fields">
        <div class="arc-field" style="grid-column: span 2;">
          <label>Task title</label>
          <input type="text" id="arc_title_${index}" value="${escAttr(action.title)}" />
        </div>
        <div class="arc-field">
          <label>Client</label>
          <input type="text" id="arc_client_${index}" value="${escAttr(action.client)}" />
        </div>
        <div class="arc-field">
          <label>Due date</label>
          <input type="date" id="arc_due_${index}" value="${action.due_date || ""}" />
        </div>
        <div class="arc-field">
          <label>Priority</label>
          <select id="arc_priority_${index}">
            ${["High","Medium","Low"].map(p => `<option ${p===action.priority?"selected":""}>${p}</option>`).join("")}
          </select>
        </div>
        <div class="arc-field">
          <label>Category</label>
          <select id="arc_cat_${index}">
            ${["Risk & Control","Commercial","Relationship","Personal"].map(c =>
              `<option ${c===action.category?"selected":""}>${c}</option>`
            ).join("")}
          </select>
        </div>
      </div>
      <div class="arc-actions">
        <button class="btn btn-confirm btn-sm" onclick="AppController.confirmOne(${index})">Confirm &amp; add</button>
        <button class="btn btn-reject btn-sm"  onclick="AppController.rejectOne(${index})">Reject</button>
      </div>
    </div>`;
  }

  function markCardConfirmed(index) {
    const card = document.getElementById(`arc_${index}`);
    if (!card) return;
    card.className = "action-review-card confirmed";
    card.querySelector(".arc-actions").innerHTML =
      `<span style="font-size:11px; color:var(--green); font-weight:600;">&#10003; Added to Smart Action List</span>`;
  }

  function markCardRejected(index) {
    const card = document.getElementById(`arc_${index}`);
    if (!card) return;
    card.className = "action-review-card rejected";
    card.querySelector(".arc-actions").innerHTML =
      `<span style="font-size:11px; color:var(--text-3);">Rejected</span>`;
  }

  function renderActionList(actions) {
    const container = document.getElementById("action-list");
    document.getElementById("list-count").textContent = `${actions.length} action(s)`;

    if (!actions.length) {
      container.innerHTML = `
        <div class="empty-state">
          <div class="empty-icon">
            <svg viewBox="0 0 48 48" width="40" height="40" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect x="8" y="6" width="32" height="36" rx="3" stroke="#d1d5db" stroke-width="2"/>
              <path d="M15 16h18M15 22h18M15 28h12" stroke="#d1d5db" stroke-width="2" stroke-linecap="round"/>
            </svg>
          </div>
          <div>No confirmed actions yet.</div>
          <div style="font-size:12px; margin-top:4px;">Process a transcript or summary to get started.</div>
        </div>`;
      return;
    }

    container.innerHTML = actions.map(a => {
      const sourceLabel = a.input_mode === "summary" ? "Summary" : "Transcript";
      return `
      <div class="action-tile">
        <div class="tile-bar ${a.priority}"></div>
        <div class="tile-body">
          <div class="tile-name">${escHtml(a.title)}</div>
          <div class="tile-meta">
            <span>${escHtml(a.client)}</span>
            <span>Due: ${formatDate(a.due_date)}</span>
            <span>${escHtml(a.category)}</span>
            <span class="source-badge">${sourceLabel}</span>
            ${a.is_duplicate ? `<span class="dup-badge">Duplicate</span>` : ""}
          </div>
        </div>
        <div class="tile-actions">
          <span class="priority-badge ${a.priority}">${a.priority}</span>
          <select class="status-select" onchange="AppController.changeStatus('${a.id}', this.value)">
            ${["not_started","started","done"].map(s =>
              `<option value="${s}" ${s===a.status?"selected":""}>${s.replace("_"," ")}</option>`
            ).join("")}
          </select>
        </div>
      </div>`;
    }).join("");
  }

  // ── Utilities ──────────────────────────────────────────────────────────
  function escHtml(s) {
    return String(s || "").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
  }
  function escAttr(s) {
    return String(s || "").replace(/"/g, "&quot;");
  }
  function formatDate(d) {
    if (!d) return "TBD";
    try { return new Date(d).toLocaleDateString("en-GB", {day:"numeric", month:"short", year:"numeric"}); }
    catch { return d; }
  }

  return {
    setPipelineStep,
    setModelStatus,
    setAnalyseBtn,
    renderAgentLog,
    renderReviewPanel,
    markCardConfirmed,
    markCardRejected,
    renderActionList,
  };
})();


/* ═══════════════════════════════════════════════════════════════════════
   MODULE 3: AppController
   ═══════════════════════════════════════════════════════════════════════ */
const AppController = (() => {

  let _extractedActions = [];
  let _actionStates     = {};
  let _meetingRef       = null;
  let _inputMode        = "transcript";  // "transcript" | "summary"

  const MODE_HINTS = {
    transcript: "Full verbatim transcript — AI will extract commitments and next steps.",
    summary:    "Pre-written meeting summary — AI will extract actions from the condensed notes.",
  };

  const SAMPLE_TRANSCRIPT = `Meeting: Portfolio Review - Harrington Family Office
Date: 20 March 2026
Attendees: James Whitfield (Banker), Sarah Harrington (Client), Tom Harrington (Co-trustee)

James: Good morning Sarah, Tom. Let's run through the portfolio. Your structured product matures on April 15th, so we need to decide on reinvestment by next Friday at the latest.

Sarah: Yes, we'd like to roll into something similar. Can you send us a proposal?

James: Absolutely, I'll prepare a structured product proposal and send it over by end of this week.

Tom: Also, we discussed the lending facility last time. I believe the rate review is coming up.

James: You're right, the bespoke lending rate expires on April 1st. I'll raise a renewal request with the credit team today.

Sarah: One more thing — we haven't received the Q4 performance report yet.

James: Apologies for that, I'll get that sent over to both of you by tomorrow morning.

Tom: And we'd like to schedule a follow-up call in two weeks to review the reinvestment options.

James: Confirmed. I'll send a calendar invite for around April 3rd.`;

  const SAMPLE_SUMMARY = `Meeting: Harrington Family Office - Portfolio Review (20 Mar 2026)
Attendees: James Whitfield (RM), Sarah & Tom Harrington

Key discussion points:
- Structured product maturing 15 Apr 2026; reinvestment decision needed by 28 Mar.
- Client expressed interest in rolling into a similar structured product.
- Bespoke lending rate expires 1 Apr 2026; credit renewal required urgently.
- Q4 performance report not yet delivered to client.
- Follow-up call requested for approximately 3 Apr 2026 to review options.

Actions agreed:
- James to send structured product proposal by end of week.
- James to raise lending rate renewal with credit team immediately.
- James to send Q4 performance report by tomorrow morning.
- James to send calendar invite for follow-up call on 3 Apr.`;

  async function init() {
    try {
      const health = await ApiClient.checkHealth();
      UIRenderer.setModelStatus(health.model_loaded, health.model_path);
    } catch {
      UIRenderer.setModelStatus(false, "unreachable");
    }

    // Mode toggle
    document.getElementById("mode-transcript").addEventListener("click", () => setMode("transcript"));
    document.getElementById("mode-summary").addEventListener("click",    () => setMode("summary"));

    // Other events
    document.getElementById("content-input").addEventListener("input", _updateCharCount);
    document.getElementById("analyse-btn").addEventListener("click", analyse);
    document.getElementById("load-sample-btn").addEventListener("click", loadSample);
    document.getElementById("confirm-all-btn").addEventListener("click", confirmAll);
    document.getElementById("reject-all-btn").addEventListener("click", rejectAll);
    document.getElementById("filter-status").addEventListener("change", _refreshList);
    document.getElementById("filter-priority").addEventListener("change", _refreshList);

    UIRenderer.setPipelineStep(1);
    UIRenderer.setAnalyseBtn(false, _inputMode);
    await _refreshList();
  }

  function setMode(mode) {
    _inputMode = mode;

    // Update toggle buttons
    document.getElementById("mode-transcript").classList.toggle("active", mode === "transcript");
    document.getElementById("mode-summary").classList.toggle("active",    mode === "summary");

    // Update label + hint + placeholder
    const label = document.getElementById("content-label");
    const textarea = document.getElementById("content-input");
    const hint  = document.getElementById("mode-hint");

    label.textContent     = mode === "summary" ? "Meeting summary" : "Meeting transcript";
    hint.textContent      = MODE_HINTS[mode];
    textarea.placeholder  = mode === "summary"
      ? "Paste meeting summary here...\n\nThe system will extract actions from the condensed notes."
      : "Paste meeting transcript here...\n\nThe system will extract commitments, next steps, and time-bound actions.";

    UIRenderer.setAnalyseBtn(false, mode);
  }

  function loadSample() {
    const textarea = document.getElementById("content-input");
    textarea.value = _inputMode === "summary" ? SAMPLE_SUMMARY : SAMPLE_TRANSCRIPT;
    document.getElementById("meeting-ref").value = "Harrington Portfolio Review 2026-03-20";
    _updateCharCount();
  }

  function _updateCharCount() {
    const len = document.getElementById("content-input").value.length;
    document.getElementById("char-count").textContent = `${len.toLocaleString()} characters`;
  }

  async function analyse() {
    const content = document.getElementById("content-input").value.trim();
    if (!content) {
      alert(`Please enter a meeting ${_inputMode}.`);
      return;
    }

    _meetingRef       = document.getElementById("meeting-ref").value.trim() || null;
    _extractedActions = [];
    _actionStates     = {};

    UIRenderer.setAnalyseBtn(true, _inputMode);
    UIRenderer.setPipelineStep(2);
    document.getElementById("card-review").style.display = "none";

    try {
      const result = await ApiClient.analyseContent(content, _inputMode, _meetingRef);
      UIRenderer.renderAgentLog(result.agent_log || [], result.warnings || []);
      _extractedActions = result.actions || [];
      _extractedActions.forEach((_, i) => { _actionStates[i] = "pending"; });
      UIRenderer.renderReviewPanel(_extractedActions, _meetingRef, _inputMode);
      UIRenderer.setPipelineStep(3);
    } catch (err) {
      UIRenderer.renderAgentLog([`Error: ${err.message}`], []);
      UIRenderer.setPipelineStep(1);
    } finally {
      UIRenderer.setAnalyseBtn(false, _inputMode);
    }
  }

  async function confirmOne(index) {
    if (_actionStates[index] !== "pending") return;

    const extracted = _extractedActions[index];
    const edits = {
      title:    document.getElementById(`arc_title_${index}`)?.value,
      client:   document.getElementById(`arc_client_${index}`)?.value,
      due_date: document.getElementById(`arc_due_${index}`)?.value,
      priority: document.getElementById(`arc_priority_${index}`)?.value,
      category: document.getElementById(`arc_cat_${index}`)?.value,
    };

    try {
      await ApiClient.confirmAction(extracted, edits, _meetingRef, _inputMode);
      _actionStates[index] = "confirmed";
      UIRenderer.markCardConfirmed(index);
      UIRenderer.setPipelineStep(4);
      await _refreshList();
    } catch (err) {
      alert(`Could not confirm action: ${err.message}`);
    }
  }

  function rejectOne(index) {
    if (_actionStates[index] !== "pending") return;
    _actionStates[index] = "rejected";
    UIRenderer.markCardRejected(index);
  }

  async function confirmAll() {
    for (const [i, state] of Object.entries(_actionStates)) {
      if (state === "pending") await confirmOne(Number(i));
    }
  }

  function rejectAll() {
    Object.keys(_actionStates).forEach(i => {
      if (_actionStates[i] === "pending") rejectOne(Number(i));
    });
  }

  async function changeStatus(id, status) {
    try {
      await ApiClient.updateStatus(id, status);
      await _refreshList();
    } catch (err) {
      alert(`Status update failed: ${err.message}`);
    }
  }

  async function _refreshList() {
    const status   = document.getElementById("filter-status")?.value  || "";
    const priority = document.getElementById("filter-priority")?.value || "";
    try {
      const result = await ApiClient.getActions(status, priority);
      UIRenderer.renderActionList(result.actions || []);
    } catch (err) {
      console.error("Failed to refresh action list:", err);
    }
  }

  return { init, confirmOne, rejectOne, confirmAll, rejectAll, changeStatus };
})();


// Bootstrap
document.addEventListener("DOMContentLoaded", () => AppController.init());
