"""
app/__init__.py
---------------
Flask application factory — Bedrock/pbwm_genai_config edition.
"""

from __future__ import annotations
import logging

from flask import Flask
from flask_cors import CORS

from app.config import app_config
from app.services.llm_service import LLMService

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger(__name__)


def create_app() -> Flask:
    flask_app = Flask(__name__, template_folder="templates", static_folder="static")
    flask_app.secret_key = app_config.secret_key

    CORS(flask_app)

    # Load Bedrock client at startup
    with flask_app.app_context():
        try:
            LLMService.get_instance().load()
        except Exception as e:
            logger.error(f"Bedrock load failed: {e}. /api/health will report model_loaded=false.")

    from app.routes.health import health_bp
    from app.routes.transcript import transcript_bp
    from app.routes.actions import actions_bp

    flask_app.register_blueprint(health_bp)
    flask_app.register_blueprint(transcript_bp)
    flask_app.register_blueprint(actions_bp)

    from flask import render_template

    @flask_app.get("/")
    def index():
        return render_template("index.html")

    logger.info("Flask app ready.")
    return flask_app
