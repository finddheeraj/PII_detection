# PII Scanner — Private Banking

A Flask web app that scans log files and text for PII using:
- **Regex** (always-on, high-precision for financial fields)
- **Microsoft Presidio NER** (optional, requires spaCy)
- **spaCy NER** (optional, requires en_core_web_lg)

---

## Quick Start (Development)

```bash
# 1. Create virtual environment
python -m venv venv
venv\Scripts\activate          # Windows
source venv/bin/activate       # Linux/Mac

# 2. Install dependencies
pip install -r requirements.txt

# 3. Install spaCy model from GitHub (if no internet on target machine)
#    Download: https://github.com/explosion/spacy-models/releases/download/en_core_web_lg-3.7.1/en_core_web_lg-3.7.1-py3-none-any.whl
pip install en_core_web_lg-3.7.1.whl --no-deps

# 4. Run
python run.py
# Open: http://localhost:5000
```

---

## VS Code

Open the folder in VS Code.  
- **F5** → "Run Flask App" starts the server  
- **F5** → "Run Tests" runs pytest  
- Python Test Explorer shows all test cases

---

## Running Tests

```bash
pytest tests/ -v --tb=short
```

Output includes a **Precision / Recall / F1 accuracy report**.

To run with coverage:
```bash
pytest tests/ -v --cov=app --cov-report=term-missing
```

---

## API Endpoints

| Method | URL | Description |
|--------|-----|-------------|
| GET  | `/` | Web UI |
| POST | `/api/scan/folder` | Scan server-side folder |
| POST | `/api/scan/upload` | Upload and scan files |
| POST | `/api/scan/text` | Scan raw text |
| GET  | `/api/health` | Health check |

### Example: Scan folder
```bash
curl -X POST http://localhost:5000/api/scan/folder \
  -H "Content-Type: application/json" \
  -d '{"folder_path": "C:\\Logs\\AppLogs", "use_regex": true}'
```

### Example: Scan text
```bash
curl -X POST http://localhost:5000/api/scan/text \
  -H "Content-Type: application/json" \
  -d '{"text": "SSN: 123-45-6789 email: user@bank.com"}'
```

---

## Building the EXE

### Step 1 — Download spaCy model from GitHub
```powershell
$url = "https://github.com/explosion/spacy-models/releases/download/en_core_web_lg-3.7.1/en_core_web_lg-3.7.1-py3-none-any.whl"
Invoke-WebRequest -Uri $url -OutFile "en_core_web_lg-3.7.1.whl"
pip install en_core_web_lg-3.7.1.whl --no-deps
```

### Step 2 — Install build deps
```bash
pip install pyinstaller
```

### Step 3 — Build
```bash
pyinstaller pii_scanner.spec
```

### Step 4 — Deploy
Copy the entire `dist/pii_scanner/` folder to the target server. Run `pii_scanner.exe`.

---

## Verifying Accuracy

The test suite measures:

| Metric | Target |
|--------|--------|
| Precision | ≥ 80% |
| Recall | ≥ 80% |
| F1 Score | ≥ 80% |

Run `pytest tests/ -v -s` to see the full accuracy report printed to console.

### What's tested
- SSN (valid formats, invalid prefix rejection)
- Email, Phone, Credit Card (Luhn validation)
- CVV, PIN, Bank Routing/Account numbers
- Passport, Driver's License, DOB
- Password, Mother's Maiden Name, Biometric references
- Toxic combination detection (routing + account = must encrypt)
- Anonymisation correctness

---

## Severity Levels

| Severity | PII Types |
|----------|-----------|
| CRITICAL | SSN, Credit Card, PAN, CVV, PIN |
| HIGH | Bank Account, Routing, Passport, Driver's License, Biometric |
| MEDIUM | DOB, Mother's Maiden Name, Password, Government ID |
| LOW | Name, Address, Email, Phone, IP |
