"""
PII Detector Test Suite
=======================
Tests accuracy, precision, recall, and F1 score.
Run with: pytest tests/ -v --tb=short
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

import pytest
from app.pii_detector import detect_pii, PIIType, anonymize_text, get_risk_summary

# ─── Fixtures ────────────────────────────────────────────────────────────────

def run_regex(text):
    return detect_pii(text, use_presidio=False, use_spacy=False, use_regex=True)

def types_found(text):
    return {m.pii_type for m in run_regex(text)}

# ─── True Positive Tests (should detect) ─────────────────────────────────────

class TestSSN:
    def test_dashed(self):
        assert PIIType.SSN in types_found("SSN: 123-45-6789")
    def test_nodash(self):
        assert PIIType.SSN in types_found("ssn=123456789")
    def test_invalid_000_prefix_not_detected(self):
        # 000 prefix is invalid SSN
        assert PIIType.SSN not in types_found("000-45-6789")
    def test_invalid_666_prefix_not_detected(self):
        assert PIIType.SSN not in types_found("666-45-6789")

class TestEmail:
    def test_simple(self):
        assert PIIType.EMAIL_ADDRESS in types_found("user@example.com")
    def test_with_dots(self):
        assert PIIType.EMAIL_ADDRESS in types_found("john.smith@bank.co.uk")
    def test_with_plus(self):
        assert PIIType.EMAIL_ADDRESS in types_found("user+tag@domain.org")
    def test_no_false_positive_plain_word(self):
        assert PIIType.EMAIL_ADDRESS not in types_found("just some text without email")

class TestPhone:
    def test_us_dashes(self):
        assert PIIType.PHONE_NUMBER in types_found("Call 555-867-5309")
    def test_us_parens(self):
        assert PIIType.PHONE_NUMBER in types_found("(800) 555-1234")
    def test_international(self):
        assert PIIType.PHONE_NUMBER in types_found("+1 415 555 2671")

class TestCreditCard:
    def test_visa_luhn_valid(self):
        assert PIIType.CREDIT_CARD_NUMBER in types_found("4532015112830366")
    def test_mastercard(self):
        assert PIIType.CREDIT_CARD_NUMBER in types_found("5425233430109903")
    def test_luhn_fail_not_detected(self):
        # Deliberately invalid Luhn
        assert PIIType.CREDIT_CARD_NUMBER not in types_found("4532015112830360")
    def test_spaced_format(self):
        assert PIIType.CREDIT_CARD_NUMBER in types_found("4532 0151 1283 0366")

class TestCVV:
    def test_labelled(self):
        assert PIIType.CVV in types_found("CVV: 123")
    def test_cvc2(self):
        assert PIIType.CVV in types_found("CVC2: 4567")

class TestPIN:
    def test_labelled(self):
        assert PIIType.PIN in types_found("PIN: 4829")
    def test_six_digit(self):
        assert PIIType.PIN in types_found("pin: 123456")

class TestBankRouting:
    def test_with_label(self):
        assert PIIType.BANK_ROUTING_NUMBER in types_found("routing number: 021000021")
    def test_aba(self):
        assert PIIType.BANK_ROUTING_NUMBER in types_found("ABA: 021000021")

class TestBankAccount:
    def test_with_label(self):
        assert PIIType.BANK_ACCOUNT_NUMBER in types_found("account number: 98765432101")
    def test_acct(self):
        assert PIIType.BANK_ACCOUNT_NUMBER in types_found("acct: 1234567890")

class TestPassport:
    def test_us_format(self):
        assert PIIType.PASSPORT in types_found("Passport: A12345678")

class TestDriversLicense:
    def test_labelled(self):
        assert PIIType.DRIVERS_LICENSE in types_found("Driver's License: D123456")
    def test_dl_prefix(self):
        assert PIIType.DRIVERS_LICENSE in types_found("DL# ABC12345")

class TestDOB:
    def test_labelled(self):
        assert PIIType.DATE_OF_BIRTH in types_found("DOB: 15/03/1985")
    def test_standalone_date(self):
        assert PIIType.DATE_OF_BIRTH in types_found("born on 01/01/1990")

class TestPassword:
    def test_equals(self):
        assert PIIType.PASSWORD in types_found("password=S3cret!")
    def test_colon(self):
        assert PIIType.PASSWORD in types_found("Password: hunter2")
    def test_memorable_word(self):
        assert PIIType.PASSWORD in types_found("memorable word: Sunshine")

class TestMothersMaidenName:
    def test_full_phrase(self):
        assert PIIType.MOTHERS_MAIDEN_NAME in types_found("Mother's maiden name: Johnson")
    def test_maiden_name(self):
        assert PIIType.MOTHERS_MAIDEN_NAME in types_found("maiden name: Williams")

class TestBiometric:
    def test_fingerprint(self):
        assert PIIType.BIOMETRIC_REFERENCE in types_found("fingerprint scan completed")
    def test_facial(self):
        assert PIIType.BIOMETRIC_REFERENCE in types_found("facial recognition enabled")
    def test_biometric(self):
        assert PIIType.BIOMETRIC_REFERENCE in types_found("biometric data stored")

class TestIPAddress:
    def test_ipv4(self):
        assert PIIType.IP_ADDRESS in types_found("Connection from 192.168.1.100")

# ─── Toxic Combination Detection ─────────────────────────────────────────────

class TestToxicCombinations:
    def test_routing_plus_account(self):
        text = "routing number: 021000021  account number: 98765432101"
        matches = run_regex(text)
        summary = get_risk_summary(matches)
        assert len(summary["toxic_combination_warnings"]) > 0

    def test_no_false_toxic(self):
        text = "The customer called at 10am"
        matches = run_regex(text)
        summary = get_risk_summary(matches)
        assert summary["toxic_combination_warnings"] == []

# ─── Anonymisation ────────────────────────────────────────────────────────────

class TestAnonymisation:
    def test_email_redacted(self):
        text = "Email me at user@example.com please"
        matches = run_regex(text)
        anon = anonymize_text(text, matches)
        assert "user@example.com" not in anon
        assert "[EMAIL_ADDRESS]" in anon

    def test_cc_redacted(self):
        text = "Card: 4532015112830366"
        matches = run_regex(text)
        anon = anonymize_text(text, matches)
        assert "4532015112830366" not in anon

# ─── Severity ────────────────────────────────────────────────────────────────

class TestSeverity:
    def test_ssn_is_critical(self):
        matches = run_regex("SSN: 123-45-6789")
        assert any(m.severity == "CRITICAL" for m in matches)

    def test_email_is_low(self):
        matches = run_regex("email: user@example.com")
        assert any(m.severity == "LOW" for m in matches)

# ─── Accuracy Metrics ────────────────────────────────────────────────────────

class TestAccuracyMetrics:
    """
    Structured precision/recall test.
    Each test case: (text, expected_type, should_detect)
    """
    CASES = [
        ("SSN 123-45-6789",        PIIType.SSN,                True),
        ("000-45-6789",            PIIType.SSN,                False),  # invalid SSN
        ("user@bank.com",          PIIType.EMAIL_ADDRESS,      True),
        ("notanemail",             PIIType.EMAIL_ADDRESS,      False),
        ("4532015112830366",       PIIType.CREDIT_CARD_NUMBER, True),
        ("1234567890123456",       PIIType.CREDIT_CARD_NUMBER, False),  # Luhn fail
        ("CVV: 234",               PIIType.CVV,                True),
        ("555-867-5309",           PIIType.PHONE_NUMBER,       True),
        ("routing number: 021000021", PIIType.BANK_ROUTING_NUMBER, True),
        ("fingerprint detected",   PIIType.BIOMETRIC_REFERENCE, True),
        ("password: abc123",       PIIType.PASSWORD,           True),
    ]

    def test_accuracy_report(self, capsys):
        tp = fp = tn = fn = 0
        for text, ptype, should_detect in self.CASES:
            detected = ptype in types_found(text)
            if should_detect and detected:     tp += 1
            elif should_detect and not detected: fn += 1
            elif not should_detect and detected: fp += 1
            else:                               tn += 1

        precision = tp / (tp + fp) if (tp + fp) > 0 else 0
        recall    = tp / (tp + fn) if (tp + fn) > 0 else 0
        f1        = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0

        with capsys.disabled():
            print(f"\n{'='*50}")
            print(f"  PII Detection Accuracy Report")
            print(f"{'='*50}")
            print(f"  True Positives:  {tp}")
            print(f"  False Positives: {fp}")
            print(f"  True Negatives:  {tn}")
            print(f"  False Negatives: {fn}")
            print(f"  Precision:       {precision:.2%}")
            print(f"  Recall:          {recall:.2%}")
            print(f"  F1 Score:        {f1:.2%}")
            print(f"{'='*50}")

        # Minimum thresholds
        assert precision >= 0.80, f"Precision too low: {precision:.2%}"
        assert recall    >= 0.80, f"Recall too low: {recall:.2%}"
        assert f1        >= 0.80, f"F1 too low: {f1:.2%}"
