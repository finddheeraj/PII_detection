# =============================================================================
# PyInstaller Spec File — PII Scanner
# =============================================================================
# BEFORE building the EXE:
#
#   1. Download spaCy en_core_web_lg from GitHub releases (no pip access needed):
#
#      PowerShell:
#        $url = "https://github.com/explosion/spacy-models/releases/download/en_core_web_lg-3.7.1/en_core_web_lg-3.7.1-py3-none-any.whl"
#        Invoke-WebRequest -Uri $url -OutFile "en_core_web_lg-3.7.1.whl"
#        pip install en_core_web_lg-3.7.1.whl --no-deps
#
#      CMD / offline:
#        pip install en_core_web_lg-3.7.1.whl --no-deps --no-index
#
#      Verify install:
#        python -c "import spacy; nlp = spacy.load('en_core_web_lg'); print('OK')"
#
#   2. Install build dependencies (with network access on a build machine):
#        pip install pyinstaller flask presidio-analyzer presidio-anonymizer spacy
#
#   3. Build:
#        pyinstaller pii_scanner.spec
#
#   4. Output: dist/pii_scanner/pii_scanner.exe
#      Copy the entire dist/pii_scanner/ folder to the target server.
#      Run: pii_scanner.exe  (opens on http://localhost:5000)
# =============================================================================

import os
import sys
import site
import spacy
from pathlib import Path

block_cipher = None

# ── Locate spaCy model data on disk ──────────────────────────────────────────
def find_spacy_model(model_name):
    """Find the installed spaCy model directory."""
    # Try spacy.util first
    try:
        import spacy.util
        model_path = spacy.util.get_package_path(model_name)
        if model_path and model_path.exists():
            return str(model_path)
    except Exception:
        pass

    # Search site-packages
    for sp in site.getsitepackages() + [site.getusersitepackages()]:
        candidate = Path(sp) / model_name
        if candidate.exists():
            return str(candidate)
        # Handle versioned folder names like en_core_web_lg-3.7.1
        for child in Path(sp).glob(f"{model_name}-*"):
            if child.is_dir():
                return str(child)

    raise FileNotFoundError(
        f"spaCy model '{model_name}' not found in site-packages.\n"
        f"Install it with: pip install en_core_web_lg-3.7.1.whl --no-deps"
    )


SPACY_MODEL_NAME = "en_core_web_lg"
SPACY_MODEL_PATH = find_spacy_model(SPACY_MODEL_NAME)
print(f"[spec] Found spaCy model at: {SPACY_MODEL_PATH}")


# ── Collect spaCy model as data tree ─────────────────────────────────────────
from PyInstaller.utils.hooks import collect_data_files, collect_submodules

spacy_model_datas = [(SPACY_MODEL_PATH, SPACY_MODEL_NAME)]

# ── Analysis ─────────────────────────────────────────────────────────────────
a = Analysis(
    ["run.py"],
    pathex=["."],
    binaries=[],
    datas=[
        # Flask templates and static files
        ("templates",            "templates"),
        ("static",               "static"),
        # App source
        ("app",                  "app"),
        # Sample logs (optional — remove if not needed in EXE)
        ("sample_logs",          "sample_logs"),
        # spaCy model
        *spacy_model_datas,
        # Presidio recogniser definitions (JSON files)
        *collect_data_files("presidio_analyzer"),
        # spaCy language data
        *collect_data_files("spacy"),
        *collect_data_files("en_core_web_lg"),
    ],
    hiddenimports=[
        # Flask + Werkzeug
        "flask", "flask.templating", "jinja2",
        "werkzeug", "werkzeug.routing", "werkzeug.serving",
        # Presidio
        "presidio_analyzer",
        "presidio_analyzer.predefined_recognizers",
        "presidio_analyzer.nlp_engine",
        "presidio_analyzer.nlp_engine.spacy_nlp_engine",
        "presidio_anonymizer",
        # spaCy and model
        "spacy", "spacy.lang", "spacy.lang.en",
        "spacy.pipeline", "spacy.tokens",
        "spacy.matcher", "spacy.morphology",
        "en_core_web_lg",
        # thinc / blis / murmurhash (spaCy deps)
        "thinc", "thinc.backends", "thinc.api",
        "blis", "murmurhash", "cymem", "preshed",
        "srsly", "catalogue", "wasabi", "typer",
        # App modules
        "app.pii_detector",
        "app.folder_scanner",
        "app.flask_app",
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=["tkinter", "matplotlib", "numpy.distutils", "pytest"],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

# ── PYZ ──────────────────────────────────────────────────────────────────────
pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

# ── EXE ──────────────────────────────────────────────────────────────────────
exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name="pii_scanner",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=True,       # Keep console so server logs are visible
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=None,
)

# ── COLLECT (folder-based distribution) ──────────────────────────────────────
coll = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[],
    name="pii_scanner",
)

# =============================================================================
# Output: dist/pii_scanner/pii_scanner.exe
#
# Deploy to target server:
#   1. Copy entire dist/pii_scanner/ folder
#   2. Run pii_scanner.exe
#   3. Open browser: http://localhost:5000
#   4. To change port: set env variable PORT=8080 before running
# =============================================================================
