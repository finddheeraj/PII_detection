"""
Folder Scanner — recursively scan log files for PII.
"""

import os
import json
import logging
from pathlib import Path
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed

from app.pii_detector import detect_pii, get_risk_summary

logger = logging.getLogger(__name__)

SUPPORTED_EXTENSIONS = {
    ".log", ".txt", ".csv", ".json", ".xml",
    ".tsv", ".out", ".trace", ".audit",
}

MAX_FILE_SIZE_MB = 50


def scan_file(filepath: str, use_presidio=True, use_spacy=True,
              use_regex=True, min_score=0.5) -> dict:
    path = Path(filepath)
    try:
        size_mb = path.stat().st_size / (1024 * 1024)
        if size_mb > MAX_FILE_SIZE_MB:
            return {
                "filename": path.name,
                "filepath": str(path),
                "status": "skipped",
                "reason": f"File too large ({size_mb:.1f} MB > {MAX_FILE_SIZE_MB} MB limit)",
                "total_detections": 0,
            }

        text = path.read_text(encoding="utf-8", errors="replace")
        matches = detect_pii(text, use_presidio=use_presidio,
                             use_spacy=use_spacy, use_regex=use_regex,
                             min_score=min_score)
        summary = get_risk_summary(matches, filename=path.name)
        summary["filepath"] = str(path)
        summary["file_size_kb"] = round(path.stat().st_size / 1024, 1)
        summary["status"] = "scanned"
        return summary

    except Exception as e:
        logger.error(f"Error scanning {filepath}: {e}")
        return {
            "filename": path.name,
            "filepath": str(filepath),
            "status": "error",
            "reason": str(e),
            "total_detections": 0,
        }


def scan_folder(folder_path: str, use_presidio=True, use_spacy=True,
                use_regex=True, min_score=0.5,
                max_workers=4, recursive=True) -> dict:
    folder = Path(folder_path)
    if not folder.exists():
        raise FileNotFoundError(f"Folder not found: {folder_path}")
    if not folder.is_dir():
        raise NotADirectoryError(f"Not a directory: {folder_path}")

    # Collect files
    if recursive:
        files = [f for f in folder.rglob("*")
                 if f.is_file() and f.suffix.lower() in SUPPORTED_EXTENSIONS]
    else:
        files = [f for f in folder.iterdir()
                 if f.is_file() and f.suffix.lower() in SUPPORTED_EXTENSIONS]

    if not files:
        return {
            "folder": str(folder),
            "scanned_at": datetime.utcnow().isoformat(),
            "total_files": 0,
            "files_with_pii": 0,
            "total_detections": 0,
            "file_results": [],
            "folder_severity_counts": {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0},
            "all_pii_types": [],
            "toxic_warnings": [],
        }

    file_results = []
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {
            executor.submit(scan_file, str(f), use_presidio, use_spacy,
                            use_regex, min_score): f
            for f in files
        }
        for future in as_completed(futures):
            file_results.append(future.result())

    # Sort by detections descending
    file_results.sort(key=lambda r: r.get("total_detections", 0), reverse=True)

    # Aggregate
    total_detections = sum(r.get("total_detections", 0) for r in file_results)
    files_with_pii = sum(1 for r in file_results if r.get("total_detections", 0) > 0)
    all_pii_types = sorted(set(
        pt for r in file_results for pt in r.get("pii_types_found", [])
    ))
    toxic_warnings = list(set(
        w for r in file_results for w in r.get("toxic_combination_warnings", [])
    ))
    folder_severity = {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0}
    for r in file_results:
        for sev, count in r.get("severity_counts", {}).items():
            folder_severity[sev] = folder_severity.get(sev, 0) + count

    return {
        "folder":                  str(folder),
        "scanned_at":              datetime.utcnow().isoformat(),
        "total_files":             len(files),
        "files_with_pii":          files_with_pii,
        "total_detections":        total_detections,
        "folder_severity_counts":  folder_severity,
        "all_pii_types":           all_pii_types,
        "toxic_warnings":          toxic_warnings,
        "file_results":            file_results,
    }
