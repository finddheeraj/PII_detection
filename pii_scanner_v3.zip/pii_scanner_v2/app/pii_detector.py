"""
PII Detection Engine — Private Banking / Financial Context
"""

import re
from dataclasses import dataclass
from enum import Enum


class PIIType(str, Enum):
    SSN                 = "SSN"
    DATE_OF_BIRTH       = "DATE_OF_BIRTH"
    DRIVERS_LICENSE     = "DRIVERS_LICENSE"
    PASSPORT            = "PASSPORT"
    BANK_ACCOUNT_NUMBER = "BANK_ACCOUNT_NUMBER"
    BANK_ROUTING_NUMBER = "BANK_ROUTING_NUMBER"
    PAN                 = "PAN"
    CREDIT_CARD_NUMBER  = "CREDIT_CARD_NUMBER"
    CVV                 = "CVV"
    PIN                 = "PIN"
    HOME_ADDRESS        = "HOME_ADDRESS"
    EMAIL_ADDRESS       = "EMAIL_ADDRESS"
    PHONE_NUMBER        = "PHONE_NUMBER"
    GOVERNMENT_ID       = "GOVERNMENT_ID"
    PERSON_NAME         = "PERSON_NAME"
    MOTHERS_MAIDEN_NAME = "MOTHERS_MAIDEN_NAME"
    BIOMETRIC_REFERENCE = "BIOMETRIC_REFERENCE"
    PASSWORD            = "PASSWORD"
    IP_ADDRESS          = "IP_ADDRESS"


PROTECTION_MAP = {
    PIIType.SSN:                  "Tokenisation SHOULD be used; Encryption SHOULD be used (Field Level) for applications storing SSN.",
    PIIType.DATE_OF_BIRTH:        "Tokenisation SHOULD be used; Encryption SHOULD be used (Field Level) for DOB.",
    PIIType.DRIVERS_LICENSE:      "Tokenisation SHOULD be used; Encryption SHOULD be used (Field Level).",
    PIIType.PASSPORT:             "Tokenisation SHOULD be used; Encryption SHOULD be used (Field Level).",
    PIIType.BANK_ACCOUNT_NUMBER:  "Tokenisation SHOULD be implemented. If combined with name/address (toxic combination), MUST be tokenised or encrypted.",
    PIIType.BANK_ROUTING_NUMBER:  "Tokenisation SHOULD be used; combined with Account Number forms toxic combination — MUST be tokenised or encrypted.",
    PIIType.PAN:                  "Tokenisation SHOULD be implemented (PCI-DSS). If combined with name/address, MUST be tokenised or encrypted.",
    PIIType.CREDIT_CARD_NUMBER:   "Tokenisation SHOULD be used; Encryption SHOULD be used (Field Level).",
    PIIType.CVV:                  "Tokenisation SHOULD be used; Encryption SHOULD be used (Field Level).",
    PIIType.PIN:                  "Access (protected): Break Glass access process required with business justification and time-bound duration.",
    PIIType.HOME_ADDRESS:         "Tokenisation SHOULD be used; Encryption SHOULD be used (Field Level).",
    PIIType.EMAIL_ADDRESS:        "Tokenisation SHOULD be used; Encryption SHOULD be used (Field Level).",
    PIIType.PHONE_NUMBER:         "Tokenisation SHOULD be used; Encryption SHOULD be used (Field Level).",
    PIIType.GOVERNMENT_ID:        "Tokenisation SHOULD be used; Encryption SHOULD be used (Field Level).",
    PIIType.PERSON_NAME:          "Tokenisation SHOULD be used when combined with other PII (toxic combination risk).",
    PIIType.MOTHERS_MAIDEN_NAME:  "Tokenisation SHOULD be used; Encryption SHOULD be used (Field Level) — Customer Shared Authentication.",
    PIIType.BIOMETRIC_REFERENCE:  "Encryption MUST be used.",
    PIIType.PASSWORD:             "Reversible encryption for readvise scenarios; one-way Hash + Standard Access Controls otherwise.",
    PIIType.IP_ADDRESS:           "Tokenisation SHOULD be used.",
}

SEVERITY_MAP = {
    PIIType.SSN:                  "CRITICAL",
    PIIType.CREDIT_CARD_NUMBER:   "CRITICAL",
    PIIType.PAN:                  "CRITICAL",
    PIIType.CVV:                  "CRITICAL",
    PIIType.PIN:                  "CRITICAL",
    PIIType.BANK_ACCOUNT_NUMBER:  "HIGH",
    PIIType.BANK_ROUTING_NUMBER:  "HIGH",
    PIIType.PASSPORT:             "HIGH",
    PIIType.DRIVERS_LICENSE:      "HIGH",
    PIIType.BIOMETRIC_REFERENCE:  "HIGH",
    PIIType.DATE_OF_BIRTH:        "MEDIUM",
    PIIType.MOTHERS_MAIDEN_NAME:  "MEDIUM",
    PIIType.PASSWORD:             "MEDIUM",
    PIIType.GOVERNMENT_ID:        "MEDIUM",
    PIIType.PERSON_NAME:          "LOW",
    PIIType.HOME_ADDRESS:         "LOW",
    PIIType.EMAIL_ADDRESS:        "LOW",
    PIIType.PHONE_NUMBER:         "LOW",
    PIIType.IP_ADDRESS:           "LOW",
}


@dataclass
class PIIMatch:
    pii_type: PIIType
    text: str
    start: int
    end: int
    score: float
    source: str
    line_number: int = 0
    recommended_protection: str = ""
    severity: str = ""

    def __post_init__(self):
        self.recommended_protection = PROTECTION_MAP.get(self.pii_type, "Encryption SHOULD be applied.")
        self.severity = SEVERITY_MAP.get(self.pii_type, "MEDIUM")

    is_toxic: bool = False   # set True by detect_pii when part of a toxic combo

    def to_dict(self):
        return {
            "pii_type":    self.pii_type.value,
            "text":        self.text,
            "start":       self.start,
            "end":         self.end,
            "score":       round(self.score, 2),
            "source":      self.source,
            "line_number": self.line_number,
            "severity":    self.severity,
            "protection":  self.recommended_protection,
            "is_toxic":    self.is_toxic,
        }


_REGEX_PATTERNS = [
    (PIIType.SSN,
     r"\b(?!000|666|9\d{2})\d{3}[-\s]?(?!00)\d{2}[-\s]?(?!0000)\d{4}\b", 0.85),
    (PIIType.DATE_OF_BIRTH,
     r"\b(?:DOB|Date of Birth|dob)\s*[:\-]?\s*(?:\d{1,2}[/\-\.]\d{1,2}[/\-\.]\d{2,4}|\d{4}[/\-\.]\d{1,2}[/\-\.]\d{1,2})\b", 0.90),
    (PIIType.DATE_OF_BIRTH,
     r"\b\d{1,2}[/\-]\d{1,2}[/\-]\d{4}\b", 0.50),
    (PIIType.EMAIL_ADDRESS,
     r"\b[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}\b", 0.99),
    (PIIType.PHONE_NUMBER,
     r"\b(?:\+?1[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}\b", 0.85),
    (PIIType.CREDIT_CARD_NUMBER,
     r"\b(?:4[0-9]{12}(?:[0-9]{3})?|5[1-5][0-9]{14}|3[47][0-9]{13}|6(?:011|5[0-9]{2})[0-9]{12}|\d{4}[\s\-]\d{4}[\s\-]\d{4}[\s\-]\d{4})\b", 0.80),
    (PIIType.CVV,
     r"\b(?:CVV2?|CVC2?|CSC)\s*[:\-]?\s*\d{3,4}\b", 0.95),
    (PIIType.PIN,
     r"\b(?:PIN|pin)\s*[:\-]?\s*\d{4,6}\b", 0.95),
    (PIIType.BANK_ROUTING_NUMBER,
     r"\b(?:routing\s*(?:number)?|ABA)\s*[:\-]?\s*[0123]\d{8}\b", 0.90),
    (PIIType.BANK_ACCOUNT_NUMBER,
     r"\b(?:account\s*(?:number|no|#)|acct\.?)\s*[:\-]?\s*\d{6,17}\b", 0.85),
    (PIIType.PASSPORT,
     r"\b(?:passport\s*(?:number|no|#)?\s*[:\-]?\s*)?[A-Z]{1,2}[0-9]{6,8}\b", 0.70),
    (PIIType.DRIVERS_LICENSE,
     r"\b(?:DL|driver[\'s]*\s*licen[sc]e|license\s*(?:number|no|#))\s*[:\-]?\s*[A-Z0-9]{5,15}\b", 0.85),
    (PIIType.IP_ADDRESS,
     r"\b(?:\d{1,3}\.){3}\d{1,3}\b", 0.80),
    (PIIType.PASSWORD,
     r"\b(?:password|passwd|pwd|secret|memorable\s*word)\s*[:\-=]\s*\S+", 0.90),
    (PIIType.MOTHERS_MAIDEN_NAME,
     r"\b(?:mother[\'s]*\s*maiden\s*name|maiden\s*name)\s*[:\-]?\s*[A-Za-z\-]+\b", 0.95),
    (PIIType.BIOMETRIC_REFERENCE,
     r"\b(?:fingerprint|retinal?\s*scan|facial\s*recognition|voice\s*print|biometric)\b", 0.90),
]

_COMPILED_PATTERNS = [
    (t, re.compile(p, re.IGNORECASE), s) for t, p, s in _REGEX_PATTERNS
]


def _luhn_check(number):
    digits = [int(d) for d in number if d.isdigit()]
    odd_digits = digits[-1::-2]
    even_digits = digits[-2::-2]
    total = sum(odd_digits)
    for d in even_digits:
        total += sum(divmod(d * 2, 10))
    return total % 10 == 0


def _line_offsets(text):
    offsets = [0]
    for line in text.split("\n")[:-1]:
        offsets.append(offsets[-1] + len(line) + 1)
    return offsets


def _line_for(offsets, pos):
    ln = 1
    for i, o in enumerate(offsets):
        if o <= pos:
            ln = i + 1
    return ln


def detect_pii_regex(text):
    offsets = _line_offsets(text)
    matches = []
    for pii_type, pattern, base_score in _COMPILED_PATTERNS:
        for m in pattern.finditer(text):
            score = base_score
            matched_text = m.group()
            if pii_type == PIIType.CREDIT_CARD_NUMBER:
                if not _luhn_check(re.sub(r"\D", "", matched_text)):
                    continue
                score = 0.95
            matches.append(PIIMatch(
                pii_type=pii_type, text=matched_text,
                start=m.start(), end=m.end(),
                score=score, source="regex",
                line_number=_line_for(offsets, m.start()),
            ))
    return matches


_presidio_analyzer = None

def _get_presidio_analyzer():
    global _presidio_analyzer
    if _presidio_analyzer is not None:
        return _presidio_analyzer
    try:
        from presidio_analyzer import AnalyzerEngine, PatternRecognizer, Pattern
        from presidio_analyzer.nlp_engine import NlpEngineProvider
        provider = NlpEngineProvider(nlp_configuration={
            "nlp_engine_name": "spacy",
            "models": [{"lang_code": "en", "model_name": "en_core_web_lg"}],
        })
        analyzer = AnalyzerEngine(nlp_engine=provider.create_engine(), supported_languages=["en"])
        for name, regex, score, entity in [
            ("cvv", r"\b(?:CVV2?|CVC2?|CSC)\s*[:\-]?\s*\d{3,4}\b", 0.95, "CVV"),
            ("routing", r"\b(?:routing\s*(?:number)?|ABA)\s*[:\-]?\s*[0123]\d{8}\b", 0.90, "BANK_ROUTING_NUMBER"),
            ("pin", r"\b(?:PIN|pin)\s*[:\-]?\s*\d{4,6}\b", 0.95, "PIN"),
            ("mmn", r"\b(?:mother[\'s]*\s*maiden\s*name|maiden\s*name)\s*[:\-]?\s*[A-Za-z\-]+\b", 0.95, "MOTHERS_MAIDEN_NAME"),
            ("bio", r"\b(?:fingerprint|retinal?\s*scan|facial\s*recognition|voice\s*print|biometric)\b", 0.90, "BIOMETRIC_REFERENCE"),
        ]:
            analyzer.registry.add_recognizer(PatternRecognizer(
                supported_entity=entity, patterns=[Pattern(name=name, regex=regex, score=score)]
            ))
        _presidio_analyzer = analyzer
        return analyzer
    except Exception:
        return None


_PRESIDIO_MAP = {
    "PERSON": PIIType.PERSON_NAME, "EMAIL_ADDRESS": PIIType.EMAIL_ADDRESS,
    "PHONE_NUMBER": PIIType.PHONE_NUMBER, "US_SSN": PIIType.SSN,
    "US_PASSPORT": PIIType.PASSPORT, "US_DRIVER_LICENSE": PIIType.DRIVERS_LICENSE,
    "US_BANK_NUMBER": PIIType.BANK_ACCOUNT_NUMBER, "CREDIT_CARD": PIIType.CREDIT_CARD_NUMBER,
    "IP_ADDRESS": PIIType.IP_ADDRESS, "LOCATION": PIIType.HOME_ADDRESS,
    "DATE_TIME": PIIType.DATE_OF_BIRTH, "CVV": PIIType.CVV,
    "BANK_ROUTING_NUMBER": PIIType.BANK_ROUTING_NUMBER, "PIN": PIIType.PIN,
    "MOTHERS_MAIDEN_NAME": PIIType.MOTHERS_MAIDEN_NAME,
    "BIOMETRIC_REFERENCE": PIIType.BIOMETRIC_REFERENCE,
}


def detect_pii_presidio(text):
    analyzer = _get_presidio_analyzer()
    if not analyzer:
        return []
    offsets = _line_offsets(text)
    matches = []
    for r in analyzer.analyze(text=text, language="en"):
        pii_type = _PRESIDIO_MAP.get(r.entity_type)
        if not pii_type:
            continue
        matches.append(PIIMatch(
            pii_type=pii_type, text=text[r.start:r.end],
            start=r.start, end=r.end, score=r.score, source="presidio",
            line_number=_line_for(offsets, r.start),
        ))
    return matches


_spacy_nlp = None

def _get_spacy_nlp():
    global _spacy_nlp
    if _spacy_nlp is not None:
        return _spacy_nlp
    try:
        import spacy
        _spacy_nlp = spacy.load("en_core_web_lg")
        return _spacy_nlp
    except Exception:
        return None


def detect_pii_spacy(text):
    nlp = _get_spacy_nlp()
    if not nlp:
        return []
    offsets = _line_offsets(text)
    spacy_map = {
        "PERSON": (PIIType.PERSON_NAME, 0.75), "GPE": (PIIType.HOME_ADDRESS, 0.60),
        "LOC": (PIIType.HOME_ADDRESS, 0.55), "DATE": (PIIType.DATE_OF_BIRTH, 0.50),
    }
    matches = []
    for ent in nlp(text).ents:
        mapping = spacy_map.get(ent.label_)
        if mapping and mapping[0]:
            matches.append(PIIMatch(
                pii_type=mapping[0], text=ent.text,
                start=ent.start_char, end=ent.end_char,
                score=mapping[1], source="spacy",
                line_number=_line_for(offsets, ent.start_char),
            ))
    return matches


TOXIC_COMBINATIONS = [
    ({PIIType.BANK_ACCOUNT_NUMBER, PIIType.PERSON_NAME},
     "Bank Account + Name: MUST be tokenised or encrypted"),
    ({PIIType.BANK_ACCOUNT_NUMBER, PIIType.HOME_ADDRESS},
     "Bank Account + Address: MUST be tokenised or encrypted"),
    ({PIIType.PAN, PIIType.PERSON_NAME},
     "PAN + Name: MUST be tokenised or encrypted (PCI-DSS)"),
    ({PIIType.BANK_ROUTING_NUMBER, PIIType.BANK_ACCOUNT_NUMBER},
     "Routing + Account Number: forms toxic combination — MUST be tokenised or encrypted"),
]


def detect_pii(text, use_presidio=True, use_spacy=True, use_regex=True,
               min_score=0.5, line_text: str = ""):
    """
    Detect PII in text.
    line_text: the raw log line (used for exception suppression).
               If empty, 'text' itself is used as the line context.
    Returns (matches, suppressed) tuple — suppressed are exception-filtered records.
    """
    from app.exceptions import apply_exceptions

    all_matches = []
    if use_presidio:
        all_matches.extend(detect_pii_presidio(text))
    if use_spacy:
        all_matches.extend(detect_pii_spacy(text))
    if use_regex:
        all_matches.extend(detect_pii_regex(text))

    all_matches = [m for m in all_matches if m.score >= min_score]
    all_matches.sort(key=lambda m: (m.start, -(m.end - m.start), -m.score))

    deduplicated = []
    last_end = -1
    for match in all_matches:
        if match.start >= last_end:
            deduplicated.append(match)
            last_end = match.end
        elif match.score > deduplicated[-1].score:
            deduplicated[-1] = match

    deduplicated = sorted(deduplicated, key=lambda m: m.start)

    # Apply exception rules
    ctx = line_text or text
    deduplicated, suppressed = apply_exceptions(deduplicated, ctx)

    # Mark toxic combinations
    detected_types = {m.pii_type for m in deduplicated}
    toxic_types: set = set()
    for combo, _ in TOXIC_COMBINATIONS:
        if combo.issubset(detected_types):
            toxic_types.update(combo)
    for m in deduplicated:
        if m.pii_type in toxic_types:
            m.is_toxic = True

    return deduplicated, suppressed


def get_risk_summary(matches, filename="", suppressed=None):
    detected_types = {m.pii_type for m in matches}
    toxic_flags = [w for combo, w in TOXIC_COMBINATIONS if combo.issubset(detected_types)]
    severity_counts = {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0}
    for m in matches:
        severity_counts[m.severity] = severity_counts.get(m.severity, 0) + 1
    return {
        "filename":                   filename,
        "total_detections":           len(matches),
        "suppressed_count":           len(suppressed) if suppressed else 0,
        "severity_counts":            severity_counts,
        "pii_types_found":            sorted([t.value for t in detected_types]),
        "toxic_combination_warnings": toxic_flags,
        "has_must_encrypt":           PIIType.BIOMETRIC_REFERENCE in detected_types,
        "detections":                 [m.to_dict() for m in matches],
        "suppressed":                 suppressed or [],
    }


def anonymize_text(text, matches):
    result = list(text)
    for match in sorted(matches, key=lambda m: m.start, reverse=True):
        result[match.start:match.end] = list(f"[{match.pii_type.value}]")
    return "".join(result)
