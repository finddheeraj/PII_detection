"""
app_run.py
──────────
Standalone launcher for the Barclays PII Detection Tool.

Steps:
  1. Install / verify all Python dependencies
  2. Download spaCy English model if not present
  3. Train the ML model (first run only, ~1 min)
  4. Train the Ensemble model (first run only, ~2–3 min)
  5. Start the Flask server on localhost:7860
  6. Auto-open browser

Usage:
    python app_run.py

Stop: press Ctrl+C
"""

import sys
import time
import subprocess
import threading
import webbrowser
from pathlib import Path

ROOT = Path(__file__).parent
sys.path.insert(0, str(ROOT))

PORT = 7860
URL  = f"http://localhost:{PORT}"

print()
print("╔══════════════════════════════════════════════════════╗")
print("║        Barclays PII Detection Tool — Starting        ║")
print("╚══════════════════════════════════════════════════════╝")
print()

# ── Step 1: Dependencies ─────────────────────────────────────────
print("[1/4] Checking Python dependencies...")
req = ROOT / "requirements.txt"
if req.exists():
    subprocess.run(
        [sys.executable, "-m", "pip", "install", "-r", str(req), "-q", "--no-warn-script-location"],
        check=False
    )
    print("      ✓ Dependencies OK")

# ── Step 2: spaCy model ──────────────────────────────────────────
print("[2/4] Checking spaCy model...")
try:
    import spacy
    spacy.load("en_core_web_sm")
    print("      ✓ spaCy model ready")
except Exception:
    print("      Downloading spaCy model (en_core_web_sm)...")
    subprocess.run(
        [sys.executable, "-m", "spacy", "download", "en_core_web_sm"],
        check=False
    )
    print("      ✓ spaCy model downloaded")

# ── Step 3: ML model (TF-IDF + LR fallback) ─────────────────────
print("[3/4] Checking ML model...")
from models.ml_model import MODEL_PATH
if not MODEL_PATH.exists():
    print("      Training base ML model (first run — ~1 minute)...")
    from models.ml_model import train as train_ml
    train_ml(n_samples=3000, verbose=False)
    print("      ✓ ML model trained and saved")
else:
    print(f"      ✓ ML model found at {MODEL_PATH.name}")

# ── Step 4: Ensemble model ───────────────────────────────────────
print("[4/4] Checking Ensemble model...")
from models.ensemble_model import ENSEMBLE_PATH, EnsembleModel
if not ENSEMBLE_PATH.exists():
    print("      Training 4-model Ensemble (first run — ~2–3 minutes)...")
    print("      [ CharLR + WordNB + SVM + MLP → Stacking meta-learner ]")
    m = EnsembleModel()
    m.train(n_samples=5000, verbose=True)
    print("      ✓ Ensemble model trained and saved")
else:
    print(f"      ✓ Ensemble model found at {ENSEMBLE_PATH.name}")

# ── Step 5: Start Flask ──────────────────────────────────────────
print()
print(f"  Starting server → {URL}")
print(f"  Press Ctrl+C to stop")
print()

from flask_app.app import app


def _open_browser():
    time.sleep(1.8)
    webbrowser.open(URL)


threading.Thread(target=_open_browser, daemon=True).start()

try:
    app.run(
        host="0.0.0.0",
        port=PORT,
        debug=False,
        use_reloader=False,
        threaded=True,
    )
except KeyboardInterrupt:
    print("\n  Server stopped. Goodbye.")
