"""
flask_app/app.py
────────────────
Flask server for the Barclays PII Detection Solution.

Routes:
  GET  /                      → Main UI
  POST /api/scan/text         → Scan pasted text
  POST /api/scan/file         → Scan uploaded file or ZIP folder
  GET  /api/feedback/summary  → Feedback stats
  POST /api/feedback          → Submit FP / TP feedback
  POST /api/retrain           → Retrain ensemble with all feedback
  GET  /api/accuracy          → Run accuracy evaluation
"""

import os
import sys
import json
import tempfile
import zipfile
from pathlib import Path
from flask import Flask, request, jsonify, render_template

ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(ROOT))

from core.detector import scan_text, scan_file
from core.pii_patterns import LABEL_COLORS

app = Flask(__name__, template_folder="templates", static_folder=None)
app.config["MAX_CONTENT_LENGTH"] = 100 * 1024 * 1024  # 100 MB


# ─────────────────────────────────────────────────────────────────
#  UI
# ─────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    return render_template("index.html")


# ─────────────────────────────────────────────────────────────────
#  Scan: Text
# ─────────────────────────────────────────────────────────────────

@app.route("/api/scan/text", methods=["POST"])
def api_scan_text():
    data      = request.get_json(force=True)
    text      = data.get("text", "").strip()
    use_spacy = data.get("use_spacy", True)
    use_ml    = data.get("use_ml", True)
    min_conf  = data.get("min_confidence", "MEDIUM")

    if not text:
        return jsonify({"error": "No text provided"}), 400

    result = scan_text(text, use_spacy=use_spacy,
                       use_ml=use_ml, min_confidence=min_conf)
    return jsonify(_serialise(result))


# ─────────────────────────────────────────────────────────────────
#  Scan: File / ZIP folder
# ─────────────────────────────────────────────────────────────────

@app.route("/api/scan/file", methods=["POST"])
def api_scan_file():
    use_spacy = request.form.get("use_spacy", "true").lower() == "true"
    use_ml    = request.form.get("use_ml",    "true").lower() == "true"
    min_conf  = request.form.get("min_confidence", "MEDIUM")

    if "file" not in request.files:
        return jsonify({"error": "No file uploaded"}), 400

    f = request.files["file"]
    if not f.filename:
        return jsonify({"error": "Empty filename"}), 400

    suffix = Path(f.filename).suffix.lower()

    if suffix == ".zip":
        return _scan_zip(f, use_spacy, use_ml, min_conf)

    with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
        f.save(tmp.name)
        tmp_path = tmp.name

    try:
        result = scan_file(tmp_path, use_spacy=use_spacy,
                           use_ml=use_ml, min_confidence=min_conf)
        result["filename"] = f.filename
        return jsonify(_serialise(result))
    finally:
        try:
            os.unlink(tmp_path)
        except Exception:
            pass


def _scan_zip(zip_file_obj, use_spacy, use_ml, min_conf):
    """Extract ZIP and scan all text files inside."""
    ALLOWED = {".txt", ".log", ".csv", ".json", ".xml", ".md"}
    all_detections = []
    file_summaries = []
    total_pii      = 0

    with tempfile.TemporaryDirectory() as tmp_dir:
        zip_path = Path(tmp_dir) / "upload.zip"
        zip_file_obj.save(str(zip_path))
        try:
            with zipfile.ZipFile(zip_path, "r") as zf:
                zf.extractall(tmp_dir)
        except zipfile.BadZipFile:
            return jsonify({"error": "Invalid ZIP file"}), 400

        files = sorted(
            [f for f in Path(tmp_dir).rglob("*")
             if f.suffix.lower() in ALLOWED and f.is_file()],
            key=lambda p: p.name
        )

        for fpath in files:
            try:
                res       = scan_file(str(fpath), use_spacy=use_spacy,
                                      use_ml=use_ml, min_confidence=min_conf)
                pii_count = res.get("total_pii", 0)
                total_pii += pii_count
                file_summaries.append({
                    "filename":   fpath.name,
                    "total_pii":  pii_count,
                    "summary":    res.get("summary", {}),
                    "line_results": [
                        {
                            "line_no":    lr["line_no"],
                            "text":       lr["text"],
                            "detections": [_det_dict(d) for d in lr["detections"]]
                        }
                        for lr in res.get("line_results", [])
                        if lr["detections"]
                    ]
                })
                for d in res.get("detections", []):
                    d["filename"] = fpath.name
                    all_detections.append(_det_dict(d))
            except Exception as e:
                file_summaries.append({"filename": fpath.name, "error": str(e)})

    from collections import Counter
    sev_counts = Counter(d.get("severity", "MEDIUM") for d in all_detections)
    lbl_counts = Counter(d.get("label", "")          for d in all_detections)

    return jsonify({
        "scan_type":       "folder",
        "total_pii":       total_pii,
        "files_scanned":   len(files),
        "summary":         dict(lbl_counts),
        "severity_counts": dict(sev_counts),
        "file_summaries":  file_summaries,
        "detections":      all_detections,
    })


# ─────────────────────────────────────────────────────────────────
#  Feedback
# ─────────────────────────────────────────────────────────────────

@app.route("/api/feedback", methods=["POST"])
def api_feedback():
    data    = request.get_json(force=True)
    text    = data.get("text", "").strip()
    label   = data.get("label", "").strip()
    is_fp   = data.get("is_fp", True)
    context = data.get("context", "")
    if not text or not label:
        return jsonify({"error": "text and label required"}), 400
    try:
        from models.ensemble_model import load_ensemble
        ensemble = load_ensemble()
        ensemble.record_feedback(text, label, is_fp=is_fp, context=context)
        return jsonify({"ok": True, "summary": ensemble.feedback_summary()})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/feedback/summary", methods=["GET"])
def api_feedback_summary():
    try:
        from models.ensemble_model import load_ensemble
        return jsonify(load_ensemble().feedback_summary())
    except Exception as e:
        return jsonify({"error": str(e), "total": 0, "fps": 0,
                        "tps": 0, "veto_trained": False, "by_label": {}})


@app.route("/api/retrain", methods=["POST"])
def api_retrain():
    data      = request.get_json(force=True) or {}
    n_samples = int(data.get("n_samples", 5000))
    try:
        from models.ensemble_model import load_ensemble
        load_ensemble().retrain_from_feedback(n_base_samples=n_samples, verbose=True)
        return jsonify({"ok": True,
                        "message": f"Retrained with {n_samples} base samples + all feedback"})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ─────────────────────────────────────────────────────────────────
#  Accuracy evaluation
# ─────────────────────────────────────────────────────────────────

@app.route("/api/accuracy", methods=["GET"])
def api_accuracy():
    use_spacy = request.args.get("use_spacy", "true").lower() == "true"
    use_ml    = request.args.get("use_ml",    "true").lower() == "true"
    try:
        from tests.accuracy import evaluate
        metrics = evaluate(use_spacy=use_spacy, use_ml=use_ml, verbose=False)
        return jsonify({
            "overall":         metrics["overall"],
            "per_label":       metrics["per_label"],
            "n_test_cases":    metrics["n_test_cases"],
            "n_passed":        metrics["n_passed"],
            "confidence_dist": metrics["confidence_dist"],
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500


# ─────────────────────────────────────────────────────────────────
#  Helpers
# ─────────────────────────────────────────────────────────────────

def _det_dict(d: dict) -> dict:
    return {
        "label":      d.get("label", ""),
        "text":       d.get("text", ""),
        "severity":   d.get("severity", "MEDIUM"),
        "confidence": d.get("final_confidence", "MEDIUM"),
        "context":    d.get("context", "")[:120],
        "line_no":    d.get("line_no"),
        "start":      d.get("start"),
        "end":        d.get("end"),
        "method":     d.get("method", "REGEX"),
        "color":      LABEL_COLORS.get(d.get("label", ""), "#ADB5BD"),
        "fp_penalty": round(d.get("fp_penalty", 0.0), 3),
    }


def _serialise(result: dict) -> dict:
    out = dict(result)
    out["detections"] = [_det_dict(d) for d in result.get("detections", [])]
    if "line_results" in out:
        out["line_results"] = [
            {
                "line_no":    lr["line_no"],
                "text":       lr["text"],
                "detections": [_det_dict(d) for d in lr["detections"]]
            }
            for lr in out["line_results"] if lr["detections"]
        ]
    out.pop("redacted_text", None)
    return out


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=7860, debug=False)
