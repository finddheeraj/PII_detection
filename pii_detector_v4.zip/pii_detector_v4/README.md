# Barclays PII Detection Tool

Hybrid Regex + ML + Ensemble PII detector for UK · Jersey · Geneva · Monaco · EU data.

---

## Quick Start

```bash
python app_run.py
```

Browser opens automatically at http://localhost:7860

**First run:** Models train automatically (~3–4 minutes total). Subsequent starts are instant.

---

## Architecture

```
app_run.py                  ← Launch script (run this)
flask_app/
  app.py                    ← Flask server + REST API
  templates/index.html      ← Barclays-styled UI (4 tabs)
core/
  detector.py               ← 3-layer detection pipeline
  pii_patterns.py           ← 20+ regex patterns + context keywords
models/
  ml_model.py               ← Layer 3a: TF-IDF + Logistic Regression (fallback)
  ensemble_model.py         ← Layer 3b: 4-model ensemble + stacking + veto
data/
  data_generator.py         ← Synthetic training data (Faker, UK/EU locales)
tests/
  accuracy.py               ← Ground-truth evaluation (50+ test cases)
```

---

## Detection Pipeline

| Layer | What it does |
|-------|-------------|
| **Regex** | Fast, high-precision matching of structured PII (NIN, IBAN, sort code, DOB, etc.) |
| **spaCy NER** | Statistical model for PERSON_NAME and LOCATION |
| **ML Ensemble** | 4-model ensemble (CharLR + WordNB + SVM + MLP) with stacking meta-learner |
| **Veto Classifier** | Online SGD classifier that learns from user FP feedback immediately |

---

## Machine Learning Details

### Base Learners (Layer 1)
- **CharLR** — TF-IDF char n-grams (2–5) + Logistic Regression — high precision
- **WordNB** — TF-IDF word n-grams (1–3) + Complement Naive Bayes — robust to noise
- **SVM** — TF-IDF char n-grams (3–6) + Calibrated Linear SVM — high recall
- **MLP** — TF-IDF char n-grams (2–4) + Neural Network (256→128) — non-linear patterns

### Stacking Meta-Learner (Layer 2)
- Logistic Regression trained on 5-fold OOF probability outputs from all 4 base models
- Combined with 15 contextual features (log-line detection, digit density, char entropy, etc.)
- Learns when to trust each base model per PII type

### Online Feedback Loop (Reinforcement-style)
- **Veto Classifier** — SGD classifier updated incrementally on each FP/TP flag
- **Pattern Memory** — n-gram similarity to known FP examples (works from 1st sample)
- **Full Retrain** — rebuilds entire ensemble with feedback-corrected labels baked in

---

## PII Types Detected

EMAIL, UK_NIN, UK_DRIVING_LICENCE, UK_POSTCODE, UK_SORT_CODE, UK_BANK_ACCOUNT,
IBAN, BIC_SWIFT, SWISS_AHV, EU_VAT, PHONE_UK, PHONE_EU, CREDIT_CARD, CVV, PAN,
SSN, DOB, PASSPORT, IP_ADDRESS, HOME_ADDRESS, MOTHERS_MAIDEN_NAME, PASSWORD,
PERSON_NAME, LOCATION

---

## API Endpoints

| Method | Route | Description |
|--------|-------|-------------|
| POST | `/api/scan/text` | Scan plain text |
| POST | `/api/scan/file` | Scan file or ZIP folder |
| POST | `/api/feedback` | Submit FP / TP feedback |
| GET  | `/api/feedback/summary` | Get learning stats |
| POST | `/api/retrain` | Full ensemble retrain |
| GET  | `/api/accuracy` | Run accuracy evaluation |

---

## Requirements

Python 3.9+ recommended.

```
pip install -r requirements.txt
```
