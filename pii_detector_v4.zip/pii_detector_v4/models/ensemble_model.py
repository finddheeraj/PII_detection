"""
ensemble_model.py
─────────────────
Multi-layer Ensemble PII Classifier.

Architecture:
  Layer 1 — Base learners (trained in parallel on same data):
    • TF-IDF char n-grams  +  Logistic Regression   (fast, high-precision)
    • TF-IDF word n-grams  +  Complement Naive Bayes (great for short noisy text)
    • TF-IDF char n-grams  +  Linear SVM (calibrated) (high-recall)
    • TF-IDF mixed         +  MLP Neural Network      (non-linear patterns)

  Layer 2 — Meta-learner (Stacking):
    • Logistic Regression trained on the probability outputs of layer-1
    • Learns WHEN to trust each base model for each PII type

  Layer 3 — Contextual Feature Augmentation:
    • Hand-crafted features injected alongside TF-IDF:
      - Is this a log-line? (timestamp/level markers)
      - Does the span contain only digits?
      - Does surrounding context have PII keywords?
      - Character entropy of the span
      - Is the span an IP-address-like pattern?
    • These features let the stacker override base-model predictions
      for ambiguous cases (the main source of false positives)

  Online Feedback Loop (Reinforcement-style):
    • Users can flag detections as FP (false positive) or FN (false negative)
    • Feedback is stored in a local SQLite database
    • A lightweight SGD classifier is incrementally updated from feedback
    • The SGD veto score is blended into the final confidence
    • This simulates a reward signal: FP flag → penalise, FN flag → reward

Usage:
    from models.ensemble_model import EnsembleModel
    model = EnsembleModel()
    model.train(n_samples=5000)
    results = model.predict_with_confidence(["text span 1", "text span 2"])
    # After user flags a FP:
    model.record_feedback("7472 Getting Product", "HOME_ADDRESS", is_fp=True)
"""

import re
import math
import sqlite3
import joblib
import numpy as np
from pathlib import Path
from typing import List, Dict, Tuple, Optional
from collections import Counter

from sklearn.pipeline import Pipeline, FeatureUnion
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression, SGDClassifier
from sklearn.svm import LinearSVC
from sklearn.naive_bayes import ComplementNB
from sklearn.neural_network import MLPClassifier
from sklearn.calibration import CalibratedClassifierCV
from sklearn.model_selection import train_test_split, StratifiedKFold
from sklearn.metrics import classification_report, accuracy_score
from sklearn.preprocessing import LabelEncoder
import scipy.sparse as sp

# ── Paths ─────────────────────────────────────────────────────────
MODEL_DIR      = Path(__file__).parent
ENSEMBLE_PATH  = MODEL_DIR / "ensemble_pii_model.joblib"
FEEDBACK_DB    = MODEL_DIR / "feedback.db"
VETO_PATH      = MODEL_DIR / "veto_model.joblib"


# ─────────────────────────────────────────────────────────────────
#  CONTEXTUAL FEATURE EXTRACTOR
# ─────────────────────────────────────────────────────────────────

class ContextualFeatureExtractor(BaseEstimator, TransformerMixin):
    """
    Extracts hand-crafted boolean/numeric features from text spans.
    These are critical for distinguishing PII from log-line artefacts.
    """

    # Regex guards
    _LOG_MARKERS    = re.compile(
        r'\b(INF|INFO|ERR|ERROR|WARN|WARNING|DBG|DEBUG|TRACE|FATAL)\b'
        r'|\d{2}[\/\-]\d{2}[\/\-]\d{2,4}'   # date prefix
        r'|\d{2}:\d{2}:\d{2}',               # time prefix
        re.IGNORECASE
    )
    _DUAL_NUMS      = re.compile(r'\b\d{4,}\s+\d{4,}\b')
    _IP_LIKE        = re.compile(r'\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b')
    _EMAIL_LIKE     = re.compile(r'\b\S+@\S+\.\S+\b')
    _PHONE_LIKE     = re.compile(r'(\+?[\d\s\-]{9,15})')
    _PII_KEYWORDS   = re.compile(
        r'\b(address|email|password|iban|passport|nin|dob|date\s*of\s*birth|'
        r'sort\s*code|account|phone|mobile|credit\s*card|postcode|ssn|cvv)\b',
        re.IGNORECASE
    )
    _LOG_VERBS      = re.compile(
        r'\b(Getting|Setting|Loading|Processing|Sending|Receiving|Fetching|'
        r'Updating|Creating|Deleting|Starting|Stopping|Connecting|Executing|'
        r'Initialising|Initializing|Product|Group|Request|Response|Service|'
        r'Thread|Session|Worker|Task|Queue|Cache)\b',
        re.IGNORECASE
    )
    _UPPERCASE_WORD = re.compile(r'\b[A-Z]{3,}\b')

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        return np.array([self._features(text) for text in X], dtype=np.float32)

    def _features(self, text: str) -> List[float]:
        t = text or ""
        digits_only = re.sub(r'\D', '', t)
        words       = t.split()
        total_chars = max(len(t), 1)

        # ── Feature 1: Is it a log line?
        f_is_log = float(bool(self._LOG_MARKERS.search(t)))

        # ── Feature 2: Dual large numbers (thread/PID pattern)
        f_dual_nums = float(bool(self._DUAL_NUMS.search(t)))

        # ── Feature 3: All-digits span
        f_all_digits = float(len(digits_only) / total_chars > 0.7)

        # ── Feature 4: Digit density
        f_digit_density = len(digits_only) / total_chars

        # ── Feature 5: Character entropy (random strings have high entropy)
        f_entropy = self._entropy(t)

        # ── Feature 6: IP-like pattern present
        f_ip_like = float(bool(self._IP_LIKE.search(t)))

        # ── Feature 7: Email-like pattern
        f_email_like = float(bool(self._EMAIL_LIKE.search(t)))

        # ── Feature 8: PII-related keyword in context
        f_pii_keyword = float(bool(self._PII_KEYWORDS.search(t)))

        # ── Feature 9: Log verb present (strong FP indicator for HOME_ADDRESS)
        f_log_verb = float(bool(self._LOG_VERBS.search(t)))

        # ── Feature 10: Uppercase-only words (log level abbreviations)
        upper_count = len(self._UPPERCASE_WORD.findall(t))
        f_upper_ratio = upper_count / max(len(words), 1)

        # ── Feature 11: Word count
        f_word_count = min(len(words) / 20.0, 1.0)

        # ── Feature 12: Starts with digits
        f_starts_digit = float(bool(t) and t[0].isdigit())

        # ── Feature 13: Phone-like pattern
        f_phone_like = float(bool(self._PHONE_LIKE.search(t)))

        # ── Feature 14: Has @ symbol
        f_has_at = float('@' in t)

        # ── Feature 15: Has separators typical of structured IDs
        f_has_separators = float(bool(re.search(r'[\-\/\.]', t)))

        return [
            f_is_log, f_dual_nums, f_all_digits, f_digit_density,
            f_entropy, f_ip_like, f_email_like, f_pii_keyword,
            f_log_verb, f_upper_ratio, f_word_count, f_starts_digit,
            f_phone_like, f_has_at, f_has_separators,
        ]

    @staticmethod
    def _entropy(text: str) -> float:
        if not text:
            return 0.0
        counts = Counter(text)
        total  = len(text)
        return -sum((c / total) * math.log2(c / total) for c in counts.values())


# ─────────────────────────────────────────────────────────────────
#  LAYER 1: BASE LEARNER PIPELINES
# ─────────────────────────────────────────────────────────────────

def _make_char_lr() -> Pipeline:
    """TF-IDF char n-grams + Logistic Regression (precision-focused)."""
    return Pipeline([
        ("tfidf", TfidfVectorizer(
            analyzer="char_wb", ngram_range=(2, 5),
            max_features=60_000, sublinear_tf=True,
            strip_accents="unicode", min_df=2,
        )),
        ("clf", LogisticRegression(
            max_iter=1000, C=5.0, class_weight="balanced",
            solver="lbfgs", multi_class="multinomial", n_jobs=-1,
        )),
    ])


def _make_word_nb() -> Pipeline:
    """TF-IDF word n-grams + Complement Naive Bayes (recall-focused, robust to noise)."""
    return Pipeline([
        ("tfidf", TfidfVectorizer(
            analyzer="word", ngram_range=(1, 3),
            max_features=40_000, sublinear_tf=True,
            strip_accents="unicode", min_df=2,
        )),
        ("clf", ComplementNB(alpha=0.3, norm=True)),
    ])


def _make_svm() -> Pipeline:
    """TF-IDF char + calibrated SVM (high-recall, separates linearly)."""
    return Pipeline([
        ("tfidf", TfidfVectorizer(
            analyzer="char_wb", ngram_range=(3, 6),
            max_features=50_000, sublinear_tf=True,
            strip_accents="unicode", min_df=2,
        )),
        ("clf", CalibratedClassifierCV(
            LinearSVC(max_iter=2000, C=1.0, class_weight="balanced"),
            cv=3, method="isotonic",
        )),
    ])


def _make_mlp() -> Pipeline:
    """TF-IDF mixed + MLP (captures non-linear feature interactions)."""
    return Pipeline([
        ("tfidf", TfidfVectorizer(
            analyzer="char_wb", ngram_range=(2, 4),
            max_features=30_000, sublinear_tf=True,
            strip_accents="unicode", min_df=2,
        )),
        ("clf", MLPClassifier(
            hidden_layer_sizes=(256, 128),
            activation="relu", solver="adam",
            max_iter=300, early_stopping=True,
            validation_fraction=0.1, random_state=42,
            alpha=1e-4,
        )),
    ])


# ─────────────────────────────────────────────────────────────────
#  ONLINE FEEDBACK STORE
# ─────────────────────────────────────────────────────────────────

class FeedbackStore:
    """
    SQLite-backed store for user feedback on detections.
    Enables the online/incremental learning loop.
    """

    def __init__(self, db_path: Path = FEEDBACK_DB):
        self.db_path = db_path
        self._init_db()

    def _init_db(self):
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS feedback (
                    id        INTEGER PRIMARY KEY AUTOINCREMENT,
                    text      TEXT    NOT NULL,
                    label     TEXT    NOT NULL,
                    is_fp     INTEGER NOT NULL,  -- 1 = false positive, 0 = true positive
                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
                )
            """)
            conn.commit()

    def add(self, text: str, label: str, is_fp: bool):
        """Record a user-confirmed FP or TP."""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                "INSERT INTO feedback (text, label, is_fp) VALUES (?, ?, ?)",
                (text, label, int(is_fp))
            )
            conn.commit()

    def get_all(self) -> List[Tuple[str, str, bool]]:
        """Return all feedback as (text, label, is_fp) tuples."""
        with sqlite3.connect(self.db_path) as conn:
            rows = conn.execute(
                "SELECT text, label, is_fp FROM feedback ORDER BY id"
            ).fetchall()
        return [(r[0], r[1], bool(r[2])) for r in rows]

    def count(self) -> int:
        with sqlite3.connect(self.db_path) as conn:
            return conn.execute("SELECT COUNT(*) FROM feedback").fetchone()[0]

    def get_fp_patterns(self) -> Dict[str, List[str]]:
        """Return dict of label → [fp_text, ...] for inspection."""
        fp: Dict[str, List[str]] = {}
        for text, label, is_fp in self.get_all():
            if is_fp:
                fp.setdefault(label, []).append(text)
        return fp


# ─────────────────────────────────────────────────────────────────
#  VETO CLASSIFIER (Online / Incremental)
# ─────────────────────────────────────────────────────────────────

class VetoClassifier:
    """
    Lightweight classifier that learns from user feedback.
    Uses two mechanisms:
    1. Pattern memory — character n-gram similarity to known FP examples
       (works from the very first feedback submission)
    2. SGDClassifier — learns generalised FP boundary from contextual features
       (becomes more powerful as feedback accumulates)
    """

    N_FEATURES = 40  # contextual (15) + label hash (25)

    def __init__(self, path: Path = VETO_PATH):
        self.path      = path
        self.extractor = ContextualFeatureExtractor()
        self._fitted   = False
        self._clf      = SGDClassifier(
            loss="modified_huber",
            learning_rate="constant",
            eta0=0.1,
            alpha=1e-4,
            random_state=42,
        )
        self._fp_patterns: Dict[str, List[str]] = {}
        self._tp_patterns: Dict[str, List[str]] = {}
        self._load()

    def _load(self):
        if self.path.exists():
            try:
                saved = joblib.load(self.path)
                self._clf         = saved["clf"]
                self._fitted      = saved.get("fitted", False)
                self._fp_patterns = saved.get("fp_patterns", {})
                self._tp_patterns = saved.get("tp_patterns", {})
            except Exception:
                pass

    def _save(self):
        joblib.dump({
            "clf": self._clf, "fitted": self._fitted,
            "fp_patterns": self._fp_patterns,
            "tp_patterns": self._tp_patterns,
        }, self.path)

    def _featurize(self, text: str, label: str) -> np.ndarray:
        ctx_feats   = self.extractor._features(text)
        label_hash  = hash(label) % 25
        label_feats = [0.0] * 25
        label_feats[label_hash] = 1.0
        return np.array(ctx_feats + label_feats, dtype=np.float32).reshape(1, -1)

    def _ngram_similarity(self, text: str, pattern: str, n: int = 3) -> float:
        """Character n-gram Jaccard similarity."""
        def ngrams(s):
            s = s.lower().strip()
            return set(s[i:i+n] for i in range(len(s) - n + 1))
        a, b = ngrams(text), ngrams(pattern)
        if not a or not b:
            return 0.0
        return len(a & b) / len(a | b)

    def _pattern_memory_score(self, text: str, label: str) -> float:
        """Returns FP score based on similarity to known FP/TP patterns."""
        fp_list = self._fp_patterns.get(label, [])
        tp_list = self._tp_patterns.get(label, [])
        if not fp_list and not tp_list:
            return 0.0
        max_fp_sim = max((self._ngram_similarity(text, p) for p in fp_list), default=0.0)
        max_tp_sim = max((self._ngram_similarity(text, p) for p in tp_list), default=0.0)
        if max_fp_sim > 0.25 and max_fp_sim > max_tp_sim * 1.5:
            return min(1.0, max_fp_sim * 1.5)
        return 0.0

    def partial_fit(self, text: str, label: str, is_fp: bool):
        """Incrementally update model from one feedback sample."""
        store = self._fp_patterns if is_fp else self._tp_patterns
        store.setdefault(label, [])
        if text not in store[label]:
            store[label].append(text[-200:])  # cap per entry

        X = self._featurize(text, label)
        y = np.array([int(is_fp)])
        self._clf.partial_fit(X, y, classes=np.array([0, 1]))
        self._fitted = True
        self._save()

    def predict_fp_proba(self, text: str, label: str) -> float:
        """Return probability that this detection is a false positive."""
        mem_score = self._pattern_memory_score(text, label)
        sgd_score = 0.0
        if self._fitted:
            try:
                X     = self._featurize(text, label)
                proba = self._clf.predict_proba(X)[0]
                sgd_score = float(proba[1]) if len(proba) > 1 else 0.0
            except Exception:
                pass

        total_patterns = sum(len(v) for v in self._fp_patterns.values())
        if total_patterns < 10:
            return mem_score
        elif total_patterns < 50:
            return max(mem_score, sgd_score * 0.5)
        else:
            return max(mem_score, sgd_score)


# ─────────────────────────────────────────────────────────────────
#  MAIN ENSEMBLE MODEL
# ─────────────────────────────────────────────────────────────────

class EnsembleModel:
    """
    3-layer ensemble PII classifier with online feedback loop.

    Training pipeline:
      1. Generate synthetic data (via data_generator)
      2. Train 4 base learners in parallel on full training set
      3. Use StratifiedKFold OOF (out-of-fold) predictions to build
         meta-features for Layer 2
      4. Train meta-learner (stacker) on [base_probas + ctx_features]
      5. Persist all components

    Inference pipeline:
      1. Extract contextual features
      2. Get probability distributions from all 4 base learners
      3. Stack with meta-learner → final class + probability
      4. Query veto classifier → FP penalty
      5. Return adjusted confidence score
    """

    LABELS = [
        "EMAIL", "UK_NIN", "UK_DRIVING_LICENCE", "UK_POSTCODE",
        "UK_SORT_CODE", "UK_BANK_ACCOUNT", "IBAN", "BIC_SWIFT",
        "SWISS_AHV", "EU_VAT", "PHONE_UK", "PHONE_EU",
        "CREDIT_CARD", "CVV", "PAN", "SSN", "DOB", "PASSPORT",
        "IP_ADDRESS", "HOME_ADDRESS", "MOTHERS_MAIDEN_NAME",
        "PASSWORD", "PERSON_NAME", "LOCATION", "NO_PII",
    ]

    def __init__(self):
        self.base_learners: List[Pipeline] = []
        self.meta_learner:  Optional[LogisticRegression] = None
        self.ctx_extractor  = ContextualFeatureExtractor()
        self.feedback_store = FeedbackStore()
        self.veto            = VetoClassifier()
        self.classes_        = self.LABELS
        self._fitted         = False
        self._load()

    # ── Persistence ───────────────────────────────────────────────

    def _load(self):
        if ENSEMBLE_PATH.exists():
            try:
                saved = joblib.load(ENSEMBLE_PATH)
                self.base_learners = saved["base_learners"]
                self.meta_learner  = saved["meta_learner"]
                self.classes_      = saved["classes"]
                self._fitted       = True
                print(f"[Ensemble] Loaded model from {ENSEMBLE_PATH}")
            except Exception as e:
                print(f"[Ensemble] Could not load saved model: {e}")

    def _save(self):
        MODEL_DIR.mkdir(parents=True, exist_ok=True)
        joblib.dump({
            "base_learners": self.base_learners,
            "meta_learner":  self.meta_learner,
            "classes":       self.classes_,
        }, ENSEMBLE_PATH)
        print(f"[Ensemble] Model saved to {ENSEMBLE_PATH}")

    # ── Training ──────────────────────────────────────────────────

    def train(self, n_samples: int = 5000, verbose: bool = True) -> Dict:
        """
        Full training run: generate data → train base learners + stacker.
        """
        import sys
        sys.path.insert(0, str(Path(__file__).parent.parent))
        from data.data_generator import generate_dataset

        if verbose:
            print(f"[Ensemble] Generating {n_samples} samples...")
        dataset = generate_dataset(n_samples)
        texts   = [t for t, _ in dataset]
        labels  = [l for _, l in dataset]

        # Build contextual features (used by stacker)
        if verbose:
            print("[Ensemble] Extracting contextual features...")
        ctx_feats = self.ctx_extractor.transform(texts)

        # ── Layer 1: Base learners ─────────────────────────────────
        base_configs = [
            ("CharLR",  _make_char_lr()),
            ("WordNB",  _make_word_nb()),
            ("SVM",     _make_svm()),
            ("MLP",     _make_mlp()),
        ]

        all_classes = sorted(set(labels))
        self.classes_ = all_classes

        # Generate OOF (Out-Of-Fold) predictions for stacking
        skf          = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
        n            = len(texts)
        n_classes    = len(all_classes)
        n_base       = len(base_configs)
        class_idx    = {c: i for i, c in enumerate(all_classes)}

        oof_proba = np.zeros((n, n_base * n_classes), dtype=np.float32)

        if verbose:
            print(f"[Ensemble] Training {n_base} base learners via 5-fold OOF...")

        for b_idx, (name, pipe) in enumerate(base_configs):
            for fold, (tr_idx, val_idx) in enumerate(skf.split(texts, labels)):
                X_tr  = [texts[i] for i in tr_idx]
                y_tr  = [labels[i] for i in tr_idx]
                X_val = [texts[i] for i in val_idx]

                pipe_fold = (
                    _make_char_lr() if name == "CharLR" else
                    _make_word_nb() if name == "WordNB" else
                    _make_svm()     if name == "SVM"    else
                    _make_mlp()
                )
                pipe_fold.fit(X_tr, y_tr)
                proba = pipe_fold.predict_proba(X_val)

                # Map classes to global order
                fold_classes = list(pipe_fold.classes_)
                for local_i, cls in enumerate(fold_classes):
                    if cls in class_idx:
                        global_i = class_idx[cls]
                        col = b_idx * n_classes + global_i
                        oof_proba[val_idx, col] = proba[:, local_i]

        # Train final base learners on full data
        if verbose:
            print("[Ensemble] Training final base learners on full dataset...")
        self.base_learners = []
        for name, pipe in base_configs:
            if verbose:
                print(f"  → {name}...")
            pipe.fit(texts, labels)
            self.base_learners.append(pipe)

        # ── Layer 2: Stacker (meta-learner) ───────────────────────
        # Input: [OOF base probs] + [contextual features]
        if verbose:
            print("[Ensemble] Training meta-learner (stacker)...")
        meta_X = np.hstack([oof_proba, ctx_feats])
        self.meta_learner = LogisticRegression(
            max_iter=500, C=2.0, class_weight="balanced",
            solver="lbfgs", multi_class="multinomial", n_jobs=-1,
        )
        self.meta_learner.fit(meta_X, labels)

        # ── Evaluate ──────────────────────────────────────────────
        X_tr, X_te, y_tr, y_te = train_test_split(
            texts, labels, test_size=0.15, random_state=42, stratify=labels
        )
        te_ctx    = self.ctx_extractor.transform(X_te)
        te_stack  = self._base_proba_matrix(X_te)
        te_meta_X = np.hstack([te_stack, te_ctx])
        y_pred    = self.meta_learner.predict(te_meta_X)
        acc       = accuracy_score(y_te, y_pred)
        report    = classification_report(y_te, y_pred, zero_division=0)

        if verbose:
            print(f"\n{'='*55}")
            print(f"  ENSEMBLE MODEL RESULTS")
            print(f"{'='*55}")
            print(f"  Accuracy: {acc:.1%}")
            print(report)

        self._fitted = True
        self._save()
        return {"accuracy": acc, "report": report, "classes": all_classes}

    # ── Inference ─────────────────────────────────────────────────

    def _base_proba_matrix(self, texts: List[str]) -> np.ndarray:
        """
        Returns (n_texts, n_base_learners * n_classes) probability matrix.
        Columns are ordered: base0_cls0, base0_cls1 ... baseN_clsM
        """
        n_classes = len(self.classes_)
        class_idx = {c: i for i, c in enumerate(self.classes_)}
        result    = np.zeros((len(texts), len(self.base_learners) * n_classes),
                             dtype=np.float32)

        for b_idx, pipe in enumerate(self.base_learners):
            proba        = pipe.predict_proba(texts)
            base_classes = list(pipe.classes_)
            for local_i, cls in enumerate(base_classes):
                if cls in class_idx:
                    global_i = class_idx[cls]
                    col      = b_idx * n_classes + global_i
                    result[:, col] = proba[:, local_i]

        return result

    def predict_with_confidence(self, texts: List[str]) -> List[Dict]:
        """
        Main inference method. Returns per-span predictions with:
          - label          : predicted PII type
          - confidence     : float 0-1 (ensemble probability)
          - fp_penalty     : veto classifier FP probability
          - adjusted_conf  : confidence after FP penalty applied
          - top3           : top-3 (label, prob) predictions
          - is_pii         : bool — is this real PII after penalties?
        """
        if not self._fitted or not self.base_learners or not self.meta_learner:
            raise RuntimeError("Model not trained. Call .train() first.")

        if not texts:
            return []

        # Layer 1 probabilities
        base_proba = self._base_proba_matrix(texts)

        # Contextual features
        ctx_feats  = self.ctx_extractor.transform(texts)

        # Layer 2 stacker
        meta_X      = np.hstack([base_proba, ctx_feats])
        final_proba = self.meta_learner.predict_proba(meta_X)
        classes     = list(self.meta_learner.classes_)

        results = []
        for i, (text, proba) in enumerate(zip(texts, final_proba)):
            top_idx   = int(np.argmax(proba))
            top_label = classes[top_idx]
            top_conf  = float(proba[top_idx])

            # Top-3
            top3_idx = np.argsort(proba)[::-1][:3]
            top3     = [(classes[j], float(proba[j])) for j in top3_idx]

            # Layer 3: veto classifier FP penalty
            fp_penalty    = self.veto.predict_fp_proba(text, top_label)
            adjusted_conf = max(0.0, top_conf * (1.0 - fp_penalty * 0.7))

            # Threshold: suppress NO_PII and very low confidence
            is_pii = (
                top_label != "NO_PII"
                and adjusted_conf >= 0.35
                and fp_penalty < 0.75   # veto if strongly flagged as FP
            )

            results.append({
                "label":         top_label,
                "confidence":    top_conf,
                "fp_penalty":    fp_penalty,
                "adjusted_conf": adjusted_conf,
                "top3":          top3,
                "is_pii":        is_pii,
            })

        return results

    # ── Feedback / Online Learning ────────────────────────────────

    def record_feedback(self, text: str, label: str, is_fp: bool,
                        context: str = ""):
        """
        Record user feedback on a detection.

        Args:
            text    : The detected value (e.g., "7472 Getting Product")
            label   : The predicted label (e.g., "HOME_ADDRESS")
            is_fp   : True if this was a false positive, False if correct
            context : Optional surrounding context text
        """
        full_text = f"{context} {text}".strip() if context else text
        self.feedback_store.add(full_text, label, is_fp)
        # Incrementally update the veto classifier
        self.veto.partial_fit(full_text, label, is_fp)
        fp_or_tp = "FP" if is_fp else "TP"
        print(f"[Feedback] Recorded {fp_or_tp} for label={label}, "
              f"text='{text[:40]}...' | "
              f"Total feedback: {self.feedback_store.count()}")

    def feedback_summary(self) -> Dict:
        """Return a summary of all recorded feedback."""
        all_fb = self.feedback_store.get_all()
        total  = len(all_fb)
        fps    = sum(1 for _, _, is_fp in all_fb if is_fp)
        tps    = total - fps
        by_label: Dict[str, Dict] = {}
        for text, label, is_fp in all_fb:
            if label not in by_label:
                by_label[label] = {"fp": 0, "tp": 0}
            key = "fp" if is_fp else "tp"
            by_label[label][key] += 1
        return {
            "total": total, "fps": fps, "tps": tps,
            "by_label": by_label,
            "veto_trained": self.veto._fitted,
        }

    def retrain_from_feedback(self, n_base_samples: int = 5000,
                              verbose: bool = True):
        """
        Full retrain that incorporates accumulated feedback into training data.
        Useful after collecting 50+ feedback examples.
        """
        feedback = self.feedback_store.get_all()
        if not feedback:
            print("[Ensemble] No feedback to incorporate. Running standard train.")
            self.train(n_samples=n_base_samples, verbose=verbose)
            return

        # Convert feedback to synthetic training rows
        # FP examples → label them as NO_PII (they were not real PII)
        # TP examples → label them as the correct label (reinforce)
        extra_texts  = []
        extra_labels = []
        for text, label, is_fp in feedback:
            extra_texts.append(text)
            extra_labels.append("NO_PII" if is_fp else label)

        if verbose:
            print(f"[Ensemble] Incorporating {len(extra_texts)} feedback samples "
                  f"({sum(1 for _,_,fp in feedback if fp)} FPs corrected)")

        import sys
        sys.path.insert(0, str(Path(__file__).parent.parent))
        from data.data_generator import generate_dataset

        base_data    = generate_dataset(n_base_samples)
        base_texts   = [t for t, _ in base_data]
        base_labels  = [l for _, l in base_data]

        # Oversample feedback to give it meaningful weight
        oversample = max(1, n_base_samples // max(len(extra_texts), 1) // 5)
        all_texts  = base_texts + extra_texts * oversample
        all_labels = base_labels + extra_labels * oversample

        if verbose:
            fp_count = sum(1 for l in extra_labels if l == "NO_PII")
            print(f"[Ensemble] Training on {len(all_texts)} total samples "
                  f"(incl. {fp_count * oversample} FP corrections)")

        # Use augmented dataset — monkey-patch generate_dataset temporarily
        self._augmented = (all_texts, all_labels)
        self._train_on_data(all_texts, all_labels, verbose=verbose)

    def _train_on_data(self, texts: List[str], labels: List[str],
                       verbose: bool = True):
        """Internal: train ensemble on provided text/label lists."""
        ctx_feats  = self.ctx_extractor.transform(texts)
        all_classes = sorted(set(labels))
        self.classes_ = all_classes
        class_idx    = {c: i for i, c in enumerate(all_classes)}
        n            = len(texts)
        n_classes    = len(all_classes)

        base_configs = [
            ("CharLR", _make_char_lr()),
            ("WordNB", _make_word_nb()),
            ("SVM",    _make_svm()),
            ("MLP",    _make_mlp()),
        ]
        n_base   = len(base_configs)
        skf      = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
        oof_proba = np.zeros((n, n_base * n_classes), dtype=np.float32)

        for b_idx, (name, pipe) in enumerate(base_configs):
            for fold, (tr_idx, val_idx) in enumerate(skf.split(texts, labels)):
                X_tr  = [texts[i] for i in tr_idx]
                y_tr  = [labels[i] for i in tr_idx]
                X_val = [texts[i] for i in val_idx]
                pipe_fold = (
                    _make_char_lr() if name == "CharLR" else
                    _make_word_nb() if name == "WordNB" else
                    _make_svm()     if name == "SVM"    else _make_mlp()
                )
                pipe_fold.fit(X_tr, y_tr)
                proba = pipe_fold.predict_proba(X_val)
                fold_classes = list(pipe_fold.classes_)
                for local_i, cls in enumerate(fold_classes):
                    if cls in class_idx:
                        global_i = class_idx[cls]
                        col = b_idx * n_classes + global_i
                        oof_proba[val_idx, col] = proba[:, local_i]

        self.base_learners = []
        for name, pipe in base_configs:
            pipe.fit(texts, labels)
            self.base_learners.append(pipe)

        meta_X = np.hstack([oof_proba, ctx_feats])
        self.meta_learner = LogisticRegression(
            max_iter=500, C=2.0, class_weight="balanced",
            solver="lbfgs", multi_class="multinomial", n_jobs=-1,
        )
        self.meta_learner.fit(meta_X, labels)
        self._fitted = True
        self._save()


# ─────────────────────────────────────────────────────────────────
#  Compatibility shim for existing detector.py
# ─────────────────────────────────────────────────────────────────

# Global singleton (lazy-loaded)
_ensemble: Optional[EnsembleModel] = None


def load_ensemble() -> EnsembleModel:
    global _ensemble
    if _ensemble is None:
        _ensemble = EnsembleModel()
        if not _ensemble._fitted:
            print("[Ensemble] No trained model found. Training now (this may take ~2 min)...")
            _ensemble.train(n_samples=5000, verbose=True)
    return _ensemble


def predict_with_confidence(texts: List[str], model) -> List[Dict]:
    """
    Drop-in replacement for the old ml_model.predict_with_confidence().
    `model` param is ignored (uses singleton); kept for API compatibility.
    """
    ensemble = load_ensemble()
    raw      = ensemble.predict_with_confidence(texts)
    # Convert to the format detector.py expects
    return [{
        "label":      r["label"],
        "confidence": r["adjusted_conf"],   # use penalty-adjusted score
        "top3":       r["top3"],
        "is_pii":     r["is_pii"],
        "fp_penalty": r["fp_penalty"],
    } for r in raw]


if __name__ == "__main__":
    print("Training Ensemble PII Model...")
    m = EnsembleModel()
    metrics = m.train(n_samples=5000, verbose=True)

    # Quick sanity test
    test_cases = [
        ("05/03/26 INF: 4820 7472 Getting Product Groups", "HOME_ADDRESS", False),
        ("Deliver to 42 Baker Street London",              "HOME_ADDRESS", True),
        ("Login from IP 192.168.1.105",                   "IP_ADDRESS",   True),
        ("user john@example.co.uk logged in",              "EMAIL",        True),
        ("System health check 1024 records processed",     "NO_PII",       False),
    ]
    print("\n=== SANITY CHECK ===")
    results = m.predict_with_confidence([t for t, _, _ in test_cases])
    for (text, expected_label, expect_pii), res in zip(test_cases, results):
        ok = "✅" if (res["is_pii"] == expect_pii) else "❌"
        print(f"{ok} label={res['label']:20s} conf={res['adjusted_conf']:.2f} "
              f"fp_pen={res['fp_penalty']:.2f} | {text[:55]}")
