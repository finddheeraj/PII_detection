"""
detector.py
───────────
Regex + ML Hybrid PII Detector.

Pipeline:
  1. REGEX layer    → fast, high-precision structured PII detection
  2. spaCy NER      → person names, locations from statistical model
  3. ML layer       → sentence-level context classifier for confidence scoring
                      and catching PII regex might miss

Each detection gets:
  - label          : PII type
  - text           : matched value
  - start/end      : character positions
  - regex_match    : bool (did regex find it?)
  - ml_label       : ML classifier prediction for context
  - ml_confidence  : ML confidence score (0-1)
  - final_confidence: combined HIGH / MEDIUM / LOW
  - severity       : CRITICAL / HIGH / MEDIUM / LOW
  - method         : REGEX / SPACY / ML
"""

import re
import sys
from pathlib import Path
from typing import List, Dict, Optional

# Add parent to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from core.pii_patterns import (
    REGEX_PATTERNS, CONTEXT_KEYWORDS,
    LABEL_COLORS, LABEL_SEVERITY
)

_spacy_nlp    = None
_ml_model     = None
_ensemble_mdl = None


def _get_spacy():
    global _spacy_nlp
    if _spacy_nlp is None:
        try:
            import spacy
            _spacy_nlp = spacy.load("en_core_web_sm")
        except Exception:
            _spacy_nlp = False
    return _spacy_nlp if _spacy_nlp else None


def _get_ensemble():
    """Load the new ensemble model (preferred)."""
    global _ensemble_mdl
    if _ensemble_mdl is None:
        try:
            from models.ensemble_model import load_ensemble
            _ensemble_mdl = load_ensemble()
        except Exception as e:
            print(f"[WARN] Ensemble model unavailable: {e}")
            _ensemble_mdl = False
    return _ensemble_mdl if _ensemble_mdl else None


def _get_ml_model():
    """Legacy TF-IDF+LR model — used as fallback if ensemble not available."""
    global _ml_model
    if _ml_model is None:
        try:
            from models.ml_model import load_model
            _ml_model = load_model()
        except Exception as e:
            print(f"[WARN] ML model unavailable: {e}")
            _ml_model = False
    return _ml_model if _ml_model else None


# ─────────────────────────────────────────────────────────────────
#  Confidence scoring
# ─────────────────────────────────────────────────────────────────

def _context_score(label: str, context: str) -> float:
    """Return 0.0–1.0 context keyword score."""
    kws = CONTEXT_KEYWORDS.get(label, [])
    if not kws:
        return 0.3
    ctx = context.lower()
    hits = sum(1 for kw in kws if kw in ctx)

    # For ambiguous labels that generate many false positives,
    # apply a stricter scoring: zero hits → penalty instead of neutral score
    HIGH_FP_LABELS = {"HOME_ADDRESS", "BIC_SWIFT", "PASSPORT", "PAN"}
    if label in HIGH_FP_LABELS and hits == 0:
        return 0.0   # no context clues → will resolve to LOW / filtered

    return min(1.0, hits / max(len(kws), 1) * 3)


def _combine_confidence(label: str, context: str,
                         ml_conf: float, regex_match: bool,
                         fp_penalty: float = 0.0) -> str:
    """
    Combine regex, context, ML signals, and veto FP penalty → HIGH/MEDIUM/LOW.
    """
    ctx_score = _context_score(label, context)

    score = 0.0
    if regex_match:
        score += 0.5
    score += ctx_score * 0.3
    score += ml_conf   * 0.2

    # Apply veto FP penalty (from online feedback loop)
    # A fp_penalty of 1.0 would halve the score; 0.75 would reduce by ~37%
    score *= max(0.0, 1.0 - fp_penalty * 0.5)

    if score >= 0.65:
        return "HIGH"
    elif score >= 0.35:
        return "MEDIUM"
    else:
        return "LOW"


# ─────────────────────────────────────────────────────────────────
#  Per-label false-positive suppression
# ─────────────────────────────────────────────────────────────────

# Words that should never appear as a "street name" word
_LOG_VERBS = re.compile(
    r'\b(Getting|Setting|Loading|Processing|Sending|Receiving|Fetching|'
    r'Updating|Creating|Deleting|Starting|Stopping|Running|Executing|'
    r'Connecting|Disconnecting|Initialising|Initializing|Product|Group|'
    r'Request|Response|Error|Warning|Debug|Info|Trace|Thread|Session|'
    r'Service|Server|Client|Worker|Task|Job|Queue|Cache|Config)\b',
    re.IGNORECASE
)

# Patterns that look like log/system data rather than real PII
_LOG_CONTEXT_RE = re.compile(
    r'\b(?:INF|ERR|WRN|DBG|WARN|INFO|DEBUG|ERROR|TRACE|FATAL)\b'
    r'|\d{4,}\s+\d{4,}'   # two or more large adjacent numbers (PIDs, thread IDs)
    r'|\bGetting\b|\bSetting\b|\bLoading\b',
    re.IGNORECASE
)

# BIC_SWIFT: must be a realistic SWIFT format (not a random uppercase word)
_SWIFT_RE = re.compile(r'^[A-Z]{4}[A-Z]{2}[A-Z0-9]{2}(?:[A-Z0-9]{3})?$')

# PASSPORT: must be followed/preceded by passport-related context within 50 chars
_PASSPORT_CTX_RE = re.compile(
    r'\b(passport|travel|document|identity|id\b|national)',
    re.IGNORECASE
)

# PAN: block pure sequential or all-same numbers
def _is_plausible_pan(val: str) -> bool:
    digits = re.sub(r'\D', '', val)
    if len(digits) < 13:
        return False
    # Reject all-same digit
    if len(set(digits)) == 1:
        return False
    # Reject sequential runs
    seq_asc = ''.join(str(i % 10) for i in range(len(digits)))
    seq_desc = seq_asc[::-1]
    if digits == seq_asc or digits == seq_desc:
        return False
    return True


def _validate_detection(label: str, val: str, full_text: str, is_log_line: bool) -> bool:
    """
    Return False to suppress a detection that is likely a false positive.
    Applies targeted rules per label.
    """
    if label == "HOME_ADDRESS":
        # Reject if any word in the matched value looks like a log verb/keyword
        if _LOG_VERBS.search(val):
            return False
        # Reject if the full text looks like a log line and the match contains digits
        # in the "street name" portion (e.g., "7472 Getting Product")
        name_part = re.sub(r'^\d+\s+', '', val)  # strip house number
        if re.search(r'\d', name_part):           # digits in street name → reject
            return False
        # Reject if context around match has log-like markers
        if is_log_line and _LOG_CONTEXT_RE.search(full_text):
            return False

    elif label == "BIC_SWIFT":
        # Must match the strict SWIFT format exactly
        if not _SWIFT_RE.match(val):
            return False
        # Suppress if it looks like a plain English word / acronym without context
        ctx_window = full_text.lower()
        if not any(k in ctx_window for k in ["swift", "bic", "bank", "transfer", "wire", "iban"]):
            # Only keep HIGH-confidence hits when no context clue
            return False

    elif label == "PASSPORT":
        # Passport numbers are short and ambiguous — require context
        start_idx = full_text.find(val)
        window = full_text[max(0, start_idx - 60): start_idx + len(val) + 60]
        if not _PASSPORT_CTX_RE.search(window):
            return False

    elif label == "PAN":
        if not _is_plausible_pan(val):
            return False
        # Suppress PANs in log lines that are clearly process/thread IDs
        if is_log_line and len(re.sub(r'\D', '', val)) <= 10:
            return False

    elif label in ("LOCATION", "PERSON_NAME"):
        # spaCy sometimes tags log keywords as names/locations; suppress in log lines
        if is_log_line and len(val.split()) == 1 and val.isupper():
            return False

    return True


# ─────────────────────────────────────────────────────────────────
#  Main detection function
# ─────────────────────────────────────────────────────────────────

def detect_pii(text: str,
               use_spacy: bool = True,
               use_ml: bool = True,
               context_chars: int = 80,
               min_confidence: str = "LOW") -> List[Dict]:
    """
    Run full Regex + ML Hybrid PII detection on text.

    Args:
        text           : Input text string
        use_spacy      : Whether to run spaCy NER layer
        use_ml         : Whether to run ML classifier layer
        context_chars  : Characters around match used for context scoring
        min_confidence : Filter results below this level (LOW/MEDIUM/HIGH)

    Returns:
        List of detection dicts sorted by position.
    """
    if not text or not text.strip():
        return []

    results   = []
    seen_spans = set()

    # ── Pre-check: is this line a log-format line? ───────────────
    # Log lines typically start with a timestamp or process-id block.
    # We track this so we can apply stricter rules for ambiguous patterns.
    _LOG_LINE_RE = re.compile(
        r'(?:'
        r'\d{2}[\/\-]\d{2}[\/\-]\d{2,4}'   # date-like prefix
        r'|\d{2}:\d{2}:\d{2}'               # time prefix
        r'|^\s*\d{4,}\s+\d{4,}'            # two big numbers (PID / thread)
        r'|\bINF\b|\bINFO\b|\bDEBUG\b|\bWARN\b|\bERROR\b|\bTRACE\b'
        r')',
        re.MULTILINE | re.IGNORECASE
    )
    is_log_line = bool(_LOG_LINE_RE.search(text))

    # ── LAYER 1: Regex ────────────────────────────────────────────
    for label, pattern in REGEX_PATTERNS.items():
        for m in pattern.finditer(text):
            # Use group(1) if capturing group, else whole match
            try:
                val   = m.group(1)
                start = m.start(1)
                end   = m.end(1)
            except IndexError:
                val   = m.group(0)
                start = m.start(0)
                end   = m.end(0)

            span_key = (start, end)
            if span_key in seen_spans:
                continue

            # ── Label-specific false-positive guards ──────────────
            if not _validate_detection(label, val, text, is_log_line):
                continue

            seen_spans.add(span_key)

            ctx_start = max(0, start - context_chars)
            ctx_end   = min(len(text), end + context_chars)
            context   = text[ctx_start:ctx_end]

            results.append({
                "text":        val,
                "label":       label,
                "start":       start,
                "end":         end,
                "context":     context,
                "regex_match": True,
                "ml_label":    None,
                "ml_confidence": 0.0,
                "method":      "REGEX",
            })

    # ── LAYER 2: spaCy NER ────────────────────────────────────────
    if use_spacy:
        nlp = _get_spacy()
        if nlp:
            doc = nlp(text)
            SPACY_MAP = {
                "PERSON": "PERSON_NAME",
                "GPE":    "LOCATION",
                "LOC":    "LOCATION",
            }
            for ent in doc.ents:
                if ent.label_ not in SPACY_MAP:
                    continue
                span_key = (ent.start_char, ent.end_char)
                if span_key in seen_spans:
                    continue
                seen_spans.add(span_key)

                context = text[max(0, ent.start_char-context_chars):
                                ent.end_char+context_chars]
                results.append({
                    "text":          ent.text,
                    "label":         SPACY_MAP[ent.label_],
                    "start":         ent.start_char,
                    "end":           ent.end_char,
                    "context":       context,
                    "regex_match":   False,
                    "ml_label":      None,
                    "ml_confidence": 0.0,
                    "method":        "SPACY",
                })

    # ── LAYER 3: ML confidence scoring ───────────────────────────
    if use_ml and results:
        # Prefer the new ensemble model; fall back to legacy LR model
        ensemble = _get_ensemble()
        if ensemble:
            from models.ensemble_model import predict_with_confidence as ens_predict
            contexts  = [r["context"] for r in results]
            ml_preds  = ens_predict(contexts, ensemble)
            for result, ml_pred in zip(results, ml_preds):
                result["ml_label"]      = ml_pred["label"]
                result["ml_confidence"] = ml_pred["confidence"]
                result["ml_top3"]       = ml_pred.get("top3", [])
                result["fp_penalty"]    = ml_pred.get("fp_penalty", 0.0)
                result["method"]        = "ENSEMBLE"
        else:
            model = _get_ml_model()
            if model:
                from models.ml_model import predict_with_confidence
                contexts = [r["context"] for r in results]
                ml_preds = predict_with_confidence(contexts, model)
                for result, ml_pred in zip(results, ml_preds):
                    result["ml_label"]      = ml_pred["label"]
                    result["ml_confidence"] = ml_pred["confidence"]
                    result["ml_top3"]       = ml_pred.get("top3", [])

    # ── Compute final confidence + severity for each result ───────
    confidence_order = {"HIGH": 3, "MEDIUM": 2, "LOW": 1}
    min_order = confidence_order.get(min_confidence, 1)

    final = []
    for r in results:
        conf = _combine_confidence(
            r["label"], r["context"],
            r.get("ml_confidence", 0.0),
            r["regex_match"],
            r.get("fp_penalty", 0.0),
        )
        r["final_confidence"] = conf
        r["severity"]         = LABEL_SEVERITY.get(r["label"], "MEDIUM")
        r["color"]            = LABEL_COLORS.get(r["label"], "#ADB5BD")

        if confidence_order.get(conf, 1) >= min_order:
            final.append(r)

    # Sort by position
    final.sort(key=lambda x: x["start"])
    return final


# ─────────────────────────────────────────────────────────────────
#  Redaction
# ─────────────────────────────────────────────────────────────────

def redact_text(text: str, detections: List[Dict],
                mask: str = "█") -> str:
    """Replace detected PII in text with mask character."""
    chars = list(text)
    for det in detections:
        for i in range(det["start"], det["end"]):
            if i < len(chars) and chars[i] not in (" ", "\t"):
                chars[i] = mask
    return "".join(chars)


# ─────────────────────────────────────────────────────────────────
#  File/folder scanner
# ─────────────────────────────────────────────────────────────────

def scan_text(text: str, **kwargs) -> Dict:
    """Scan a plain text string."""
    detections = detect_pii(text, **kwargs)
    return _build_scan_result(text, detections, source="text_input")


def scan_file(file_path: str, **kwargs) -> Dict:
    """Scan a single file."""
    path = Path(file_path)
    if not path.exists():
        return {"error": f"File not found: {file_path}"}

    with open(path, "r", encoding="utf-8", errors="replace") as f:
        content = f.read()

    lines = content.splitlines()
    all_detections = []
    line_results   = []

    offset = 0
    for line_no, line in enumerate(lines, 1):
        dets = detect_pii(line, **kwargs)
        for d in dets:
            d["line_no"] = line_no
            d["start"]  += offset
            d["end"]    += offset
        all_detections.extend(dets)
        line_results.append({"line_no": line_no, "text": line, "detections": dets})
        offset += len(line) + 1  # +1 for newline

    return _build_scan_result(
        content, all_detections,
        source=str(path),
        line_results=line_results
    )


def scan_folder(folder_path: str,
                extensions: List[str] = None,
                **kwargs) -> Dict:
    """Scan all files in a folder."""
    folder = Path(folder_path)
    if not folder.exists() or not folder.is_dir():
        return {"error": f"Folder not found: {folder_path}"}

    if extensions is None:
        extensions = [".txt", ".log", ".csv", ".json", ".xml", ".md"]

    file_results = {}
    for f in folder.rglob("*"):
        if f.suffix.lower() in extensions and f.is_file():
            result = scan_file(str(f), **kwargs)
            file_results[str(f)] = result

    total_pii = sum(r.get("total_pii", 0) for r in file_results.values())
    return {
        "source":       str(folder),
        "scan_type":    "folder",
        "files_scanned": len(file_results),
        "total_pii":    total_pii,
        "file_results": file_results,
    }


def _build_scan_result(text: str, detections: List[Dict],
                       source: str = "", **extra) -> Dict:
    from collections import Counter
    summary = Counter(d["label"] for d in detections)
    severity_counts = Counter(d["severity"] for d in detections)

    return {
        "source":          source,
        "scan_type":       "text",
        "total_pii":       len(detections),
        "detections":      detections,
        "summary":         dict(summary),
        "severity_counts": dict(severity_counts),
        "redacted_text":   redact_text(text, detections),
        **extra,
    }
