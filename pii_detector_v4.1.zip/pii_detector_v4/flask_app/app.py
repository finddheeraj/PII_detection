"""
flask_app/app.py - Barclays PII Detection with SSE progress streaming
"""

import os, sys, json, uuid, queue, tempfile, threading, zipfile
from collections import Counter
from pathlib import Path
from flask import Flask, request, jsonify, render_template, Response, stream_with_context

ROOT = Path(__file__).parent.parent
sys.path.insert(0, str(ROOT))

from core.detector import scan_text, detect_pii
from core.pii_patterns import LABEL_COLORS

app = Flask(__name__, template_folder="templates", static_folder=None)
app.config["MAX_CONTENT_LENGTH"] = 100 * 1024 * 1024

_jobs: dict = {}
_jobs_lock = threading.Lock()
ALLOWED_EXTS = {".txt", ".log", ".csv", ".json", ".xml", ".md"}

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/api/scan/text", methods=["POST"])
def api_scan_text():
    data = request.get_json(force=True)
    text = data.get("text", "").strip()
    if not text:
        return jsonify({"error": "No text provided"}), 400
    result = scan_text(text, use_spacy=data.get("use_spacy", True),
                       use_ml=data.get("use_ml", True),
                       min_confidence=data.get("min_confidence", "MEDIUM"))
    return jsonify(_serialise(result))

@app.route("/api/scan/file/upload", methods=["POST"])
def api_scan_file_upload():
    use_spacy = request.form.get("use_spacy", "true").lower() == "true"
    use_ml    = request.form.get("use_ml",    "true").lower() == "true"
    min_conf  = request.form.get("min_confidence", "MEDIUM")
    if "file" not in request.files:
        return jsonify({"error": "No file uploaded"}), 400
    f = request.files["file"]
    if not f.filename:
        return jsonify({"error": "Empty filename"}), 400
    suffix  = Path(f.filename).suffix.lower()
    scan_id = str(uuid.uuid4())
    tmp_path = tempfile.mktemp(suffix=suffix)
    f.save(tmp_path)
    q = queue.Queue()
    with _jobs_lock:
        _jobs[scan_id] = q
    threading.Thread(target=_scan_worker,
                     args=(scan_id, tmp_path, f.filename, suffix, use_spacy, use_ml, min_conf),
                     daemon=True).start()
    return jsonify({"scan_id": scan_id, "filename": f.filename})

@app.route("/api/scan/file/stream")
def api_scan_file_stream():
    scan_id = request.args.get("scan_id", "")
    with _jobs_lock:
        q = _jobs.get(scan_id)
    if q is None:
        return Response('data: {"type":"error","message":"Unknown scan_id"}\n\n',
                        mimetype="text/event-stream")
    def generate():
        while True:
            try:
                msg = q.get(timeout=20)
            except queue.Empty:
                yield ": heartbeat\n\n"
                continue
            if msg is None:
                break
            yield f"data: {msg}\n\n"
        with _jobs_lock:
            _jobs.pop(scan_id, None)
    return Response(stream_with_context(generate()), mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})

def _push(scan_id, payload):
    with _jobs_lock:
        q = _jobs.get(scan_id)
    if q:
        q.put(json.dumps(payload))

def _scan_worker(scan_id, tmp_path, orig_fname, suffix, use_spacy, use_ml, min_conf):
    try:
        if suffix == ".zip":
            _worker_zip(scan_id, tmp_path, use_spacy, use_ml, min_conf)
        else:
            _worker_single(scan_id, tmp_path, orig_fname, use_spacy, use_ml, min_conf)
    except Exception as e:
        _push(scan_id, {"type": "error", "message": str(e)})
    finally:
        try: os.unlink(tmp_path)
        except: pass
        with _jobs_lock:
            q = _jobs.get(scan_id)
        if q: q.put(None)

def _worker_single(scan_id, tmp_path, filename, use_spacy, use_ml, min_conf):
    with open(tmp_path, "r", encoding="utf-8", errors="replace") as fh:
        lines = fh.readlines()
    total_lines = len(lines)
    _push(scan_id, {"type": "start", "total_files": 1, "filename": filename,
                    "total_lines": total_lines})
    all_dets, line_results, pii_found, offset = [], [], 0, 0
    for i, line in enumerate(lines, 1):
        text = line.rstrip("\n")
        dets = detect_pii(text, use_spacy=use_spacy, use_ml=use_ml, min_confidence=min_conf)
        for d in dets:
            d["line_no"] = i
            d["start"]  += offset
            d["end"]    += offset
        all_dets.extend(dets)
        line_results.append({"line_no": i, "text": text, "detections": dets})
        pii_found += len(dets)
        offset    += len(line)
        if i % 10 == 0 or i == total_lines:
            _push(scan_id, {"type": "progress", "file": filename,
                            "file_no": 1, "total_files": 1,
                            "lines_done": i, "total_lines": total_lines,
                            "pii_found": pii_found,
                            "pct": round(i / max(total_lines, 1) * 100)})
    _push(scan_id, {"type": "file_done", "file": filename, "pii_found": pii_found})
    _push(scan_id, {"type": "done", "scan_type": "single", "filename": filename,
                    "total_pii": len(all_dets),
                    "summary":   dict(Counter(d["label"] for d in all_dets)),
                    "severity_counts": dict(Counter(d.get("severity","MEDIUM") for d in all_dets)),
                    "detections": [_det_dict(d) for d in all_dets],
                    "line_results": [{"line_no": lr["line_no"], "text": lr["text"],
                                      "detections": [_det_dict(d) for d in lr["detections"]]}
                                     for lr in line_results if lr["detections"]]})

def _worker_zip(scan_id, tmp_path, use_spacy, use_ml, min_conf):
    with tempfile.TemporaryDirectory() as tmp_dir:
        try:
            with zipfile.ZipFile(tmp_path, "r") as zf:
                zf.extractall(tmp_dir)
        except zipfile.BadZipFile:
            _push(scan_id, {"type": "error", "message": "Invalid ZIP file"}); return
        files = sorted([f for f in Path(tmp_dir).rglob("*")
                        if f.suffix.lower() in ALLOWED_EXTS and f.is_file()],
                       key=lambda p: p.name)
        total_files = len(files)
        _push(scan_id, {"type": "start", "total_files": total_files,
                        "filename": "folder.zip", "total_lines": None})
        all_dets, file_sums, total_pii = [], [], 0
        for f_no, fpath in enumerate(files, 1):
            fname = fpath.name
            try:
                with open(fpath, "r", encoding="utf-8", errors="replace") as fh:
                    lines = fh.readlines()
            except Exception as e:
                file_sums.append({"filename": fname, "error": str(e)})
                _push(scan_id, {"type": "file_error", "file": fname,
                                "file_no": f_no, "total_files": total_files, "message": str(e)})
                continue
            total_lines = len(lines)
            file_dets, file_lrs, file_pii, offset = [], [], 0, 0
            _push(scan_id, {"type": "progress", "file": fname,
                            "file_no": f_no, "total_files": total_files,
                            "lines_done": 0, "total_lines": total_lines,
                            "pii_found": total_pii,
                            "pct": round((f_no-1)/max(total_files,1)*100)})
            for i, line in enumerate(lines, 1):
                text = line.rstrip("\n")
                dets = detect_pii(text, use_spacy=use_spacy, use_ml=use_ml, min_confidence=min_conf)
                for d in dets:
                    d["line_no"] = i; d["filename"] = fname
                file_dets.extend(dets)
                file_lrs.append({"line_no": i, "text": text, "detections": dets})
                file_pii += len(dets); offset += len(line)
                if i % 25 == 0 or i == total_lines:
                    pct = round(((f_no-1) + i/max(total_lines,1))/max(total_files,1)*100)
                    _push(scan_id, {"type": "progress", "file": fname,
                                    "file_no": f_no, "total_files": total_files,
                                    "lines_done": i, "total_lines": total_lines,
                                    "pii_found": total_pii + file_pii, "pct": pct})
            total_pii += file_pii; all_dets.extend(file_dets)
            file_sums.append({"filename": fname, "total_pii": file_pii,
                               "summary": dict(Counter(d["label"] for d in file_dets)),
                               "line_results": [{"line_no": lr["line_no"], "text": lr["text"],
                                                 "detections": [_det_dict(d) for d in lr["detections"]]}
                                                for lr in file_lrs if lr["detections"]]})
            _push(scan_id, {"type": "file_done", "file": fname, "file_no": f_no,
                            "total_files": total_files, "pii_found": file_pii,
                            "total_pii_so_far": total_pii})
        _push(scan_id, {"type": "done", "scan_type": "folder",
                        "total_pii": total_pii, "files_scanned": total_files,
                        "summary": dict(Counter(d.get("label","") for d in all_dets)),
                        "severity_counts": dict(Counter(d.get("severity","MEDIUM") for d in all_dets)),
                        "file_summaries": file_sums,
                        "detections": [_det_dict(d) for d in all_dets]})

@app.route("/api/feedback", methods=["POST"])
def api_feedback():
    data = request.get_json(force=True)
    text = data.get("text","").strip(); label = data.get("label","").strip()
    if not text or not label: return jsonify({"error": "text and label required"}), 400
    try:
        from models.ensemble_model import load_ensemble
        e = load_ensemble(); e.record_feedback(text, label, is_fp=data.get("is_fp",True), context=data.get("context",""))
        return jsonify({"ok": True, "summary": e.feedback_summary()})
    except Exception as ex: return jsonify({"error": str(ex)}), 500

@app.route("/api/feedback/summary", methods=["GET"])
def api_feedback_summary():
    try:
        from models.ensemble_model import load_ensemble
        return jsonify(load_ensemble().feedback_summary())
    except Exception as e:
        return jsonify({"error": str(e), "total":0, "fps":0, "tps":0, "veto_trained":False, "by_label":{}})

@app.route("/api/retrain", methods=["POST"])
def api_retrain():
    data = request.get_json(force=True) or {}
    n = int(data.get("n_samples", 5000))
    try:
        from models.ensemble_model import load_ensemble
        load_ensemble().retrain_from_feedback(n_base_samples=n, verbose=True)
        return jsonify({"ok": True, "message": f"Retrained with {n} base samples + all feedback"})
    except Exception as e: return jsonify({"error": str(e)}), 500

@app.route("/api/accuracy", methods=["GET"])
def api_accuracy():
    try:
        from tests.accuracy import evaluate
        m = evaluate(use_spacy=request.args.get("use_spacy","true").lower()=="true",
                     use_ml=request.args.get("use_ml","true").lower()=="true", verbose=False)
        return jsonify({"overall": m["overall"], "per_label": m["per_label"],
                        "n_test_cases": m["n_test_cases"], "n_passed": m["n_passed"],
                        "confidence_dist": m["confidence_dist"]})
    except Exception as e: return jsonify({"error": str(e)}), 500

def _det_dict(d):
    return {"label": d.get("label",""), "text": d.get("text",""),
            "severity": d.get("severity","MEDIUM"), "confidence": d.get("final_confidence","MEDIUM"),
            "context": d.get("context","")[:120], "line_no": d.get("line_no"),
            "start": d.get("start"), "end": d.get("end"), "method": d.get("method","REGEX"),
            "color": LABEL_COLORS.get(d.get("label",""), "#ADB5BD"),
            "fp_penalty": round(d.get("fp_penalty", 0.0), 3)}

def _serialise(result):
    out = dict(result)
    out["detections"] = [_det_dict(d) for d in result.get("detections", [])]
    if "line_results" in out:
        out["line_results"] = [{"line_no": lr["line_no"], "text": lr["text"],
                                 "detections": [_det_dict(d) for d in lr["detections"]]}
                                for lr in out["line_results"] if lr["detections"]]
    out.pop("redacted_text", None)
    return out

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=7860, debug=False, threaded=True)
