from flask import Flask, request, jsonify, render_template
from pbwm_genai_config.resources import LLMCallable
import pbwm_genai_config.mlflow.context_managers as mlflow_cm

app = Flask(__name__)


def call_llm(llm_func: LLMCallable, system_prompt: str, user_message: str) -> dict:
    """
    Calls the LLM using the pbwm_genai_config LLMCallable.
    Returns a dict with 'response' or 'error'.
    """
    with mlflow_cm.mlflow_run_context() as root_span:
        with mlflow_cm.mlflow_invoke_trace(
            root_span=root_span, name="llm_invoke"
        ) as main_span:
            llm_response, llm_input = llm_func(
                system_messages=[{"role": "system", "content": system_prompt}],
                messages=[
                    {
                        "role": "user",
                        "content": user_message,
                    }
                ],
                return_model_inputs=True,
            )

    # Extract text from response content
    content_blocks = llm_response.get("content", [])
    response_text = " ".join(
        block.get("text", "")
        for block in content_blocks
        if block.get("type") == "text"
    )

    return {
        "response": response_text,
        "raw": llm_response,
    }


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/chat", methods=["POST"])
def chat():
    data = request.get_json()

    if not data:
        return jsonify({"error": "No JSON body provided"}), 400

    user_message = data.get("message", "").strip()
    system_prompt = data.get(
        "system_prompt", "You are a helpful assistant."
    ).strip()

    if not user_message:
        return jsonify({"error": "Message cannot be empty"}), 400

    try:
        # -------------------------------------------------------------------
        # Replace this with your actual LLMCallable instantiation.
        # pbwm_genai_config handles authentication, endpoint config, etc.
        # Example (replace with real factory/init from your internal library):
        #
        #   from pbwm_genai_config.resources import get_llm_callable
        #   llm_func = get_llm_callable(model_id="your-model-id")
        #
        # For now we raise a NotImplementedError as a placeholder.
        # -------------------------------------------------------------------
        raise NotImplementedError(
            "Replace this block with your pbwm_genai_config LLMCallable initialisation."
        )

        result = call_llm(
            llm_func=llm_func,
            system_prompt=system_prompt,
            user_message=user_message,
        )
        return jsonify({"response": result["response"]}), 200

    except NotImplementedError as e:
        return jsonify({"error": str(e)}), 501
    except Exception as e:
        app.logger.error(f"LLM call failed: {e}")
        return jsonify({"error": f"LLM call failed: {str(e)}"}), 500


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
