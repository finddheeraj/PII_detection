# Flask LLM Chat App

A minimal Flask application that connects to an LLM via `pbwm_genai_config` and exposes a clean chat UI.

## Project Structure

```
flask_llm_app/
├── app.py                  # Flask app + LLM logic
├── requirements.txt
├── README.md
└── templates/
    └── index.html          # Chat UI
```

## Setup

```bash
pip install -r requirements.txt
```

> `pbwm_genai_config` must be installed from your internal Barclays PyPI registry.

## Configuration

In `app.py`, locate the `TODO` block inside the `/chat` route and replace the `NotImplementedError` with your actual `LLMCallable` instantiation:

```python
# Example — replace with your real factory call:
from pbwm_genai_config.resources import get_llm_callable

llm_func = get_llm_callable(model_id="your-model-id")
```

## Run

```bash
python app.py
```

Then open: [http://localhost:5000](http://localhost:5000)

## API

### POST `/chat`

**Request**
```json
{
  "message": "What is the capital of France?",
  "system_prompt": "You are a helpful assistant."
}
```

**Response (200)**
```json
{
  "response": "The capital of France is Paris."
}
```

**Response (error)**
```json
{
  "error": "Description of what went wrong"
}
```
