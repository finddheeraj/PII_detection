"""
data_generator.py
─────────────────
Generates synthetic labelled training data for the ML classifier.
Uses Faker with UK/EU locales to produce realistic PII-containing sentences.
"""

import random
import re
from faker import Faker
from typing import List, Tuple

# EU / UK locales for realistic names, addresses, phones
_LOCALES = ["en_GB", "fr_FR", "de_DE", "it_IT", "es_ES", "nl_NL"]
fake_pool = [Faker(loc) for loc in _LOCALES]
fake_en   = Faker("en_GB")


def _fake() -> Faker:
    return random.choice(fake_pool)


# ─────────────────────────────────────────────────────────────────
#  PII value generators
# ─────────────────────────────────────────────────────────────────

def gen_uk_nin() -> str:
    valid_prefix = ["AB","AE","AH","AK","AL","AM","AP","AR","AS","AT",
                    "AW","AX","AY","AZ","BA","BB","BE","BH","BK","BL","BM"]
    suffix = random.choice("ABCD")
    return f"{random.choice(valid_prefix)}{random.randint(10,99)}{random.randint(10,99)}{random.randint(10,99)}{suffix}"

def gen_uk_driving_licence() -> str:
    surname = fake_en.last_name()[:5].upper().ljust(5,"X")
    dob     = f"{random.randint(50,99)}{random.randint(1,12):02d}{random.randint(1,28):02d}"
    suffix  = f"{chr(random.randint(65,90))}{chr(random.randint(65,90))}{random.randint(1,9)}{chr(random.randint(65,90))}{chr(random.randint(65,90))}"
    return f"{surname}{dob}{suffix}"

def gen_uk_postcode() -> str:
    areas = ["SW1A 1AA","EC1A 1BB","W1A 0AX","JE2 4WN","GY1 1AA","IM1 1AB"]
    return random.choice(areas) if random.random() < 0.3 else fake_en.postcode()

def gen_uk_sort_code() -> str:
    return f"{random.randint(10,99):02d}-{random.randint(10,99):02d}-{random.randint(10,99):02d}"

def gen_uk_bank_account() -> str:
    return f"{random.randint(10000000,99999999)}"

def gen_iban(country: str = None) -> str:
    countries = {
        "GB": (22, "NWBK60161331"),
        "JE": (22, "MOYN00991234"),
        "MC": (27, "5811222000010"),
        "CH": (21, "9300762011623"),
        "FR": (27, "7630006000011"),
        "DE": (22, "37040044012"),
    }
    if country is None:
        country = random.choice(list(countries.keys()))
    length, prefix = countries[country]
    check = f"{random.randint(10,99)}"
    digits = "".join([str(random.randint(0,9)) for _ in range(length - len(country) - 2 - len(prefix))])
    return f"{country}{check}{prefix}{digits}"

def gen_swiss_ahv() -> str:
    return f"756.{random.randint(1000,9999)}.{random.randint(1000,9999)}.{random.randint(10,99)}"

def gen_eu_vat(country: str = None) -> str:
    prefixes = ["GB","FR","DE","IT","ES","NL","BE","AT","PT","IE"]
    if country is None:
        country = random.choice(prefixes)
    return f"{country}{random.randint(100000000,999999999)}"

def gen_phone_uk() -> str:
    formats = [
        f"07{random.randint(700,999)}{random.randint(100000,999999)}",
        f"+447{random.randint(700,999)}{random.randint(100000,999999)}",
        f"+44 7{random.randint(700,999)} {random.randint(100000,999999)}",
    ]
    return random.choice(formats)

def gen_phone_eu() -> str:
    prefixes = ["+33", "+41", "+377", "+352", "+32", "+31", "+49", "+39"]
    prefix = random.choice(prefixes)
    return f"{prefix}{random.randint(600000000,699999999)}"

def gen_credit_card() -> str:
    # Visa-style
    n = f"4{random.randint(100,999)}{random.randint(1000,9999)}{random.randint(1000,9999)}{random.randint(1000,9999)}"
    return f"{n[:4]} {n[4:8]} {n[8:12]} {n[12:]}"

def gen_cvv() -> str:
    return str(random.randint(100, 999))

def gen_dob() -> str:
    day   = random.randint(1, 28)
    month = random.randint(1, 12)
    year  = random.randint(1950, 2003)
    fmt   = random.choice([
        f"{day:02d}/{month:02d}/{year}",
        f"{year}-{month:02d}-{day:02d}",
        f"{day:02d}.{month:02d}.{year}",
    ])
    return fmt

def gen_ssn() -> str:
    return f"{random.randint(100,799):03d}-{random.randint(10,99):02d}-{random.randint(1000,9999):04d}"

def gen_passport() -> str:
    letters = "".join(random.choices("ABCDEFGHJKLMNPRSTUVWXYZ", k=random.randint(1,2)))
    digits  = "".join([str(random.randint(0,9)) for _ in range(random.randint(6,7))])
    return f"{letters}{digits}"

def gen_ip() -> str:
    return f"{random.randint(1,254)}.{random.randint(0,255)}.{random.randint(0,255)}.{random.randint(1,254)}"

def gen_email() -> str:
    domains = ["gmail.com","outlook.com","yahoo.co.uk","hotmail.fr","protonmail.com",
               "example.co.uk","company.eu","bank.ch","finance.mc","gov.je"]
    name = fake_en.first_name().lower() + "." + fake_en.last_name().lower()
    return f"{name}@{random.choice(domains)}"

def gen_password() -> str:
    words  = ["Secure","Pass","My","Bank","Login","Auth"]
    digits = str(random.randint(100,999))
    symbols = random.choice(["!","@","#","$"])
    return random.choice(words) + digits + symbols

def gen_address() -> str:
    numbers = [str(random.randint(1, 200))]
    streets = ["High Street","Main Road","Church Lane","Oak Avenue",
               "Victoria Road","King Street","London Road","Mill Lane"]
    return f"{random.choice(numbers)} {random.choice(streets)}"

def gen_maiden_name() -> str:
    return fake_en.last_name()


# ─────────────────────────────────────────────────────────────────
#  Sentence templates
# ─────────────────────────────────────────────────────────────────

TEMPLATES = [
    # EMAIL
    ("Customer email address is {EMAIL} for account notifications.",              "EMAIL"),
    ("Login recovery sent to {EMAIL}.",                                            "EMAIL"),
    ("Contact {EMAIL} for marketing communications.",                              "EMAIL"),
    ("E-mail {EMAIL} verified.",                                                   "EMAIL"),

    # UK_NIN
    ("National insurance number {UK_NIN} on file for payroll.",                   "UK_NIN"),
    ("NI number: {UK_NIN} registered.",                                            "UK_NIN"),
    ("Employee NIN {UK_NIN} added to HR system.",                                  "UK_NIN"),

    # UK_DRIVING_LICENCE
    ("Driving licence {UK_DRIVING_LICENCE} verified for identity.",                "UK_DRIVING_LICENCE"),
    ("DVLA record {UK_DRIVING_LICENCE} submitted.",                                "UK_DRIVING_LICENCE"),

    # UK_POSTCODE
    ("Delivery to postcode {UK_POSTCODE} confirmed.",                              "UK_POSTCODE"),
    ("Customer postcode {UK_POSTCODE} on account.",                                "UK_POSTCODE"),
    ("Address postcode registered as {UK_POSTCODE}.",                              "UK_POSTCODE"),

    # UK_SORT_CODE + UK_BANK_ACCOUNT
    ("Bank sort code {UK_SORT_CODE} account number {UK_BANK_ACCOUNT}.",            "UK_SORT_CODE"),
    ("Direct debit sort code {UK_SORT_CODE} account {UK_BANK_ACCOUNT} set up.",    "UK_SORT_CODE"),

    # IBAN
    ("IBAN {IBAN} submitted for wire transfer.",                                   "IBAN"),
    ("Payment to IBAN {IBAN} processed.",                                          "IBAN"),
    ("Bank account IBAN: {IBAN}.",                                                 "IBAN"),

    # SWISS_AHV
    ("Swiss AHV number {SWISS_AHV} for Geneva resident.",                          "SWISS_AHV"),
    ("AVS social security {SWISS_AHV} registered.",                                "SWISS_AHV"),

    # EU_VAT
    ("VAT registration number {EU_VAT} on invoice.",                               "EU_VAT"),
    ("Company EU VAT: {EU_VAT}.",                                                  "EU_VAT"),

    # PHONE_UK
    ("Mobile phone {PHONE_UK} for two-factor authentication.",                     "PHONE_UK"),
    ("Contact number {PHONE_UK} registered.",                                      "PHONE_UK"),
    ("SMS notification sent to {PHONE_UK}.",                                       "PHONE_UK"),

    # PHONE_EU
    ("European phone {PHONE_EU} on account.",                                      "PHONE_EU"),
    ("Contact {PHONE_EU} for Monaco client.",                                      "PHONE_EU"),
    ("Geneva office telephone {PHONE_EU}.",                                        "PHONE_EU"),

    # CREDIT_CARD
    ("Credit card number {CREDIT_CARD} processed.",                                "CREDIT_CARD"),
    ("Card payment {CREDIT_CARD} for transaction.",                                "CREDIT_CARD"),

    # CVV
    ("CVV: {CVV} for card verification.",                                          "CVV"),
    ("Security code CVV {CVV} provided.",                                          "CVV"),

    # SSN
    ("Social security number {SSN} for identity verification.",                    "SSN"),
    ("SSN {SSN} on file for tax purposes.",                                        "SSN"),

    # DOB
    ("Date of birth {DOB} for age verification.",                                  "DOB"),
    ("Customer DOB {DOB} on account.",                                             "DOB"),
    ("Born on {DOB} registered.",                                                  "DOB"),

    # PASSPORT
    ("Passport number {PASSPORT} for travel document.",                            "PASSPORT"),
    ("Non-citizen passport {PASSPORT} submitted.",                                 "PASSPORT"),

    # IP_ADDRESS
    ("Login request from IP {IP_ADDRESS} recorded.",                               "IP_ADDRESS"),
    ("Network access from {IP_ADDRESS} flagged.",                                  "IP_ADDRESS"),

    # HOME_ADDRESS
    ("Customer home address {HOME_ADDRESS}, {UK_POSTCODE}.",                       "HOME_ADDRESS"),
    ("Billing address: {HOME_ADDRESS}.",                                           "HOME_ADDRESS"),

    # MOTHERS_MAIDEN_NAME
    ("Mother's maiden name: {MOTHERS_MAIDEN_NAME} on record.",                     "MOTHERS_MAIDEN_NAME"),
    ("Security question mother's maiden name {MOTHERS_MAIDEN_NAME}.",              "MOTHERS_MAIDEN_NAME"),

    # PASSWORD
    ("password: {PASSWORD} set for account.",                                      "PASSWORD"),
    ("User credential passwd={PASSWORD} stored.",                                  "PASSWORD"),

    # NO PII (negative examples)
    ("Transaction processed successfully at 14:32:01.",                            "NO_PII"),
    ("System health check: all services operational.",                             "NO_PII"),
    ("Order #1234 dispatched to warehouse zone B.",                                "NO_PII"),
    ("User logged out after 30 minutes of inactivity.",                            "NO_PII"),
    ("Database backup completed in 45 seconds.",                                   "NO_PII"),
    ("Application version 2.4.1 deployed to production.",                         "NO_PII"),
    ("Cache cleared successfully.",                                                "NO_PII"),
    ("Error code 404: resource not found.",                                        "NO_PII"),
    ("Scheduled maintenance window starts at 02:00 UTC.",                         "NO_PII"),
    ("Record count: 1024 entries processed.",                                      "NO_PII"),
]


VALUE_GENERATORS = {
    "EMAIL":                gen_email,
    "UK_NIN":               gen_uk_nin,
    "UK_DRIVING_LICENCE":   gen_uk_driving_licence,
    "UK_POSTCODE":          gen_uk_postcode,
    "UK_SORT_CODE":         gen_uk_sort_code,
    "UK_BANK_ACCOUNT":      gen_uk_bank_account,
    "IBAN":                 gen_iban,
    "SWISS_AHV":            gen_swiss_ahv,
    "EU_VAT":               gen_eu_vat,
    "PHONE_UK":             gen_phone_uk,
    "PHONE_EU":             gen_phone_eu,
    "CREDIT_CARD":          gen_credit_card,
    "CVV":                  gen_cvv,
    "SSN":                  gen_ssn,
    "DOB":                  gen_dob,
    "PASSPORT":             gen_passport,
    "IP_ADDRESS":           gen_ip,
    "HOME_ADDRESS":         gen_address,
    "MOTHERS_MAIDEN_NAME":  gen_maiden_name,
    "PASSWORD":             gen_password,
}


def _fill_template(template: str) -> str:
    """Replace {LABEL} placeholders in a template with generated values."""
    result = template
    for label, generator in VALUE_GENERATORS.items():
        if f"{{{label}}}" in result:
            result = result.replace(f"{{{label}}}", generator(), 1)
    return result


def generate_dataset(n_samples: int = 2000, seed: int = 42) -> List[Tuple[str, str]]:
    """
    Generate n_samples labelled (text, label) pairs.
    Returns list of (sentence, pii_label) where pii_label is the
    primary PII type present, or 'NO_PII'.
    """
    random.seed(seed)
    dataset = []

    # Weight templates so each label gets reasonable coverage
    pii_templates  = [t for t in TEMPLATES if t[1] != "NO_PII"]
    none_templates = [t for t in TEMPLATES if t[1] == "NO_PII"]

    for _ in range(n_samples):
        if random.random() < 0.3:
            tmpl, label = random.choice(none_templates)
        else:
            tmpl, label = random.choice(pii_templates)

        text = _fill_template(tmpl)
        dataset.append((text, label))

    return dataset


def generate_mixed_log(n_lines: int = 500) -> List[str]:
    """
    Generate a realistic mixed log file (PII interspersed with normal log lines).
    Useful for testing the file/folder scan mode.
    """
    normal_lines = [
        "INFO  2024-01-15 09:12:34 - Request received from client",
        "DEBUG 2024-01-15 09:12:35 - Processing payment gateway response",
        "INFO  2024-01-15 09:12:36 - Transaction completed successfully",
        "WARN  2024-01-15 09:12:37 - Retry attempt 1 for service call",
        "ERROR 2024-01-15 09:12:38 - Connection timeout after 30s",
        "INFO  2024-01-15 09:12:39 - Cache hit for key: user_preferences",
        "DEBUG 2024-01-15 09:12:40 - Query executed in 12ms",
        "INFO  2024-01-15 09:12:41 - Session created for user",
        "INFO  2024-01-15 09:12:42 - Audit log entry created",
        "DEBUG 2024-01-15 09:12:43 - Config loaded from environment",
    ]

    pii_templates = [t for t in TEMPLATES if t[1] != "NO_PII"]
    lines = []

    for _ in range(n_lines):
        if random.random() < 0.25:  # 25% of log lines contain PII
            tmpl, _ = random.choice(pii_templates)
            lines.append(f"INFO  2024-01-15 - {_fill_template(tmpl)}")
        else:
            lines.append(random.choice(normal_lines))

    return lines


if __name__ == "__main__":
    print("Generating synthetic dataset...")
    ds = generate_dataset(100)
    for text, label in ds[:5]:
        print(f"  [{label}] {text}")
    print(f"\nTotal: {len(ds)} samples generated.")
