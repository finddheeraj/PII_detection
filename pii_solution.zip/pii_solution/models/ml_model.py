"""
ml_model.py
───────────
ML component of the Regex + ML Hybrid pipeline.
Trains a TF-IDF + Logistic Regression text classifier on synthetic data
to predict whether a text span is PII and what type it is.

This complements the regex layer by:
  1. Catching PII that regex might miss (e.g., names, free-text addresses)
  2. Providing a confidence score for each detection
  3. Classifying text chunks that look like PII but need context
"""

import os
import sys
import joblib
import numpy as np
from pathlib import Path
from typing import List, Tuple, Dict

from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.metrics import (
    classification_report, confusion_matrix,
    precision_recall_fscore_support, accuracy_score
)

MODEL_PATH = Path(__file__).parent.parent / "models" / "pii_classifier.joblib"
METRICS_PATH = Path(__file__).parent.parent / "models" / "training_metrics.txt"


def build_pipeline() -> Pipeline:
    """Build sklearn ML pipeline: TF-IDF → Logistic Regression."""
    return Pipeline([
        ("tfidf", TfidfVectorizer(
            analyzer="char_wb",       # character n-grams capture patterns well
            ngram_range=(2, 5),       # bi- to 5-grams
            max_features=50_000,
            sublinear_tf=True,
            strip_accents="unicode",
            min_df=2,
        )),
        ("clf", LogisticRegression(
            max_iter=1000,
            C=5.0,
            class_weight="balanced",  # handle class imbalance
            solver="lbfgs",
            multi_class="multinomial",
            n_jobs=-1,
        )),
    ])


def train(n_samples: int = 3000, test_size: float = 0.2,
          verbose: bool = True) -> Dict:
    """
    Generate synthetic data, train the classifier, save model.

    Returns dict with accuracy metrics.
    """
    # Import here to avoid circular dependency
    sys.path.insert(0, str(Path(__file__).parent.parent))
    from data.data_generator import generate_dataset

    if verbose:
        print(f"[ML] Generating {n_samples} synthetic training samples...")
    dataset = generate_dataset(n_samples)

    texts  = [t for t, _ in dataset]
    labels = [l for _, l in dataset]

    # Train / test split
    X_train, X_test, y_train, y_test = train_test_split(
        texts, labels, test_size=test_size, random_state=42, stratify=labels
    )

    if verbose:
        print(f"[ML] Training on {len(X_train)} samples, testing on {len(X_test)}...")
        label_dist = {}
        for l in labels:
            label_dist[l] = label_dist.get(l, 0) + 1
        print(f"[ML] Label distribution: {dict(sorted(label_dist.items()))}")

    model = build_pipeline()
    model.fit(X_train, y_train)

    # Evaluate
    y_pred = model.predict(X_test)
    accuracy = accuracy_score(y_test, y_pred)
    report   = classification_report(y_test, y_pred, zero_division=0)
    prec, rec, f1, _ = precision_recall_fscore_support(
        y_test, y_pred, average="weighted", zero_division=0
    )

    # Cross-validation
    cv_scores = cross_val_score(model, texts, labels, cv=5, scoring="f1_weighted")

    metrics = {
        "accuracy":       accuracy,
        "precision":      prec,
        "recall":         rec,
        "f1_weighted":    f1,
        "cv_f1_mean":     cv_scores.mean(),
        "cv_f1_std":      cv_scores.std(),
        "report":         report,
        "n_train":        len(X_train),
        "n_test":         len(X_test),
        "classes":        list(model.classes_),
    }

    if verbose:
        print(f"\n{'='*55}")
        print(f"  ML MODEL TRAINING RESULTS")
        print(f"{'='*55}")
        print(f"  Accuracy  : {accuracy:.1%}")
        print(f"  Precision : {prec:.1%}")
        print(f"  Recall    : {rec:.1%}")
        print(f"  F1        : {f1:.1%}")
        print(f"  CV F1     : {cv_scores.mean():.1%} ± {cv_scores.std():.1%}")
        print(f"\n{report}")

    # Save model
    MODEL_PATH.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(model, MODEL_PATH)
    if verbose:
        print(f"[ML] Model saved to {MODEL_PATH}")

    # Save metrics report
    with open(METRICS_PATH, "w") as f:
        f.write("ML MODEL TRAINING METRICS\n")
        f.write("="*55 + "\n")
        f.write(f"Accuracy   : {accuracy:.4f}\n")
        f.write(f"Precision  : {prec:.4f}\n")
        f.write(f"Recall     : {rec:.4f}\n")
        f.write(f"F1         : {f1:.4f}\n")
        f.write(f"CV F1 Mean : {cv_scores.mean():.4f}\n")
        f.write(f"CV F1 Std  : {cv_scores.std():.4f}\n\n")
        f.write(report)

    return metrics


def load_model() -> Pipeline:
    """Load saved model. Trains a fresh one if not found."""
    if not MODEL_PATH.exists():
        print("[ML] No trained model found. Training now...")
        train(verbose=True)
    return joblib.load(MODEL_PATH)


def predict_with_confidence(texts: List[str], model: Pipeline) -> List[Dict]:
    """
    Given a list of text spans, return label + confidence for each.
    Returns list of {label, confidence, probabilities}.
    """
    if not texts:
        return []

    proba_matrix = model.predict_proba(texts)
    classes      = model.classes_

    results = []
    for proba in proba_matrix:
        top_idx   = np.argmax(proba)
        top_label = classes[top_idx]
        top_conf  = float(proba[top_idx])

        # Top-3 labels
        top3_idx    = np.argsort(proba)[::-1][:3]
        top3        = [(classes[i], float(proba[i])) for i in top3_idx]

        results.append({
            "label":       top_label,
            "confidence":  top_conf,
            "top3":        top3,
            "is_pii":      top_label != "NO_PII" and top_conf >= 0.4,
        })

    return results


if __name__ == "__main__":
    print("Training PII ML classifier...")
    metrics = train(n_samples=3000, verbose=True)
