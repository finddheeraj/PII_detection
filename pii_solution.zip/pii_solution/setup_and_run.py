"""
setup_and_run.py
────────────────
First-time setup + launch script.
Run this once:  python setup_and_run.py
"""

import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).parent


def run(cmd: list, msg: str):
    print(f"\n[SETUP] {msg}...")
    result = subprocess.run(cmd, capture_output=False)
    if result.returncode != 0:
        print(f"[WARN] Command exited with code {result.returncode}")
    return result.returncode == 0


def main():
    print("="*55)
    print("  PII Detection Solution — Setup & Launch")
    print("="*55)

    # 1. Install requirements
    run([sys.executable, "-m", "pip", "install", "-r", str(ROOT / "requirements.txt")],
        "Installing requirements")

    # 2. Download spaCy model
    try:
        import spacy
        spacy.load("en_core_web_sm")
        print("[SETUP] spaCy model already installed.")
    except Exception:
        run([sys.executable, "-m", "spacy", "download", "en_core_web_sm"],
            "Downloading spaCy en_core_web_sm")

    # 3. Train ML model
    sys.path.insert(0, str(ROOT))
    from models.ml_model import MODEL_PATH, train
    if not MODEL_PATH.exists():
        print("\n[SETUP] Training ML classifier on synthetic data...")
        train(n_samples=3000, verbose=True)
    else:
        print(f"[SETUP] ML model already exists at {MODEL_PATH}")

    # 4. Create reports folder
    (ROOT / "reports").mkdir(exist_ok=True)

    # 5. Launch UI
    print("\n[SETUP] Launching Gradio UI...")
    print("        Open http://localhost:7860 in your browser\n")

    import importlib.util
    spec = importlib.util.spec_from_file_location("app", ROOT / "ui" / "app.py")
    mod  = importlib.util.module_from_spec(spec)
    sys.modules["app"] = mod
    spec.loader.exec_module(mod)


if __name__ == "__main__":
    main()
