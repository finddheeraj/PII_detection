"""
accuracy.py
───────────
Accuracy / confidence evaluation for the PII detection pipeline.
Runs against a labelled European ground-truth dataset and outputs:
  - Precision, Recall, F1 per label
  - Overall weighted metrics
  - False positive / false negative analysis
  - Confidence score distribution
  - HTML accuracy report
"""

import sys
from pathlib import Path
from collections import defaultdict
from typing import List, Tuple, Dict

sys.path.insert(0, str(Path(__file__).parent.parent))

from core.detector import detect_pii
from core.pii_patterns import LABEL_COLORS

# ─────────────────────────────────────────────────────────────────
#  European Ground-Truth Test Cases
# ─────────────────────────────────────────────────────────────────

GROUND_TRUTH: List[Tuple[str, List[str]]] = [

    # EMAIL
    ("Customer email address is john.smith@example.co.uk for notifications.",     ["EMAIL"]),
    ("Login recovery sent to pierre.dupont@banque.fr.",                            ["EMAIL"]),
    ("Contact user@monaco.mc for account updates.",                                ["EMAIL"]),
    ("E-mail hans.mueller@bank.ch registered.",                                    ["EMAIL"]),

    # UK NIN
    ("National insurance number AB123456C on file for payroll.",                   ["UK_NIN"]),
    ("NI number: QQ 12 34 56 C registered.",                                       ["UK_NIN"]),
    ("Employee NIN AB123456D added to HR system.",                                 ["UK_NIN"]),

    # UK Driving Licence
    ("Driving licence MORGA657054SM9IJ verified for identity.",                    ["UK_DRIVING_LICENCE"]),
    ("DVLA record SMITH751130JA9AB submitted.",                                    ["UK_DRIVING_LICENCE"]),

    # UK Postcode
    ("Delivery to postcode SW1A 1AA confirmed.",                                   ["UK_POSTCODE"]),
    ("Customer address postcode EC1A 1BB on account.",                             ["UK_POSTCODE"]),
    ("Jersey postcode JE2 4WN registered.",                                        ["UK_POSTCODE"]),

    # UK Sort Code + Bank Account
    ("Bank sort code 20-00-00 account number 12345678.",                           ["UK_SORT_CODE", "UK_BANK_ACCOUNT"]),
    ("Direct debit sort code 40-47-84 account 58572485 set up.",                  ["UK_SORT_CODE", "UK_BANK_ACCOUNT"]),

    # IBAN
    ("IBAN GB29NWBK60161331926819 submitted for wire transfer.",                   ["IBAN"]),
    ("Jersey IBAN JE29MOYN00991234567890 on file.",                                ["IBAN"]),
    ("Monaco account IBAN MC5811222000010123456789030.",                           ["IBAN"]),
    ("Swiss IBAN CH9300762011623852957 for Geneva.",                               ["IBAN"]),
    ("French IBAN FR7630006000011234567890189.",                                   ["IBAN"]),

    # Swiss AHV
    ("Swiss AHV number 756.1234.5678.90 for Geneva resident.",                    ["SWISS_AHV"]),
    ("AVS social security 756.9876.5432.10 registered.",                           ["SWISS_AHV"]),

    # EU VAT
    ("Company VAT registration number GB123456789 on invoice.",                   ["EU_VAT"]),
    ("VAT FR12345678901 for French entity.",                                       ["EU_VAT"]),

    # Phone UK
    ("Mobile phone 07911123456 for two-factor authentication.",                    ["PHONE_UK"]),
    ("+447700900123 registered for SMS notifications.",                            ["PHONE_UK"]),

    # Phone EU
    ("Monaco contact phone +37798765432 on record.",                              ["PHONE_EU"]),
    ("Geneva office telephone +41227654321.",                                      ["PHONE_EU"]),
    ("French mobile +33612345678 for 2FA.",                                        ["PHONE_EU"]),

    # Credit Card + CVV
    ("Credit card 4111 1111 1111 1111 processed.",                                ["CREDIT_CARD"]),
    ("CVV: 456 for card verification.",                                            ["CVV"]),

    # DOB
    ("Date of birth 15/08/1985 on file.",                                         ["DOB"]),
    ("Customer born 1990-03-22.",                                                  ["DOB"]),
    ("Swiss DOB 22.03.1990 registered.",                                           ["DOB"]),

    # SSN
    ("Social security number 123-45-6789 for identity verification.",             ["SSN"]),

    # Passport
    ("Passport number AB1234567 submitted for travel.",                            ["PASSPORT"]),
    ("Non-citizen passport P1234567 verified.",                                    ["PASSPORT"]),

    # IP Address
    ("Login request from IP 192.168.1.105 recorded.",                             ["IP_ADDRESS"]),
    ("Access from 10.0.0.1 in network log.",                                      ["IP_ADDRESS"]),

    # Password
    ("password: MySecret123! set for account.",                                   ["PASSWORD"]),

    # Mixed PII
    ("John email john@test.com NIN AB123456C DOB 01/01/1980.",                    ["EMAIL", "UK_NIN", "DOB"]),
    ("IBAN GB29NWBK60161331926819 sort code 20-00-00 account 12345678.",          ["IBAN", "UK_SORT_CODE", "UK_BANK_ACCOUNT"]),

    # TRUE NEGATIVES (should NOT be flagged as PII)
    ("Transaction processed successfully at 14:32:01.",                            []),
    ("System health check: all services operational.",                             []),
    ("Order #1234 dispatched to warehouse zone B.",                                []),
    ("User logged out after 30 minutes of inactivity.",                            []),
    ("Database backup completed in 45 seconds.",                                   []),
    ("Application version 2.4.1 deployed to production.",                         []),
    ("Cache cleared. Record count: 1024 entries.",                                 []),
    ("Scheduled maintenance window starts at 02:00 UTC.",                         []),
]


# ─────────────────────────────────────────────────────────────────
#  Core evaluation
# ─────────────────────────────────────────────────────────────────

def evaluate(use_spacy: bool = True, use_ml: bool = True,
             verbose: bool = True) -> Dict:
    """
    Run detection against ground truth and compute accuracy metrics.
    Returns dict with all metrics and case-level details.
    """
    label_stats  = defaultdict(lambda: {"TP": 0, "FP": 0, "FN": 0})
    case_results = []
    fp_cases, fn_cases = [], []
    confidence_dist = {"HIGH": 0, "MEDIUM": 0, "LOW": 0}

    for text, expected_labels in GROUND_TRUTH:
        detections      = detect_pii(text, use_spacy=use_spacy, use_ml=use_ml)
        detected_labels = list(set(d["label"] for d in detections))

        # Tally confidence distribution
        for d in detections:
            conf = d.get("final_confidence", "MEDIUM")
            confidence_dist[conf] = confidence_dist.get(conf, 0) + 1

        exp_set = set(expected_labels)
        det_set = set(detected_labels)

        tp = exp_set & det_set
        fp = det_set - exp_set
        fn = exp_set - det_set

        for lbl in tp: label_stats[lbl]["TP"] += 1
        for lbl in fp: label_stats[lbl]["FP"] += 1
        for lbl in fn: label_stats[lbl]["FN"] += 1

        if fp:
            fp_cases.append({
                "text":            text,
                "false_positives": list(fp),
                "all_detected":    detected_labels,
                "expected":        expected_labels,
            })
        if fn:
            fn_cases.append({
                "text":            text,
                "false_negatives": list(fn),
                "expected":        expected_labels,
                "detected":        detected_labels,
            })

        status = "PASS" if not fp and not fn else ("FP_ONLY" if not fn else "FN")
        case_results.append({
            "text":     text[:90] + ("..." if len(text) > 90 else ""),
            "expected": expected_labels,
            "detected": detected_labels,
            "tp": len(tp), "fp": len(fp), "fn": len(fn),
            "status":   status,
        })

    # Overall metrics
    total_tp = sum(s["TP"] for s in label_stats.values())
    total_fp = sum(s["FP"] for s in label_stats.values())
    total_fn = sum(s["FN"] for s in label_stats.values())

    precision = total_tp / (total_tp + total_fp) if (total_tp + total_fp) > 0 else 0
    recall    = total_tp / (total_tp + total_fn) if (total_tp + total_fn) > 0 else 0
    f1        = 2 * precision * recall / (precision + recall) if (precision + recall) > 0 else 0

    # Per-label metrics
    label_metrics = {}
    for lbl, s in sorted(label_stats.items()):
        tp, fp, fn = s["TP"], s["FP"], s["FN"]
        p = tp / (tp + fp) if (tp + fp) > 0 else 0
        r = tp / (tp + fn) if (tp + fn) > 0 else 0
        f = 2 * p * r / (p + r) if (p + r) > 0 else 0
        label_metrics[lbl] = {
            "TP": tp, "FP": fp, "FN": fn,
            "precision": p, "recall": r, "f1": f
        }

    metrics = {
        "overall": {
            "precision": precision,
            "recall":    recall,
            "f1":        f1,
            "total_tp":  total_tp,
            "total_fp":  total_fp,
            "total_fn":  total_fn,
        },
        "per_label":          label_metrics,
        "case_results":       case_results,
        "false_positives":    fp_cases,
        "false_negatives":    fn_cases,
        "confidence_dist":    confidence_dist,
        "n_test_cases":       len(GROUND_TRUTH),
        "n_passed":           sum(1 for c in case_results if c["status"] == "PASS"),
    }

    if verbose:
        _print_report(metrics)

    return metrics


def _print_report(metrics: Dict):
    ov = metrics["overall"]
    print("\n" + "="*60)
    print("  PII DETECTION ACCURACY REPORT")
    print("  Region: UK · Jersey · Geneva · Monaco · EU")
    print("="*60)
    print(f"  Test cases   : {metrics['n_test_cases']}")
    print(f"  Passed       : {metrics['n_passed']}")
    print(f"  Precision    : {ov['precision']:.1%}")
    print(f"  Recall       : {ov['recall']:.1%}")
    print(f"  F1 Score     : {ov['f1']:.1%}")
    print(f"  TP={ov['total_tp']}  FP={ov['total_fp']}  FN={ov['total_fn']}")
    print("-"*60)
    print(f"  {'Label':<25} {'P':>6} {'R':>6} {'F1':>6}  TP FP FN")
    print("-"*60)
    for lbl, m in metrics["per_label"].items():
        print(f"  {lbl:<25} {m['precision']:>5.0%} {m['recall']:>5.0%} "
              f"{m['f1']:>5.0%}  {m['TP']:2} {m['FP']:2} {m['FN']:2}")
    print("-"*60)
    dist = metrics["confidence_dist"]
    print(f"  Confidence dist: HIGH={dist.get('HIGH',0)}  "
          f"MEDIUM={dist.get('MEDIUM',0)}  LOW={dist.get('LOW',0)}")
    print("="*60 + "\n")


# ─────────────────────────────────────────────────────────────────
#  HTML accuracy report
# ─────────────────────────────────────────────────────────────────

def generate_accuracy_report(metrics: Dict, output_path: str = "accuracy_report.html"):
    from datetime import datetime
    ov    = metrics["overall"]
    lm    = metrics["per_label"]
    cases = metrics["case_results"]
    ts    = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    def _pct(v): return f"{v:.0%}"
    def _color(v):
        if v >= 0.8: return "#20C997"
        if v >= 0.5: return "#F59F00"
        return "#F06595"

    label_rows = ""
    for lbl, m in sorted(lm.items(), key=lambda x: -x[1]["f1"]):
        c = LABEL_COLORS.get(lbl, "#ADB5BD")
        label_rows += (
            f'<tr>'
            f'<td><span style="background:{c};padding:2px 8px;border-radius:4px;'
            f'font-weight:600;color:#0f1117;font-size:0.8rem">{lbl}</span></td>'
            f'<td style="color:{_color(m["precision"])}">{_pct(m["precision"])}</td>'
            f'<td style="color:{_color(m["recall"])}">{_pct(m["recall"])}</td>'
            f'<td style="color:{_color(m["f1"])};font-weight:700">{_pct(m["f1"])}</td>'
            f'<td>{m["TP"]}</td><td style="color:#F59F00">{m["FP"]}</td>'
            f'<td style="color:#F06595">{m["FN"]}</td>'
            f'</tr>'
        )

    case_rows = ""
    for c in cases:
        icon = "✅" if c["status"] == "PASS" else ("⚠️" if c["status"] == "FP_ONLY" else "❌")
        exp  = ", ".join(c["expected"]) or "—"
        det  = ", ".join(c["detected"]) or "—"
        case_rows += (
            f'<tr class="{"pii-row" if c["status"] != "PASS" else ""}">'
            f'<td>{icon}</td>'
            f'<td style="font-family:monospace;font-size:0.78rem">{c["text"]}</td>'
            f'<td style="font-size:0.78rem;color:#94a3b8">{exp}</td>'
            f'<td style="font-size:0.78rem;color:#e2e8f0">{det}</td>'
            f'<td>{c["tp"]}</td><td style="color:#F59F00">{c["fp"]}</td>'
            f'<td style="color:#F06595">{c["fn"]}</td>'
            f'</tr>'
        )

    dist = metrics["confidence_dist"]
    html = f"""<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><title>PII Accuracy Report</title>
<style>
  *{{box-sizing:border-box;margin:0;padding:0}}
  body{{font-family:'Segoe UI',Arial,sans-serif;background:#0f1117;color:#e2e8f0;padding:28px}}
  h1{{font-size:1.5rem;color:#f8fafc;margin-bottom:4px}}
  h2{{font-size:1.1rem;color:#cbd5e1;margin:24px 0 10px}}
  .sub{{color:#94a3b8;font-size:0.87rem;margin-bottom:24px}}
  .cards{{display:flex;gap:14px;flex-wrap:wrap;margin-bottom:24px}}
  .card{{background:#1e2230;border-radius:10px;padding:14px 22px;min-width:130px;text-align:center}}
  .card .num{{font-size:1.8rem;font-weight:700}}
  .card .lbl{{font-size:0.75rem;color:#94a3b8;margin-top:4px}}
  table{{width:100%;border-collapse:collapse;background:#1e2230;border-radius:8px;overflow:hidden;font-size:0.85rem}}
  th{{background:#2d3347;padding:8px 12px;text-align:left;color:#94a3b8;font-size:0.8rem}}
  td{{padding:6px 12px;vertical-align:middle}}
  tr:not(:last-child) td{{border-bottom:1px solid #2d3347}}
  .pii-row{{background:#1a1f30}}
  .wrap{{border-radius:10px;border:1px solid #2d3347;overflow:hidden;margin-bottom:24px}}
  .scroll{{max-height:420px;overflow-y:auto}}
  .footer{{font-size:0.75rem;color:#4a5568;margin-top:20px}}
</style></head>
<body>
<h1>📊 PII Detection — Accuracy Report</h1>
<div class="sub">Region: UK · Jersey · Geneva · Monaco · EU &nbsp;|&nbsp; Generated: {ts}</div>

<div class="cards">
  <div class="card"><div class="num">{metrics["n_test_cases"]}</div><div class="lbl">Test Cases</div></div>
  <div class="card"><div class="num" style="color:#20C997">{metrics["n_passed"]}</div><div class="lbl">Passed</div></div>
  <div class="card"><div class="num" style="color:{_color(ov['precision'])}">{_pct(ov['precision'])}</div><div class="lbl">Precision</div></div>
  <div class="card"><div class="num" style="color:{_color(ov['recall'])}">{_pct(ov['recall'])}</div><div class="lbl">Recall</div></div>
  <div class="card"><div class="num" style="color:{_color(ov['f1'])}">{_pct(ov['f1'])}</div><div class="lbl">F1 Score</div></div>
  <div class="card"><div class="num" style="color:#20C997">{dist.get('HIGH',0)}</div><div class="lbl">High Conf.</div></div>
  <div class="card"><div class="num" style="color:#F59F00">{dist.get('MEDIUM',0)}</div><div class="lbl">Med. Conf.</div></div>
  <div class="card"><div class="num" style="color:#F06595">{dist.get('LOW',0)}</div><div class="lbl">Low Conf.</div></div>
</div>

<h2>Per-Label Metrics</h2>
<div class="wrap"><table>
  <tr><th>Label</th><th>Precision</th><th>Recall</th><th>F1</th><th>TP</th><th>FP</th><th>FN</th></tr>
  {label_rows}
</table></div>

<h2>Test Case Results</h2>
<div class="wrap scroll"><table>
  <tr><th></th><th>Text</th><th>Expected</th><th>Detected</th><th>TP</th><th>FP</th><th>FN</th></tr>
  {case_rows}
</table></div>

<div class="footer">
  Precision = TP/(TP+FP) &nbsp;|&nbsp; Recall = TP/(TP+FN) &nbsp;|&nbsp;
  F1 = harmonic mean of Precision &amp; Recall<br>
  ✅ = correct &nbsp; ⚠️ = false positive &nbsp; ❌ = missed PII
</div>
</body></html>"""

    with open(output_path, "w", encoding="utf-8") as f:
        f.write(html)
    print(f"[INFO] Accuracy report saved: {output_path}")
    return output_path


if __name__ == "__main__":
    metrics = evaluate(verbose=True)
    generate_accuracy_report(metrics)
