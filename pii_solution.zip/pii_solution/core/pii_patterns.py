"""
pii_patterns.py
───────────────
All regex patterns and context keywords for PII detection.
Covers: UK · Jersey · Geneva · Monaco · EU + General (Credit Card, SSN, etc.)
Based on the PII definition document provided.
"""

import re

# ─────────────────────────────────────────────────────────────────
#  REGEX PATTERNS  (label → compiled regex)
# ─────────────────────────────────────────────────────────────────

REGEX_PATTERNS = {

    # ── Email ─────────────────────────────────────────────────────
    "EMAIL": re.compile(
        r'\b[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}\b'
    ),

    # ── UK National Insurance Number ──────────────────────────────
    # Format: AB 12 34 56 C  (with or without spaces)
    "UK_NIN": re.compile(
        r'\b(?!BG|GB|NK|KN|TN|NT|ZZ)[A-CEGHJ-PR-TW-Z]{2}'
        r'\s?\d{2}\s?\d{2}\s?\d{2}\s?[A-D]\b',
        re.IGNORECASE
    ),

    # ── UK Driving Licence ────────────────────────────────────────
    # Format: MORGA657054SM9IJ  (5 letters + 6 digits + 2 letters + 1 digit + 2 letters)
    "UK_DRIVING_LICENCE": re.compile(
        r'\b[A-Z]{5}\d{6}[A-Z]{2}\d[A-Z]{2}\b'
    ),

    # ── UK Postcode ───────────────────────────────────────────────
    "UK_POSTCODE": re.compile(
        r'\b[A-Z]{1,2}\d[A-Z\d]?\s?\d[A-Z]{2}\b',
        re.IGNORECASE
    ),

    # ── UK Sort Code ──────────────────────────────────────────────
    "UK_SORT_CODE": re.compile(
        r'\b\d{2}-\d{2}-\d{2}\b'
    ),

    # ── UK Bank Account (8 digits) ────────────────────────────────
    "UK_BANK_ACCOUNT": re.compile(
        r'(?i)(?:account\s*(?:number|no\.?|#)?\s*:?\s*)(\d{8})\b'
    ),

    # ── IBAN (EU / UK / Jersey / Monaco / Swiss) ──────────────────
    "IBAN": re.compile(
        r'\b(GB|JE|MC|CH|FR|DE|IT|ES|NL|BE|AT|PT|IE|LU|DK|SE|NO|'
        r'FI|PL|CZ|HU|RO|BG|HR|SI|SK|LT|LV|EE|CY|MT|GR)'
        r'\d{2}[A-Z0-9]{11,30}\b'
    ),

    # ── BIC / SWIFT ───────────────────────────────────────────────
    "BIC_SWIFT": re.compile(
        r'\b[A-Z]{4}[A-Z]{2}[A-Z0-9]{2}(?:[A-Z0-9]{3})?\b'
    ),

    # ── Swiss AHV (756.xxxx.xxxx.xx) ─────────────────────────────
    "SWISS_AHV": re.compile(
        r'\b756\.\d{4}\.\d{4}\.\d{2}\b'
    ),

    # ── EU VAT Number ─────────────────────────────────────────────
    "EU_VAT": re.compile(
        r'\b(GB|FR|DE|IT|ES|NL|BE|AT|PT|IE|LU|DK|SE|FI|PL|CZ|HU|MC|CH)'
        r'\d{8,12}\b'
    ),

    # ── Phone – UK (+44 / 07xxx) ──────────────────────────────────
    "PHONE_UK": re.compile(
        r'(?:\+44|0044|0)(?:\s?\(0\))?\s?7\d{3}\s?\d{3}\s?\d{3,4}'
        r'|(?:\+44|0044)\s?\d{2,4}\s?\d{3,4}\s?\d{3,4}'
    ),

    # ── Phone – EU (+33/+41/+377 etc.) ───────────────────────────
    "PHONE_EU": re.compile(
        r'\+(?:33|41|377|352|32|31|49|39|34|351|353|45|46|47|48)'
        r'[\s\-]?\d[\d\s\-]{6,12}\d'
    ),

    # ── Credit Card (16 digit / Luhn-friendly) ────────────────────
    "CREDIT_CARD": re.compile(
        r'\b(?:4\d{3}|5[1-5]\d{2}|3[47]\d{2}|6(?:011|5\d{2}))'
        r'[\s\-]?\d{4}[\s\-]?\d{4}[\s\-]?\d{4}\b'
    ),

    # ── CVV ───────────────────────────────────────────────────────
    "CVV": re.compile(
        r'(?i)(?:cvv|cvc|cvv2|security\s*code)\s*:?\s*(\d{3,4})\b'
    ),

    # ── Primary Account Number (PAN / generic 13–19 digit) ───────
    "PAN": re.compile(
        r'\b\d{13,19}\b'
    ),

    # ── SSN (US – kept for completeness) ─────────────────────────
    "SSN": re.compile(
        r'\b(?!000|666|9\d{2})\d{3}-(?!00)\d{2}-(?!0000)\d{4}\b'
    ),

    # ── Date of Birth ─────────────────────────────────────────────
    # DD/MM/YYYY  DD-MM-YYYY  DD.MM.YYYY  YYYY-MM-DD
    "DOB": re.compile(
        r'\b(?:0[1-9]|[12]\d|3[01])[\/\-\.](?:0[1-9]|1[0-2])[\/\-\.](?:19|20)\d{2}\b'
        r'|\b(?:19|20)\d{2}-(?:0[1-9]|1[0-2])-(?:0[1-9]|[12]\d|3[01])\b'
    ),

    # ── Passport (generic) ────────────────────────────────────────
    "PASSPORT": re.compile(
        r'\b[A-Z]{1,2}\d{6,9}\b'
    ),

    # ── IP Address ────────────────────────────────────────────────
    "IP_ADDRESS": re.compile(
        r'\b(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}'
        r'(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\b'
    ),

    # ── Home Address (street pattern) ─────────────────────────────
    "HOME_ADDRESS": re.compile(
        r'\b\d{1,5}\s+[A-Z][a-zA-Z\s]{3,40}'
        r'(?:Street|St|Road|Rd|Avenue|Ave|Lane|Ln|Drive|Dr|Court|Ct|'
        r'Place|Pl|Way|Close|Cl|Crescent|Cres|Boulevard|Blvd)\b',
        re.IGNORECASE
    ),

    # ── Mother's Maiden Name (context-triggered) ──────────────────
    "MOTHERS_MAIDEN_NAME": re.compile(
        r'(?i)(?:mother[\'s]*\s*maiden\s*name|maiden\s*name)\s*:?\s*([A-Z][a-z]+)'
    ),

    # ── Online Credentials / Password ────────────────────────────
    "PASSWORD": re.compile(
        r'(?i)(?:password|passwd|pwd|secret)\s*[:=]\s*\S+'
    ),
}

# ─────────────────────────────────────────────────────────────────
#  CONTEXT KEYWORDS  (boost confidence when nearby)
# ─────────────────────────────────────────────────────────────────

CONTEXT_KEYWORDS = {
    "EMAIL":                ["email", "e-mail", "mail", "contact", "login", "recovery", "notification"],
    "UK_NIN":               ["national insurance", "ni number", "nin", "nino", "payroll", "tax"],
    "UK_DRIVING_LICENCE":   ["driving licence", "driver licence", "dvla", "identity"],
    "UK_POSTCODE":          ["postcode", "post code", "address", "delivery", "zip"],
    "UK_SORT_CODE":         ["sort code", "sortcode", "bank", "transfer"],
    "UK_BANK_ACCOUNT":      ["account", "bank account", "checking", "savings", "deposit"],
    "IBAN":                 ["iban", "bank", "account", "transfer", "payment", "wire"],
    "BIC_SWIFT":            ["bic", "swift", "bank", "transfer", "wire"],
    "SWISS_AHV":            ["ahv", "avs", "social security", "insurance", "geneva", "swiss"],
    "EU_VAT":               ["vat", "tax", "registration", "invoice"],
    "PHONE_UK":             ["phone", "mobile", "tel", "contact", "sms", "2fa", "call"],
    "PHONE_EU":             ["phone", "mobile", "tel", "contact", "sms", "2fa"],
    "CREDIT_CARD":          ["credit card", "card number", "debit", "payment", "transaction", "pan"],
    "CVV":                  ["cvv", "cvc", "security code", "card verification"],
    "PAN":                  ["pan", "primary account", "card", "payment"],
    "SSN":                  ["social security", "ssn", "tax id", "identity"],
    "DOB":                  ["date of birth", "dob", "born", "birthday", "age verification"],
    "PASSPORT":             ["passport", "travel document", "identity", "non-citizen"],
    "IP_ADDRESS":           ["ip", "address", "network", "request", "login", "access", "device"],
    "HOME_ADDRESS":         ["address", "home", "residence", "delivery", "billing"],
    "MOTHERS_MAIDEN_NAME":  ["maiden", "mother", "security question", "authentication"],
    "PASSWORD":             ["password", "passwd", "credential", "login", "secret"],
}

# ─────────────────────────────────────────────────────────────────
#  LABEL METADATA  (for UI display)
# ─────────────────────────────────────────────────────────────────

LABEL_COLORS = {
    "EMAIL":                "#22B8CF",
    "UK_NIN":               "#FF6B6B",
    "UK_DRIVING_LICENCE":   "#94D82D",
    "UK_POSTCODE":          "#74C0FC",
    "UK_SORT_CODE":         "#FFA94D",
    "UK_BANK_ACCOUNT":      "#845EF7",
    "IBAN":                 "#5C7CFA",
    "BIC_SWIFT":            "#339AF0",
    "SWISS_AHV":            "#20C997",
    "EU_VAT":               "#FAB005",
    "PHONE_UK":             "#F06595",
    "PHONE_EU":             "#CC5DE8",
    "CREDIT_CARD":          "#FF6B6B",
    "CVV":                  "#F03E3E",
    "PAN":                  "#AE3EC9",
    "SSN":                  "#D6336C",
    "DOB":                  "#FFA94D",
    "PASSPORT":             "#2F9E44",
    "IP_ADDRESS":           "#1971C2",
    "HOME_ADDRESS":         "#E67700",
    "MOTHERS_MAIDEN_NAME":  "#862E9C",
    "PASSWORD":             "#C92A2A",
    "PERSON_NAME":          "#FF8787",
    "LOCATION":             "#FFA94D",
}

# Severity of each PII type (HIGH = must redact, MEDIUM = should redact)
LABEL_SEVERITY = {
    "CREDIT_CARD":          "CRITICAL",
    "CVV":                  "CRITICAL",
    "SSN":                  "CRITICAL",
    "UK_NIN":               "CRITICAL",
    "IBAN":                 "CRITICAL",
    "UK_BANK_ACCOUNT":      "CRITICAL",
    "UK_SORT_CODE":         "HIGH",
    "PASSWORD":             "CRITICAL",
    "SWISS_AHV":            "CRITICAL",
    "PASSPORT":             "HIGH",
    "UK_DRIVING_LICENCE":   "HIGH",
    "DOB":                  "HIGH",
    "MOTHERS_MAIDEN_NAME":  "HIGH",
    "PAN":                  "HIGH",
    "EMAIL":                "MEDIUM",
    "PHONE_UK":             "MEDIUM",
    "PHONE_EU":             "MEDIUM",
    "HOME_ADDRESS":         "MEDIUM",
    "UK_POSTCODE":          "MEDIUM",
    "IP_ADDRESS":           "MEDIUM",
    "EU_VAT":               "LOW",
    "BIC_SWIFT":            "LOW",
    "PERSON_NAME":          "MEDIUM",
    "LOCATION":             "LOW",
}
