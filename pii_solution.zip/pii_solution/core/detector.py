"""
detector.py
───────────
Regex + ML Hybrid PII Detector.

Pipeline:
  1. REGEX layer    → fast, high-precision structured PII detection
  2. spaCy NER      → person names, locations from statistical model
  3. ML layer       → sentence-level context classifier for confidence scoring
                      and catching PII regex might miss

Each detection gets:
  - label          : PII type
  - text           : matched value
  - start/end      : character positions
  - regex_match    : bool (did regex find it?)
  - ml_label       : ML classifier prediction for context
  - ml_confidence  : ML confidence score (0-1)
  - final_confidence: combined HIGH / MEDIUM / LOW
  - severity       : CRITICAL / HIGH / MEDIUM / LOW
  - method         : REGEX / SPACY / ML
"""

import re
import sys
from pathlib import Path
from typing import List, Dict, Optional

# Add parent to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from core.pii_patterns import (
    REGEX_PATTERNS, CONTEXT_KEYWORDS,
    LABEL_COLORS, LABEL_SEVERITY
)

_spacy_nlp  = None
_ml_model   = None


def _get_spacy():
    global _spacy_nlp
    if _spacy_nlp is None:
        try:
            import spacy
            _spacy_nlp = spacy.load("en_core_web_sm")
        except Exception:
            _spacy_nlp = False
    return _spacy_nlp if _spacy_nlp else None


def _get_ml_model():
    global _ml_model
    if _ml_model is None:
        try:
            from models.ml_model import load_model
            _ml_model = load_model()
        except Exception as e:
            print(f"[WARN] ML model unavailable: {e}")
            _ml_model = False
    return _ml_model if _ml_model else None


# ─────────────────────────────────────────────────────────────────
#  Confidence scoring
# ─────────────────────────────────────────────────────────────────

def _context_score(label: str, context: str) -> float:
    """Return 0.0–1.0 context keyword score."""
    kws = CONTEXT_KEYWORDS.get(label, [])
    if not kws:
        return 0.3
    ctx = context.lower()
    hits = sum(1 for kw in kws if kw in ctx)
    return min(1.0, hits / max(len(kws), 1) * 3)


def _combine_confidence(label: str, context: str,
                         ml_conf: float, regex_match: bool) -> str:
    """
    Combine regex, context, and ML signals into HIGH/MEDIUM/LOW.
    """
    ctx_score = _context_score(label, context)

    # Weighted combination
    score = 0.0
    if regex_match:
        score += 0.5            # regex always adds weight
    score += ctx_score * 0.3   # context keywords
    score += ml_conf   * 0.2   # ML confidence

    if score >= 0.65:
        return "HIGH"
    elif score >= 0.35:
        return "MEDIUM"
    else:
        return "LOW"


# ─────────────────────────────────────────────────────────────────
#  Main detection function
# ─────────────────────────────────────────────────────────────────

def detect_pii(text: str,
               use_spacy: bool = True,
               use_ml: bool = True,
               context_chars: int = 80,
               min_confidence: str = "LOW") -> List[Dict]:
    """
    Run full Regex + ML Hybrid PII detection on text.

    Args:
        text           : Input text string
        use_spacy      : Whether to run spaCy NER layer
        use_ml         : Whether to run ML classifier layer
        context_chars  : Characters around match used for context scoring
        min_confidence : Filter results below this level (LOW/MEDIUM/HIGH)

    Returns:
        List of detection dicts sorted by position.
    """
    if not text or not text.strip():
        return []

    results   = []
    seen_spans = set()

    # ── LAYER 1: Regex ────────────────────────────────────────────
    for label, pattern in REGEX_PATTERNS.items():
        for m in pattern.finditer(text):
            # Use group(1) if capturing group, else whole match
            try:
                val   = m.group(1)
                start = m.start(1)
                end   = m.end(1)
            except IndexError:
                val   = m.group(0)
                start = m.start(0)
                end   = m.end(0)

            span_key = (start, end)
            if span_key in seen_spans:
                continue
            seen_spans.add(span_key)

            ctx_start = max(0, start - context_chars)
            ctx_end   = min(len(text), end + context_chars)
            context   = text[ctx_start:ctx_end]

            results.append({
                "text":        val,
                "label":       label,
                "start":       start,
                "end":         end,
                "context":     context,
                "regex_match": True,
                "ml_label":    None,
                "ml_confidence": 0.0,
                "method":      "REGEX",
            })

    # ── LAYER 2: spaCy NER ────────────────────────────────────────
    if use_spacy:
        nlp = _get_spacy()
        if nlp:
            doc = nlp(text)
            SPACY_MAP = {
                "PERSON": "PERSON_NAME",
                "GPE":    "LOCATION",
                "LOC":    "LOCATION",
            }
            for ent in doc.ents:
                if ent.label_ not in SPACY_MAP:
                    continue
                span_key = (ent.start_char, ent.end_char)
                if span_key in seen_spans:
                    continue
                seen_spans.add(span_key)

                context = text[max(0, ent.start_char-context_chars):
                                ent.end_char+context_chars]
                results.append({
                    "text":          ent.text,
                    "label":         SPACY_MAP[ent.label_],
                    "start":         ent.start_char,
                    "end":           ent.end_char,
                    "context":       context,
                    "regex_match":   False,
                    "ml_label":      None,
                    "ml_confidence": 0.0,
                    "method":        "SPACY",
                })

    # ── LAYER 3: ML confidence scoring ───────────────────────────
    if use_ml and results:
        model = _get_ml_model()
        if model:
            from models.ml_model import predict_with_confidence
            # Build context windows for ML
            contexts = [r["context"] for r in results]
            ml_preds = predict_with_confidence(contexts, model)

            for result, ml_pred in zip(results, ml_preds):
                result["ml_label"]      = ml_pred["label"]
                result["ml_confidence"] = ml_pred["confidence"]
                result["ml_top3"]       = ml_pred.get("top3", [])

    # ── Compute final confidence + severity for each result ───────
    confidence_order = {"HIGH": 3, "MEDIUM": 2, "LOW": 1}
    min_order = confidence_order.get(min_confidence, 1)

    final = []
    for r in results:
        conf = _combine_confidence(
            r["label"], r["context"],
            r.get("ml_confidence", 0.0),
            r["regex_match"]
        )
        r["final_confidence"] = conf
        r["severity"]         = LABEL_SEVERITY.get(r["label"], "MEDIUM")
        r["color"]            = LABEL_COLORS.get(r["label"], "#ADB5BD")

        if confidence_order.get(conf, 1) >= min_order:
            final.append(r)

    # Sort by position
    final.sort(key=lambda x: x["start"])
    return final


# ─────────────────────────────────────────────────────────────────
#  Redaction
# ─────────────────────────────────────────────────────────────────

def redact_text(text: str, detections: List[Dict],
                mask: str = "█") -> str:
    """Replace detected PII in text with mask character."""
    chars = list(text)
    for det in detections:
        for i in range(det["start"], det["end"]):
            if i < len(chars) and chars[i] not in (" ", "\t"):
                chars[i] = mask
    return "".join(chars)


# ─────────────────────────────────────────────────────────────────
#  File/folder scanner
# ─────────────────────────────────────────────────────────────────

def scan_text(text: str, **kwargs) -> Dict:
    """Scan a plain text string."""
    detections = detect_pii(text, **kwargs)
    return _build_scan_result(text, detections, source="text_input")


def scan_file(file_path: str, **kwargs) -> Dict:
    """Scan a single file."""
    path = Path(file_path)
    if not path.exists():
        return {"error": f"File not found: {file_path}"}

    with open(path, "r", encoding="utf-8", errors="replace") as f:
        content = f.read()

    lines = content.splitlines()
    all_detections = []
    line_results   = []

    offset = 0
    for line_no, line in enumerate(lines, 1):
        dets = detect_pii(line, **kwargs)
        for d in dets:
            d["line_no"] = line_no
            d["start"]  += offset
            d["end"]    += offset
        all_detections.extend(dets)
        line_results.append({"line_no": line_no, "text": line, "detections": dets})
        offset += len(line) + 1  # +1 for newline

    return _build_scan_result(
        content, all_detections,
        source=str(path),
        line_results=line_results
    )


def scan_folder(folder_path: str,
                extensions: List[str] = None,
                **kwargs) -> Dict:
    """Scan all files in a folder."""
    folder = Path(folder_path)
    if not folder.exists() or not folder.is_dir():
        return {"error": f"Folder not found: {folder_path}"}

    if extensions is None:
        extensions = [".txt", ".log", ".csv", ".json", ".xml", ".md"]

    file_results = {}
    for f in folder.rglob("*"):
        if f.suffix.lower() in extensions and f.is_file():
            result = scan_file(str(f), **kwargs)
            file_results[str(f)] = result

    total_pii = sum(r.get("total_pii", 0) for r in file_results.values())
    return {
        "source":       str(folder),
        "scan_type":    "folder",
        "files_scanned": len(file_results),
        "total_pii":    total_pii,
        "file_results": file_results,
    }


def _build_scan_result(text: str, detections: List[Dict],
                       source: str = "", **extra) -> Dict:
    from collections import Counter
    summary = Counter(d["label"] for d in detections)
    severity_counts = Counter(d["severity"] for d in detections)

    return {
        "source":          source,
        "scan_type":       "text",
        "total_pii":       len(detections),
        "detections":      detections,
        "summary":         dict(summary),
        "severity_counts": dict(severity_counts),
        "redacted_text":   redact_text(text, detections),
        **extra,
    }
