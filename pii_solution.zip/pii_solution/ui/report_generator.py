"""
report_generator.py
────────────────────
Generates HTML scan reports for file-level PII detection results.
"""

import sys
from pathlib import Path
from datetime import datetime
from typing import Dict

sys.path.insert(0, str(Path(__file__).parent.parent))
from core.pii_patterns import LABEL_COLORS, LABEL_SEVERITY


def _esc(s: str) -> str:
    return str(s).replace("&","&amp;").replace("<","&lt;").replace(">","&gt;")


def _highlight_line(text: str, detections: list) -> str:
    if not detections:
        return _esc(text)
    result, prev = [], 0
    for det in sorted(detections, key=lambda x: x["start"]):
        s, e   = det["start"], det["end"]
        colour = LABEL_COLORS.get(det["label"], "#ADB5BD")
        label  = det["label"]
        conf   = det.get("final_confidence", "")
        result.append(_esc(text[prev:s]))
        result.append(
            f'<mark style="background:{colour};border-radius:3px;padding:1px 4px;'
            f'color:#0f1117;font-weight:600;cursor:help" '
            f'title="{label} | {conf}">'
            f'{_esc(text[s:e])}'
            f'<sup style="font-size:0.6em;margin-left:2px">{label}</sup></mark>'
        )
        prev = e
    result.append(_esc(text[prev:]))
    return "".join(result)


def generate_file_report(scan_result: Dict, output_path: str) -> str:
    lines     = scan_result.get("line_results", [])
    total_pii = scan_result.get("total_pii", 0)
    summary   = scan_result.get("summary", {})
    source    = scan_result.get("source", "")
    ts        = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    pii_lines = sum(1 for l in lines if l["detections"])

    badge_html = " ".join(
        f'<span style="background:{LABEL_COLORS.get(lbl,"#aaa")};padding:2px 8px;'
        f'border-radius:4px;font-size:0.78rem;font-weight:600;color:#0f1117;">'
        f'{lbl} ({cnt})</span>'
        for lbl, cnt in sorted(summary.items(), key=lambda x: -x[1])
    )

    log_rows = "".join(
        f'<tr class="{"pii-row" if l["detections"] else ""}">'
        f'<td class="ln">{l["line_no"]}</td>'
        f'<td><code>{_highlight_line(l["text"], l["detections"])}</code></td></tr>\n'
        for l in lines
    )

    html = f"""<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><title>PII Report</title>
<style>
  *{{box-sizing:border-box;margin:0;padding:0}}
  body{{font-family:'Segoe UI',Arial,sans-serif;background:#0f1117;color:#e2e8f0;padding:24px}}
  h1{{font-size:1.4rem;color:#f8fafc;margin-bottom:4px}}
  .sub{{color:#94a3b8;font-size:0.87rem;margin-bottom:20px}}
  .cards{{display:flex;gap:12px;flex-wrap:wrap;margin-bottom:20px}}
  .card{{background:#1e2230;border-radius:8px;padding:12px 20px;text-align:center;min-width:120px}}
  .card .n{{font-size:1.6rem;font-weight:700}}.card .l{{font-size:0.75rem;color:#94a3b8;margin-top:2px}}
  .legend{{margin:12px 0 16px;line-height:2.2}}
  .filter-bar{{display:flex;gap:10px;align-items:center;margin-bottom:10px}}
  .filter-bar input[type=text]{{background:#1e2230;border:1px solid #2d3347;color:#e2e8f0;
    border-radius:6px;padding:6px 12px;font-size:0.85rem;width:260px}}
  .filter-bar label{{font-size:0.84rem;color:#94a3b8;cursor:pointer}}
  .wrap{{max-height:600px;overflow-y:auto;border-radius:10px;border:1px solid #2d3347}}
  table{{width:100%;border-collapse:collapse;background:#1e2230;font-size:0.82rem}}
  th{{background:#2d3347;padding:7px 12px;text-align:left;color:#94a3b8;position:sticky;top:0;z-index:2}}
  td{{padding:4px 10px;vertical-align:top}}
  .ln{{color:#4a5568;width:48px;text-align:right;padding-right:12px;border-right:1px solid #2d3347}}
  .pii-row{{background:#1a1f30}}.pii-row:hover{{background:#20253a}}
  mark{{cursor:help}}
</style></head>
<body>
<h1>🔍 PII Detection Report</h1>
<div class="sub">File: <code>{_esc(source)}</code> &nbsp;|&nbsp; {ts}</div>
<div class="cards">
  <div class="card"><div class="n">{len(lines)}</div><div class="l">Lines</div></div>
  <div class="card"><div class="n" style="color:#f87171">{pii_lines}</div><div class="l">PII Lines</div></div>
  <div class="card"><div class="n" style="color:#fb923c">{total_pii}</div><div class="l">PII Items</div></div>
  <div class="card"><div class="n">{len(summary)}</div><div class="l">PII Types</div></div>
</div>
<div class="legend">{badge_html or '<span style="color:#20C997">✅ No PII detected</span>'}</div>
<div class="filter-bar">
  <input type="text" id="fi" placeholder="🔎 Filter lines..." oninput="filterLines()">
  <label><input type="checkbox" id="po" onchange="filterLines()"> PII lines only</label>
</div>
<div class="wrap"><table id="lt">
  <thead><tr><th style="width:48px">#</th><th>Log Line</th></tr></thead>
  <tbody>{log_rows}</tbody>
</table></div>
<script>
function filterLines(){{
  const q=document.getElementById('fi').value.toLowerCase();
  const p=document.getElementById('po').checked;
  document.querySelectorAll('#lt tbody tr').forEach(r=>{{
    r.style.display=((!q||r.textContent.toLowerCase().includes(q))&&(!p||r.classList.contains('pii-row')))?'':'none';
  }});
}}
</script>
</body></html>"""

    with open(output_path, "w", encoding="utf-8") as f:
        f.write(html)
    return output_path
