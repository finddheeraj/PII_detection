# 🔍 PII Detection Solution

**Regex + ML Hybrid** PII detector for European data (UK · Jersey · Geneva · Monaco · EU)

Based on your PII definition document covering: SSN, DOB, Credit Card, CVV, Bank Accounts,
IBAN, NI Numbers, Passports, Driver's Licences, Biometric Data, Passwords, and more.

---

## Quick Start

### 1. Prerequisites
- Python 3.9+
- VS Code with Python extension

### 2. Install & Run (one command)
```bash
python setup_and_run.py
```

This will:
- Install all dependencies from `requirements.txt`
- Download the spaCy `en_core_web_sm` model
- Train the ML classifier on synthetic European PII data (~1 min)
- Launch the Gradio UI at **http://localhost:7860**

### 3. Manual setup (alternative)
```bash
pip install -r requirements.txt
python -m spacy download en_core_web_sm
python ui/app.py
```

---

## Project Structure

```
pii_solution/
├── setup_and_run.py          ← Run this first
├── requirements.txt
│
├── core/
│   ├── detector.py           ← Hybrid Regex + ML + spaCy pipeline
│   └── pii_patterns.py       ← All regex patterns & context keywords
│
├── models/
│   ├── ml_model.py           ← TF-IDF + Logistic Regression classifier
│   └── pii_classifier.joblib ← Trained model (auto-generated)
│
├── data/
│   └── data_generator.py     ← Synthetic EU PII data generator
│
├── ui/
│   ├── app.py                ← Gradio 4-tab UI
│   └── report_generator.py   ← HTML report generator
│
├── tests/
│   └── accuracy.py           ← Precision/Recall/F1 evaluation
│
└── reports/                  ← Generated HTML reports saved here
```

---

## UI Tabs

| Tab | Description |
|-----|-------------|
| **📝 Text Input** | Paste text, see inline colour-coded highlights |
| **📄 File Scan** | Upload or enter path to `.txt/.log/.csv` etc. |
| **📁 Folder Scan** | Scan all files in a directory recursively |
| **📊 Accuracy** | Run evaluation against 50+ labelled EU test cases |

---

## PII Types Detected (20+)

| Label | Region | Severity |
|-------|--------|----------|
| EMAIL | Universal | MEDIUM |
| UK_NIN | UK · Jersey | CRITICAL |
| UK_DRIVING_LICENCE | UK | HIGH |
| UK_POSTCODE | UK · Jersey | MEDIUM |
| UK_SORT_CODE | UK | HIGH |
| UK_BANK_ACCOUNT | UK | CRITICAL |
| IBAN | UK/JE/CH/MC/FR/DE/EU | CRITICAL |
| BIC_SWIFT | EU | LOW |
| SWISS_AHV | Switzerland · Geneva | CRITICAL |
| EU_VAT | EU | LOW |
| PHONE_UK | UK | MEDIUM |
| PHONE_EU | EU/Monaco/Geneva | MEDIUM |
| CREDIT_CARD | Universal | CRITICAL |
| CVV | Universal | CRITICAL |
| PAN | Universal | HIGH |
| SSN | US (legacy) | CRITICAL |
| DOB | Universal | HIGH |
| PASSPORT | Universal | HIGH |
| IP_ADDRESS | Universal | MEDIUM |
| HOME_ADDRESS | Universal | MEDIUM |
| MOTHERS_MAIDEN_NAME | Universal | HIGH |
| PASSWORD | Universal | CRITICAL |
| PERSON_NAME | Universal (spaCy) | MEDIUM |
| LOCATION | Universal (spaCy) | LOW |

---

## Detection Pipeline

```
Input Text
    │
    ├── REGEX layer       → Structured PII (IBAN, NIN, email, phone, etc.)
    │
    ├── spaCy NER         → Person names, locations (en_core_web_sm)
    │
    └── ML Classifier     → TF-IDF + Logistic Regression
                            Trained on synthetic EU PII data
                            Provides confidence scoring per detection
                            Combines with regex + context keywords
                            → final: HIGH / MEDIUM / LOW confidence
```

---

## Confidence Scoring

Each detection gets a confidence score combining:
- **Regex match** (0.5 weight) — did the pattern match?
- **Context keywords** (0.3 weight) — nearby words like "IBAN", "sort code", "NI number"
- **ML classifier** (0.2 weight) — sentence-level prediction confidence

| Score | Meaning |
|-------|---------|
| **HIGH** | Regex matched + context keyword found |
| **MEDIUM** | Regex matched, no strong context |
| **LOW** | Weak match, review manually |

---

## Running Accuracy Evaluation Standalone

```bash
python tests/accuracy.py
```

Opens `reports/accuracy_report.html` with per-label Precision/Recall/F1.

---

## Retraining the ML Model

```bash
python models/ml_model.py
```

Or increase sample size in `setup_and_run.py`:
```python
train(n_samples=5000, verbose=True)
```
