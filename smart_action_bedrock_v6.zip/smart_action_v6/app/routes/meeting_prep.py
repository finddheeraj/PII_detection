"""
routes/meeting_prep.py  (v6)
-----------------------------
GET  /api/meeting/types    -> list of meeting types
GET  /api/meeting/blocks   -> list of all content blocks
POST /api/meeting/defaults -> default block IDs for a meeting type
POST /api/meeting/prepare  -> generate objectives + agenda + email
"""

from __future__ import annotations
import logging

from flask import Blueprint, request, jsonify
from pydantic import BaseModel, Field
from typing import Optional, List

from app.services.llm_service import LLMService
from app.config import app_config

logger = logging.getLogger(__name__)

meeting_prep_bp = Blueprint("meeting_prep", __name__, url_prefix="/api/meeting")

# ── Meeting types ─────────────────────────────────────────────────────────────

MEETING_TYPES = [
    "Introductory / Discovery",
    "Opportunity / Solution Exploration",
    "Onboarding / Setup",
    "Regulatory / Compliance Onboarding",
    "Advisory Meeting",
    "Market / Insights Update",
    "Periodic Review (ASR)",
    "Decision / Approval / Execution",
    "Risk / Compliance Meeting",
    "Issue Resolution / Escalation",
    "Lunch / Dinner",
    "Coffee Chat",
    "Networking Event",
    "Termination / Offboarding",
]

# ── Content blocks catalogue ──────────────────────────────────────────────────

CONTENT_BLOCKS = [
    {"id": "static_info",        "label": "Static Information",              "module": "Client Profile",  "default_minutes": 5},
    {"id": "client_sentiment",   "label": "Client Sentiment Analysis",       "module": "Client Profile",  "default_minutes": 10},
    {"id": "one_page_summary",   "label": "One Page Summary",                "module": "Client Profile",  "default_minutes": 10},
    {"id": "activity_history",   "label": "Meeting / Activity History",      "module": "Relationship",    "default_minutes": 10},
    {"id": "client_actions",     "label": "Outstanding Client Actions",      "module": "Relationship",    "default_minutes": 10},
    {"id": "annual_review",      "label": "Annual Review & Material Changes","module": "Relationship",    "default_minutes": 15},
    {"id": "perf_drivers",       "label": "Performance Drivers",             "module": "Portfolio",       "default_minutes": 15},
    {"id": "portfolio_holdings", "label": "Account & Portfolio Holdings",    "module": "Portfolio",       "default_minutes": 15},
    {"id": "transactions",       "label": "Transactions",                    "module": "Portfolio",       "default_minutes": 10},
    {"id": "fees",               "label": "Fees Data",                       "module": "Portfolio",       "default_minutes": 5},
    {"id": "market_insights",    "label": "Market Insights",                 "module": "Market",          "default_minutes": 15},
    {"id": "sales_mgmt",         "label": "Sales Management Insights",       "module": "Market",          "default_minutes": 10},
    {"id": "cross_team_wf",      "label": "Cross-team Workflow Log",         "module": "Operations",      "default_minutes": 10},
    {"id": "future_planning",    "label": "Future Planning Suggestions",     "module": "Planning",        "default_minutes": 10},
]

# ── Smart defaults per meeting type ──────────────────────────────────────────

DEFAULTS_BY_TYPE = {
    "Introductory / Discovery":           ["static_info", "one_page_summary", "market_insights"],
    "Opportunity / Solution Exploration": ["static_info", "client_sentiment", "perf_drivers", "market_insights", "sales_mgmt"],
    "Onboarding / Setup":                 ["static_info", "one_page_summary", "portfolio_holdings", "fees"],
    "Regulatory / Compliance Onboarding": ["static_info", "annual_review", "cross_team_wf"],
    "Advisory Meeting":                   ["static_info", "client_sentiment", "perf_drivers", "portfolio_holdings", "market_insights", "future_planning"],
    "Market / Insights Update":           ["market_insights", "sales_mgmt", "perf_drivers"],
    "Periodic Review (ASR)":              ["static_info", "one_page_summary", "annual_review", "perf_drivers", "portfolio_holdings", "fees", "client_actions"],
    "Decision / Approval / Execution":    ["static_info", "client_actions", "perf_drivers", "transactions"],
    "Risk / Compliance Meeting":          ["static_info", "annual_review", "cross_team_wf", "transactions", "fees"],
    "Issue Resolution / Escalation":      ["static_info", "activity_history", "client_actions", "cross_team_wf"],
    "Lunch / Dinner":                     ["static_info", "one_page_summary", "activity_history"],
    "Coffee Chat":                        ["static_info", "activity_history"],
    "Networking Event":                   ["static_info", "one_page_summary"],
    "Termination / Offboarding":          ["static_info", "one_page_summary", "portfolio_holdings", "fees", "transactions", "annual_review"],
}

# ── Pydantic models ───────────────────────────────────────────────────────────

class ContentBlockInput(BaseModel):
    id:      str
    label:   str
    minutes: int = Field(..., ge=1, le=120)

class MeetingPrepRequest(BaseModel):
    context:        str                     = Field(..., min_length=10, max_length=5_000)
    client_name:    str                     = Field(..., min_length=1,  max_length=100)
    banker_name:    str                     = Field(..., min_length=1,  max_length=100)
    meeting_type:   str                     = Field(...)
    content_blocks: List[ContentBlockInput] = Field(..., min_items=1)
    meeting_date:   Optional[str]           = None
    meeting_time:   Optional[str]           = None
    location:       Optional[str]           = None

# ── System prompt ─────────────────────────────────────────────────────────────

SYSTEM_PROMPT = f"""You are an AI assistant for Barclays Private Bank & Wealth Management (India).
Your task is to prepare structured meeting materials for a private banker.

Today's date is {app_config.reference_date}.

Given a meeting type, ordered content blocks with allocated minutes, and a brief meeting description,
produce the following in a single JSON object:

{{
  "objectives": [
    "Objective 1 — clear, one-sentence banker goal",
    "Objective 2",
    "Objective 3"
  ],
  "agenda": [
    {{ "order": 1, "time": "10:00 AM", "duration_min": 5,  "item": "Welcome and introductions",       "section_id": null }},
    {{ "order": 2, "time": "10:05 AM", "duration_min": 15, "item": "Portfolio performance review",     "section_id": "perf_drivers" }},
    {{ "order": 3, "time": "10:20 AM", "duration_min": 5,  "item": "Next steps and action items",     "section_id": null }},
    {{ "order": 4, "time": "10:25 AM", "duration_min": 5,  "item": "Close",                           "section_id": null }}
  ],
  "total_minutes": 30,
  "email_subject": "Meeting Invitation — Portfolio Review | Barclays Private Bank",
  "email_body": "Dear [Client Name],\\n\\nI hope this message finds you well...\\n\\nWarm regards,\\n[Banker Name]\\nBarclays Private Bank & Wealth Management"
}}

Rules:
- Objectives: 3 to 5 bullet points, banker-facing, action-oriented, specific to the meeting type.
- Agenda: Always open with Welcome (5 min) and close with Next Steps + Close (~10 min combined).
  Map each selected content block to one or more agenda items respecting its allocated minutes.
  Compute clock times sequentially from the given meeting_time (default 10:00 AM if not provided).
- duration_min MUST be an integer (not a string).
- total_minutes MUST equal the exact sum of all duration_min values.
- Email: Professional, warm, Barclays Private Bank tone. Include objectives and agenda inline. Sign off with banker name.
- No emoji anywhere.
- Return ONLY the JSON object — no markdown fences, no explanation."""


# ── Routes ────────────────────────────────────────────────────────────────────

@meeting_prep_bp.get("/types")
def get_meeting_types():
    return jsonify({"meeting_types": MEETING_TYPES}), 200


@meeting_prep_bp.get("/blocks")
def get_content_blocks():
    return jsonify({"blocks": CONTENT_BLOCKS}), 200


@meeting_prep_bp.post("/defaults")
def get_defaults():
    raw   = request.get_json(force=True) or {}
    mtype = raw.get("meeting_type", "")
    if mtype not in DEFAULTS_BY_TYPE:
        return jsonify({"error": "Unknown meeting type"}), 400
    return jsonify({"default_block_ids": DEFAULTS_BY_TYPE[mtype]}), 200


@meeting_prep_bp.post("/prepare")
def prepare_meeting():
    raw = request.get_json(force=True)
    try:
        body = MeetingPrepRequest(**raw)
    except Exception as e:
        return jsonify({"error": "Invalid request", "detail": str(e)}), 400

    extra_lines = [
        f"Meeting date: {body.meeting_date}" if body.meeting_date else "",
        f"Meeting time: {body.meeting_time}" if body.meeting_time else "",
        f"Location: {body.location}"         if body.location     else "",
    ]
    extra = "\n".join(filter(None, extra_lines))

    blocks_lines    = "\n".join(f"  - {b.label} ({b.minutes} min)" for b in body.content_blocks)
    total_block_min = sum(b.minutes for b in body.content_blocks)

    user_prompt = f"""Client name:   {body.client_name}
Banker name:   {body.banker_name}
Meeting type:  {body.meeting_type}
{extra}

Selected content blocks (ordered, with allocated discussion time):
{blocks_lines}
Total block time: {total_block_min} min  (add ~5 min Welcome and ~10 min Next Steps + Close)

Meeting context:
{body.context}

Generate objectives, agenda, and invitation email now."""

    logger.info(
        f"Meeting prep — type={body.meeting_type}, client={body.client_name}, "
        f"blocks={len(body.content_blocks)}, total_min={total_block_min}"
    )

    llm = LLMService.get_instance()
    try:
        result = llm.generate_json(system=SYSTEM_PROMPT, user=user_prompt)
        return jsonify(result), 200
    except Exception as e:
        logger.error(f"Meeting prep LLM error: {e}")
        return jsonify({"error": "LLM generation failed", "detail": str(e)}), 500
