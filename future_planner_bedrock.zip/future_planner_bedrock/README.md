# Future Planning Tool – Bedrock POC
## Smart Action List | Sub-requirement 7 | AWS Bedrock Edition

Flask-based proof-of-concept using **AWS Bedrock via pbwm_genai_config** —
the exact same connection pattern as your Barclays Jupyter notebook and
the `smart_action_bedrock` project.

---

## Quick Start

```bash
# 1. Install pbwm_genai_config (your local .whl)
pip install C:\SourceCode\genai-meeting-prep-api\pbwm_genai_config-0.1.9.13-py3-none-any.whl

# 2. Install other dependencies
pip install -r requirements.txt

# 3. Configure credentials
copy .env.example .env
# Edit .env — fill in USER_USERNAME, USER_PASSWORD, CREDS_ROLE_ARN

# 4. Run
python run.py
# → http://localhost:5050
```

---

## How the Bedrock connection works

This POC mirrors your notebook **cells [8]–[18]** exactly:

| Notebook Cell | This Project |
|---|---|
| `config = Config(logger=logger)` | `LLMService.load()` in `app/services/llm_service.py` |
| `boto3_session = config._aws_session` | same |
| `botocore_config = config._aws_config` | same |
| `bedrock_runtime = boto3_session.client("bedrock-runtime", ...)` | same |
| `bedrock_runtime.invoke_model(modelId=..., body=...)` | `LLMService.generate()` |
| `_extract_text(response_body)` | same, inline in `generate()` |

The AI explanation endpoint (`POST /api/explain`) flows:

```
Browser  →  Flask /api/explain
              ↓
         LLMService.generate()
              ↓
         pbwm_genai_config (handles proxy, creds, STS role assumption)
              ↓
         AWS Bedrock → Claude (eu.anthropic.claude-sonnet-4-5-...)
              ↓
         Natural-language explanation returned to browser
```

No credentials or API keys are ever exposed to the browser.

---

## Project Structure

```
future_planner_bedrock/
├── run.py                          # Entry point — loads Bedrock at startup
├── .env.example                    # Copy to .env and fill credentials
├── requirements.txt
└── app/
    ├── __init__.py                 # Flask app factory
    ├── config.py                   # BedrockConfig + AppConfig (reads .env)
    ├── services/
    │   ├── llm_service.py          # Bedrock singleton (mirrors notebook)
    │   └── planning_service.py     # Scoring, slot-matching, AI explanation
    ├── routes/
    │   ├── planning.py             # All Future Planning API endpoints
    │   └── health.py               # GET /api/health (reports LLM status)
    └── templates/
        └── index.html              # Barclays-branded UI
```

---

## API Endpoints

| Method | Path | Description |
|---|---|---|
| GET | `/` | Main dashboard UI |
| GET | `/api/slots` | Today's mock Outlook calendar slots |
| GET | `/api/suggestions` | AI-scored suggestions matched to slots |
| POST | `/api/explain` | **Bedrock Claude** generates explanation for a suggestion |
| POST | `/api/accept` | Book action into Outlook (session) |
| POST | `/api/reject` | Dismiss action (removed from suggestions) |
| POST | `/api/snooze` | Snooze action (hidden temporarily) |
| POST | `/api/reshuffle` | Surface next-best action for a slot |
| GET | `/api/learning_summary` | Accept/reject/snooze counters |
| POST | `/api/reset` | Clear session |
| GET | `/api/health` | App + Bedrock client status |

---

## Graceful Degradation

If Bedrock is unavailable (network issue, credentials not set, pbwm_genai_config
not installed), the app **still runs** — the `✦ Explain` button returns a
rule-based fallback explanation instead. All other features (scoring, slot
matching, accept/reject/snooze/reshuffle) are purely rule-based and always work.

---

## For Production

| Mock | Replace with |
|---|---|
| `MOCK_CALENDAR_SLOTS` | Microsoft Graph API (Outlook) |
| `MOCK_ACTIONS` | Smart Action List database |
| Session-based learning | Persistent user preferences DB |
| In-memory state | Redis / SQL store |
