"""
app/__init__.py
---------------
Flask application factory for Future Planning Tool POC.
"""

import logging
from flask import Flask
from dotenv import load_dotenv

load_dotenv()

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(name)s — %(message)s",
)


def create_app() -> Flask:
    from app.config import app_config

    flask_app = Flask(
        __name__,
        template_folder="templates",
        static_folder="static",
    )
    flask_app.secret_key = app_config.secret_key

    # Register blueprints
    from app.routes.planning  import planning_bp
    from app.routes.health    import health_bp

    flask_app.register_blueprint(planning_bp)
    flask_app.register_blueprint(health_bp)

    return flask_app
