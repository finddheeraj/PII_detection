"""
config.py
---------
Configuration for Future Planning Tool POC — AWS Bedrock via pbwm_genai_config.
Mirrors the pattern from smart_action_bedrock exactly.
Set values in .env (never hardcode credentials).
"""

import os
from dataclasses import dataclass


@dataclass
class BedrockConfig:
    aws_region:  str   = os.getenv("CREDS_DEFAULT_REGION", "eu-west-2")
    model_id:    str   = os.getenv("LLM_CHAT_MODEL", "eu.anthropic.claude-sonnet-4-5-20250929-v1:0")
    verify_ssl:  str   = os.getenv("USER_VERIFY_PEM", "")
    temperature: float = 0.3
    max_tokens:  int   = 512   # Explanations are short; keep it snappy


@dataclass
class AppConfig:
    debug:      bool = os.getenv("FLASK_DEBUG", "true").lower() == "true"
    host:       str  = os.getenv("FLASK_HOST", "0.0.0.0")
    port:       int  = int(os.getenv("FLASK_PORT", "5050"))
    secret_key: str  = os.getenv("SECRET_KEY", "future-planner-dev-key")


bedrock_config = BedrockConfig()
app_config     = AppConfig()
