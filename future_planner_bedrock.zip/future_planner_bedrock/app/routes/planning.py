"""
routes/planning.py
------------------
All Future Planning Tool API endpoints.
"""

from __future__ import annotations
import logging
from flask import Blueprint, request, jsonify, render_template, session

from app.services.planning_service import (
    MOCK_CALENDAR_SLOTS,
    MOCK_ACTIONS,
    score_action,
    match_actions_to_slot,
    generate_explanation,
)

logger = logging.getLogger(__name__)
planning_bp = Blueprint("planning", __name__)


# ── UI ─────────────────────────────────────────────────────────────────────

@planning_bp.get("/")
def index():
    return render_template("index.html")


# ── Calendar Slots ─────────────────────────────────────────────────────────

@planning_bp.get("/api/slots")
def get_slots():
    return jsonify(MOCK_CALENDAR_SLOTS)


# ── Suggestions (Rule-ranked) ──────────────────────────────────────────────

@planning_bp.get("/api/suggestions")
def get_suggestions():
    rejected = session.get("rejected", [])
    snoozed  = session.get("snoozed",  [])

    result = []
    for slot in MOCK_CALENDAR_SLOTS:
        matched = match_actions_to_slot(slot, MOCK_ACTIONS, rejected, snoozed)
        if matched:
            top = matched[0]
            result.append({
                "slot":         slot,
                "action":       top,
                "score":        score_action(top),
                "alternatives": [{"id": a["id"], "task": a["task"]} for a in matched[1:]],
            })
    return jsonify(result)


# ── AI Explanation (Bedrock) ───────────────────────────────────────────────

@planning_bp.post("/api/explain")
def explain():
    """
    Call Bedrock Claude to generate a natural-language explanation
    for why a specific action fits a specific slot.
    """
    data      = request.get_json(force=True)
    action_id = data.get("action_id")
    slot_id   = data.get("slot_id")

    action = next((a for a in MOCK_ACTIONS if a["id"] == action_id), None)
    slot   = next((s for s in MOCK_CALENDAR_SLOTS if s["id"] == slot_id), None)

    if not action or not slot:
        return jsonify({"error": "Action or slot not found"}), 404

    try:
        explanation = generate_explanation(action, slot)
        return jsonify({"explanation": explanation, "source": "bedrock"})
    except Exception as e:
        logger.error(f"[/api/explain] Error: {e}")
        return jsonify({
            "explanation": f"High urgency ({action['urgency']}/10) and client value alignment make this the optimal use of this slot.",
            "source": "fallback"
        })


# ── Accept / Reject / Snooze ───────────────────────────────────────────────

@planning_bp.post("/api/accept")
def accept():
    data = request.get_json(force=True)
    accepted = session.get("accepted", [])
    accepted.append({
        "action_id": data.get("action_id"),
        "slot_id":   data.get("slot_id"),
    })
    session["accepted"] = accepted
    return jsonify({"status": "accepted", "message": "Task scheduled in your Outlook calendar."})


@planning_bp.post("/api/reject")
def reject():
    data = request.get_json(force=True)
    rejected = session.get("rejected", [])
    rejected.append(data.get("action_id"))
    session["rejected"] = rejected
    return jsonify({"status": "rejected"})


@planning_bp.post("/api/snooze")
def snooze():
    data = request.get_json(force=True)
    snoozed = session.get("snoozed", [])
    snoozed.append(data.get("action_id"))
    session["snoozed"] = snoozed
    return jsonify({"status": "snoozed"})


# ── Reshuffle ──────────────────────────────────────────────────────────────

@planning_bp.post("/api/reshuffle")
def reshuffle():
    data    = request.get_json(force=True)
    slot_id = data.get("slot_id")

    slot = next((s for s in MOCK_CALENDAR_SLOTS if s["id"] == slot_id), None)
    if not slot:
        return jsonify({"error": "Slot not found"}), 404

    rejected = session.get("rejected", [])
    snoozed  = session.get("snoozed",  [])
    matched  = match_actions_to_slot(slot, MOCK_ACTIONS, rejected, snoozed)

    if len(matched) > 1:
        matched = matched[1:] + matched[:1]

    if not matched:
        return jsonify({"action": None})

    top = matched[0]
    return jsonify({
        "action":       top,
        "score":        score_action(top),
        "alternatives": [{"id": a["id"], "task": a["task"]} for a in matched[1:]],
    })


# ── Learning Stats ─────────────────────────────────────────────────────────

@planning_bp.get("/api/learning_summary")
def learning_summary():
    return jsonify({
        "accepted_count": len(session.get("accepted", [])),
        "rejected_count": len(session.get("rejected", [])),
        "snoozed_count":  len(session.get("snoozed",  [])),
    })


# ── Reset ──────────────────────────────────────────────────────────────────

@planning_bp.post("/api/reset")
def reset():
    session.clear()
    return jsonify({"status": "reset"})
