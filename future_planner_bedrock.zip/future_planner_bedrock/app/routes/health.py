"""
routes/health.py
----------------
Health check — also reports Bedrock client status.
"""

from flask import Blueprint, jsonify
from app.services.llm_service import LLMService

health_bp = Blueprint("health", __name__, url_prefix="/api")


@health_bp.get("/health")
def health():
    llm = LLMService.get_instance()
    return jsonify({
        "status":      "ok",
        "llm_loaded":  llm.is_loaded,
        "llm_backend": "AWS Bedrock via pbwm_genai_config",
    })
