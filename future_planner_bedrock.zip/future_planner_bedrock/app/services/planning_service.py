"""
services/planning_service.py
-----------------------------
Core planning logic for Future Planning Tool.

Hybrid architecture:
  - Rule-based: slot classification, effort matching, compliance floor
  - AI (Bedrock): urgency/value scoring weights + natural-language explanation
"""

from __future__ import annotations
import logging
from typing import Any

from app.services.llm_service import LLMService

logger = logging.getLogger(__name__)

# ── Mock Data ──────────────────────────────────────────────────────────────

MOCK_CALENDAR_SLOTS = [
    {"id": "s1", "label": "09:15 – 09:30", "duration": 15, "type": "short",  "time": "09:15"},
    {"id": "s2", "label": "10:45 – 11:15", "duration": 30, "type": "medium", "time": "10:45"},
    {"id": "s3", "label": "12:00 – 12:45", "duration": 45, "type": "long",   "time": "12:00"},
    {"id": "s4", "label": "14:00 – 14:10", "duration": 10, "type": "short",  "time": "14:00"},
    {"id": "s5", "label": "15:30 – 16:15", "duration": 45, "type": "long",   "time": "15:30"},
    {"id": "s6", "label": "16:45 – 17:00", "duration": 15, "type": "short",  "time": "16:45"},
]

MOCK_ACTIONS = [
    {
        "id": "a1", "task": "Send KYC reminder to Ananya Sharma",
        "client": "Ananya Sharma", "estimated_minutes": 10,
        "effort": "low", "urgency": 9, "value": 7,
        "tags": ["compliance", "KYC"], "due": "Today", "type": "follow-up"
    },
    {
        "id": "a2", "task": "Review portfolio rebalancing proposal – Mehta Family Office",
        "client": "Mehta Family Office", "estimated_minutes": 40,
        "effort": "high", "urgency": 6, "value": 10,
        "tags": ["investment", "proposal"], "due": "Tomorrow", "type": "investment"
    },
    {
        "id": "a3", "task": "Approve offshore bond transfer documentation",
        "client": "Chen Wei", "estimated_minutes": 20,
        "effort": "medium", "urgency": 8, "value": 8,
        "tags": ["compliance", "approval"], "due": "Today", "type": "approval"
    },
    {
        "id": "a4", "task": "Draft investment memo – Gupta Holdings ESG fund",
        "client": "Gupta Holdings", "estimated_minutes": 50,
        "effort": "high", "urgency": 5, "value": 9,
        "tags": ["investment", "ESG"], "due": "This week", "type": "investment"
    },
    {
        "id": "a5", "task": "Send meeting follow-up notes to Al-Rashid family",
        "client": "Al-Rashid Family", "estimated_minutes": 12,
        "effort": "low", "urgency": 7, "value": 6,
        "tags": ["relationship", "follow-up"], "due": "Today", "type": "follow-up"
    },
    {
        "id": "a6", "task": "Prepare tailored FX hedging proposal – Nakamura Corp",
        "client": "Nakamura Corp", "estimated_minutes": 45,
        "effort": "high", "urgency": 7, "value": 10,
        "tags": ["investment", "FX"], "due": "Tomorrow", "type": "investment"
    },
    {
        "id": "a7", "task": "Confirm R&C sign-off on Patel trust restructure",
        "client": "Patel Trust", "estimated_minutes": 8,
        "effort": "low", "urgency": 10, "value": 8,
        "tags": ["compliance", "R&C"], "due": "Today", "type": "compliance"
    },
    {
        "id": "a8", "task": "Call to check in with Okonkwo re: philanthropy goals",
        "client": "James Okonkwo", "estimated_minutes": 30,
        "effort": "medium", "urgency": 4, "value": 7,
        "tags": ["relationship"], "due": "This week", "type": "relationship"
    },
]


# ── Scoring (rule-based hybrid) ────────────────────────────────────────────

def score_action(action: dict) -> float:
    """
    Deterministic scoring formula.
    Urgency × 0.5 + Value × 0.35 − effort_penalty + compliance_boost
    """
    urgency = action["urgency"]
    value   = action["value"]
    effort_penalty   = {"low": 0, "medium": -0.5, "high": -1.5}[action["effort"]]
    compliance_boost = 2 if any(t in ["compliance", "R&C", "KYC"] for t in action["tags"]) else 0
    return round((urgency * 0.5) + (value * 0.35) + effort_penalty + compliance_boost, 2)


def match_actions_to_slot(
    slot: dict,
    actions: list[dict],
    rejected_ids: list[str] | None = None,
    snoozed_ids:  list[str] | None = None,
) -> list[dict]:
    """Rule-based: filter by slot duration + sort by score."""
    rejected_ids = rejected_ids or []
    snoozed_ids  = snoozed_ids  or []

    eligible = [
        a for a in actions
        if a["id"] not in rejected_ids
        and a["id"] not in snoozed_ids
        and a["estimated_minutes"] <= slot["duration"] + 5
    ]
    return sorted(eligible, key=score_action, reverse=True)[:3]


# ── AI Explanation via Bedrock ─────────────────────────────────────────────

EXPLAIN_SYSTEM = """You are an intelligent assistant for a private banker at Barclays Wealth.
Given a calendar slot and a suggested action, write a SHORT (2 sentences max) compelling reason
why this is the best use of this time. Be specific, professional, and concise. No filler words.
Respond with ONLY the reason text — no preamble, no labels."""


def generate_explanation(action: dict, slot: dict) -> str:
    """Call Bedrock Claude to generate a natural-language explanation."""
    llm = LLMService.get_instance()

    if not llm.is_loaded:
        logger.warning("[Explain] LLM not loaded — returning fallback.")
        return _fallback_explanation(action, slot)

    user_prompt = (
        f"Slot: {slot['label']} ({slot['duration']} minutes, {slot['type']} slot)\n"
        f"Action: {action['task']}\n"
        f"Client: {action['client']}\n"
        f"Tags: {', '.join(action['tags'])}\n"
        f"Urgency: {action['urgency']}/10 | Client value: {action['value']}/10\n"
        f"Effort: {action['effort']} | Due: {action['due']}\n\n"
        f"Why is this the best action for this slot?"
    )

    try:
        return llm.generate(system=EXPLAIN_SYSTEM, user=user_prompt)
    except Exception as e:
        logger.error(f"[Explain] Bedrock call failed: {e}")
        return _fallback_explanation(action, slot)


def _fallback_explanation(action: dict, slot: dict) -> str:
    """Rule-based fallback if Bedrock is unavailable."""
    compliance_tags = [t for t in action["tags"] if t in ["compliance", "R&C", "KYC"]]
    if compliance_tags:
        return (
            f"This {slot['type']} slot is ideal for a compliance-critical item. "
            f"With urgency {action['urgency']}/10 and a {action['due'].lower()} deadline, "
            f"this should not be deferred."
        )
    return (
        f"This {slot['duration']}-minute window matches the estimated effort perfectly. "
        f"At urgency {action['urgency']}/10 and client value {action['value']}/10, "
        f"this is the highest-scoring available action for {action['client']}."
    )
