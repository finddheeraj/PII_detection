"""
services/llm_service.py
-----------------------
LLM service using AWS Bedrock via pbwm_genai_config.

Mirrors exactly the pattern in your Barclays Jupyter notebook and
smart_action_bedrock project:

  Cell [8]:  config = Config(logger=logger)
  Cell [14]: boto3_session = config._aws_session
  Cell [15]: botocore_config = config._aws_config
  Cell [16]: bedrock_runtime = boto3_session.client("bedrock-runtime", ...)
  Cell [18]: bedrock_runtime.invoke_model(modelId=..., body=...)
"""

from __future__ import annotations
import json
import logging
import re
from typing import Any

from app.config import bedrock_config

logger = logging.getLogger(__name__)


class LLMService:
    """
    Singleton wrapper around AWS Bedrock via pbwm_genai_config.
    Reads USER_USERNAME, USER_PASSWORD, CREDS_ROLE_ARN etc. from
    environment automatically — pbwm_genai_config picks them up itself.
    """

    _instance: "LLMService | None" = None
    _client = None
    _loaded: bool = False

    @classmethod
    def get_instance(cls) -> "LLMService":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def load(self) -> None:
        """Initialise the Bedrock client using pbwm_genai_config credentials."""
        if self._loaded:
            return

        logger.info("[Bedrock] Initialising via pbwm_genai_config...")

        try:
            from pbwm_genai_config import Config, logger as pbwm_logger
        except ImportError:
            raise RuntimeError(
                "pbwm_genai_config is not installed.\n"
                "Install it with:\n"
                "  pip install C:\\SourceCode\\genai-meeting-prep-api\\pbwm_genai_config-0.1.9.13-py3-none-any.whl"
            )

        # Mirrors your notebook cells [8]–[16] exactly
        config          = Config(logger=pbwm_logger)
        session         = config._aws_session
        botocore_config = config._aws_config

        verify = bedrock_config.verify_ssl if bedrock_config.verify_ssl else True

        self._client = session.client(
            service_name="bedrock-runtime",
            region_name=bedrock_config.aws_region,
            config=botocore_config,
            verify=verify,
        )

        self._loaded = True
        logger.info(f"[Bedrock] Client ready. Model: {bedrock_config.model_id}")

    @property
    def is_loaded(self) -> bool:
        return self._loaded

    def generate(self, system: str, user: str) -> str:
        """
        Call Bedrock invoke_model using Anthropic Messages API format.
        Mirrors your notebook's request_body structure exactly.
        """
        if not self._loaded or self._client is None:
            raise RuntimeError("Bedrock client not loaded. Call load() first.")

        request_body = {
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens":  bedrock_config.max_tokens,
            "temperature": bedrock_config.temperature,
            "system": [{"type": "text", "text": system}],
            "messages": [
                {
                    "role": "user",
                    "content": [{"type": "text", "text": user}],
                }
            ],
        }

        response = self._client.invoke_model(
            modelId=bedrock_config.model_id,
            body=json.dumps(request_body),
        )

        response_body = json.loads(response["body"].read())

        # Extract text from content blocks (mirrors _extract_text from notebook)
        content = response_body.get("content", [])
        if isinstance(content, str):
            return content.strip()
        texts = [
            block.get("text", "")
            for block in content
            if isinstance(block, dict) and block.get("type") == "text"
        ]
        return "".join(texts).strip()

    def generate_json(self, system: str, user: str) -> Any:
        """Run inference and parse the response as JSON."""
        raw = self.generate(system=system, user=user)
        return self._parse_json(raw)

    @staticmethod
    def _parse_json(raw: str) -> Any:
        cleaned = re.sub(r"```(?:json)?", "", raw).strip().rstrip("`").strip()
        match = re.search(r"[\[{]", cleaned)
        if match:
            cleaned = cleaned[match.start():]
        try:
            return json.loads(cleaned)
        except json.JSONDecodeError as e:
            logger.warning(f"JSON parse failed. Raw output:\n{raw}")
            raise ValueError(f"Could not parse LLM output as JSON: {e}") from e
