"""
run.py
------
Entry point for Future Planning Tool POC.

Usage:
    python run.py

The Bedrock client is initialised at startup so the first /api/explain
call is instant rather than incurring a cold-start delay.
"""

import os
import logging
from dotenv import load_dotenv

load_dotenv()

from app import create_app
from app.config import app_config
from app.services.llm_service import LLMService

logger = logging.getLogger(__name__)

flask_app = create_app()

if __name__ == "__main__":
    # ── Initialise Bedrock client at startup ──────────────────────────────
    try:
        llm = LLMService.get_instance()
        llm.load()
        logger.info("[Startup] Bedrock LLM client ready.")
    except Exception as e:
        logger.warning(
            f"[Startup] Bedrock client could not be loaded: {e}\n"
            "The app will still run — AI explanations will use rule-based fallback."
        )

    flask_app.run(
        host=app_config.host,
        port=app_config.port,
        debug=app_config.debug,
    )
