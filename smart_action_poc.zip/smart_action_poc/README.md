# Smart Action List — Meeting Follow-Up POC
## Sub-requirement 9: Client Meeting Follow-Up Actions

### Architecture
```
smart_action_poc/
├── app/
│   ├── __init__.py              # Flask app factory
│   ├── config.py                # Configuration (model path, settings)
│   ├── routes/
│   │   ├── __init__.py
│   │   ├── transcript.py        # POST /api/transcript/analyse
│   │   ├── actions.py           # GET/POST/PATCH /api/actions
│   │   └── health.py            # GET /api/health
│   ├── services/
│   │   ├── __init__.py
│   │   ├── llm_service.py       # LLaMA model loading & inference
│   │   └── action_service.py    # Action CRUD & business logic
│   ├── agents/
│   │   ├── __init__.py
│   │   └── followup_agent.py    # LangGraph agent graph
│   ├── tools/
│   │   ├── __init__.py
│   │   ├── extractor_tool.py    # Tool: extract actions from transcript
│   │   ├── validator_tool.py    # Tool: validate & enrich extracted actions
│   │   └── dedup_tool.py        # Tool: detect duplicate actions
│   ├── models/
│   │   ├── __init__.py
│   │   └── schemas.py           # Pydantic models
│   ├── static/
│   │   ├── css/main.css
│   │   └── js/app.js
│   └── templates/
│       └── index.html
├── tests/
│   ├── test_tools.py
│   ├── test_agent.py
│   └── test_routes.py
├── run.py                       # Entry point
├── requirements.txt
└── README.md
```

### Stack
- **Flask** — REST API + HTML serving
- **LangGraph** — Agent orchestration (Extractor → Validator → Dedup → Output)
- **llama-cpp-python** — Local LLaMA 3B GGUF inference
- **Pydantic** — Schema validation
- **SQLite** (via Flask built-in) — Action persistence

### Setup

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Set your GGUF model path in app/config.py
MODEL_PATH = "/path/to/your/llama-3b.gguf"

# 3. Run
python run.py
```

### LangGraph Flow
```
START → extract_actions → validate_actions → deduplicate → format_output → END
```
Each node is a separate LangGraph node backed by a tool.
The LLM is only called in `extract_actions`. All other nodes are deterministic.
