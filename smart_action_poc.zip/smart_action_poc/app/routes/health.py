"""
routes/health.py
----------------
GET /api/health  → Liveness + model readiness check.
"""

from flask import Blueprint, jsonify
from app.services.llm_service import LLMService
from app.config import model_config

health_bp = Blueprint("health", __name__, url_prefix="/api")


@health_bp.get("/health")
def health():
    llm = LLMService.get_instance()
    return jsonify({
        "status":       "ok",
        "model_loaded": llm.is_loaded,
        "model_path":   model_config.model_path,
    }), 200
