"""
config.py
---------
Central configuration for the Smart Action List POC.
Update MODEL_PATH to point to your local LLaMA 3B GGUF file.
"""

import os
from dataclasses import dataclass


@dataclass
class ModelConfig:
    # ── Update this to your GGUF file path ──────────────────────────────────
    model_path: str = os.getenv(
        "LLAMA_MODEL_PATH",
        "./models/llama-3b.gguf"   # <-- change this
    )
    # ── Inference settings ───────────────────────────────────────────────────
    n_ctx: int = 4096              # context window
    n_threads: int = 4             # CPU threads
    n_gpu_layers: int = 0          # set > 0 if you have GPU
    temperature: float = 0.1       # low = more deterministic extraction
    max_tokens: int = 1024
    top_p: float = 0.9


@dataclass
class AppConfig:
    debug: bool = os.getenv("FLASK_DEBUG", "true").lower() == "true"
    host: str = os.getenv("FLASK_HOST", "0.0.0.0")
    port: int = int(os.getenv("FLASK_PORT", "5000"))
    secret_key: str = os.getenv("SECRET_KEY", "dev-secret-change-in-prod")

    # Today's date injected into prompts for relative deadline parsing
    reference_date: str = "2026-03-20"


# Singleton instances
model_config = ModelConfig()
app_config = AppConfig()
