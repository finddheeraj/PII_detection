"""
services/llm_service.py
-----------------------
Singleton wrapper around llama-cpp-python.
Responsible for:
  - Loading the GGUF model once at startup
  - Providing a clean generate() interface used by agent tools
  - Formatting the LLaMA 3 chat prompt template
"""

from __future__ import annotations
import json
import logging
import re
from typing import Any

from llama_cpp import Llama

from app.config import model_config

logger = logging.getLogger(__name__)


# ── Prompt templates ──────────────────────────────────────────────────────────

LLAMA3_SYSTEM_TEMPLATE = "<|begin_of_text|><|start_header_id|>system<|end_header_id|>\n{system}<|eot_id|>"
LLAMA3_USER_TEMPLATE   = "<|start_header_id|>user<|end_header_id|>\n{user}<|eot_id|>"
LLAMA3_ASST_TEMPLATE   = "<|start_header_id|>assistant<|end_header_id|>\n"


def build_llama3_prompt(system: str, user: str) -> str:
    """Build a LLaMA 3 instruct-format prompt string."""
    return (
        LLAMA3_SYSTEM_TEMPLATE.format(system=system)
        + LLAMA3_USER_TEMPLATE.format(user=user)
        + LLAMA3_ASST_TEMPLATE
    )


# ── LLM Service ───────────────────────────────────────────────────────────────

class LLMService:
    """
    Singleton LLaMA inference service.

    Usage:
        llm = LLMService.get_instance()
        text = llm.generate(system="...", user="...")
        data = llm.generate_json(system="...", user="...")
    """

    _instance: LLMService | None = None
    _model: Llama | None = None

    @classmethod
    def get_instance(cls) -> "LLMService":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def __init__(self):
        self._model = None
        self._loaded = False

    def load(self) -> None:
        """Load the GGUF model. Called once at app startup."""
        if self._loaded:
            return
        logger.info(f"Loading LLaMA model from: {model_config.model_path}")
        try:
            self._model = Llama(
                model_path=model_config.model_path,
                n_ctx=model_config.n_ctx,
                n_threads=model_config.n_threads,
                n_gpu_layers=model_config.n_gpu_layers,
                verbose=False,
            )
            self._loaded = True
            logger.info("LLaMA model loaded successfully.")
        except Exception as e:
            logger.error(f"Failed to load LLaMA model: {e}")
            raise

    @property
    def is_loaded(self) -> bool:
        return self._loaded

    def generate(self, system: str, user: str) -> str:
        """
        Run inference and return the raw text response.
        Raises RuntimeError if model is not loaded.
        """
        if not self._loaded or self._model is None:
            raise RuntimeError("LLM not loaded. Call LLMService.load() first.")

        prompt = build_llama3_prompt(system=system, user=user)

        output = self._model(
            prompt,
            max_tokens=model_config.max_tokens,
            temperature=model_config.temperature,
            top_p=model_config.top_p,
            stop=["<|eot_id|>", "<|end_of_text|>"],
            echo=False,
        )

        return output["choices"][0]["text"].strip()

    def generate_json(self, system: str, user: str) -> Any:
        """
        Run inference expecting a JSON response.
        Strips markdown fences and parses. Returns parsed object.
        Raises ValueError on parse failure.
        """
        raw = self.generate(system=system, user=user)
        return self._parse_json(raw)

    @staticmethod
    def _parse_json(raw: str) -> Any:
        """Strip markdown fences and parse JSON robustly."""
        # Remove ```json ... ``` or ``` ... ```
        cleaned = re.sub(r"```(?:json)?", "", raw).strip().rstrip("`").strip()

        # Sometimes the model outputs text before the JSON — find first [ or {
        match = re.search(r"[\[\{]", cleaned)
        if match:
            cleaned = cleaned[match.start():]

        try:
            return json.loads(cleaned)
        except json.JSONDecodeError as e:
            logger.warning(f"JSON parse failed. Raw output:\n{raw}")
            raise ValueError(f"Could not parse LLM output as JSON: {e}") from e
