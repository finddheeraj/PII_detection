/**
 * app.js  —  PRISM Smart Action List v3
 * Single unified UI with independent Transcript and Summary panels.
 * Both panels share one Smart Action List on the right.
 * No emoji anywhere — SVG icons only.
 */
"use strict";

/* ═══════════════════════════════════════════════════════════
   API CLIENT
   ═══════════════════════════════════════════════════════════ */
const ApiClient = (() => {
  async function _req(method, path, body) {
    const opts = { method, headers: { "Content-Type": "application/json" } };
    if (body !== undefined) opts.body = JSON.stringify(body);
    const res  = await fetch(path, opts);
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);
    return data;
  }
  return {
    health:   ()                                  => _req("GET",   "/api/health"),
    analyse:  (content, inputMode, meetingRef)    => _req("POST",  "/api/transcript/analyse",
                                                      { content, input_mode: inputMode, meeting_ref: meetingRef }),
    confirm:  (extracted, edits, meetingRef, mode)=> _req("POST",  "/api/actions/confirm",
                                                      { extracted, edits, meeting_ref: meetingRef, input_mode: mode }),
    actions:  (status, priority, source)          => _req("GET",
                                                      `/api/actions?status=${status}&priority=${priority}&source=${source}`),
    setStatus:(id, status)                        => _req("PATCH", `/api/actions/${id}/status`, { status }),
  };
})();

/* ═══════════════════════════════════════════════════════════
   HELPERS
   ═══════════════════════════════════════════════════════════ */
const esc  = s => String(s||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
const escA = s => String(s||"").replace(/"/g,"&quot;");
const fmtDate = d => {
  if (!d) return "TBD";
  try { return new Date(d).toLocaleDateString("en-GB",{day:"numeric",month:"short",year:"numeric"}); }
  catch { return d; }
};
const $ = id => document.getElementById(id);

/* ═══════════════════════════════════════════════════════════
   PANEL FACTORY
   Creates an independent controller for each input column.
   Both share the same action list renderer.
   ═══════════════════════════════════════════════════════════ */
function createPanel(mode) {
  // mode = "transcript" | "summary"
  const p = mode === "transcript" ? "t" : "s";  // prefix for DOM ids

  let _actions = [];   // extracted actions from last run
  let _states  = {};   // index -> "pending"|"confirmed"|"rejected"
  let _ref     = null;

  /* ── pipeline ── */
  function setPipe(step) {
    [1,2,3,4].forEach(n => {
      const el = $(`${p}-ps${n}`);
      el.classList.remove("active","done");
      if (n < step)  el.classList.add("done");
      if (n === step) el.classList.add("active");
    });
  }

  /* ── analyse button state ── */
  function setBtnLoading(loading) {
    const btn = $(`${p}-analyse-btn`);
    btn.disabled = loading;
    const label = mode === "transcript" ? "Analyse transcript" : "Analyse summary";
    const cls   = mode === "summary" ? " btn-summary" : "";
    btn.innerHTML = loading
      ? `<span class="spinner"></span> Analysing...`
      : `<svg width="13" height="13" viewBox="0 0 16 16" fill="currentColor">
           <path d="M6.5 1a5.5 5.5 0 104.383 8.823l3.147 3.147a.75.75 0 001.06-1.06l-3.147-3.147A5.5 5.5 0 006.5 1zm-4 5.5a4 4 0 118 0 4 4 0 01-8 0z"/>
         </svg>${label}`;
  }

  /* ── agent log ── */
  function showLog(lines, warnings) {
    $(`${p}-card-log`).style.display = "block";
    $(`${p}-agent-log`).innerHTML = [
      ...lines.map(l    => `<div class="log-info">&#9658; ${esc(l)}</div>`),
      ...warnings.map(w => `<div class="log-warn">&#9888; ${esc(w)}</div>`),
    ].join("");
  }

  /* ── review card HTML ── */
  function reviewCardHtml(a, i) {
    const modeLabel = mode === "summary" ? "Summary" : "Transcript";
    const dupHtml   = a.is_duplicate
      ? `<div class="dup-warn">&#9888; Possible duplicate of an existing action</div>` : "";
    const quoteHtml = a.source_quote
      ? `<div class="arc-quote">"${esc(a.source_quote)}"</div>` : "";

    return `
    <div class="arc" id="${p}-arc-${i}">
      <div class="arc-head">
        <div class="arc-title-wrap">
          <div class="arc-title">${esc(a.title)}</div>
          <div class="arc-client">${esc(a.client)} &middot; ${esc(a.category)}</div>
        </div>
        <span class="arc-mode ${mode}">${modeLabel}</span>
        <span class="pri ${a.priority}">${a.priority}</span>
      </div>
      ${quoteHtml}
      ${dupHtml}
      <div class="arc-fields">
        <div class="arc-field" style="grid-column:span 2">
          <label>Task title</label>
          <input type="text" id="${p}-arc-title-${i}" value="${escA(a.title)}"/>
        </div>
        <div class="arc-field">
          <label>Client</label>
          <input type="text" id="${p}-arc-client-${i}" value="${escA(a.client)}"/>
        </div>
        <div class="arc-field">
          <label>Due date</label>
          <input type="date" id="${p}-arc-due-${i}" value="${a.due_date||""}"/>
        </div>
        <div class="arc-field">
          <label>Priority</label>
          <select id="${p}-arc-pri-${i}">
            ${["High","Medium","Low"].map(v=>`<option ${v===a.priority?"selected":""}>${v}</option>`).join("")}
          </select>
        </div>
        <div class="arc-field">
          <label>Category</label>
          <select id="${p}-arc-cat-${i}">
            ${["Risk & Control","Commercial","Relationship","Personal"].map(v=>
              `<option ${v===a.category?"selected":""}>${v}</option>`).join("")}
          </select>
        </div>
      </div>
      <div class="arc-btns">
        <button class="btn btn-confirm btn-sm" onclick="${p}Panel.confirmOne(${i})">Confirm &amp; add</button>
        <button class="btn btn-reject  btn-sm" onclick="${p}Panel.rejectOne(${i})">Reject</button>
      </div>
    </div>`;
  }

  /* ── show review panel ── */
  function showReview(actions) {
    $(`${p}-card-review`).style.display = "block";
    $(`${p}-review-meta`).textContent = `${actions.length} action(s) detected`;
    $(`${p}-review-container`).innerHTML =
      `<div class="review-list">${actions.map((a,i) => reviewCardHtml(a,i)).join("")}</div>`;
  }

  function markConfirmed(i) {
    const el = $(`${p}-arc-${i}`);
    if (!el) return;
    el.className = "arc confirmed";
    el.querySelector(".arc-btns").innerHTML =
      `<span style="font-size:11px;color:var(--green);font-weight:600">&#10003; Added to Smart Action List</span>`;
  }

  function markRejected(i) {
    const el = $(`${p}-arc-${i}`);
    if (!el) return;
    el.className = "arc rejected";
    el.querySelector(".arc-btns").innerHTML =
      `<span style="font-size:11px;color:var(--text-3)">Rejected</span>`;
  }

  /* ── char count ── */
  function updateCount() {
    const n = $(`${p}-input`).value.length;
    $(`${p}-count`).textContent = `${n.toLocaleString()} characters`;
  }

  /* ── analyse ── */
  async function analyse() {
    const content = $(`${p}-input`).value.trim();
    if (!content) { alert(`Please enter a meeting ${mode}.`); return; }

    _ref     = $(`${p}-ref`).value.trim() || null;
    _actions = [];
    _states  = {};

    setBtnLoading(true);
    setPipe(2);
    $(`${p}-card-review`).style.display = "none";

    try {
      const res = await ApiClient.analyse(content, mode, _ref);
      showLog(res.agent_log || [], res.warnings || []);
      _actions = res.actions || [];
      _actions.forEach((_,i) => _states[i] = "pending");
      showReview(_actions);
      setPipe(3);
    } catch(err) {
      showLog([`Error: ${err.message}`], []);
      setPipe(1);
    } finally {
      setBtnLoading(false);
    }
  }

  /* ── confirm one ── */
  async function confirmOne(i) {
    if (_states[i] !== "pending") return;
    const extracted = _actions[i];
    const edits = {
      title:    $(`${p}-arc-title-${i}`)?.value,
      client:   $(`${p}-arc-client-${i}`)?.value,
      due_date: $(`${p}-arc-due-${i}`)?.value,
      priority: $(`${p}-arc-pri-${i}`)?.value,
      category: $(`${p}-arc-cat-${i}`)?.value,
    };
    try {
      await ApiClient.confirm(extracted, edits, _ref, mode);
      _states[i] = "confirmed";
      markConfirmed(i);
      setPipe(4);
      await ActionList.refresh();
    } catch(err) {
      alert(`Could not confirm: ${err.message}`);
    }
  }

  function rejectOne(i) {
    if (_states[i] !== "pending") return;
    _states[i] = "rejected";
    markRejected(i);
  }

  async function confirmAll() {
    for (const [i,s] of Object.entries(_states))
      if (s === "pending") await confirmOne(Number(i));
  }

  function rejectAll() {
    Object.keys(_states).forEach(i => { if (_states[i]==="pending") rejectOne(Number(i)); });
  }

  /* ── init ── */
  function init(sampleText) {
    $(`${p}-input`).addEventListener("input", updateCount);
    $(`${p}-analyse-btn`).addEventListener("click", analyse);
    $(`${p}-confirm-all`).addEventListener("click", confirmAll);
    $(`${p}-reject-all`).addEventListener("click", rejectAll);
    $(`sample-${mode}-btn`).addEventListener("click", () => {
      $(`${p}-input`).value = sampleText;
      $(`${p}-ref`).value   = "Harrington Portfolio Review 2026-03-20";
      updateCount();
    });
    setPipe(1);
  }

  return { init, confirmOne, rejectOne, confirmAll, rejectAll };
}

/* ═══════════════════════════════════════════════════════════
   SHARED ACTION LIST
   ═══════════════════════════════════════════════════════════ */
const ActionList = (() => {
  function renderList(actions) {
    const box = $("action-list");
    $("list-count").textContent = `${actions.length} action(s)`;

    if (!actions.length) {
      box.innerHTML = `
        <div class="empty-state">
          <div class="empty-icon">
            <svg viewBox="0 0 64 64" width="48" height="48" fill="none">
              <rect x="10" y="8" width="44" height="48" rx="4" stroke="#cbd5e1" stroke-width="2.5"/>
              <path d="M20 22h24M20 30h24M20 38h16" stroke="#cbd5e1" stroke-width="2.5" stroke-linecap="round"/>
            </svg>
          </div>
          <p class="empty-msg">No confirmed actions yet.</p>
          <p class="empty-hint">Use either panel to process a transcript or summary.</p>
        </div>`;
      return;
    }

    box.innerHTML = actions.map(a => {
      const srcClass = a.input_mode === "summary" ? "src-summary" : "src-transcript";
      const srcLabel = a.input_mode === "summary" ? "Summary" : "Transcript";
      return `
      <div class="a-tile">
        <div class="a-bar ${a.priority}"></div>
        <div class="a-body">
          <div class="a-name">${esc(a.title)}</div>
          <div class="a-meta">
            <span>${esc(a.client)}</span>
            <span>Due: ${fmtDate(a.due_date)}</span>
            <span>${esc(a.category)}</span>
            <span class="${srcClass}">${srcLabel}</span>
            ${a.is_duplicate ? `<span class="dup-badge">Duplicate</span>` : ""}
          </div>
        </div>
        <div class="a-actions">
          <span class="pri ${a.priority}">${a.priority}</span>
          <select class="status-sel" onchange="ActionList.setStatus('${a.id}',this.value)">
            ${["not_started","started","done"].map(s=>
              `<option value="${s}" ${s===a.status?"selected":""}>${s.replace("_"," ")}</option>`).join("")}
          </select>
        </div>
      </div>`;
    }).join("");
  }

  async function refresh() {
    const status   = $("filter-status")?.value   || "";
    const priority = $("filter-priority")?.value || "";
    const source   = $("filter-source")?.value   || "";
    try {
      const res = await ApiClient.actions(status, priority, source);
      // Client-side source filter (backend doesn't filter by source yet)
      let list = res.actions || [];
      if (source) list = list.filter(a => a.input_mode === source);
      renderList(list);
    } catch(err) { console.error("List refresh failed:", err); }
  }

  async function setStatus(id, status) {
    try { await ApiClient.setStatus(id, status); await refresh(); }
    catch(err) { alert(`Status update failed: ${err.message}`); }
  }

  function init() {
    $("filter-status").addEventListener("change",   refresh);
    $("filter-priority").addEventListener("change", refresh);
    $("filter-source").addEventListener("change",   refresh);
  }

  return { refresh, setStatus, init };
})();

/* ═══════════════════════════════════════════════════════════
   SAMPLE DATA
   ═══════════════════════════════════════════════════════════ */
const SAMPLE_TRANSCRIPT = `Meeting: Portfolio Review - Harrington Family Office
Date: 20 March 2026
Attendees: James Whitfield (Banker), Sarah Harrington (Client), Tom Harrington (Co-trustee)

James: Good morning Sarah, Tom. Your structured product matures on April 15th — we need to decide on reinvestment by next Friday.

Sarah: Yes, we'd like to roll into something similar. Can you send us a proposal?

James: Absolutely, I'll prepare a structured product proposal by end of this week.

Tom: Also, the bespoke lending rate review is coming up.

James: Correct — it expires April 1st. I'll raise a renewal request with the credit team today.

Sarah: We haven't received the Q4 performance report yet.

James: Apologies — I'll get that over to both of you by tomorrow morning.

Tom: We'd like a follow-up call in two weeks to review reinvestment options.

James: Confirmed. I'll send a calendar invite for around April 3rd.`;

const SAMPLE_SUMMARY = `Meeting: Harrington Family Office — Portfolio Review (20 Mar 2026)
Banker: James Whitfield | Clients: Sarah & Tom Harrington

Key points discussed:
- Structured product matures 15 Apr 2026. Reinvestment decision needed by 28 Mar.
- Client wishes to roll into a similar structured product. Proposal requested.
- Bespoke lending rate expires 1 Apr 2026. Credit renewal required urgently.
- Q4 performance report not yet delivered to client.
- Follow-up call requested for approximately 3 Apr 2026.

Actions agreed:
- Send structured product proposal by end of week.
- Raise lending rate renewal with credit team immediately.
- Send Q4 performance report by tomorrow morning.
- Send calendar invite for follow-up call on 3 Apr.`;

/* ═══════════════════════════════════════════════════════════
   BOOT
   ═══════════════════════════════════════════════════════════ */
// Expose panels globally so onclick handlers in HTML can reach them
let tPanel, sPanel;

document.addEventListener("DOMContentLoaded", async () => {
  // Health check
  try {
    const h = await ApiClient.health();
    $("model-dot").className = "status-dot " + (h.model_loaded ? "ok" : "err");
    $("model-status-text").textContent = h.model_loaded ? "Bedrock model ready" : `Model not loaded · ${h.model_path}`;
  } catch {
    $("model-dot").className    = "status-dot err";
    $("model-status-text").textContent = "Model unreachable";
  }

  // Init both panels
  tPanel = createPanel("transcript");
  sPanel = createPanel("summary");
  tPanel.init(SAMPLE_TRANSCRIPT);
  sPanel.init(SAMPLE_SUMMARY);

  // Init shared action list
  ActionList.init();
  await ActionList.refresh();
});
