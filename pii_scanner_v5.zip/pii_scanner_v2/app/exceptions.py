"""
exceptions.py — PII Detection Exception / Suppression Rules
============================================================
Post-detection filter that suppresses known false-positive patterns.

HOW TO ADD EXCEPTIONS
---------------------
1. Log timestamp formats  → add a regex to _LOG_TIMESTAMP_PATTERNS
2. Custom field / context → add a tuple to SUPPRESSION_RULES:
       (PIIType_or_None, re.compile(r"pattern"), "Human-readable reason")
   Use None as the type to suppress ALL PII types on matching lines.
"""

import re
from app.pii_detector import PIIType

# ─────────────────────────────────────────────────────────────────────────────
# SECTION 1 — Log timestamp patterns
# Any date/time match that falls inside the leading timestamp of a log line
# is suppressed as DATE_OF_BIRTH.
#
# Covered formats:
#   2024-01-15 08:23:11.456     ISO datetime (with optional ms)
#   2024-01-15T08:23:11Z        ISO-8601
#   2024/01/15 08:23:11         Slash-ISO
#   15/01/2024 08:23:11         DD/MM/YYYY datetime
#   15-01-2024 08:23:11         DD-MM-YYYY datetime
#   15-Jan-2024 08:23:11        Apache-style named month
#   Jan 15 08:23:11             Syslog (BSD)
#   Jan 15, 2024 08:23:11       Long syslog
#   [2024-01-15 08:23:11]       Bracketed ISO
#   [15/01/2024 08:23:11]       Bracketed DD/MM
#   {2024-01-15 08:23:11}       Braced ISO
#   2024-01-15                  Date-only prefix (e.g. audit logs)
#   08:23:11.456                Time-only prefix (e.g. unit-test output)
#   Mon Jan 15 08:23:11 2024    ctime() style
#   1705316591                  Unix epoch (10 digits)
#   1705316591456               Unix epoch milliseconds (13 digits)
# ─────────────────────────────────────────────────────────────────────────────

_MONTH_NAMES = r"(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)"
_HH_MM_SS    = r"\d{2}:\d{2}(?::\d{2}(?:[.,]\d{1,6})?)?"   # HH:MM  or HH:MM:SS  or HH:MM:SS.mmm

_LOG_TIMESTAMP_PATTERNS: list[str] = [

    # ── ISO / RFC-3339 ────────────────────────────────────────────────────────
    # 2024-01-15 08:23:11  /  2024-01-15T08:23:11.456Z
    rf"^\[?\{{?\d{{4}}[-/]\d{{2}}[-/]\d{{2}}[T\s]{_HH_MM_SS}(?:Z|[+-]\d{{2}}:\d{{2}})?[\]}}]?",

    # ── DD/MM/YYYY or DD-MM-YYYY with time ────────────────────────────────────
    # 15/01/2024 08:23:11  /  15-01-2024 08:23
    rf"^\[?\d{{1,2}}[/\-]\d{{1,2}}[/\-]\d{{4}}\s+{_HH_MM_SS}[\]?]?",

    # ── Apache / named-month date ─────────────────────────────────────────────
    # 15-Jan-2024 08:23:11  /  15/Jan/2024:08:23:11 +0000
    rf"^\[?\d{{1,2}}[/\-]{_MONTH_NAMES}[/\-]\d{{4}}[:\s]{_HH_MM_SS}(?:\s[+-]\d{{4}})?[\]]?",

    # ── Syslog (BSD / RFC-5424) ───────────────────────────────────────────────
    # Jan 15 08:23:11  /  Jan 15, 2024 08:23:11
    rf"^{_MONTH_NAMES}\s+\d{{1,2}}(?:,\s*\d{{4}})?\s+{_HH_MM_SS}",

    # ── ctime() style ────────────────────────────────────────────────────────
    # Mon Jan 15 08:23:11 2024
    rf"^(?:Mon|Tue|Wed|Thu|Fri|Sat|Sun)\s+{_MONTH_NAMES}\s+\d{{1,2}}\s+{_HH_MM_SS}\s+\d{{4}}",

    # ── Date-only prefix ──────────────────────────────────────────────────────
    # 2024-01-15  (followed by space/tab/end-of-token)
    r"^\[?\d{4}[-/]\d{2}[-/]\d{2}(?=\s|$|\])",

    # ── Time-only prefix (unit test output, etc.) ─────────────────────────────
    # 08:23:11.456
    rf"^{_HH_MM_SS}(?:\s|$)",

    # ── Unix epoch ────────────────────────────────────────────────────────────
    # [1705316591]  or  [1705316591456]
    r"^\[?\d{10,13}[\].]?(?:\s|$)",
]

_LOG_TS_COMPILED: list[re.Pattern] = [
    re.compile(p, re.IGNORECASE) for p in _LOG_TIMESTAMP_PATTERNS
]


def _log_ts_span(line: str) -> tuple[int, int] | None:
    """
    If the line begins with a recognised log timestamp, return (start, end)
    of that token in the original string.  Returns None otherwise.
    """
    stripped  = line.lstrip()
    leading   = len(line) - len(stripped)
    for pat in _LOG_TS_COMPILED:
        m = pat.match(stripped)
        if m:
            return (leading, leading + m.end())
    return None


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 2 — Custom suppression rules
#
# Each rule is a 3-tuple:
#   (pii_type | None, compiled_regex, human_reason)
#
# The regex is matched against the FULL LINE (not just the detected span).
# Use None as pii_type to suppress every PII type on a matching line.
# ─────────────────────────────────────────────────────────────────────────────

SUPPRESSION_RULES: list[tuple] = [

    # ── Credit card false positives ───────────────────────────────────────────
    # Log correlation/trace/request IDs that are long digit strings
    (PIIType.CREDIT_CARD_NUMBER,
     re.compile(
         r'(?:request|trace|correlation|span|message|msg|log|event|job|task|batch)'
         r'[\-_]?(?:id|ID|Id)\s*[=:\s]\s*[\dA-Fa-f\-]+',
         re.IGNORECASE),
     "Log correlation/trace ID — not a credit card"),

    # Metric or counter values that happen to be 13-16 digit numbers
    (PIIType.CREDIT_CARD_NUMBER,
     re.compile(
         r'(?:bytes|size|offset|length|count|total|seq(?:uence)?|index|pos(?:ition)?)'
         r'\s*[=:\s]\s*\d{10,}',
         re.IGNORECASE),
     "File size / metric / sequence value — not a credit card"),

    # ── IP address false positives ────────────────────────────────────────────
    # All RFC-1918 private ranges — infrastructure not personal
    (PIIType.IP_ADDRESS,
     re.compile(r'\b(?:10\.\d{1,3}\.\d{1,3}\.\d{1,3}'
                r'|172\.(?:1[6-9]|2\d|3[01])\.\d+\.\d+'
                r'|192\.168\.\d{1,3}\.\d{1,3}'          # Class C private
                r'|169\.254\.\d+\.\d+)',                  # link-local
                ),
     "Private/internal subnet IP — not personal data"),

    # Loopback and unspecified
    (PIIType.IP_ADDRESS,
     re.compile(r'\b(?:127\.\d+\.\d+\.\d+|0\.0\.0\.0)\b'),
     "Loopback/unspecified IP — not personal data"),

    # IP embedded in URL path — infrastructure reference
    (PIIType.IP_ADDRESS,
     re.compile(r'https?://[^\s]*\d+\.\d+\.\d+\.\d+', re.IGNORECASE),
     "IP embedded in URL — low PII risk in log context"),

    # ── Phone false positives ─────────────────────────────────────────────────
    # Network port references — require explicit 'port' keyword OR host:port pattern
    # Previous rule (?:port|:\s*)\d{4,5} was too broad: matched 'phone: 07700'
    (PIIType.PHONE_NUMBER,
     re.compile(
         r'\bport\s*[=:\s]\s*\d{2,5}\b'                                           # port keyword
         r'|(?:localhost|\d{1,3}(?:\.\d{1,3}){3}|[\w\-]+\.[\w\-]+):\d{2,5}\b',   # host:port
         re.IGNORECASE),
     "Network port reference — not a phone number"),

    # Build/version strings that look like dashed phone numbers
    (PIIType.PHONE_NUMBER,
     re.compile(r'(?:build|release|version|ver)\s*[=:\s]\s*\d+[.\-]\d+[.\-]\d+',
                re.IGNORECASE),
     "Build/version number — not a phone number"),

    # ── SSN false positives ───────────────────────────────────────────────────
    # txn_id / order_ref / correlation fields that happen to be NNN-NN-NNNN
    (PIIType.SSN,
     re.compile(
         r"(?:txn|transaction|order|ref(?:erence)?|request|correlation|trace|span|msg)"
         r"[_\-]?id\s*[=:]\s*\d{3}-\d{2}-\d{4}",
         re.IGNORECASE),
     "Transaction/reference ID — not an SSN"),

    # OTP / verification codes stored as NNN-NN-NNNN
    (PIIType.SSN,
     re.compile(r"\b(?:otp|one[_\-]?time[_\-]?(?:password|code|pin))\b", re.IGNORECASE),
     "OTP/verification code — not an SSN"),

    # ── Phone number false positives ──────────────────────────────────────────
    # Build numbers / version codes  e.g.  build: 1234.567.8901
    (PIIType.PHONE_NUMBER,
     re.compile(r"\b(?:build|release|version)[:\s=]\s*\d+\.\d+\.\d+", re.IGNORECASE),
     "Build/version number — not a phone number"),

    # ── Date false positives ──────────────────────────────────────────────────
    # Expiry dates on config/cert lines   expires: 2025-06-30
    (PIIType.DATE_OF_BIRTH,
     re.compile(r"\b(?:expir(?:y|es?|ation)|valid[_\-]?(?:from|until|to)|not[_\-]?(?:before|after))\b",
                re.IGNORECASE),
     "Certificate/config expiry date — not a date of birth"),

    # Fiscal/quarter reporting dates  Q1 2024  /  FY2024-03
    (PIIType.DATE_OF_BIRTH,
     re.compile(r"\b(?:Q[1-4]\s*\d{4}|FY\s*\d{4}|fiscal\s+\d{4})\b", re.IGNORECASE),
     "Fiscal/quarter date — not a date of birth"),

    # ── Global: test / dummy / mock data ─────────────────────────────────────
    # Suppress ALL types on clearly synthetic lines
    (None,
     re.compile(r"\b(?:test|dummy|sample|placeholder|example|mock|fake|synthetic)\b",
                re.IGNORECASE),
     "Test/dummy data line — suppressed globally"),

    # ── Health / heartbeat probes ─────────────────────────────────────────────
    (None,
     re.compile(r"\b(?:health[_\-]?check|heartbeat|ping|k8s[_\-]?probe|liveness|readiness)\b",
                re.IGNORECASE),
     "Health-check / probe line — no PII expected"),
]


# ─────────────────────────────────────────────────────────────────────────────
# SECTION 3 — Public filter
# ─────────────────────────────────────────────────────────────────────────────

def apply_exceptions(matches: list, line_text: str) -> tuple[list, list]:
    """
    Filter PII matches for a single line, applying all exception rules.

    Returns
    -------
    kept        : matches that survived all exception rules
    suppressed  : list of dicts {match fields + suppression_reason}
    """
    kept:       list = []
    suppressed: list = []

    ts_span = _log_ts_span(line_text)

    for m in matches:
        reason: str | None = None

        # ── Rule A: Log timestamp overlap ─────────────────────────────────────
        if m.pii_type == PIIType.DATE_OF_BIRTH and ts_span:
            ts_start, ts_end = ts_span
            if m.start < ts_end and m.end > ts_start:
                reason = "Log line timestamp — not a date of birth"

        # ── Rule B: Custom suppression rules ─────────────────────────────────
        if reason is None:
            for rule_type, line_pattern, rule_reason in SUPPRESSION_RULES:
                if rule_type is not None and m.pii_type != rule_type:
                    continue
                if line_pattern.search(line_text):
                    reason = rule_reason
                    break

        if reason:
            rec = m.to_dict()
            rec["suppression_reason"] = reason
            suppressed.append(rec)
        else:
            kept.append(m)

    return kept, suppressed
