"""
Flask Application — PII Scanner v2
SSE streaming, per-file status tracker, stop-scan support
"""

import os, json, uuid, queue, tempfile, shutil, threading, zipfile
from pathlib import Path
from flask import Flask, request, jsonify, render_template, Response, stream_with_context

from app.pii_detector import detect_pii_regex, get_risk_summary, anonymize_text, detect_pii

app = Flask(__name__, template_folder="../templates", static_folder="../static")
app.config["MAX_CONTENT_LENGTH"] = 200 * 1024 * 1024

ALLOWED_EXTS = {".txt", ".log", ".csv", ".json", ".xml", ".tsv", ".out", ".md"}

# ── Job registry ──────────────────────────────────────────────────────────────
# scan_id -> {"q": Queue, "stop": threading.Event}
_jobs: dict = {}
_jobs_lock = threading.Lock()


# ── Routes ────────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/scan/text", methods=["POST"])
def api_scan_text():
    data = request.get_json(force=True) or {}
    text = data.get("text", "").strip()
    if not text:
        return jsonify({"error": "No text provided"}), 400
    matches, suppressed = detect_pii(
        text,
        use_presidio=data.get("use_presidio", False),
        use_spacy=data.get("use_spacy", False),
        use_regex=data.get("use_regex", True),
        use_bert=data.get("use_bert", False),
        min_score=float(data.get("min_score", 0.5)),
    )
    summary = get_risk_summary(matches, filename="<inline>", suppressed=suppressed)
    summary["anonymized"] = anonymize_text(text, matches)
    summary["detections"] = [m.to_dict() for m in matches]
    return jsonify(summary)


@app.route("/api/scan/upload", methods=["POST"])
def api_scan_upload():
    """Upload a single file or a ZIP of a folder. Returns scan_id for SSE stream."""
    if "file" not in request.files:
        return jsonify({"error": "No file uploaded"}), 400
    f = request.files["file"]
    if not f.filename:
        return jsonify({"error": "Empty filename"}), 400

    use_presidio = request.form.get("use_presidio", "false").lower() == "true"
    use_spacy    = request.form.get("use_spacy",    "false").lower() == "true"
    use_regex    = request.form.get("use_regex",    "true").lower()  == "true"
    use_bert     = request.form.get("use_bert",     "false").lower() == "true"
    min_score    = float(request.form.get("min_score", "0.5"))

    suffix   = Path(f.filename).suffix.lower()
    scan_id  = str(uuid.uuid4())
    tmp_path = tempfile.mktemp(suffix=suffix)
    f.save(tmp_path)

    q    = queue.Queue()
    stop = threading.Event()
    with _jobs_lock:
        _jobs[scan_id] = {"q": q, "stop": stop}

    threading.Thread(
        target=_scan_worker,
        args=(scan_id, tmp_path, f.filename, suffix,
              use_presidio, use_spacy, use_regex, use_bert, min_score),
        daemon=True,
    ).start()

    return jsonify({"scan_id": scan_id, "filename": f.filename})


@app.route("/api/scan/stream")
def api_scan_stream():
    """SSE stream for a running scan."""
    scan_id = request.args.get("scan_id", "")
    with _jobs_lock:
        job = _jobs.get(scan_id)
    if job is None:
        return Response(
            'data: {"type":"error","message":"Unknown scan_id"}\n\n',
            mimetype="text/event-stream"
        )

    q = job["q"]

    def generate():
        while True:
            try:
                msg = q.get(timeout=25)
            except queue.Empty:
                yield ": heartbeat\n\n"
                continue
            if msg is None:
                break
            yield f"data: {msg}\n\n"
        with _jobs_lock:
            _jobs.pop(scan_id, None)

    return Response(
        stream_with_context(generate()),
        mimetype="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


@app.route("/api/scan/stop", methods=["POST"])
def api_scan_stop():
    """Signal a running scan to stop."""
    scan_id = (request.get_json(force=True) or {}).get("scan_id", "")
    with _jobs_lock:
        job = _jobs.get(scan_id)
    if job:
        job["stop"].set()
        return jsonify({"ok": True, "message": "Stop signal sent"})
    return jsonify({"ok": False, "message": "Scan not found or already finished"}), 404


@app.route("/api/health")
def health():
    from app.bert_detector import bert_status
    return jsonify({"status": "ok", "bert": bert_status()})


# ── Worker helpers ────────────────────────────────────────────────────────────

def _push(scan_id, payload):
    with _jobs_lock:
        job = _jobs.get(scan_id)
    if job:
        job["q"].put(json.dumps(payload))


def _stopped(scan_id) -> bool:
    with _jobs_lock:
        job = _jobs.get(scan_id)
    return bool(job and job["stop"].is_set())


def _scan_worker(scan_id, tmp_path, orig_fname, suffix,
                 use_presidio, use_spacy, use_regex, use_bert, min_score):
    try:
        if suffix == ".zip":
            _worker_zip(scan_id, tmp_path, use_presidio, use_spacy, use_regex, use_bert, min_score)
        else:
            _worker_single(scan_id, tmp_path, orig_fname, use_presidio, use_spacy, use_regex, use_bert, min_score)
    except Exception as e:
        _push(scan_id, {"type": "error", "message": str(e)})
    finally:
        try:
            os.unlink(tmp_path)
        except Exception:
            pass
        with _jobs_lock:
            job = _jobs.get(scan_id)
        if job:
            job["q"].put(None)


def _worker_single(scan_id, tmp_path, filename, use_presidio, use_spacy, use_regex, use_bert, min_score):
    with open(tmp_path, "r", encoding="utf-8", errors="replace") as fh:
        lines = fh.readlines()
    total_lines = len(lines)

    _push(scan_id, {
        "type": "start", "total_files": 1,
        "filename": filename, "total_lines": total_lines,
        "files": [{"name": filename, "status": "scanning", "lines": total_lines, "pii": 0}],
    })

    all_dets, line_results, pii_found = [], [], 0
    all_suppressed = []
    for i, line in enumerate(lines, 1):
        if _stopped(scan_id):
            _push(scan_id, {"type": "stopped", "message": "Scan stopped by user."})
            return

        text = line.rstrip("\n")
        dets, suppressed = detect_pii(text, use_presidio=use_presidio, use_spacy=use_spacy,
                          use_regex=use_regex, use_bert=use_bert,
                          min_score=min_score, line_text=text)
        for d in dets:
            d_dict = d.to_dict()
            d_dict["line_no"] = i
            all_dets.append(d_dict)
        for s in suppressed:
            s["line_no"] = i
            all_suppressed.append(s)
        if dets:
            line_results.append({"line_no": i, "text": text,
                                  "detections": [d.to_dict() for d in dets]})
        pii_found += len(dets)

        if i % 10 == 0 or i == total_lines:
            _push(scan_id, {
                "type": "progress", "file": filename,
                "file_no": 1, "total_files": 1,
                "lines_done": i, "total_lines": total_lines,
                "pii_found": pii_found,
                "pct": round(i / max(total_lines, 1) * 100),
            })

    _push(scan_id, {"type": "file_done", "file": filename, "file_no": 1,
                    "total_files": 1, "pii_found": pii_found})

    from collections import Counter
    _push(scan_id, {
        "type": "done", "scan_type": "single", "filename": filename,
        "total_pii": len(all_dets),
        "total_suppressed": len(all_suppressed),
        "summary": dict(Counter(d["pii_type"] for d in all_dets)),
        "severity_counts": dict(Counter(d.get("severity", "MEDIUM") for d in all_dets)),
        "detections": all_dets,
        "suppressed": all_suppressed,
        "line_results": line_results,
    })


def _worker_zip(scan_id, tmp_path, use_presidio, use_spacy, use_regex, use_bert, min_score):
    from collections import Counter
    tmpdir = tempfile.mkdtemp()
    try:
        try:
            with zipfile.ZipFile(tmp_path, "r") as zf:
                zf.extractall(tmpdir)
        except zipfile.BadZipFile:
            _push(scan_id, {"type": "error", "message": "Invalid ZIP file"})
            return

        files = sorted(
            [f for f in Path(tmpdir).rglob("*")
             if f.is_file() and f.suffix.lower() in ALLOWED_EXTS],
            key=lambda p: p.name,
        )
        total_files = len(files)

        if total_files == 0:
            _push(scan_id, {"type": "error", "message": "No supported files found in ZIP."})
            return

        # Build initial file manifest for the status grid
        file_manifest = [
            {"name": f.name, "status": "pending", "lines": 0, "pii": 0, "error": None}
            for f in files
        ]

        _push(scan_id, {
            "type": "start", "total_files": total_files,
            "filename": "folder.zip", "total_lines": None,
            "files": file_manifest,
        })

        all_dets, file_sums, total_pii = [], [], 0

        for f_no, fpath in enumerate(files, 1):
            if _stopped(scan_id):
                _push(scan_id, {"type": "stopped",
                                "message": f"Scan stopped after {f_no-1}/{total_files} files."})
                return

            fname = fpath.name

            # Mark as scanning
            _push(scan_id, {
                "type": "file_status", "file": fname, "file_no": f_no,
                "total_files": total_files, "status": "scanning",
            })

            try:
                with open(fpath, "r", encoding="utf-8", errors="replace") as fh:
                    lines = fh.readlines()
            except Exception as e:
                _push(scan_id, {
                    "type": "file_status", "file": fname, "file_no": f_no,
                    "total_files": total_files, "status": "error", "message": str(e),
                })
                file_sums.append({"filename": fname, "status": "error", "error": str(e),
                                   "total_pii": 0, "summary": {}, "line_results": []})
                continue

            total_lines = len(lines)
            file_dets, file_lrs, file_pii, file_suppressed = [], [], 0, []

            for i, line in enumerate(lines, 1):
                if _stopped(scan_id):
                    _push(scan_id, {"type": "stopped",
                                    "message": f"Stopped mid-file: {fname} ({i}/{total_lines} lines)"})
                    return

                text = line.rstrip("\n")
                dets, suppressed = detect_pii(text, use_presidio=use_presidio, use_spacy=use_spacy,
                                  use_regex=use_regex, use_bert=use_bert,
                                  min_score=min_score, line_text=text)
                for d in dets:
                    d_dict = d.to_dict()
                    d_dict["line_no"] = i
                    d_dict["filename"] = fname
                    file_dets.append(d_dict)
                for s in suppressed:
                    s["line_no"] = i
                    s["filename"] = fname
                    file_suppressed.append(s)
                if dets:
                    file_lrs.append({"line_no": i, "text": text,
                                     "detections": [d.to_dict() for d in dets]})
                file_pii += len(dets)

                # Progress update every 25 lines or at end
                if i % 25 == 0 or i == total_lines:
                    pct = round(((f_no - 1) + i / max(total_lines, 1)) / max(total_files, 1) * 100)
                    _push(scan_id, {
                        "type": "progress", "file": fname,
                        "file_no": f_no, "total_files": total_files,
                        "lines_done": i, "total_lines": total_lines,
                        "pii_found": total_pii + file_pii, "pct": pct,
                    })

            total_pii += file_pii
            all_dets.extend(file_dets)

            file_sums.append({
                "filename": fname, "status": "done",
                "total_pii": file_pii, "lines": total_lines,
                "total_suppressed": len(file_suppressed),
                "summary": dict(Counter(d["pii_type"] for d in file_dets)),
                "line_results": file_lrs,
                "suppressed": file_suppressed,
            })

            _push(scan_id, {
                "type": "file_done", "file": fname, "file_no": f_no,
                "total_files": total_files, "pii_found": file_pii,
                "total_pii_so_far": total_pii, "lines": total_lines,
            })

        _push(scan_id, {
            "type": "done", "scan_type": "folder",
            "total_pii": total_pii, "files_scanned": total_files,
            "total_suppressed": sum(f.get("total_suppressed", 0) for f in file_sums),
            "summary": dict(Counter(d.get("pii_type", "") for d in all_dets)),
            "severity_counts": dict(Counter(d.get("severity", "MEDIUM") for d in all_dets)),
            "file_summaries": file_sums,
            "detections": all_dets,
        })

    finally:
        shutil.rmtree(tmpdir, ignore_errors=True)


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)


# ── Routes ────────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/scan/text", methods=["POST"])
def api_scan_text():
    data = request.get_json(force=True) or {}
    text = data.get("text", "").strip()
    if not text:
        return jsonify({"error": "No text provided"}), 400
    matches, suppressed = detect_pii(
        text,
        use_presidio=data.get("use_presidio", False),
        use_spacy=data.get("use_spacy", False),
        use_regex=data.get("use_regex", True),
        min_score=float(data.get("min_score", 0.5)),
    )
    summary = get_risk_summary(matches, filename="<inline>", suppressed=suppressed)
    summary["anonymized"] = anonymize_text(text, matches)
    summary["detections"] = [m.to_dict() for m in matches]
    return jsonify(summary)


@app.route("/api/scan/upload", methods=["POST"])
def api_scan_upload():
    """Upload a single file or a ZIP of a folder. Returns scan_id for SSE stream."""
    if "file" not in request.files:
        return jsonify({"error": "No file uploaded"}), 400
    f = request.files["file"]
    if not f.filename:
        return jsonify({"error": "Empty filename"}), 400

    use_presidio = request.form.get("use_presidio", "false").lower() == "true"
    use_spacy    = request.form.get("use_spacy",    "false").lower() == "true"
    use_regex    = request.form.get("use_regex",    "true").lower()  == "true"
    min_score    = float(request.form.get("min_score", "0.5"))

    suffix   = Path(f.filename).suffix.lower()
    scan_id  = str(uuid.uuid4())
    tmp_path = tempfile.mktemp(suffix=suffix)
    f.save(tmp_path)

    q    = queue.Queue()
    stop = threading.Event()
    with _jobs_lock:
        _jobs[scan_id] = {"q": q, "stop": stop}

    threading.Thread(
        target=_scan_worker,
        args=(scan_id, tmp_path, f.filename, suffix,
              use_presidio, use_spacy, use_regex, min_score),
        daemon=True,
    ).start()

    return jsonify({"scan_id": scan_id, "filename": f.filename})


@app.route("/api/scan/stream")
def api_scan_stream():
    """SSE stream for a running scan."""
    scan_id = request.args.get("scan_id", "")
    with _jobs_lock:
        job = _jobs.get(scan_id)
    if job is None:
        return Response(
            'data: {"type":"error","message":"Unknown scan_id"}\n\n',
            mimetype="text/event-stream"
        )

    q = job["q"]

    def generate():
        while True:
            try:
                msg = q.get(timeout=25)
            except queue.Empty:
                yield ": heartbeat\n\n"
                continue
            if msg is None:
                break
            yield f"data: {msg}\n\n"
        with _jobs_lock:
            _jobs.pop(scan_id, None)

    return Response(
        stream_with_context(generate()),
        mimetype="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


@app.route("/api/scan/stop", methods=["POST"])
def api_scan_stop():
    """Signal a running scan to stop."""
    scan_id = (request.get_json(force=True) or {}).get("scan_id", "")
    with _jobs_lock:
        job = _jobs.get(scan_id)
    if job:
        job["stop"].set()
        return jsonify({"ok": True, "message": "Stop signal sent"})
    return jsonify({"ok": False, "message": "Scan not found or already finished"}), 404


@app.route("/api/health")
def health():
    return jsonify({"status": "ok"})


# ── Worker helpers ────────────────────────────────────────────────────────────

def _push(scan_id, payload):
    with _jobs_lock:
        job = _jobs.get(scan_id)
    if job:
        job["q"].put(json.dumps(payload))


def _stopped(scan_id) -> bool:
    with _jobs_lock:
        job = _jobs.get(scan_id)
    return bool(job and job["stop"].is_set())


def _scan_worker(scan_id, tmp_path, orig_fname, suffix,
                 use_presidio, use_spacy, use_regex, min_score):
    try:
        if suffix == ".zip":
            _worker_zip(scan_id, tmp_path, use_presidio, use_spacy, use_regex, min_score)
        else:
            _worker_single(scan_id, tmp_path, orig_fname, use_presidio, use_spacy, use_regex, min_score)
    except Exception as e:
        _push(scan_id, {"type": "error", "message": str(e)})
    finally:
        try:
            os.unlink(tmp_path)
        except Exception:
            pass
        with _jobs_lock:
            job = _jobs.get(scan_id)
        if job:
            job["q"].put(None)


def _worker_single(scan_id, tmp_path, filename, use_presidio, use_spacy, use_regex, min_score):
    with open(tmp_path, "r", encoding="utf-8", errors="replace") as fh:
        lines = fh.readlines()
    total_lines = len(lines)

    _push(scan_id, {
        "type": "start", "total_files": 1,
        "filename": filename, "total_lines": total_lines,
        "files": [{"name": filename, "status": "scanning", "lines": total_lines, "pii": 0}],
    })

    all_dets, line_results, pii_found = [], [], 0
    all_suppressed = []
    for i, line in enumerate(lines, 1):
        if _stopped(scan_id):
            _push(scan_id, {"type": "stopped", "message": "Scan stopped by user."})
            return

        text = line.rstrip("\n")
        dets, suppressed = detect_pii(text, use_presidio=use_presidio, use_spacy=use_spacy,
                          use_regex=use_regex, min_score=min_score, line_text=text)
        for d in dets:
            d_dict = d.to_dict()
            d_dict["line_no"] = i
            all_dets.append(d_dict)
        for s in suppressed:
            s["line_no"] = i
            all_suppressed.append(s)
        if dets:
            line_results.append({"line_no": i, "text": text,
                                  "detections": [d.to_dict() for d in dets]})
        pii_found += len(dets)

        if i % 10 == 0 or i == total_lines:
            _push(scan_id, {
                "type": "progress", "file": filename,
                "file_no": 1, "total_files": 1,
                "lines_done": i, "total_lines": total_lines,
                "pii_found": pii_found,
                "pct": round(i / max(total_lines, 1) * 100),
            })

    _push(scan_id, {"type": "file_done", "file": filename, "file_no": 1,
                    "total_files": 1, "pii_found": pii_found})

    from collections import Counter
    _push(scan_id, {
        "type": "done", "scan_type": "single", "filename": filename,
        "total_pii": len(all_dets),
        "total_suppressed": len(all_suppressed),
        "summary": dict(Counter(d["pii_type"] for d in all_dets)),
        "severity_counts": dict(Counter(d.get("severity", "MEDIUM") for d in all_dets)),
        "detections": all_dets,
        "suppressed": all_suppressed,
        "line_results": line_results,
    })


def _worker_zip(scan_id, tmp_path, use_presidio, use_spacy, use_regex, min_score):
    from collections import Counter
    tmpdir = tempfile.mkdtemp()
    try:
        try:
            with zipfile.ZipFile(tmp_path, "r") as zf:
                zf.extractall(tmpdir)
        except zipfile.BadZipFile:
            _push(scan_id, {"type": "error", "message": "Invalid ZIP file"})
            return

        files = sorted(
            [f for f in Path(tmpdir).rglob("*")
             if f.is_file() and f.suffix.lower() in ALLOWED_EXTS],
            key=lambda p: p.name,
        )
        total_files = len(files)

        if total_files == 0:
            _push(scan_id, {"type": "error", "message": "No supported files found in ZIP."})
            return

        # Build initial file manifest for the status grid
        file_manifest = [
            {"name": f.name, "status": "pending", "lines": 0, "pii": 0, "error": None}
            for f in files
        ]

        _push(scan_id, {
            "type": "start", "total_files": total_files,
            "filename": "folder.zip", "total_lines": None,
            "files": file_manifest,
        })

        all_dets, file_sums, total_pii = [], [], 0

        for f_no, fpath in enumerate(files, 1):
            if _stopped(scan_id):
                _push(scan_id, {"type": "stopped",
                                "message": f"Scan stopped after {f_no-1}/{total_files} files."})
                return

            fname = fpath.name

            # Mark as scanning
            _push(scan_id, {
                "type": "file_status", "file": fname, "file_no": f_no,
                "total_files": total_files, "status": "scanning",
            })

            try:
                with open(fpath, "r", encoding="utf-8", errors="replace") as fh:
                    lines = fh.readlines()
            except Exception as e:
                _push(scan_id, {
                    "type": "file_status", "file": fname, "file_no": f_no,
                    "total_files": total_files, "status": "error", "message": str(e),
                })
                file_sums.append({"filename": fname, "status": "error", "error": str(e),
                                   "total_pii": 0, "summary": {}, "line_results": []})
                continue

            total_lines = len(lines)
            file_dets, file_lrs, file_pii, file_suppressed = [], [], 0, []

            for i, line in enumerate(lines, 1):
                if _stopped(scan_id):
                    _push(scan_id, {"type": "stopped",
                                    "message": f"Stopped mid-file: {fname} ({i}/{total_lines} lines)"})
                    return

                text = line.rstrip("\n")
                dets, suppressed = detect_pii(text, use_presidio=use_presidio, use_spacy=use_spacy,
                                  use_regex=use_regex, min_score=min_score, line_text=text)
                for d in dets:
                    d_dict = d.to_dict()
                    d_dict["line_no"] = i
                    d_dict["filename"] = fname
                    file_dets.append(d_dict)
                for s in suppressed:
                    s["line_no"] = i
                    s["filename"] = fname
                    file_suppressed.append(s)
                if dets:
                    file_lrs.append({"line_no": i, "text": text,
                                     "detections": [d.to_dict() for d in dets]})
                file_pii += len(dets)

                # Progress update every 25 lines or at end
                if i % 25 == 0 or i == total_lines:
                    pct = round(((f_no - 1) + i / max(total_lines, 1)) / max(total_files, 1) * 100)
                    _push(scan_id, {
                        "type": "progress", "file": fname,
                        "file_no": f_no, "total_files": total_files,
                        "lines_done": i, "total_lines": total_lines,
                        "pii_found": total_pii + file_pii, "pct": pct,
                    })

            total_pii += file_pii
            all_dets.extend(file_dets)

            file_sums.append({
                "filename": fname, "status": "done",
                "total_pii": file_pii, "lines": total_lines,
                "total_suppressed": len(file_suppressed),
                "summary": dict(Counter(d["pii_type"] for d in file_dets)),
                "line_results": file_lrs,
                "suppressed": file_suppressed,
            })

            _push(scan_id, {
                "type": "file_done", "file": fname, "file_no": f_no,
                "total_files": total_files, "pii_found": file_pii,
                "total_pii_so_far": total_pii, "lines": total_lines,
            })

        _push(scan_id, {
            "type": "done", "scan_type": "folder",
            "total_pii": total_pii, "files_scanned": total_files,
            "total_suppressed": sum(f.get("total_suppressed", 0) for f in file_sums),
            "summary": dict(Counter(d.get("pii_type", "") for d in all_dets)),
            "severity_counts": dict(Counter(d.get("severity", "MEDIUM") for d in all_dets)),
            "file_summaries": file_sums,
            "detections": all_dets,
        })

    finally:
        shutil.rmtree(tmpdir, ignore_errors=True)


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
