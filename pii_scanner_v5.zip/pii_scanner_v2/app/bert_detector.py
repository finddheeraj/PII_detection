"""
bert_detector.py — BERT-based PII Detection
============================================
Uses a fine-tuned token-classification NER model (e.g. dslim/bert-base-NER
or any Hugging Face model in the ./models/bert_pii/ folder) to detect named
entities and map them to PIIType values.

The model is loaded lazily on first use and cached for the lifetime of the
process.  If the model folder is missing, this module degrades gracefully
and returns no matches — the rest of the pipeline is unaffected.

FOLDER CONVENTION
-----------------
Place your downloaded model files in:

    <project_root>/models/bert_pii/

Required files (standard Hugging Face format):
    config.json
    tokenizer_config.json
    vocab.txt  (or tokenizer.json for fast tokenisers)
    pytorch_model.bin  (or model.safetensors)
    special_tokens_map.json

The folder path can be overridden at runtime by setting the environment
variable BERT_MODEL_PATH before launching the server.

SUPPORTED MODELS
----------------
Any Hugging Face token-classification model whose labels follow the
IOB/BILOU scheme and include standard NER tags (PER, LOC, ORG, MISC,
or full names like PERSON, LOCATION, etc.).

Recommended models (download separately):
    dslim/bert-base-NER          — fast, good precision, small (400 MB)
    Jean-Baptiste/roberta-large-ner-english — higher recall, larger (1.4 GB)
    obi/deid_bert_i2b2           — fine-tuned on medical PII (de-identification)
    ghadeermobasher/BC5CDR-Chemical-Disease-balanced-BiomedNLP-BiomedBERT-base

HOW TO DOWNLOAD
---------------
Option A — Hugging Face CLI (requires internet on build machine):

    pip install huggingface_hub
    python -c "
    from huggingface_hub import snapshot_download
    snapshot_download(
        repo_id='dslim/bert-base-NER',
        local_dir='models/bert_pii',
        ignore_patterns=['*.msgpack','flax_model*','tf_model*','rust_model*'],
    )
    "

Option B — Manual download from https://huggingface.co/dslim/bert-base-NER/tree/main
    Download all files and place them in models/bert_pii/

Option C — On an internet-connected machine, then copy:
    pip install transformers torch
    from transformers import AutoTokenizer, AutoModelForTokenClassification
    AutoTokenizer.from_pretrained('dslim/bert-base-NER').save_pretrained('models/bert_pii')
    AutoModelForTokenClassification.from_pretrained('dslim/bert-base-NER').save_pretrained('models/bert_pii')
"""

import os
import logging
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

# ── Model path resolution ─────────────────────────────────────────────────────
# Resolve relative to this file's parent (project root)
_DEFAULT_MODEL_DIR = Path(__file__).resolve().parent.parent / "models" / "bert_pii"

def _model_path() -> Path:
    """Return the BERT model directory. Override via BERT_MODEL_PATH env var."""
    env = os.environ.get("BERT_MODEL_PATH", "")
    return Path(env) if env else _DEFAULT_MODEL_DIR


# ── BERT entity → PIIType mapping ────────────────────────────────────────────
# Labels vary by model. We handle both short (PER, LOC) and long (PERSON,
# LOCATION) forms, plus B-/I-/L-/U- IOB prefixes automatically.

from app.pii_detector import PIIType

_LABEL_MAP: dict[str, Optional[PIIType]] = {
    # Person names
    "PER":      PIIType.PERSON_NAME,
    "PERSON":   PIIType.PERSON_NAME,
    # Locations / addresses
    "LOC":      PIIType.HOME_ADDRESS,
    "LOCATION": PIIType.HOME_ADDRESS,
    "GPE":      PIIType.HOME_ADDRESS,    # Geo-Political Entity
    # Organisations — low PII risk, only flag if combined
    "ORG":      None,                    # skip — not PII on its own
    # Miscellaneous entities — skip
    "MISC":     None,
    "O":        None,
    # Some models use full descriptive labels
    "PHONE":    PIIType.PHONE_NUMBER,
    "EMAIL":    PIIType.EMAIL_ADDRESS,
    "SSN":      PIIType.SSN,
    "ID":       PIIType.GOVERNMENT_ID,
    "DATE":     None,   # Too broad — causes same FPs as spaCy DATE
    "TIME":     None,
    "URL":      None,
    "IP":       PIIType.IP_ADDRESS,
    "AGE":      None,
    "NORP":     None,   # Nationalities/religions/political groups — skip
    "FAC":      None,   # Facilities
    "PRODUCT":  None,
    "EVENT":    None,
    "LAW":      None,
    "LANGUAGE": None,
    "CARDINAL": None,
    "ORDINAL":  None,
    "QUANTITY": None,
    "MONEY":    None,
    "PERCENT":  None,
    "WORK_OF_ART": None,
}

def _resolve_label(raw_label: str) -> Optional[PIIType]:
    """Strip IOB prefix (B-, I-, L-, U-, S-) and look up the entity type."""
    if "-" in raw_label:
        raw_label = raw_label.split("-", 1)[1]
    return _LABEL_MAP.get(raw_label.upper())


# ── Lazy-loaded pipeline ───────────────────────────────────────────────────────
_bert_pipeline = None
_bert_load_error: Optional[str] = None   # store error so we don't retry on every line


def _get_bert_pipeline():
    """Load and cache the HF NER pipeline. Returns None if unavailable."""
    global _bert_pipeline, _bert_load_error

    if _bert_pipeline is not None:
        return _bert_pipeline
    if _bert_load_error is not None:
        return None   # already failed — don't retry

    model_dir = _model_path()

    if not model_dir.exists():
        _bert_load_error = (
            f"BERT model folder not found: {model_dir}\n"
            f"See app/bert_detector.py for download instructions."
        )
        logger.warning(_bert_load_error)
        return None

    try:
        from transformers import pipeline, AutoTokenizer, AutoModelForTokenClassification
        import torch

        logger.info(f"Loading BERT NER model from {model_dir} …")
        tokenizer = AutoTokenizer.from_pretrained(str(model_dir), local_files_only=True)
        model     = AutoModelForTokenClassification.from_pretrained(
            str(model_dir), local_files_only=True)

        device = 0 if torch.cuda.is_available() else -1   # GPU if available, else CPU
        _bert_pipeline = pipeline(
            task="ner",
            model=model,
            tokenizer=tokenizer,
            aggregation_strategy="simple",  # merge consecutive B/I tokens
            device=device,
        )
        logger.info(f"BERT NER model loaded (device={'GPU' if device==0 else 'CPU'})")
        return _bert_pipeline

    except ImportError as e:
        _bert_load_error = (
            f"transformers / torch not installed: {e}\n"
            f"Run: pip install transformers torch"
        )
        logger.error(_bert_load_error)
        return None

    except Exception as e:
        _bert_load_error = f"Failed to load BERT model: {e}"
        logger.error(_bert_load_error)
        return None


def bert_status() -> dict:
    """Return current BERT engine status — used by the /api/health endpoint."""
    model_dir = _model_path()
    if _bert_pipeline is not None:
        return {"available": True,  "status": "loaded", "model_path": str(model_dir)}
    if _bert_load_error:
        return {"available": False, "status": "error",  "error": _bert_load_error}
    if not model_dir.exists():
        return {"available": False, "status": "not_found",
                "model_path": str(model_dir),
                "hint": "Download model and place in models/bert_pii/"}
    return {"available": False, "status": "not_loaded"}


# ── Main detection function ────────────────────────────────────────────────────

def detect_pii_bert(text: str, line_number: int = 1,
                    min_score: float = 0.70) -> list:
    """
    Run BERT NER on a single line of text.

    Parameters
    ----------
    text        : the log line / text to analyse
    line_number : passed through to PIIMatch for line attribution
    min_score   : minimum entity confidence to accept (default 0.70)
                  BERT scores are softmax probabilities (0–1).

    Returns
    -------
    list[PIIMatch]
    """
    if not text or not text.strip():
        return []

    nlp = _get_bert_pipeline()
    if nlp is None:
        return []

    from app.pii_detector import PIIMatch

    try:
        # Truncate very long lines — BERT has a 512-token limit
        # Characters are a rough proxy; 500 chars is safe for most log lines
        text_to_scan = text[:1500]

        entities = nlp(text_to_scan)
        matches  = []

        for ent in entities:
            score     = float(ent.get("score", 0))
            raw_label = ent.get("entity_group") or ent.get("entity", "O")
            pii_type  = _resolve_label(raw_label)

            if pii_type is None:
                continue
            if score < min_score:
                continue

            word  = ent.get("word", "").strip()
            start = ent.get("start", 0)
            end   = ent.get("end",   len(word))

            # Strip Hugging Face word-piece artefacts (## prefix)
            word = word.replace(" ##", "").replace("##", "")
            if not word:
                continue

            matches.append(PIIMatch(
                pii_type=pii_type,
                text=word,
                start=start,
                end=end,
                score=round(score, 3),
                source="bert",
                line_number=line_number,
            ))

        return matches

    except Exception as e:
        logger.error(f"BERT detection error on line {line_number}: {e}")
        return []
