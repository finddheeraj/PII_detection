# =============================================================================
# PyInstaller Spec File — PII Scanner (with BERT support)
# =============================================================================
#
# PRE-BUILD CHECKLIST
# -------------------
#
# 1. Install Python dependencies:
#
#      pip install pyinstaller flask \
#          presidio-analyzer presidio-anonymizer \
#          spacy transformers torch
#
# 2. Install spaCy model (download the .whl from GitHub, then install offline):
#
#      PowerShell:
#        $url = "https://github.com/explosion/spacy-models/releases/download/en_core_web_lg-3.7.1/en_core_web_lg-3.7.1-py3-none-any.whl"
#        Invoke-WebRequest -Uri $url -OutFile "en_core_web_lg-3.7.1.whl"
#        pip install en_core_web_lg-3.7.1.whl --no-deps
#
#      Verify:
#        python -c "import spacy; spacy.load('en_core_web_lg'); print('spaCy OK')"
#
# 3. Download a BERT NER model and place it in:
#
#      models/bert_pii/
#
#    Option A - Hugging Face Hub (internet required on build machine):
#      pip install huggingface_hub
#      python -c "
#      from huggingface_hub import snapshot_download
#      snapshot_download(
#          repo_id='dslim/bert-base-NER',
#          local_dir='models/bert_pii',
#          ignore_patterns=['*.msgpack','flax_model*','tf_model*','rust_model*'],
#      )"
#
#    Option B - Save from Python then copy to air-gapped machine:
#      python -c "
#      from transformers import AutoTokenizer, AutoModelForTokenClassification
#      AutoTokenizer.from_pretrained('dslim/bert-base-NER').save_pretrained('models/bert_pii')
#      AutoModelForTokenClassification.from_pretrained('dslim/bert-base-NER').save_pretrained('models/bert_pii')
#      "
#
#    Option C - Manual: download all files from
#      https://huggingface.co/dslim/bert-base-NER/tree/main
#      and place in models/bert_pii/
#
#    BERT is OPTIONAL - if models/bert_pii/ is absent the app runs fine
#    using Regex + Presidio + spaCy only.
#
# 4. Build the EXE:
#
#      pyinstaller pii_scanner.spec
#
# 5. Output: dist/pii_scanner/pii_scanner.exe
#    Copy the ENTIRE dist/pii_scanner/ folder to the target server.
#    Run pii_scanner.exe -> opens on http://localhost:5000
#
#    To change port: set PORT=8080 before running (or edit run.py)
#
# NOTES
# -----
# * The BERT model folder is bundled inside the EXE distribution so the
#   target machine needs no internet access.
# * PyTorch CPU-only wheels are ~700 MB smaller if GPU is not needed:
#     pip install torch --index-url https://download.pytorch.org/whl/cpu
# * To EXCLUDE BERT entirely from the build, set BUNDLE_BERT=0:
#     set BUNDLE_BERT=0 && pyinstaller pii_scanner.spec   (Windows)
#     BUNDLE_BERT=0 pyinstaller pii_scanner.spec           (Linux/Mac)
# =============================================================================

import os
import sys
import site
from pathlib import Path

block_cipher = None

# -- Should we bundle the BERT model? -----------------------------------------
# Set env var BUNDLE_BERT=0 to skip BERT entirely (smaller EXE, no torch dep).
_bundle_bert = os.environ.get("BUNDLE_BERT", "1") != "0"
_bert_model_dir = Path("models") / "bert_pii"
_bert_model_exists = _bert_model_dir.exists() and any(_bert_model_dir.iterdir())

if _bundle_bert and not _bert_model_exists:
    print(
        "\n[spec] WARNING: BUNDLE_BERT=1 but '{}' is empty or missing.\n"
        "       BERT toggle will appear in the UI but detection will be disabled at runtime.\n"
        "       To bundle the model: download it to {}/ and rebuild.\n"
        "       To suppress this warning and skip BERT entirely: set BUNDLE_BERT=0\n"
        .format(_bert_model_dir, _bert_model_dir)
    )

print("[spec] BUNDLE_BERT={}".format("yes" if _bundle_bert else "no"))
if _bundle_bert and _bert_model_exists:
    print("[spec] Found BERT model at: {}".format(_bert_model_dir.resolve()))


# -- Locate spaCy model -------------------------------------------------------
import spacy

def find_spacy_model(model_name):
    """Find the installed spaCy model directory."""
    try:
        import spacy.util
        model_path = spacy.util.get_package_path(model_name)
        if model_path and model_path.exists():
            return str(model_path)
    except Exception:
        pass
    for sp in site.getsitepackages() + [site.getusersitepackages()]:
        candidate = Path(sp) / model_name
        if candidate.exists():
            return str(candidate)
        for child in Path(sp).glob("{}-*".format(model_name)):
            if child.is_dir():
                return str(child)
    raise FileNotFoundError(
        "spaCy model '{}' not found. "
        "Install with: pip install en_core_web_lg-3.7.1.whl --no-deps".format(model_name)
    )

SPACY_MODEL_NAME = "en_core_web_lg"
SPACY_MODEL_PATH = find_spacy_model(SPACY_MODEL_NAME)
print("[spec] Found spaCy model at: {}".format(SPACY_MODEL_PATH))


# -- Collect data files -------------------------------------------------------
from PyInstaller.utils.hooks import collect_data_files, collect_submodules

datas = [
    ("templates",   "templates"),
    ("static",      "static"),
    ("app",         "app"),
    ("sample_logs", "sample_logs"),
    (SPACY_MODEL_PATH, SPACY_MODEL_NAME),
    *collect_data_files("presidio_analyzer"),
    *collect_data_files("spacy"),
    *collect_data_files("en_core_web_lg"),
]

# Bundle BERT model folder (placed at models/bert_pii inside dist)
if _bundle_bert and _bert_model_exists:
    datas.append((str(_bert_model_dir), str(_bert_model_dir)))

# Transformers tokeniser/config data
try:
    datas += collect_data_files("transformers")
    print("[spec] transformers data files collected")
except Exception:
    print("[spec] transformers not installed -- skipping transformers data files")


# -- Hidden imports -----------------------------------------------------------
hidden = [
    # Flask + Werkzeug
    "flask", "flask.templating", "jinja2",
    "werkzeug", "werkzeug.routing", "werkzeug.serving",
    # Presidio
    "presidio_analyzer",
    "presidio_analyzer.predefined_recognizers",
    "presidio_analyzer.nlp_engine",
    "presidio_analyzer.nlp_engine.spacy_nlp_engine",
    "presidio_anonymizer",
    # spaCy and model
    "spacy", "spacy.lang", "spacy.lang.en",
    "spacy.pipeline", "spacy.tokens",
    "spacy.matcher", "spacy.morphology",
    "en_core_web_lg",
    # spaCy C-extension deps
    "thinc", "thinc.backends", "thinc.api",
    "blis", "murmurhash", "cymem", "preshed",
    "srsly", "catalogue", "wasabi", "typer",
    # App modules
    "app.pii_detector",
    "app.bert_detector",
    "app.folder_scanner",
    "app.flask_app",
    "app.exceptions",
]

if _bundle_bert:
    hidden += [
        "transformers",
        "transformers.pipelines",
        "transformers.pipelines.token_classification",
        "transformers.models.bert",
        "transformers.models.bert.modeling_bert",
        "transformers.models.bert.tokenization_bert",
        "transformers.models.bert.tokenization_bert_fast",
        "transformers.models.roberta",
        "transformers.models.roberta.modeling_roberta",
        "transformers.models.roberta.tokenization_roberta",
        "transformers.tokenization_utils",
        "transformers.tokenization_utils_fast",
        "tokenizers",
        "torch",
        "torch.nn",
        "torch.nn.functional",
        "torch.jit",
        "torch._C",
        "torch.cuda",
        "torch.backends",
        "torch.backends.cpu",
        "torch.backends.cudnn",
    ]


# -- Analysis -----------------------------------------------------------------
a = Analysis(
    ["run.py"],
    pathex=["."],
    binaries=[],
    datas=datas,
    hiddenimports=hidden,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[
        "tkinter", "matplotlib", "numpy.distutils", "pytest",
        "tensorflow", "jax", "flax",
        "IPython", "jupyter", "nbformat",
    ],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

# -- PYZ ----------------------------------------------------------------------
pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

# -- EXE ----------------------------------------------------------------------
exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name="pii_scanner",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    console=True,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=None,
)

# -- COLLECT ------------------------------------------------------------------
coll = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    strip=False,
    upx=True,
    upx_exclude=[
        "torch_python*.pyd",
        "*.so",
    ],
    name="pii_scanner",
)

# =============================================================================
# DEPLOYMENT
# =============================================================================
# Output: dist/pii_scanner/pii_scanner.exe
#
# Copy the ENTIRE dist/pii_scanner/ folder to the target server, then:
#   pii_scanner.exe             -> http://localhost:5000
#   set PORT=8080 & pii_scanner.exe  -> http://localhost:8080
#
# The BERT model is bundled inside dist/pii_scanner/models/bert_pii/
# No internet connection required on the target server.
#
# EXPECTED DIST SIZE
# ------------------
#   Without BERT (BUNDLE_BERT=0)   : ~400-600 MB
#   With BERT dslim/bert-base-NER  : ~1.4-1.8 GB
#   With roberta-large-ner-english : ~3.0-3.5 GB
# =============================================================================
