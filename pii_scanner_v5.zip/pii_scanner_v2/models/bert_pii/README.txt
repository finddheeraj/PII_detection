Place your downloaded BERT NER model files here.
================================================

Expected files (standard Hugging Face format):
  config.json
  tokenizer_config.json
  tokenizer.json          (fast tokeniser — preferred)
  vocab.txt               (classic tokeniser fallback)
  pytorch_model.bin       OR  model.safetensors
  special_tokens_map.json

Recommended model: dslim/bert-base-NER
  Size: ~400 MB
  Labels: PER, LOC, ORG, MISC (IOB2 scheme)

Download options:
-----------------

Option A — Hugging Face Hub CLI (internet required):
  pip install huggingface_hub
  python -c "
  from huggingface_hub import snapshot_download
  snapshot_download(
      repo_id='dslim/bert-base-NER',
      local_dir='models/bert_pii',
      ignore_patterns=['*.msgpack','flax_model*','tf_model*','rust_model*'],
  )"

Option B — Python save (internet on build machine, then copy):
  python -c "
  from transformers import AutoTokenizer, AutoModelForTokenClassification
  tok = AutoTokenizer.from_pretrained('dslim/bert-base-NER')
  tok.save_pretrained('models/bert_pii')
  mdl = AutoModelForTokenClassification.from_pretrained('dslim/bert-base-NER')
  mdl.save_pretrained('models/bert_pii')
  "

Option C — Manual download:
  Visit https://huggingface.co/dslim/bert-base-NER/tree/main
  Download each file and place it in this folder.

Overriding the model path at runtime:
  set BERT_MODEL_PATH=C:\path\to\your\model
  pii_scanner.exe

BERT is optional. The app runs fine without any files here —
the BERT toggle in the UI will simply be inactive.
