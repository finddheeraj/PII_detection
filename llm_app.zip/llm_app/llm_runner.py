from typing import Any, Dict, List, Optional
from pwm_genai_config import logger
from pwm_genai_config.resources import LLWCallable, AssertLLWConfig

from schemas.summary_of_summaries import LLWCitation, LLWCitationsSummary
from utils.enum import LLWStatus
from utils.result import LLWResult
from utils import utils


def _check_max_token(response: Dict):
    """If the LLM hit its token limit, return an error result immediately."""
    if response.get("stop_reason", None) == "max_tokens":
        return LLWResult(
            status=LLWStatus.MAX_TOKENS_REACHED,
            content="Max tokens reached!",
            metadata=utils.extract_llm_metadata(response=response),
            raw_response=response,
        )
    return None


def _extract_citations(
    response: Dict,
    id_to_title: Optional[Dict[str, Any]] = None,
):
    """
    Parse the LLM response and build a list of LLWCitation objects.
    Each content block from the LLM either has citations attached or is plain text.
    """
    citations = []

    for elem in response.get("content", []):
        is_citation = elem.get("citations", None)

        if is_citation:
            current_citation = elem.get("citations")[0]

            document_id = current_citation.get("document_title", None)
            document_title = (
                None if not id_to_title else id_to_title.get(document_id)
            )

            quote = current_citation.get("cited_text", None)
            start_char_index = current_citation.get("start_char_index", None)
            end_char_index = current_citation.get("end_char_index", None)

            citations.append(
                LLWCitation(
                    summary=elem.get("text", ""),
                    document_title=document_title,
                    document_id=document_id,
                    quote=quote,
                    start_char_index=start_char_index,
                    end_char_index=end_char_index,
                )
            )
        else:
            citations.append(LLWCitation(summary=elem.get("text", "")))

    return LLWResult(
        status=LLWStatus.SUCCESS,
        content=LLWCitationsSummary(citations=citations),
        metadata=utils.extract_llm_metadata(response=response),
        raw_response=response,
    )


def run_llm_citation(
    system_prompt: List[Dict],
    message_prompt: List[Dict],
    id_to_title: Optional[Dict[str, Any]] = None,
) -> LLWResult:
    """
    Simplified entry point:
      1. Call the LLM once via pwm_genai_config's llm_func
      2. Check for max-token errors
      3. Extract and return citations
    """
    from pwm_genai_config.resources import get_default_llm_callable
    llm_func: LLWCallable = get_default_llm_callable()

    logger.info("Calling LLM (single attempt, no guardrails, no MLflow)")

    llm_response, llm_input = llm_func(
        system_messages=system_prompt,
        messages=[
            {
                "role": "user",
                "content": message_prompt,
            }
        ],
        return_model_inputs=True,
    )

    if max_token_check := _check_max_token(response=llm_response):
        max_token_check.set_raw_llm_input(llm_input)
        return max_token_check

    final_response: LLWResult = _extract_citations(
        response=llm_response, id_to_title=id_to_title
    )
    final_response.set_raw_llm_input(llm_input)

    return final_response
