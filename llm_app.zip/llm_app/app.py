from flask import Flask, request, jsonify, render_template
from llm_runner import run_llm_citation

app = Flask(__name__)


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/ask", methods=["POST"])
def ask():
    data = request.get_json()
    user_message = data.get("message", "")
    documents = data.get("documents", [])  # optional list of document dicts

    if not user_message:
        return jsonify({"error": "No message provided"}), 400

    system_prompt = [
        {
            "text": "You are a helpful assistant. Answer clearly and concisely."
        }
    ]

    # message_prompt can include document sources for citation mode
    message_prompt = documents + [{"type": "text", "text": user_message}]

    try:
        result = run_llm_citation(
            system_prompt=system_prompt,
            message_prompt=message_prompt,
        )

        if result.status.name == "SUCCESS":
            return jsonify({
                "status": "success",
                "citations": [
                    {
                        "summary": c.summary,
                        "document_id": c.document_id,
                        "document_title": c.document_title,
                        "quote": c.quote,
                    }
                    for c in result.content.citations
                ]
            })
        else:
            return jsonify({
                "status": result.status.name,
                "message": str(result.content)
            }), 500

    except Exception as e:
        return jsonify({"error": str(e)}), 500


if __name__ == "__main__":
    app.run(debug=True)
