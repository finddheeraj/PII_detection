# LLM Citation Flask App

Minimal Flask app to call your team's `pwm_genai_config` LLM setup — no guardrails, no MLflow.

## Structure

```
llm_app/
├── app.py              # Flask routes
├── llm_runner.py       # Core LLM call logic (stripped from teammate's code)
├── templates/
│   └── index.html      # Simple UI
└── requirements.txt
```

## Run

```bash
pip install -r requirements.txt
python app.py
```

Visit http://localhost:5000

## API

POST `/ask`
```json
{
  "message": "Summarise the document",
  "documents": []   // optional — pass Bedrock-format document blocks here
}
```
