"""
rules/scorers.py
================
Urgency scoring strategies used by rule-based processors.
Each scorer implements BaseScorer.score() → float (0–1).

Classes:
  DeadlineScorer    — scores based on days_remaining field
  SeverityScorer    — scores based on severity / priority string
  AUMScorer         — scores based on client AUM (higher AUM = higher urgency)
  NBAScorer         — passes through the engine's propensity score directly
  CompositeScorer   — weighted combination of multiple scorers
"""

from __future__ import annotations
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from core.interfaces import BaseScorer


class DeadlineScorer(BaseScorer):
    """
    Maps days_remaining → urgency score.
    Negative days (overdue) always score 1.0.
    """

    def score(self, event: dict) -> float:
        days = event.get("days_remaining", 30)
        if days <= 0:   return 1.00
        if days <= 2:   return 0.97
        if days <= 5:   return 0.90
        if days <= 7:   return 0.82
        if days <= 14:  return 0.68
        if days <= 30:  return 0.50
        return 0.30


class SeverityScorer(BaseScorer):
    """Maps a string severity / priority label to a 0–1 score."""

    _MAP = {"CRITICAL": 1.0, "HIGH": 0.80, "MEDIUM": 0.55, "LOW": 0.30}

    def score(self, event: dict) -> float:
        sev = (event.get("severity") or event.get("priority") or "LOW").upper()
        return self._MAP.get(sev, 0.30)


class AUMScorer(BaseScorer):
    """
    Scores CRM events based on client AUM.
    Bands: <1M → 0.4, 1–5M → 0.6, 5–20M → 0.75, >20M → 0.90
    """

    def score(self, event: dict) -> float:
        aum = event.get("aum") or event.get("potential_aum") or 0
        if aum >= 20_000_000: return 0.90
        if aum >= 5_000_000:  return 0.75
        if aum >= 1_000_000:  return 0.60
        return 0.40


class NBAScorer(BaseScorer):
    """Passes the engine's propensity score through directly."""

    def score(self, event: dict) -> float:
        return float(event.get("score", 0.5))


class CompositeScorer(BaseScorer):
    """
    Weighted average of multiple scorers.
    weights must sum to 1.0.

    Example:
        CompositeScorer([
            (DeadlineScorer(), 0.6),
            (SeverityScorer(), 0.4),
        ])
    """

    def __init__(self, scorers_weights: list[tuple[BaseScorer, float]]):
        total = sum(w for _, w in scorers_weights)
        assert abs(total - 1.0) < 0.001, "Weights must sum to 1.0"
        self._sw = scorers_weights

    def score(self, event: dict) -> float:
        return sum(scorer.score(event) * weight for scorer, weight in self._sw)
