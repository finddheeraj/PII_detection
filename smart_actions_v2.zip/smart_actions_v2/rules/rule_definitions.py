"""
rules/rule_definitions.py
=========================
One rule class per business scenario.
Every rule implements BaseRule.evaluate(event) → Optional[ActionItem].

Rules are DETERMINISTIC and AUDITABLE — each carries a RULE_ID
that appears in the ActionItem's audit trail for compliance reporting.

Rule classes:
  KYCExpiryRule           — fire when KYC renewal < threshold days
  OverdueSuitabilityRule  — fire when suitability review is overdue
  DocumentExpiryRule      — fire when ID/passport copy expiring soon
  RiskReviewRule          — fire on portfolio risk events
  ClientInactivityRule    — fire when no contact beyond threshold days
  ProductMaturityRule     — fire when product matures within window
  ProspectFollowUpRule    — fire when proposal has no response
  WorkflowTaskRule        — fire on cross-team task arrival
  CriticalAlertRule       — fire on CRITICAL severity events (alert-only)
"""

from __future__ import annotations
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from typing import Optional
from core.interfaces import BaseRule
from core.models import (
    ActionItem, ActionSource, ActionType,
    Priority, DecisionMethod
)
from rules.scorers import DeadlineScorer, SeverityScorer, AUMScorer, CompositeScorer


# ── Shared scorers (instantiated once, reused across rules) ───────────────────

_deadline_scorer  = DeadlineScorer()
_severity_scorer  = SeverityScorer()
_aum_scorer       = AUMScorer()
_composite_risk   = CompositeScorer([(_deadline_scorer, 0.65), (_severity_scorer, 0.35)])
_composite_crm    = CompositeScorer([(_severity_scorer, 0.50), (_aum_scorer, 0.50)])


# ── Risk rules ─────────────────────────────────────────────────────────────────

class KYCExpiryRule(BaseRule):
    """
    Fires when KYC renewal is due within THRESHOLD days.
    CRITICAL if overdue, HIGH if within 7 days, MEDIUM otherwise.
    """
    RULE_ID          = "RULE_KYC_001"
    RULE_DESCRIPTION = "KYC renewal within 30 days"
    SOURCE           = "RISK"
    THRESHOLD_DAYS   = 30

    def evaluate(self, event: dict) -> Optional[ActionItem]:
        if event.get("type") != "KYC_EXPIRY":
            return None
        days = event.get("days_remaining", 99)
        if days > self.THRESHOLD_DAYS:
            return None

        priority = (
            Priority.CRITICAL if days <= 0 else
            Priority.HIGH     if days <= 7 else
            Priority.MEDIUM
        )
        urgency = _composite_risk.score(event)

        return ActionItem(
            id           = f"ACT_{event['id']}",
            source       = ActionSource.RISK,
            action_type  = ActionType.KYC_EXPIRY,
            client_id    = event["client_id"],
            client_name  = event["client_name"],
            title        = f"[R&C] KYC renewal due — {event['client_name']}",
            detail       = (
                f"{event['description']}. Regulation: {event['regulation']}. "
                f"Days remaining: {days}."
            ),
            priority         = priority,
            urgency_score    = urgency,
            decision_method  = DecisionMethod.RULE_BASED,
            rule_id          = self.RULE_ID,
            rule_rationale   = (
                f"{self.RULE_DESCRIPTION}: {days} days remaining "
                f"(threshold: {self.THRESHOLD_DAYS}). Priority set to {priority.value}."
            ),
            metadata = event,
        )


class OverdueSuitabilityRule(BaseRule):
    """
    Fires when annual suitability review is overdue (days_remaining <= 0).
    Always CRITICAL — MiFID II regulatory obligation.
    """
    RULE_ID          = "RULE_SUIT_001"
    RULE_DESCRIPTION = "Annual suitability review overdue — MiFID II"
    SOURCE           = "RISK"

    def evaluate(self, event: dict) -> Optional[ActionItem]:
        if event.get("type") != "SUITABILITY_REVIEW":
            return None
        days = event.get("days_remaining", 1)
        if days > 0:
            return None

        return ActionItem(
            id           = f"ACT_{event['id']}",
            source       = ActionSource.RISK,
            action_type  = ActionType.SUITABILITY_REVIEW,
            client_id    = event["client_id"],
            client_name  = event["client_name"],
            title        = f"[R&C] OVERDUE: Suitability review — {event['client_name']}",
            detail       = (
                f"Suitability review is {abs(days)} day(s) overdue. "
                f"Regulation: {event['regulation']}. Immediate action required."
            ),
            priority         = Priority.CRITICAL,
            urgency_score    = 1.0,
            decision_method  = DecisionMethod.RULE_BASED,
            rule_id          = self.RULE_ID,
            rule_rationale   = (
                f"{self.RULE_DESCRIPTION}: review is {abs(days)} day(s) overdue. "
                f"Automatically set to CRITICAL."
            ),
            metadata = event,
        )


class DocumentExpiryRule(BaseRule):
    """
    Fires when an identity document expires within THRESHOLD days.
    """
    RULE_ID          = "RULE_DOC_001"
    RULE_DESCRIPTION = "Identity document expiry within 30 days"
    SOURCE           = "RISK"
    THRESHOLD_DAYS   = 30

    def evaluate(self, event: dict) -> Optional[ActionItem]:
        if event.get("type") != "DOCUMENT_EXPIRY":
            return None
        days = event.get("days_remaining", 99)
        if days > self.THRESHOLD_DAYS:
            return None

        priority = Priority.HIGH if days <= 7 else Priority.MEDIUM
        urgency  = _deadline_scorer.score(event)

        return ActionItem(
            id           = f"ACT_{event['id']}",
            source       = ActionSource.RISK,
            action_type  = ActionType.DOCUMENT_EXPIRY,
            client_id    = event["client_id"],
            client_name  = event["client_name"],
            title        = f"[R&C] Document expiring — {event['client_name']}",
            detail       = f"{event['description']}. Regulation: {event['regulation']}.",
            priority         = priority,
            urgency_score    = urgency,
            decision_method  = DecisionMethod.RULE_BASED,
            rule_id          = self.RULE_ID,
            rule_rationale   = (
                f"{self.RULE_DESCRIPTION}: {days} days remaining. "
                f"Priority: {priority.value}."
            ),
            metadata = event,
        )


class RiskReviewRule(BaseRule):
    """Fires on any portfolio risk review event."""
    RULE_ID          = "RULE_RISK_001"
    RULE_DESCRIPTION = "Portfolio risk review required"
    SOURCE           = "RISK"

    def evaluate(self, event: dict) -> Optional[ActionItem]:
        if event.get("type") != "RISK_REVIEW":
            return None

        sev     = event.get("severity", "MEDIUM")
        priority = Priority(sev) if sev in Priority._value2member_map_ else Priority.MEDIUM
        urgency  = _composite_risk.score(event)

        return ActionItem(
            id           = f"ACT_{event['id']}",
            source       = ActionSource.RISK,
            action_type  = ActionType.RISK_REVIEW,
            client_id    = event["client_id"],
            client_name  = event["client_name"],
            title        = f"[R&C] Portfolio risk review — {event['client_name']}",
            detail       = event["description"],
            priority         = priority,
            urgency_score    = urgency,
            decision_method  = DecisionMethod.RULE_BASED,
            rule_id          = self.RULE_ID,
            rule_rationale   = f"{self.RULE_DESCRIPTION}. Severity: {sev}.",
            metadata = event,
        )


# ── CRM rules ──────────────────────────────────────────────────────────────────

class ClientInactivityRule(BaseRule):
    """
    Fires when a client has not been contacted for more than THRESHOLD days.
    Priority scales with AUM.
    """
    RULE_ID          = "RULE_CRM_001"
    RULE_DESCRIPTION = "Client contact gap exceeds threshold"
    SOURCE           = "CRM"
    THRESHOLD_DAYS   = 30

    def evaluate(self, event: dict) -> Optional[ActionItem]:
        if event.get("type") != "CLIENT_INACTIVITY":
            return None
        days = event.get("last_contact_days", 0)
        if days < self.THRESHOLD_DAYS:
            return None

        urgency  = _composite_crm.score(event)
        priority = Priority.HIGH if urgency >= 0.7 else Priority.MEDIUM

        return ActionItem(
            id           = f"ACT_{event['id']}",
            source       = ActionSource.CRM,
            action_type  = ActionType.CLIENT_INACTIVITY,
            client_id    = event["client_id"],
            client_name  = event["client_name"],
            title        = f"[Opportunity] Contact client — {event['client_name']}",
            detail       = (
                f"No contact in {days} days. "
                f"AUM: £{event.get('aum', 0):,.0f}."
            ),
            priority         = priority,
            urgency_score    = urgency,
            decision_method  = DecisionMethod.RULE_BASED,
            rule_id          = self.RULE_ID,
            rule_rationale   = (
                f"{self.RULE_DESCRIPTION}: {days} days since last contact "
                f"(threshold: {self.THRESHOLD_DAYS}). AUM weight applied."
            ),
            metadata = event,
        )


class ProductMaturityRule(BaseRule):
    """
    Fires when a client product matures within THRESHOLD days.
    High urgency — maturity events have fixed deadlines.
    """
    RULE_ID          = "RULE_CRM_002"
    RULE_DESCRIPTION = "Product maturity within contact window"
    SOURCE           = "CRM"
    THRESHOLD_DAYS   = 21

    def evaluate(self, event: dict) -> Optional[ActionItem]:
        if event.get("type") != "PRODUCT_MATURITY":
            return None

        return ActionItem(
            id           = f"ACT_{event['id']}",
            source       = ActionSource.CRM,
            action_type  = ActionType.PRODUCT_MATURITY,
            client_id    = event["client_id"],
            client_name  = event["client_name"],
            title        = f"[Opportunity] Product maturing — {event['client_name']}",
            detail       = (
                f"{event['description']}. "
                f"Maturity date: {event.get('maturity_date', 'TBC')}. "
                f"Amount: £{event.get('amount', 0):,.0f}."
            ),
            priority         = Priority.HIGH,
            urgency_score    = 0.78,
            decision_method  = DecisionMethod.RULE_BASED,
            rule_id          = self.RULE_ID,
            rule_rationale   = f"{self.RULE_DESCRIPTION}. Fixed deadline — HIGH priority.",
            due_date         = event.get("maturity_date"),
            metadata = event,
        )


class ProspectFollowUpRule(BaseRule):
    """
    Fires when a proposal has received no response after THRESHOLD days.
    """
    RULE_ID          = "RULE_CRM_003"
    RULE_DESCRIPTION = "Prospect proposal with no response"
    SOURCE           = "CRM"
    THRESHOLD_DAYS   = 5

    def evaluate(self, event: dict) -> Optional[ActionItem]:
        if event.get("type") != "PROSPECT_FOLLOW_UP":
            return None

        urgency = _composite_crm.score(event)

        return ActionItem(
            id           = f"ACT_{event['id']}",
            source       = ActionSource.CRM,
            action_type  = ActionType.PROSPECT_FOLLOW_UP,
            client_id    = event["client_id"],
            client_name  = event["client_name"],
            title        = f"[Opportunity] Follow up on proposal — {event['client_name']}",
            detail       = event["description"],
            priority         = Priority(event.get("priority", "MEDIUM")),
            urgency_score    = urgency,
            decision_method  = DecisionMethod.RULE_BASED,
            rule_id          = self.RULE_ID,
            rule_rationale   = f"{self.RULE_DESCRIPTION}. Potential AUM considered.",
            metadata = event,
        )


# ── Workflow rule ──────────────────────────────────────────────────────────────

class WorkflowTaskRule(BaseRule):
    """
    Converts any incoming cross-team workflow task into an ActionItem.
    No threshold — all tasks surface (filtered by priority in the orchestrator).
    """
    RULE_ID          = "RULE_WF_001"
    RULE_DESCRIPTION = "Cross-team workflow task requiring banker action"
    SOURCE           = "WORKFLOW"

    def evaluate(self, event: dict) -> Optional[ActionItem]:
        prio_str = event.get("priority", "MEDIUM")
        priority = Priority(prio_str) if prio_str in Priority._value2member_map_ else Priority.MEDIUM
        urgency  = _severity_scorer.score(event)

        return ActionItem(
            id           = f"ACT_{event['id']}",
            source       = ActionSource.WORKFLOW,
            action_type  = ActionType.CROSS_TEAM_TASK,
            client_id    = event["client_id"],
            client_name  = event["client_name"],
            title        = f"[{event['source_team']}] {event['title']} — {event['client_name']}",
            detail       = (
                f"Task from {event['source_team']} team. "
                f"System: {event['system']} ({event['ticket']}). "
                f"Due: {event.get('due_date', 'TBC')}."
            ),
            priority         = priority,
            urgency_score    = urgency,
            decision_method  = DecisionMethod.RULE_BASED,
            rule_id          = self.RULE_ID,
            rule_rationale   = f"{self.RULE_DESCRIPTION}. Priority from source system: {prio_str}.",
            due_date         = event.get("due_date"),
            metadata = event,
        )
