"""
rules/rule_engine.py
====================
Executes all registered rules against raw events from connectors.
Also runs the deterministic alert evaluation pass.

Classes:
  RuleRegistry   — holds all registered rules; rules can be toggled on/off
  AlertEvaluator — deterministic rule that produces Alert objects
  RuleEngine     — orchestrates connectors + registry → ActionItems + Alerts
"""

from __future__ import annotations
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from typing import Optional
from core.interfaces import BaseRule, BaseDataConnector
from core.models import ActionItem, Alert, ActionSource, Priority
from rules.rule_definitions import (
    KYCExpiryRule, OverdueSuitabilityRule, DocumentExpiryRule,
    RiskReviewRule, ClientInactivityRule, ProductMaturityRule,
    ProspectFollowUpRule, WorkflowTaskRule,
)
from data.connectors import (
    RiskSystemConnector, CRMConnector, WorkflowConnector,
)


# ── Rule registry ─────────────────────────────────────────────────────────────

class RuleRegistry:
    """
    Maintains the list of active rules.
    Rules can be disabled at runtime (useful for A/B testing or rollout).
    """

    def __init__(self):
        self._rules: list[tuple[BaseRule, bool]] = []   # (rule, enabled)

    def register(self, rule: BaseRule, enabled: bool = True) -> "RuleRegistry":
        self._rules.append((rule, enabled))
        return self

    def disable(self, rule_id: str):
        self._rules = [
            (r, False) if r.RULE_ID == rule_id else (r, enabled)
            for r, enabled in self._rules
        ]

    def active_rules(self) -> list[BaseRule]:
        return [r for r, enabled in self._rules if enabled]

    def all_rules(self) -> list[dict]:
        return [
            {**r.describe(), "enabled": enabled}
            for r, enabled in self._rules
        ]


# ── Alert evaluator ───────────────────────────────────────────────────────────

class AlertEvaluator:
    """
    Deterministic pass over already-produced ActionItems.
    Fires alerts for CRITICAL items and overdue R&C events.
    This is intentionally rule-based — zero tolerance for hallucination
    on items that require immediate regulatory action.
    """

    def evaluate(self, actions: list[ActionItem]) -> list[Alert]:
        alerts: list[Alert] = []
        for action in actions:
            is_critical = action.priority == Priority.CRITICAL
            is_overdue  = (
                action.source == ActionSource.RISK and
                action.metadata.get("days_remaining", 1) <= 0
            )
            if is_critical or is_overdue:
                alerts.append(Alert(
                    id          = f"ALERT_{action.id}",
                    title       = action.title,
                    message     = f"Immediate action required: {action.detail}",
                    alert_type  = "CRITICAL" if is_critical else "OVERDUE",
                    source      = action.source,
                    rule_id     = action.rule_id,
                    triggered_by= "RULE_BASED",
                ))
        return alerts


# ── Rule engine ───────────────────────────────────────────────────────────────

class RuleEngine:
    """
    Main rule-based processing layer.

    Workflow:
      1. Fetch raw events from each connector
      2. Run all active rules against each event
      3. Collect ActionItems (de-duplicated by id)
      4. Run AlertEvaluator over the results
      5. Return (actions, alerts)
    """

    def __init__(self):
        self.registry  = self._build_registry()
        self.evaluator = AlertEvaluator()
        self._connectors: list[tuple[BaseDataConnector, list[BaseRule]]] = [
            (
                RiskSystemConnector(),
                [r for r in self.registry.active_rules()
                 if r.SOURCE == "RISK"]
            ),
            (
                CRMConnector(),
                [r for r in self.registry.active_rules()
                 if r.SOURCE == "CRM"]
            ),
            (
                WorkflowConnector(),
                [r for r in self.registry.active_rules()
                 if r.SOURCE == "WORKFLOW"]
            ),
        ]

    def _build_registry(self) -> RuleRegistry:
        registry = RuleRegistry()
        registry \
            .register(KYCExpiryRule()) \
            .register(OverdueSuitabilityRule()) \
            .register(DocumentExpiryRule()) \
            .register(RiskReviewRule()) \
            .register(ClientInactivityRule()) \
            .register(ProductMaturityRule()) \
            .register(ProspectFollowUpRule()) \
            .register(WorkflowTaskRule())
        return registry

    def run(self) -> tuple[list[ActionItem], list[Alert]]:
        """Execute all rules and return (actions, alerts)."""
        print("[RuleEngine] Running deterministic rule evaluation...")
        actions: dict[str, ActionItem] = {}

        for connector, rules in self._connectors:
            events = connector.fetch()
            print(f"[RuleEngine] {connector.CONNECTOR_NAME}: {len(events)} events, {len(rules)} rules")
            for event in events:
                for rule in rules:
                    result = rule.evaluate(event)
                    if result and result.id not in actions:
                        actions[result.id] = result
                        print(f"[RuleEngine] ✓ Rule {rule.RULE_ID} fired → {result.id}")

        action_list = list(actions.values())
        alerts      = self.evaluator.evaluate(action_list)
        print(f"[RuleEngine] Produced {len(action_list)} actions, {len(alerts)} alerts")
        return action_list, alerts

    def get_rules_manifest(self) -> list[dict]:
        """Returns all registered rules and their enabled status — for the UI."""
        return self.registry.all_rules()
