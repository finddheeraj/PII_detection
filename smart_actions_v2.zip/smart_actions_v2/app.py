"""
app.py
======
Flask application — entry point.

Routes:
  GET  /                      → main UI
  GET  /api/actions           → run full pipeline, return JSON
  GET  /api/stream            → SSE live progress stream
  GET  /api/rules             → list all registered rules + enabled status
  POST /api/feedback          → banker thumbs up/down
  GET  /api/feedback/summary  → all feedback collected
"""

import json
import time
import queue
import builtins

from flask import Flask, jsonify, render_template, request, Response, stream_with_context
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

# ── SSE progress queue ────────────────────────────────────────────────────────
_sse_queue: queue.Queue = queue.Queue(maxsize=100)

# Redirect print() into the SSE queue so graph node logs stream to the browser
_orig_print = builtins.print

def _sse_print(*args, **kwargs):
    msg = " ".join(str(a) for a in args)
    _orig_print(msg, **kwargs)
    try:
        _sse_queue.put_nowait({"type": "progress", "message": msg})
    except queue.Full:
        pass

builtins.print = _sse_print

# ── Feedback store ────────────────────────────────────────────────────────────
_feedback: list[dict] = []


# ── Routes ────────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/actions", methods=["GET"])
def get_actions():
    try:
        from orchestrator.graph import get_orchestrator
        result  = get_orchestrator().run()
        payload = result.to_dict()
        _sse_queue.put_nowait({"type": "done", "message": "✓ Pipeline complete"})
        return jsonify({"status": "ok", "data": payload})
    except Exception as exc:
        _sse_queue.put_nowait({"type": "error", "message": str(exc)})
        return jsonify({"status": "error", "message": str(exc)}), 500


@app.route("/api/stream")
def sse_stream():
    def generate():
        yield 'data: {"type":"connected","message":"SSE connected"}\n\n'
        while True:
            try:
                event = _sse_queue.get(timeout=30)
                yield f"data: {json.dumps(event)}\n\n"
                if event.get("type") in ("done", "error"):
                    break
            except queue.Empty:
                yield 'data: {"type":"heartbeat"}\n\n'

    return Response(
        stream_with_context(generate()),
        mimetype="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


@app.route("/api/rules", methods=["GET"])
def get_rules():
    try:
        from rules.rule_engine import RuleEngine
        manifest = RuleEngine().get_rules_manifest()
        return jsonify({"status": "ok", "rules": manifest})
    except Exception as exc:
        return jsonify({"status": "error", "message": str(exc)}), 500


@app.route("/api/feedback", methods=["POST"])
def post_feedback():
    data = request.get_json(force=True)
    _feedback.append({
        "action_id": data.get("action_id"),
        "signal":    data.get("signal"),
        "timestamp": time.time(),
    })
    return jsonify({"status": "ok", "total": len(_feedback)})


@app.route("/api/feedback/summary", methods=["GET"])
def feedback_summary():
    return jsonify({"feedback": _feedback})


if __name__ == "__main__":
    print("Starting Smart Action List v2 on http://localhost:5050")
    app.run(host="0.0.0.0", port=5050, debug=False, threaded=True)
