# Smart Action List v2 — Hybrid Rule + Agent POC

## System design

```
┌─────────────────────────────────────────────────────────────┐
│                    core/models.py                           │
│   ActionItem · Alert · Priority · DecisionMethod · enums    │
├─────────────────────────────────────────────────────────────┤
│                   core/interfaces.py                        │
│   BaseRule · BaseAgent · BaseDataConnector · BaseScorer     │
└──────────────┬──────────────────────────┬───────────────────┘
               │                          │
    ┌──────────▼──────────┐    ┌──────────▼──────────┐
    │  RULE-BASED LAYER   │    │  AGENT-BASED LAYER  │
    │                     │    │                     │
    │ rules/scorers.py    │    │ agents/llm_client.py│
    │  DeadlineScorer     │    │  LLMClient          │
    │  SeverityScorer     │    │  MockLLMClient      │
    │  AUMScorer          │    │                     │
    │  CompositeScorer    │    │ agents/             │
    │                     │    │ agent_definitions.py│
    │ rules/              │    │  MeetingFollowUp    │
    │ rule_definitions.py │    │  NBATranslation     │
    │  KYCExpiryRule      │    │  RationaleGenerator │
    │  OverdueSuitability │    │  PlanningAgent      │
    │  DocumentExpiryRule │    │                     │
    │  RiskReviewRule     │    └──────────┬──────────┘
    │  ClientInactivity   │               │
    │  ProductMaturity    │    ┌──────────▼──────────┐
    │  ProspectFollowUp   │    │   data/connectors   │
    │  WorkflowTaskRule   │    │  RiskSystemConnector│
    │                     │    │  CRMConnector       │
    │ rules/rule_engine.py│    │  NBAEngineConnector │
    │  RuleRegistry       │    │  WorkflowConnector  │
    │  AlertEvaluator     │    │  CalendarConnector  │
    │  RuleEngine         │    └─────────────────────┘
    └──────────┬──────────┘
               │
    ┌──────────▼──────────────────────────────────────┐
    │              orchestrator/graph.py               │
    │  GraphState (TypedDict) · Orchestrator           │
    │                                                  │
    │  LangGraph nodes:                                │
    │    rule_engine_node   → RuleEngine.run()         │
    │    agent_meeting_node → MeetingFollowUpAgent     │
    │    agent_nba_node     → NBATranslationAgent      │
    │    merge_node         → dual-layer prioritise    │
    │    rationale_node     → RationaleGeneratorAgent  │
    │    planning_node      → PlanningAgent            │
    │    assemble_node      → PipelineResult           │
    └──────────┬──────────────────────────────────────┘
               │
    ┌──────────▼──────────┐
    │       app.py        │
    │  GET  /             │
    │  GET  /api/actions  │
    │  GET  /api/stream   │
    │  GET  /api/rules    │
    │  POST /api/feedback │
    └─────────────────────┘
```

## Class inventory

| Class | File | Type | Purpose |
|---|---|---|---|
| `Priority` | core/models.py | Enum | CRITICAL/HIGH/MEDIUM/LOW with weights |
| `ActionSource` | core/models.py | Enum | Source with compliance float weights |
| `DecisionMethod` | core/models.py | Enum | RULE_BASED / AGENT_BASED / HYBRID |
| `ActionItem` | core/models.py | Dataclass | Canonical action object |
| `Alert` | core/models.py | Dataclass | Critical alert for banner |
| `PipelineResult` | core/models.py | Dataclass | Final assembled payload |
| `BaseRule` | core/interfaces.py | ABC | Contract for all rules |
| `BaseAgent` | core/interfaces.py | ABC | Contract for all agents |
| `BaseDataConnector` | core/interfaces.py | ABC | Contract for data sources |
| `BaseScorer` | core/interfaces.py | ABC | Contract for urgency scorers |
| `DeadlineScorer` | rules/scorers.py | Rule | Scores by days_remaining |
| `SeverityScorer` | rules/scorers.py | Rule | Scores by severity string |
| `AUMScorer` | rules/scorers.py | Rule | Scores by client AUM |
| `NBAScorer` | rules/scorers.py | Rule | Passes through propensity score |
| `CompositeScorer` | rules/scorers.py | Rule | Weighted combination of scorers |
| `KYCExpiryRule` | rules/rule_definitions.py | Rule | KYC renewal threshold |
| `OverdueSuitabilityRule` | rules/rule_definitions.py | Rule | MiFID II overdue review |
| `DocumentExpiryRule` | rules/rule_definitions.py | Rule | Passport/ID expiry |
| `RiskReviewRule` | rules/rule_definitions.py | Rule | Portfolio risk events |
| `ClientInactivityRule` | rules/rule_definitions.py | Rule | Contact gap threshold |
| `ProductMaturityRule` | rules/rule_definitions.py | Rule | Product maturity window |
| `ProspectFollowUpRule` | rules/rule_definitions.py | Rule | Unanswered proposals |
| `WorkflowTaskRule` | rules/rule_definitions.py | Rule | Cross-team task intake |
| `RuleRegistry` | rules/rule_engine.py | Service | Holds all rules, enable/disable |
| `AlertEvaluator` | rules/rule_engine.py | Service | Deterministic alert pass |
| `RuleEngine` | rules/rule_engine.py | Service | Runs registry against connectors |
| `RiskSystemConnector` | data/connectors.py | Connector | Risk & compliance data |
| `CRMConnector` | data/connectors.py | Connector | CRM events |
| `NBAEngineConnector` | data/connectors.py | Connector | NBA scores |
| `WorkflowConnector` | data/connectors.py | Connector | JIRA/ServiceNow tasks |
| `CalendarConnector` | data/connectors.py | Connector | Free calendar slots |
| `LLMClient` | agents/llm_client.py | Service | Llama GGUF wrapper |
| `MockLLMClient` | agents/llm_client.py | Service | Canned responses for demo |
| `MeetingFollowUpAgent` | agents/agent_definitions.py | Agent | Meeting notes → actions |
| `NBATranslationAgent` | agents/agent_definitions.py | Agent | NBA scores → action titles |
| `RationaleGeneratorAgent` | agents/agent_definitions.py | Agent | Adds ranking rationale |
| `PlanningAgent` | agents/agent_definitions.py | Agent | Calendar slot matching |
| `GraphState` | orchestrator/graph.py | TypedDict | LangGraph state |
| `Orchestrator` | orchestrator/graph.py | Service | Builds + runs LangGraph |

## Setup

```bash
python -m venv venv && source venv/bin/activate
pip install -r requirements.txt

# Place your GGUF file — or skip (MockLLMClient runs automatically)
mkdir models
# copy llama-3-3b.gguf into ./models/

python app.py
# → http://localhost:5050
```

## Key UI features

- **Stats row** shows rule-based vs agent-based action counts side by side
- **Decision audit tab** on every card shows the exact rule ID + rule rationale or LLM rationale
- **Scoring tab** shows urgency score, source weight, and final score with bar charts
- **Rules manifest tab** lists all registered rules and their enabled status
- **Legend** explains the three decision method colours throughout the UI
