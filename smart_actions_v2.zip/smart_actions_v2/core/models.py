"""
core/models.py
==============
Central data models shared across the entire system.
Every module imports from here — no circular dependencies.

Classes:
  Priority        — Enum: CRITICAL / HIGH / MEDIUM / LOW
  ActionSource    — Enum: RISK / CRM / NBA / WORKFLOW / PLANNING
  ActionType      — Enum: fine-grained action categories
  DecisionMethod  — Enum: RULE_BASED / AGENT_BASED / HYBRID
  ActionItem      — The canonical action object flowing through the system
  Alert           — Urgent notification surfaced in the UI banner
  FeedbackSignal  — Banker thumbs-up / thumbs-down on an action
  PipelineResult  — Final assembled payload returned by the orchestrator
"""

from __future__ import annotations
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional
import uuid
import time


# ── Enumerations ──────────────────────────────────────────────────────────────

class Priority(str, Enum):
    CRITICAL = "CRITICAL"
    HIGH     = "HIGH"
    MEDIUM   = "MEDIUM"
    LOW      = "LOW"

    @property
    def weight(self) -> int:
        return {"CRITICAL": 4, "HIGH": 3, "MEDIUM": 2, "LOW": 1}[self.value]


class ActionSource(str, Enum):
    RISK     = "RISK"
    CRM      = "CRM"
    NBA      = "NBA"
    WORKFLOW = "WORKFLOW"
    PLANNING = "PLANNING"

    @property
    def source_weight(self) -> float:
        """Hard-layer weight: compliance items float above commercial ones."""
        return {
            "RISK":     0.15,
            "WORKFLOW": 0.10,
            "CRM":      0.05,
            "NBA":      0.00,
            "PLANNING": 0.00,
        }[self.value]


class ActionType(str, Enum):
    # Risk / compliance
    KYC_EXPIRY          = "KYC_EXPIRY"
    SUITABILITY_REVIEW  = "SUITABILITY_REVIEW"
    DOCUMENT_EXPIRY     = "DOCUMENT_EXPIRY"
    RISK_REVIEW         = "RISK_REVIEW"
    # CRM / commercial
    CLIENT_INACTIVITY   = "CLIENT_INACTIVITY"
    PRODUCT_MATURITY    = "PRODUCT_MATURITY"
    PROSPECT_FOLLOW_UP  = "PROSPECT_FOLLOW_UP"
    MEETING_FOLLOW_UP   = "MEETING_FOLLOW_UP"
    # NBA / campaign
    NBA_RECOMMENDATION  = "NBA_RECOMMENDATION"
    # Workflow
    CROSS_TEAM_TASK     = "CROSS_TEAM_TASK"
    # Planning
    SCHEDULED_ACTION    = "SCHEDULED_ACTION"


class DecisionMethod(str, Enum):
    RULE_BASED  = "RULE_BASED"   # deterministic, auditable
    AGENT_BASED = "AGENT_BASED"  # LLM-driven, contextual
    HYBRID      = "HYBRID"       # both applied in sequence


# ── Core domain objects ───────────────────────────────────────────────────────

@dataclass
class ActionItem:
    """
    The canonical action object that flows through every layer of the system.
    Both rule-based and agent-based processors read and write this object.
    """
    # Identity
    id:           str = field(default_factory=lambda: f"ACT_{uuid.uuid4().hex[:8].upper()}")
    source:       ActionSource  = ActionSource.RISK
    action_type:  ActionType    = ActionType.KYC_EXPIRY

    # Content
    client_id:    str = ""
    client_name:  str = ""
    title:        str = ""
    detail:       str = ""

    # Prioritisation
    priority:       Priority = Priority.MEDIUM
    urgency_score:  float    = 0.5   # 0–1, higher = more urgent
    final_score:    float    = 0.0   # computed by Orchestrator

    # Decision audit trail
    decision_method:   DecisionMethod = DecisionMethod.RULE_BASED
    rule_id:           Optional[str]  = None   # which rule triggered this
    rule_rationale:    Optional[str]  = None   # human-readable rule explanation
    agent_rationale:   Optional[str]  = None   # LLM-generated rationale
    combined_rationale: Optional[str] = None   # final rationale shown in UI

    # Scheduling
    due_date:       Optional[str] = None
    suggested_slot: Optional[str] = None
    slot_reason:    Optional[str] = None

    # Raw source payload (for drill-down)
    metadata: dict = field(default_factory=dict)

    def to_dict(self) -> dict:
        return {
            "id":                 self.id,
            "source":             self.source.value,
            "action_type":        self.action_type.value,
            "client_id":          self.client_id,
            "client_name":        self.client_name,
            "title":              self.title,
            "detail":             self.detail,
            "priority":           self.priority.value,
            "urgency_score":      round(self.urgency_score, 3),
            "final_score":        round(self.final_score, 3),
            "decision_method":    self.decision_method.value,
            "rule_id":            self.rule_id,
            "rule_rationale":     self.rule_rationale,
            "agent_rationale":    self.agent_rationale,
            "combined_rationale": self.combined_rationale,
            "due_date":           self.due_date,
            "suggested_slot":     self.suggested_slot,
            "slot_reason":        self.slot_reason,
            "metadata":           self.metadata,
        }


@dataclass
class Alert:
    """Critical / overdue item surfaced in the top banner."""
    id:           str
    title:        str
    message:      str
    alert_type:   str          # "CRITICAL" | "OVERDUE" | "REGULATORY"
    source:       ActionSource
    rule_id:      Optional[str] = None
    triggered_by: str = "RULE_BASED"

    def to_dict(self) -> dict:
        return {
            "id":           self.id,
            "title":        self.title,
            "message":      self.message,
            "alert_type":   self.alert_type,
            "source":       self.source.value,
            "rule_id":      self.rule_id,
            "triggered_by": self.triggered_by,
        }


@dataclass
class FeedbackSignal:
    """Banker feedback on a single action."""
    action_id:  str
    signal:     str        # "up" | "down"
    timestamp:  float = field(default_factory=time.time)
    banker_id:  str   = "default"


@dataclass
class PipelineResult:
    """Final assembled payload returned to Flask and then to the browser."""
    all_actions:    list[ActionItem] = field(default_factory=list)
    risk_actions:   list[ActionItem] = field(default_factory=list)
    crm_actions:    list[ActionItem] = field(default_factory=list)
    nba_actions:    list[ActionItem] = field(default_factory=list)
    wf_actions:     list[ActionItem] = field(default_factory=list)
    alerts:         list[Alert]      = field(default_factory=list)
    total:          int  = 0
    critical_count: int  = 0
    rule_count:     int  = 0    # how many actions were decided by rules
    agent_count:    int  = 0    # how many actions were decided by agents

    def to_dict(self) -> dict:
        return {
            "all_actions":    [a.to_dict() for a in self.all_actions],
            "risk_actions":   [a.to_dict() for a in self.risk_actions],
            "crm_actions":    [a.to_dict() for a in self.crm_actions],
            "nba_actions":    [a.to_dict() for a in self.nba_actions],
            "wf_actions":     [a.to_dict() for a in self.wf_actions],
            "alerts":         [a.to_dict() for a in self.alerts],
            "total":          self.total,
            "critical_count": self.critical_count,
            "rule_count":     self.rule_count,
            "agent_count":    self.agent_count,
        }
