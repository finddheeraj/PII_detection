"""
core/interfaces.py
==================
Abstract base classes that every rule and every agent must implement.
This enforces a consistent contract across the system and makes it
trivial to add new rules or agents without touching orchestration code.

Classes:
  BaseRule          — contract for all rule-based processors
  BaseAgent         — contract for all LLM-based agents
  BaseDataConnector — contract for all upstream data source connectors
  BaseScorer        — contract for urgency/priority scoring strategies
"""

from __future__ import annotations
from abc import ABC, abstractmethod
from typing import Optional
from core.models import ActionItem, Alert, Priority


# ── Rule interface ────────────────────────────────────────────────────────────

class BaseRule(ABC):
    """
    A rule is a deterministic, auditable decision unit.
    It evaluates a single raw event dict and either:
      - returns an ActionItem  (rule fired)
      - returns None           (rule did not fire)

    Every rule has a unique RULE_ID used in audit trails.
    """

    RULE_ID:          str = "RULE_BASE"
    RULE_DESCRIPTION: str = "Base rule — override in subclass"
    SOURCE:           str = "UNKNOWN"

    @abstractmethod
    def evaluate(self, event: dict) -> Optional[ActionItem]:
        """
        Evaluate a single raw event.
        Returns an ActionItem if the rule fires, else None.
        """
        ...

    def describe(self) -> dict:
        return {
            "rule_id":     self.RULE_ID,
            "description": self.RULE_DESCRIPTION,
            "source":      self.SOURCE,
        }


# ── Agent interface ───────────────────────────────────────────────────────────

class BaseAgent(ABC):
    """
    An agent uses an LLM to handle tasks that require contextual reasoning,
    natural language understanding, or cross-domain inference.

    Unlike rules, agents may return enriched versions of existing ActionItems
    (e.g. adding rationale or slot suggestions) or generate new ones from
    unstructured input (e.g. meeting notes).
    """

    AGENT_NAME:        str = "BaseAgent"
    AGENT_DESCRIPTION: str = "Base agent — override in subclass"

    @abstractmethod
    def run(self, input_data: dict | list) -> list[ActionItem]:
        """
        Process input data and return a list of ActionItems.
        Input may be raw events, existing ActionItems, or free text.
        """
        ...

    def describe(self) -> dict:
        return {
            "agent_name":  self.AGENT_NAME,
            "description": self.AGENT_DESCRIPTION,
        }


# ── Data connector interface ──────────────────────────────────────────────────

class BaseDataConnector(ABC):
    """
    A data connector retrieves raw events from an upstream system
    (CRM, risk system, workflow tool, calendar, etc.).
    In production each connector wraps a real API call or DB query.
    In the POC they return mock data.
    """

    CONNECTOR_NAME: str = "BaseConnector"

    @abstractmethod
    def fetch(self) -> list[dict]:
        """Fetch and return raw event dicts from the upstream source."""
        ...

    def describe(self) -> dict:
        return {"connector": self.CONNECTOR_NAME}


# ── Scorer interface ──────────────────────────────────────────────────────────

class BaseScorer(ABC):
    """
    A scorer computes a numeric urgency_score (0–1) for a raw event dict.
    Scorers are used by rules to assign initial urgency before LLM enrichment.
    """

    @abstractmethod
    def score(self, event: dict) -> float:
        """Return a 0–1 urgency score for the given event."""
        ...
