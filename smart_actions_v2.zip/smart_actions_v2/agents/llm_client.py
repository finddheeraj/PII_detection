"""
agents/llm_client.py
====================
Singleton wrapper around the local Llama 3 GGUF model via llama-cpp-python.

Classes:
  LLMClient   — loads model once, exposes call() and call_json()
  MockLLMClient — deterministic fallback used when model is not available
                  (lets the POC run without a GPU / model file)
"""

from __future__ import annotations
import os
import re
import json
import time
from typing import Optional


class LLMClient:
    """
    Wraps llama-cpp-python Llama.
    Model is loaded lazily on the first call.
    """

    _instance: Optional["LLMClient"] = None

    def __init__(self):
        self._llm = None

    @classmethod
    def get(cls) -> "LLMClient":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def _load(self):
        if self._llm is not None:
            return
        from llama_cpp import Llama
        model_path = os.environ.get("LLM_MODEL_PATH", "./models/llama-3-3b.gguf")
        print(f"[LLMClient] Loading model: {model_path}")
        self._llm = Llama(
            model_path   = model_path,
            n_ctx        = 4096,
            n_threads    = int(os.environ.get("LLM_THREADS", "4")),
            n_gpu_layers = int(os.environ.get("LLM_GPU_LAYERS", "0")),
            verbose      = False,
        )
        print("[LLMClient] Model ready.")

    def call(self, prompt: str, max_tokens: int = 256, temperature: float = 0.2) -> str:
        self._load()
        t0  = time.time()
        out = self._llm(
            prompt,
            max_tokens  = max_tokens,
            temperature = temperature,
            stop        = ["</s>", "[INST]", "Human:", "User:"],
            echo        = False,
        )
        elapsed = time.time() - t0
        text    = out["choices"][0]["text"].strip()
        print(f"[LLMClient] Generated {len(text)} chars in {elapsed:.1f}s")
        return text

    def call_json(self, prompt: str, max_tokens: int = 512) -> Optional[dict | list]:
        raw = self.call(prompt, max_tokens=max_tokens, temperature=0.1)
        # Strip markdown fences
        raw = re.sub(r"```(?:json)?", "", raw).strip().strip("`").strip()
        # Extract first JSON block
        match = re.search(r"(\{.*\}|\[.*\])", raw, re.DOTALL)
        if match:
            raw = match.group(1)
        try:
            return json.loads(raw)
        except json.JSONDecodeError:
            print(f"[LLMClient] JSON parse error. Raw: {raw[:200]}")
            return None


class MockLLMClient:
    """
    Deterministic mock — used when no GGUF model is present.
    Returns canned but sensible responses so the full pipeline
    can be demonstrated without a local GPU.
    """

    _MEETING_TITLES = {
        "bond":   "Initiate bond ladder rollover and ESG review",
        "rate":   "Discuss interest rate impact on portfolio",
        "esg":    "Review ESG switch options for equity sleeve",
        "default":"Schedule follow-up call to address client concerns",
    }

    _NBA_TITLES = {
        "Structured Note":           "Present capital-protected structured note to client",
        "Bond Ladder":               "Propose 3-year bond ladder for income needs",
        "Discretionary":             "Schedule DPM rebalancing review call",
        "default":                   "Review product recommendation with client",
    }

    def call(self, prompt: str, max_tokens: int = 256, temperature: float = 0.2) -> str:
        # Simple keyword match to return a plausible canned response
        prompt_lower = prompt.lower()
        if "meeting" in prompt_lower or "follow" in prompt_lower:
            for kw, title in self._MEETING_TITLES.items():
                if kw in prompt_lower:
                    return title
            return self._MEETING_TITLES["default"]
        if "recommend" in prompt_lower or "product" in prompt_lower:
            for kw, title in self._NBA_TITLES.items():
                if kw in prompt_lower:
                    return title
            return self._NBA_TITLES["default"]
        return "Action required based on client context"

    def call_json(self, prompt: str, max_tokens: int = 512) -> Optional[dict | list]:
        prompt_lower = prompt.lower()

        # Rationale response
        if "rationale" in prompt_lower or "ranked" in prompt_lower:
            return [
                {"rank": 1, "rationale": "Overdue regulatory obligation requiring immediate remediation."},
                {"rank": 2, "rationale": "Critical compliance deadline within 5 days per FCA COBS."},
                {"rank": 3, "rationale": "Cross-team task with imminent due date and client impact."},
                {"rank": 4, "rationale": "High-value client with upcoming product maturity event."},
                {"rank": 5, "rationale": "Strong NBA signal aligned to client risk profile."},
            ]

        # Calendar schedule response
        if "slot" in prompt_lower or "calendar" in prompt_lower:
            return [
                {"action_index": 1, "slot": "Today 10:00–10:30",  "reason": "Short urgent compliance task."},
                {"action_index": 2, "slot": "Today 14:00–15:00",  "reason": "Complex review needs 60 min."},
                {"action_index": 3, "slot": "Tomorrow 09:00–09:30","reason": "Quick call for follow-up."},
                {"action_index": 4, "slot": "Tomorrow 11:00–12:00","reason": "Proposal discussion prep."},
            ]

        return None


def get_llm_client() -> LLMClient | MockLLMClient:
    """
    Returns a real LLMClient if the model file exists,
    otherwise falls back to MockLLMClient so the demo runs anywhere.
    """
    model_path = os.environ.get("LLM_MODEL_PATH", "./models/llama-3-3b.gguf")
    if os.path.exists(model_path):
        return LLMClient.get()
    print(f"[LLMClient] Model not found at {model_path} — using MockLLMClient")
    return MockLLMClient()
