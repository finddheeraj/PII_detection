"""
agents/agent_definitions.py
============================
One agent class per domain task requiring LLM reasoning.
Every agent implements BaseAgent.run() → list[ActionItem].

Agents handle what rules cannot:
  - Unstructured text (meeting notes)
  - Translation of ML scores into human language
  - Cross-domain reasoning (calendar + action priority)
  - Generating audit-ready rationale for ranked items

Agent classes:
  MeetingFollowUpAgent   — parses meeting notes → structured ActionItems
  NBATranslationAgent    — translates NBA scores → banker-friendly actions
  RationaleGeneratorAgent— adds LLM rationale to top-N ranked actions
  PlanningAgent          — maps top actions to calendar slots
"""

from __future__ import annotations
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from core.interfaces import BaseAgent
from core.models import (
    ActionItem, ActionSource, ActionType,
    Priority, DecisionMethod
)
from agents.llm_client import get_llm_client
from data.connectors import CRMConnector, NBAEngineConnector, CalendarConnector


# ── Meeting follow-up agent ───────────────────────────────────────────────────

class MeetingFollowUpAgent(BaseAgent):
    """
    Reads CRM events of type MEETING_FOLLOW_UP.
    Uses the LLM to parse freetext meeting notes into a clear,
    structured action title and detail.

    Why agent, not rule:
      Meeting notes are unstructured natural language.
      A rule can detect the event type but cannot extract intent.
    """
    AGENT_NAME        = "MeetingFollowUpAgent"
    AGENT_DESCRIPTION = "Parses meeting notes into structured follow-up actions"

    def run(self, input_data: list[dict]) -> list[ActionItem]:
        llm     = get_llm_client()
        actions = []

        for event in input_data:
            if event.get("type") != "MEETING_FOLLOW_UP":
                continue

            print(f"[{self.AGENT_NAME}] Processing meeting notes for {event['client_name']}")

            prompt = (
                f"<s>[INST] You are a private banking assistant. "
                f"A banker had a client meeting. Here are the notes:\n"
                f"'{event['description']}'\n\n"
                f"Write ONE short action item title (max 12 words) the banker should do next. "
                f"Start with a verb. Reply with ONLY the title, no explanation. [/INST]"
            )
            title = llm.call(prompt, max_tokens=60).strip().strip('"').strip("'")

            actions.append(ActionItem(
                id           = f"ACT_{event['id']}",
                source       = ActionSource.CRM,
                action_type  = ActionType.MEETING_FOLLOW_UP,
                client_id    = event["client_id"],
                client_name  = event["client_name"],
                title        = f"[Follow-up] {title} — {event['client_name']}",
                detail       = event["description"],
                priority         = Priority(event.get("priority", "HIGH")),
                urgency_score    = 0.72,
                decision_method  = DecisionMethod.AGENT_BASED,
                agent_rationale  = (
                    f"LLM parsed meeting notes to extract key action: '{title}'. "
                    f"Notes contained multiple topics requiring structured follow-up."
                ),
                metadata = event,
            ))

        return actions


# ── NBA translation agent ─────────────────────────────────────────────────────

class NBATranslationAgent(BaseAgent):
    """
    Translates raw NBA engine scores into human-readable banker actions.
    Uses the LLM to incorporate product context, client rationale,
    and campaign framing into a natural action title.

    Why agent, not rule:
      Rules can threshold on score but cannot generate contextual language.
      The LLM combines product name + client rationale + campaign = real action.
    """
    AGENT_NAME        = "NBATranslationAgent"
    AGENT_DESCRIPTION = "Translates NBA propensity scores into actionable items"

    def run(self, input_data: list[dict]) -> list[ActionItem]:
        llm     = get_llm_client()
        actions = []

        for score in input_data:
            print(f"[{self.AGENT_NAME}] Translating NBA score for {score['client_name']}")

            prompt = (
                f"<s>[INST] You are a private banking assistant. "
                f"The analytics engine recommends offering '{score['product']}' "
                f"to client {score['client_name']} (confidence: {score['score']:.0%}). "
                f"Rationale: {score['rationale']}. Campaign: {score['campaign']}. "
                f"Write ONE short banker action title (max 12 words) starting with a verb. "
                f"Reply with ONLY the title. [/INST]"
            )
            title = llm.call(prompt, max_tokens=60).strip().strip('"').strip("'")

            actions.append(ActionItem(
                id           = f"ACT_{score['id']}",
                source       = ActionSource.NBA,
                action_type  = ActionType.NBA_RECOMMENDATION,
                client_id    = score["client_id"],
                client_name  = score["client_name"],
                title        = f"[Campaign] {title}",
                detail       = (
                    f"NBA recommendation: {score['product']}. "
                    f"Propensity score: {score['score']:.0%}. "
                    f"Rationale: {score['rationale']}. "
                    f"Campaign: {score['campaign']}."
                ),
                priority         = Priority.HIGH if score["score"] >= 0.85 else Priority.MEDIUM,
                urgency_score    = round(score["score"] * 0.75, 2),
                decision_method  = DecisionMethod.AGENT_BASED,
                agent_rationale  = (
                    f"LLM translated NBA score {score['score']:.0%} for "
                    f"'{score['product']}' into a contextual action title."
                ),
                metadata = score,
            ))

        return actions


# ── Rationale generator agent ─────────────────────────────────────────────────

class RationaleGeneratorAgent(BaseAgent):
    """
    Takes the already-prioritised action list and asks the LLM to
    generate a one-sentence rationale for the top-N items explaining
    WHY each action is ranked where it is.

    Enriches existing ActionItems in-place (adds agent_rationale).
    Returns the same list with rationale fields populated.

    Why agent:
      Generating contextual, readable rationale across multiple
      dimensions (regulatory urgency, commercial value, deadline) 
      requires cross-domain reasoning that rules cannot produce.
    """
    AGENT_NAME        = "RationaleGeneratorAgent"
    AGENT_DESCRIPTION = "Generates ranking rationale for top-N prioritised actions"
    TOP_N             = 5

    def run(self, input_data: list[ActionItem]) -> list[ActionItem]:
        if not input_data:
            return input_data

        llm    = get_llm_client()
        top_n  = input_data[:self.TOP_N]

        summary = "\n".join(
            f"{i+1}. {a.title} (priority: {a.priority.value}, source: {a.source.value})"
            for i, a in enumerate(top_n)
        )

        prompt = (
            f"<s>[INST] You are a private banking AI assistant. "
            f"Explain in ONE professional sentence why each action below "
            f"is ranked in this order for a private banker.\n\n"
            f"{summary}\n\n"
            f"Reply ONLY as JSON: "
            f'[{{"rank": 1, "rationale": "..."}}, ...] '
            f"No preamble. [/INST]"
        )

        print(f"[{self.AGENT_NAME}] Generating rationale for top {self.TOP_N} actions")
        result = llm.call_json(prompt, max_tokens=512)

        if result and isinstance(result, list):
            for item in result:
                idx = item.get("rank", 0) - 1
                if 0 <= idx < len(top_n):
                    top_n[idx].agent_rationale  = item.get("rationale", "")
                    top_n[idx].decision_method  = DecisionMethod.HYBRID
                    top_n[idx].combined_rationale = (
                        f"Rule: {top_n[idx].rule_rationale or 'N/A'}  |  "
                        f"AI: {top_n[idx].agent_rationale}"
                    )

        return input_data


# ── Planning agent ─────────────────────────────────────────────────────────────

class PlanningAgent(BaseAgent):
    """
    Maps the top prioritised actions to available calendar slots.
    Uses the LLM to reason over action type, estimated effort,
    and slot duration to suggest the best match.

    Why agent:
      Matching actions to slots requires reasoning about effort estimates,
      action type (quick call vs detailed review), and relative urgency —
      a multi-dimensional problem that rules cannot solve without
      exponential conditional logic.
    """
    AGENT_NAME        = "PlanningAgent"
    AGENT_DESCRIPTION = "Matches top actions to available calendar slots"
    TOP_N             = 4

    def run(self, input_data: list[ActionItem]) -> list[ActionItem]:
        if not input_data:
            return input_data

        llm   = get_llm_client()
        slots = CalendarConnector().fetch()

        if not slots:
            return input_data

        top_n = input_data[:self.TOP_N]

        actions_summary = "\n".join(
            f"[{i+1}] {a.title} (priority: {a.priority.value}, type: {a.action_type.value})"
            for i, a in enumerate(top_n)
        )
        slots_summary = "\n".join(
            f"- {s['date']} {s['slot']} ({s['duration_mins']} mins)"
            for s in slots
        )

        prompt = (
            f"<s>[INST] You are a private banking scheduling assistant. "
            f"Match the following actions to the most suitable calendar slots "
            f"based on urgency, action type, and available time.\n\n"
            f"Actions:\n{actions_summary}\n\n"
            f"Available slots:\n{slots_summary}\n\n"
            f"Reply ONLY as JSON: "
            f'[{{"action_index": 1, "slot": "date time", "reason": "brief reason"}}, ...] '
            f"for all {len(top_n)} actions. No preamble. [/INST]"
        )

        print(f"[{self.AGENT_NAME}] Scheduling top {len(top_n)} actions against {len(slots)} slots")
        result = llm.call_json(prompt, max_tokens=400)

        if result and isinstance(result, list):
            slot_map = {item["action_index"]: item for item in result if "action_index" in item}
            for i, action in enumerate(top_n):
                if (i + 1) in slot_map:
                    action.suggested_slot = slot_map[i + 1].get("slot", "")
                    action.slot_reason    = slot_map[i + 1].get("reason", "")

        return input_data
