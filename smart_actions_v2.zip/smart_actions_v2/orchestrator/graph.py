"""
orchestrator/graph.py
=====================
LangGraph graph and top-level Orchestrator class.

The Orchestrator ties the rule engine and all agents together
into a single pipeline.  It is the only class Flask talks to.

Graph topology:
  START
    → rule_engine_node       deterministic: rules + alerts
    → agent_nba_node         LLM: NBA translation
    → agent_meeting_node     LLM: meeting follow-up parsing
    → merge_node             merge + dual-layer prioritise
    → rationale_node         LLM: add rationale to top-5
    → planning_node          LLM: calendar slot matching
    → assemble_node          build final PipelineResult
  END

Classes:
  GraphState    — TypedDict state flowing through nodes
  Orchestrator  — builds + runs the graph; exposes run() → PipelineResult
"""

from __future__ import annotations
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from typing import TypedDict
from langgraph.graph import StateGraph, START, END

from core.models import (
    ActionItem, Alert, ActionSource, Priority,
    DecisionMethod, PipelineResult
)
from rules.rule_engine import RuleEngine
from agents.agent_definitions import (
    MeetingFollowUpAgent, NBATranslationAgent,
    RationaleGeneratorAgent, PlanningAgent,
)
from data.connectors import CRMConnector, NBAEngineConnector


# ── Graph state ───────────────────────────────────────────────────────────────

class GraphState(TypedDict):
    # Rule engine outputs
    rule_actions: list[ActionItem]
    alerts:       list[Alert]
    # Agent outputs
    meeting_actions: list[ActionItem]
    nba_actions:     list[ActionItem]
    # Merged and ranked
    all_actions:        list[ActionItem]
    prioritised_actions: list[ActionItem]
    # After enrichment
    final_actions: list[ActionItem]
    # Result
    pipeline_result: PipelineResult


# ── Prioritisation logic ──────────────────────────────────────────────────────

def _compute_final_score(action: ActionItem) -> float:
    """
    Dual-layer scoring:
      Layer 1 (hard): source weight ensures R&C items always float above commercial
      Layer 2 (soft): urgency_score as tiebreaker within the same priority
    """
    p  = action.priority.weight             # 1–4
    u  = action.urgency_score               # 0–1
    sw = action.source.source_weight        # 0–0.15
    return round(p + u + sw, 4)


# ── Graph nodes ───────────────────────────────────────────────────────────────

def rule_engine_node(state: GraphState) -> GraphState:
    """Run the deterministic rule engine."""
    engine = RuleEngine()
    rule_actions, alerts = engine.run()
    return {**state, "rule_actions": rule_actions, "alerts": alerts}


def agent_meeting_node(state: GraphState) -> GraphState:
    """Run the meeting follow-up agent on CRM data."""
    crm_events = CRMConnector().fetch()
    agent      = MeetingFollowUpAgent()
    actions    = agent.run(crm_events)
    return {**state, "meeting_actions": actions}


def agent_nba_node(state: GraphState) -> GraphState:
    """Run the NBA translation agent on engine scores."""
    nba_scores = NBAEngineConnector().fetch()
    agent      = NBATranslationAgent()
    actions    = agent.run(nba_scores)
    return {**state, "nba_actions": actions}


def merge_node(state: GraphState) -> GraphState:
    """
    Merge all action lists, de-duplicate by id,
    compute final scores, and sort.
    """
    print("[Orchestrator] Merging and prioritising all actions...")

    seen: dict[str, ActionItem] = {}
    for action in (
        state.get("rule_actions", []) +
        state.get("meeting_actions", []) +
        state.get("nba_actions", [])
    ):
        if action.id not in seen:
            action.final_score = _compute_final_score(action)
            seen[action.id] = action

    prioritised = sorted(seen.values(), key=lambda a: a.final_score, reverse=True)
    print(f"[Orchestrator] {len(prioritised)} unique actions after merge")
    return {**state, "all_actions": list(seen.values()), "prioritised_actions": prioritised}


def rationale_node(state: GraphState) -> GraphState:
    """Add LLM-generated rationale to top-N actions."""
    agent   = RationaleGeneratorAgent()
    actions = agent.run(state.get("prioritised_actions", []))
    return {**state, "prioritised_actions": actions}


def planning_node(state: GraphState) -> GraphState:
    """Map top actions to calendar slots."""
    agent   = PlanningAgent()
    actions = agent.run(state.get("prioritised_actions", []))
    return {**state, "final_actions": actions}


def assemble_node(state: GraphState) -> GraphState:
    """Build the final PipelineResult payload."""
    print("[Orchestrator] Assembling final payload...")

    actions = state.get("final_actions") or state.get("prioritised_actions", [])
    alerts  = state.get("alerts", [])

    def by_source(src: ActionSource) -> list[ActionItem]:
        return [a for a in actions if a.source == src]

    rule_count  = sum(1 for a in actions if a.decision_method == DecisionMethod.RULE_BASED)
    agent_count = sum(1 for a in actions if a.decision_method != DecisionMethod.RULE_BASED)

    result = PipelineResult(
        all_actions    = actions,
        risk_actions   = by_source(ActionSource.RISK),
        crm_actions    = by_source(ActionSource.CRM),
        nba_actions    = by_source(ActionSource.NBA),
        wf_actions     = by_source(ActionSource.WORKFLOW),
        alerts         = alerts,
        total          = len(actions),
        critical_count = len(alerts),
        rule_count     = rule_count,
        agent_count    = agent_count,
    )
    return {**state, "pipeline_result": result}


# ── Orchestrator ──────────────────────────────────────────────────────────────

class Orchestrator:
    """
    Builds and compiles the LangGraph graph once at startup.
    Exposes run() for Flask to call per request.
    """

    def __init__(self):
        self._graph = self._build()

    def _build(self):
        g = StateGraph(GraphState)

        g.add_node("rule_engine",  rule_engine_node)
        g.add_node("agent_meeting",agent_meeting_node)
        g.add_node("agent_nba",    agent_nba_node)
        g.add_node("merge",        merge_node)
        g.add_node("rationale",    rationale_node)
        g.add_node("planning",     planning_node)
        g.add_node("assemble",     assemble_node)

        g.add_edge(START,           "rule_engine")
        g.add_edge("rule_engine",   "agent_meeting")
        g.add_edge("agent_meeting", "agent_nba")
        g.add_edge("agent_nba",     "merge")
        g.add_edge("merge",         "rationale")
        g.add_edge("rationale",     "planning")
        g.add_edge("planning",      "assemble")
        g.add_edge("assemble",      END)

        return g.compile()

    def run(self) -> PipelineResult:
        initial: GraphState = {
            "rule_actions":      [],
            "alerts":            [],
            "meeting_actions":   [],
            "nba_actions":       [],
            "all_actions":       [],
            "prioritised_actions": [],
            "final_actions":     [],
            "pipeline_result":   PipelineResult(),
        }
        result = self._graph.invoke(initial)
        return result["pipeline_result"]


# Singleton — imported by Flask
_orchestrator_instance: Orchestrator | None = None

def get_orchestrator() -> Orchestrator:
    global _orchestrator_instance
    if _orchestrator_instance is None:
        _orchestrator_instance = Orchestrator()
    return _orchestrator_instance
