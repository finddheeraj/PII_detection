"""
data/connectors.py
==================
One connector class per upstream data source.
Each implements BaseDataConnector.fetch() returning raw event dicts.

In production: replace fetch() body with the real API/DB call.
The rest of the system (rules, agents, orchestrator) needs no changes.

Classes:
  RiskSystemConnector      — KYC, suitability, document expiry, risk reviews
  CRMConnector             — client inactivity, product maturity, follow-ups
  NBAEngineConnector       — next-best-action scores from analytics engine
  WorkflowConnector        — cross-team tasks from JIRA / ServiceNow
  CalendarConnector        — banker's available time slots
"""

from __future__ import annotations
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from datetime import date, timedelta
from core.interfaces import BaseDataConnector

_today = date.today()


class RiskSystemConnector(BaseDataConnector):
    """
    Simulates the risk & compliance system.
    Produces KYC expiries, suitability reviews, document expiries,
    and portfolio risk events.
    """
    CONNECTOR_NAME = "RiskSystem"

    def fetch(self) -> list[dict]:
        return [
            {
                "id": "R001", "client_id": "C001",
                "client_name": "Arjun Mehta",
                "type": "KYC_EXPIRY",
                "description": "KYC renewal due",
                "days_remaining": 5,
                "regulation": "FCA / COBS",
                "severity": "HIGH",
            },
            {
                "id": "R002", "client_id": "C002",
                "client_name": "Priya Sharma",
                "type": "SUITABILITY_REVIEW",
                "description": "Annual suitability review overdue",
                "days_remaining": -2,
                "regulation": "MiFID II",
                "severity": "CRITICAL",
            },
            {
                "id": "R003", "client_id": "C003",
                "client_name": "James Thornton",
                "type": "DOCUMENT_EXPIRY",
                "description": "Passport copy expiring in 14 days",
                "days_remaining": 14,
                "regulation": "AML",
                "severity": "MEDIUM",
            },
            {
                "id": "R004", "client_id": "C004",
                "client_name": "Sarah Liu",
                "type": "RISK_REVIEW",
                "description": "Portfolio risk review triggered by market movement",
                "days_remaining": 3,
                "regulation": "Internal policy",
                "severity": "HIGH",
            },
        ]


class CRMConnector(BaseDataConnector):
    """
    Simulates the CRM system.
    Produces inactivity nudges, product maturities, prospect follow-ups
    and meeting follow-up notes.
    """
    CONNECTOR_NAME = "CRM"

    def fetch(self) -> list[dict]:
        return [
            {
                "id": "CRM001", "client_id": "C005",
                "client_name": "David Okafor",
                "type": "CLIENT_INACTIVITY",
                "description": "No contact in 45 days",
                "last_contact_days": 45,
                "aum": 4_500_000,
                "priority": "HIGH",
            },
            {
                "id": "CRM002", "client_id": "C006",
                "client_name": "Elena Vasquez",
                "type": "PRODUCT_MATURITY",
                "description": "Fixed deposit maturing in 10 days",
                "maturity_date": str(_today + timedelta(days=10)),
                "amount": 750_000,
                "priority": "HIGH",
            },
            {
                "id": "CRM003", "client_id": "C007",
                "client_name": "Rajiv Patel",
                "type": "PROSPECT_FOLLOW_UP",
                "description": "Proposal sent 7 days ago — no response yet",
                "proposal_date": str(_today - timedelta(days=7)),
                "potential_aum": 2_000_000,
                "priority": "MEDIUM",
            },
            {
                "id": "CRM004", "client_id": "C001",
                "client_name": "Arjun Mehta",
                "type": "MEETING_FOLLOW_UP",
                "description": (
                    "Call on Monday: client expressed concern about rising rates, "
                    "wants to discuss bond ladder rollover and possible ESG switch "
                    "for the equity sleeve. Also asked about offshore structuring options."
                ),
                "meeting_date": str(_today - timedelta(days=2)),
                "priority": "HIGH",
            },
        ]


class NBAEngineConnector(BaseDataConnector):
    """
    Simulates the Next Best Action analytics engine.
    Returns propensity scores and campaign context.
    """
    CONNECTOR_NAME = "NBAEngine"

    def fetch(self) -> list[dict]:
        return [
            {
                "id": "NBA001", "client_id": "C002",
                "client_name": "Priya Sharma",
                "product": "Structured Note — Capital Protected",
                "score": 0.91,
                "rationale": "High risk-aversion + recent liquidity event",
                "campaign": "Q2 Structured Products",
            },
            {
                "id": "NBA002", "client_id": "C003",
                "client_name": "James Thornton",
                "product": "Bond Ladder — 3yr",
                "score": 0.83,
                "rationale": "Income-seeking profile, low equity allocation",
                "campaign": "Fixed Income Drive",
            },
            {
                "id": "NBA003", "client_id": "C005",
                "client_name": "David Okafor",
                "product": "Discretionary Portfolio Review",
                "score": 0.78,
                "rationale": "Portfolio drift vs IPS target detected",
                "campaign": "DPM Rebalancing",
            },
        ]


class WorkflowConnector(BaseDataConnector):
    """
    Simulates cross-team tasks arriving from JIRA / ServiceNow.
    """
    CONNECTOR_NAME = "WorkflowTools"

    def fetch(self) -> list[dict]:
        return [
            {
                "id": "WF001", "client_id": "C004",
                "client_name": "Sarah Liu",
                "source_team": "Operations",
                "title": "Account opening docs — sign-off required",
                "due_date": str(_today + timedelta(days=2)),
                "priority": "HIGH",
                "system": "ServiceNow",
                "ticket": "INC0045231",
            },
            {
                "id": "WF002", "client_id": "C006",
                "client_name": "Elena Vasquez",
                "source_team": "Credit",
                "title": "Lombard facility renewal — credit approval pending",
                "due_date": str(_today + timedelta(days=7)),
                "priority": "MEDIUM",
                "system": "JIRA",
                "ticket": "CRD-8812",
            },
        ]


class CalendarConnector(BaseDataConnector):
    """
    Simulates the banker's calendar free slots.
    """
    CONNECTOR_NAME = "Calendar"

    def fetch(self) -> list[dict]:
        return [
            {"date": str(_today),                       "slot": "10:00–10:30", "duration_mins": 30},
            {"date": str(_today),                       "slot": "14:00–15:00", "duration_mins": 60},
            {"date": str(_today + timedelta(days=1)),   "slot": "09:00–09:30", "duration_mins": 30},
            {"date": str(_today + timedelta(days=1)),   "slot": "11:00–12:00", "duration_mins": 60},
        ]
