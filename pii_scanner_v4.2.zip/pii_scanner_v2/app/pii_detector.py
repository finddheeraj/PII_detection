"""
PII Detection Engine — Private Banking / Financial Context

Design principles:
- Every pattern requires EITHER a keyword/structural gate OR mathematical validation
- No bare numeric patterns that match general log metadata
- UK + US + EU formats covered
- Pre-screen filter avoids running 16 patterns on clean lines
"""

import re
from dataclasses import dataclass, field
from enum import Enum


# ── PII Types ─────────────────────────────────────────────────────────────────

class PIIType(str, Enum):
    SSN                 = "SSN"
    DATE_OF_BIRTH       = "DATE_OF_BIRTH"
    DRIVERS_LICENSE     = "DRIVERS_LICENSE"
    PASSPORT            = "PASSPORT"
    BANK_ACCOUNT_NUMBER = "BANK_ACCOUNT_NUMBER"
    BANK_ROUTING_NUMBER = "BANK_ROUTING_NUMBER"
    PAN                 = "PAN"
    CREDIT_CARD_NUMBER  = "CREDIT_CARD_NUMBER"
    CVV                 = "CVV"
    PIN                 = "PIN"
    HOME_ADDRESS        = "HOME_ADDRESS"
    EMAIL_ADDRESS       = "EMAIL_ADDRESS"
    PHONE_NUMBER        = "PHONE_NUMBER"
    GOVERNMENT_ID       = "GOVERNMENT_ID"
    PERSON_NAME         = "PERSON_NAME"
    MOTHERS_MAIDEN_NAME = "MOTHERS_MAIDEN_NAME"
    BIOMETRIC_REFERENCE = "BIOMETRIC_REFERENCE"
    PASSWORD            = "PASSWORD"
    IP_ADDRESS          = "IP_ADDRESS"


PROTECTION_MAP = {
    PIIType.SSN:                  "Tokenisation SHOULD be used; Encryption SHOULD be used (Field Level) for applications storing SSN.",
    PIIType.DATE_OF_BIRTH:        "Tokenisation SHOULD be used; Encryption SHOULD be used (Field Level) for DOB.",
    PIIType.DRIVERS_LICENSE:      "Tokenisation SHOULD be used; Encryption SHOULD be used (Field Level).",
    PIIType.PASSPORT:             "Tokenisation SHOULD be used; Encryption SHOULD be used (Field Level).",
    PIIType.BANK_ACCOUNT_NUMBER:  "Tokenisation SHOULD be implemented. If combined with name/address (toxic combination), MUST be tokenised or encrypted.",
    PIIType.BANK_ROUTING_NUMBER:  "Tokenisation SHOULD be used; combined with Account Number forms toxic combination — MUST be tokenised or encrypted.",
    PIIType.PAN:                  "Tokenisation SHOULD be implemented (PCI-DSS). If combined with name/address, MUST be tokenised or encrypted.",
    PIIType.CREDIT_CARD_NUMBER:   "Tokenisation SHOULD be used; Encryption SHOULD be used (Field Level).",
    PIIType.CVV:                  "Tokenisation SHOULD be used; Encryption SHOULD be used (Field Level).",
    PIIType.PIN:                  "Access (protected): Break Glass access process required with business justification and time-bound duration.",
    PIIType.HOME_ADDRESS:         "Tokenisation SHOULD be used; Encryption SHOULD be used (Field Level).",
    PIIType.EMAIL_ADDRESS:        "Tokenisation SHOULD be used; Encryption SHOULD be used (Field Level).",
    PIIType.PHONE_NUMBER:         "Tokenisation SHOULD be used; Encryption SHOULD be used (Field Level).",
    PIIType.GOVERNMENT_ID:        "Tokenisation SHOULD be used; Encryption SHOULD be used (Field Level).",
    PIIType.PERSON_NAME:          "Tokenisation SHOULD be used when combined with other PII (toxic combination risk).",
    PIIType.MOTHERS_MAIDEN_NAME:  "Tokenisation SHOULD be used; Encryption SHOULD be used (Field Level) — Customer Shared Authentication.",
    PIIType.BIOMETRIC_REFERENCE:  "Encryption MUST be used.",
    PIIType.PASSWORD:             "Reversible encryption for readvise scenarios; one-way Hash + Standard Access Controls otherwise.",
    PIIType.IP_ADDRESS:           "Tokenisation SHOULD be used.",
}

SEVERITY_MAP = {
    PIIType.SSN:                  "CRITICAL",
    PIIType.CREDIT_CARD_NUMBER:   "CRITICAL",
    PIIType.PAN:                  "CRITICAL",
    PIIType.CVV:                  "CRITICAL",
    PIIType.PIN:                  "CRITICAL",
    PIIType.BANK_ACCOUNT_NUMBER:  "HIGH",
    PIIType.BANK_ROUTING_NUMBER:  "HIGH",
    PIIType.PASSPORT:             "HIGH",
    PIIType.DRIVERS_LICENSE:      "HIGH",
    PIIType.BIOMETRIC_REFERENCE:  "HIGH",
    PIIType.DATE_OF_BIRTH:        "MEDIUM",
    PIIType.MOTHERS_MAIDEN_NAME:  "MEDIUM",
    PIIType.PASSWORD:             "MEDIUM",
    PIIType.GOVERNMENT_ID:        "MEDIUM",
    PIIType.PERSON_NAME:          "LOW",
    PIIType.HOME_ADDRESS:         "LOW",
    PIIType.EMAIL_ADDRESS:        "LOW",
    PIIType.PHONE_NUMBER:         "LOW",
    PIIType.IP_ADDRESS:           "LOW",
}


# ── Match dataclass ───────────────────────────────────────────────────────────

@dataclass
class PIIMatch:
    pii_type:   PIIType
    text:       str
    start:      int
    end:        int
    score:      float
    source:     str
    line_number: int  = 1
    recommended_protection: str = field(default="", init=False)
    severity:   str  = field(default="", init=False)
    is_toxic:   bool = False

    def __post_init__(self):
        self.recommended_protection = PROTECTION_MAP.get(
            self.pii_type, "Encryption SHOULD be applied.")
        self.severity = SEVERITY_MAP.get(self.pii_type, "MEDIUM")

    def to_dict(self):
        return {
            "pii_type":    self.pii_type.value,
            "text":        self.text,
            "start":       self.start,
            "end":         self.end,
            "score":       round(self.score, 2),
            "source":      self.source,
            "line_number": self.line_number,
            "severity":    self.severity,
            "protection":  self.recommended_protection,
            "is_toxic":    self.is_toxic,
        }


# ── Regex patterns ────────────────────────────────────────────────────────────
#
# DESIGN RULE: Every pattern must be "context-anchored" — it either:
#   (a) requires a keyword before the value  (e.g. "SSN: 123-45-6789")
#   (b) has strong structural uniqueness     (e.g. email @, card Luhn check)
#   (c) has a mathematical validator          (e.g. Luhn for credit cards)
#
# This eliminates the most common FP class: bare numeric sequences in logs
# that happen to match a NNN-NN-NNNN or NNN-NNN-NNNN shape.

_REGEX_PATTERNS = [

    # ── SSN — keyword required ────────────────────────────────────────────────
    # Bare NNN-NN-NNNN removed: too many FPs with ref IDs, ticket numbers, SKUs
    (PIIType.SSN,
     r'(?:SSN|S\.S\.N\.?|social\s*security\s*(?:number|num|no|#)?'
     r'|tax\s*(?:id|identification)|TIN\b|ITIN\b)\s*[:\-#]?\s*'
     r'(?!000|666|9\d{2})\d{3}[-\s]?(?!00)\d{2}[-\s]?(?!0000)\d{4}\b',
     0.92),

    # ── Date of Birth — keyword required ──────────────────────────────────────
    # Bare date DD/MM/YYYY removed: matches every scheduled date, expiry date, etc.
    (PIIType.DATE_OF_BIRTH,
     r'\b(?:DOB|D\.O\.B\.?|[Dd]ate\s*[Oo]f\s*[Bb]irth|date_of_birth'
     r'|birthdate|birth\s*date|born)\s*[:\-=]?\s*'
     r'(?:\d{1,2}[/\-\.]\d{1,2}[/\-\.]\d{2,4}|\d{4}[/\-\.]\d{1,2}[/\-\.]\d{1,2})',
     0.92),

    # ── Email — structurally unique (@ + domain) ──────────────────────────────
    (PIIType.EMAIL_ADDRESS,
     r'\b[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}\b',
     0.99),

    # ── Phone — keyword OR structural gate required ───────────────────────────
    # Removed bare NNN-NNN-NNNN: matches HTTP metrics, thread IDs, process IDs
    # Removed 'number' keyword: too generic, matches 'account number: 87654321'
    # Covers: explicit phone keywords, +country, (area), UK 07xxx
    (PIIType.PHONE_NUMBER,
     r'(?:'
     # Keyword gate (phone-specific words only, not generic 'number')
     r'(?:phone|tel(?:ephone)?|mobile|cell|fax|contact|call\s*us)\s*[:\-]?\s*'
     r'(?:\+\d{1,3}[\s\-.]?)?\d[\d\s\-\.]{5,13}\d'
     r'|'
     # +country code with at least one separator OR compact ≥10 digits
     r'\+\d{1,3}[\s\-.]?\d[\d\s\-\.]{5,13}\d'
     r'|'
     # (area code) bracketed prefix
     r'\(\d{3,4}\)\s*\d[\d\s\-\.]{5,11}\d'
     r'|'
     # UK mobile: 07xxx compact (11 digits), spaced (07xxx xxxxxx), dashed (07xxx-xxx-xxx)
     r'\b07\d{9,10}\b'
     r'|'
     r'\b07\d{3}[\s\-]\d{3}[\s\-]\d{3}\b'
     r'|'
     r'\b07\d{3}[\s\-]\d{6}\b'
     r')',
     0.88),

    # ── Credit card — keyword required OR spaced/dashed format ───────────────
    # Bare 16-digit numbers removed: RequestId, MessageId, traceId, sequence
    # numbers are commonly 13-16 digits and pass Luhn by coincidence.
    # Spaced/dashed format (NNNN-NNNN-NNNN-NNNN) is always a card — no keyword needed.
    (PIIType.CREDIT_CARD_NUMBER,
     r'(?:'
     # Keyword gate → card number immediately follows
     r'(?:card(?:\s*number)?|pan|visa|mastercard|maestro|amex|american\s*express'
     r'|credit\s*card|debit\s*card|payment\s*card|cc)\s*[:\#]?\s*'
     r'(?:4[0-9]{12}(?:[0-9]{3})?|5[1-5][0-9]{14}|3[47][0-9]{13}|6(?:011|5[0-9]{2})[0-9]{12})'
     r'|'
     # Grouped format always indicates a card (structurally unambiguous)
     r'\d{4}[\s\-]\d{4}[\s\-]\d{4}[\s\-]\d{4}'
     r')',
     0.90),

    # ── CVV — keyword required ────────────────────────────────────────────────
    (PIIType.CVV,
     r'\b(?:CVV2?|CVC2?|CSC)\s*[:\-]?\s*\d{3,4}\b',
     0.95),

    # ── PIN — keyword required ────────────────────────────────────────────────
    (PIIType.PIN,
     r'\b(?:PIN)\s*[:\-]?\s*\d{4,6}\b',
     0.95),

    # ── Bank routing — keyword required ──────────────────────────────────────
    (PIIType.BANK_ROUTING_NUMBER,
     r'\b(?:routing\s*(?:number|num|no|#)?|ABA\s*(?:number|num)?)\s*[:\-]?\s*[0123]\d{8}\b',
     0.90),

    # ── Bank account — keyword required ──────────────────────────────────────
    (PIIType.BANK_ACCOUNT_NUMBER,
     r'\b(?:account\s*(?:number|num|no|#)|acct\.?|sort\s*code)\s*[:\-]?\s*\d{6,17}\b',
     0.85),

    # ── Passport — keyword required ───────────────────────────────────────────
    # Bare [A-Z]{1,2}[0-9]{6,8} removed: matches AWS IDs, error codes, log refs
    (PIIType.PASSPORT,
     r'\bpassport\s*(?:number|num|no|#)?\s*[:\-]?\s*[A-Z]{1,2}[0-9]{6,8}\b',
     0.90),

    # ── Driver's licence — keyword required ───────────────────────────────────
    (PIIType.DRIVERS_LICENSE,
     r'\b(?:DL\b|driver[\'s]*\s*licen[sc]e|driving\s*licen[sc]e'
     r'|licence\s*(?:number|num|no|#))\s*[:\-]?\s*[A-Z0-9]{5,18}\b',
     0.85),

    # ── IP address — octet-validated, not preceded by / or word chars ─────────
    # Prevents matching version strings (1.2.345.0), URL paths (/v1/2.3.4/api),
    # and chained dot sequences (1.2.3.4.5.6).
    (PIIType.IP_ADDRESS,
     r'(?<![/\w\.])'
     r'(?:(?:25[0-5]|2[0-4]\d|1\d{2}|[1-9]\d|\d)\.){3}'
     r'(?:25[0-5]|2[0-4]\d|1\d{2}|[1-9]\d|\d)'
     r'(?![/\.\w])',
     0.80),

    # ── Password — keyword required ───────────────────────────────────────────
    (PIIType.PASSWORD,
     r'\b(?:password|passwd|pwd|secret|memorable\s*word|passphrase)\s*[:\-=]\s*\S+',
     0.90),

    # ── Mother's maiden name — keyword required ────────────────────────────────
    (PIIType.MOTHERS_MAIDEN_NAME,
     r'\b(?:mother[\'s]*\s*maiden\s*name|maiden\s*name)\s*[:\-]?\s*[A-Za-z\-]+\b',
     0.95),

    # ── Biometric — keyword required ──────────────────────────────────────────
    (PIIType.BIOMETRIC_REFERENCE,
     r'\b(?:fingerprint|retinal?\s*scan|facial\s*recognition|voice\s*print|biometric)\b',
     0.90),

    # ── UK NI number ──────────────────────────────────────────────────────────
    # Format: XX 99 99 99 X  (two letters, six digits, one letter)
    # Added as GOVERNMENT_ID — no keyword required because format is unique enough
    (PIIType.GOVERNMENT_ID,
     r'\b(?:NI|NIN|national\s*insurance(?:\s*number)?)\s*[:\-]?\s*'
     r'[A-CEGHJ-PR-TW-Z]{2}\s*\d{2}\s*\d{2}\s*\d{2}\s*[A-D]\b'
     r'|'
     r'\b[A-CEGHJ-PR-TW-Z]{2}\d{6}[A-D]\b',   # bare NI format is structurally unique
     0.88),
]

_COMPILED_PATTERNS = [
    (t, re.compile(p, re.IGNORECASE), s) for t, p, s in _REGEX_PATTERNS
]


# ── Pre-screen filter ─────────────────────────────────────────────────────────
# One fast check that covers ALL signals any of the patterns above could match.
# Lines that don't hit this are skipped entirely — ~2× throughput on real logs.

_PRESCREEN = re.compile(
    r'@'                                            # email
    r'|\d{3}[-\s]\d{2}[-\s]\d{4}'                 # SSN shape (still need keyword but cheap gate)
    r'|(?:SSN|S\.S\.N|social\s*security|TIN\b|ITIN\b)'
    r'|(?:DOB|D\.O\.B|date.of.birth|birthdate|born)'
    r'|(?:CVV|CVC|CSC)'
    r'|\bPIN\b'
    r'|(?:routing|ABA)'
    r'|(?:account|acct)'
    r'|\bpassport\b'
    r'|(?:licen[sc]e|\bDL\b|driving)'
    r'|(?:maiden)'
    r'|(?:password|passwd|pwd|secret)'
    r'|(?:biometric|fingerprint|retina|facial|voice.print)'
    r'|(?:phone|tel(?:ephone)?|mobile|cell|fax)'
    r'|\+\d{1,3}[\s\-.]?\d'                        # +country phone
    r'|\(\d{3,4}\)\s*\d'                            # (area) phone
    r'|\b07\d{9}'                                   # UK mobile
    r'|\b4\d{12}|\b5[1-5]\d{14}|\b3[47]\d{13}'    # card prefixes
    r'|\d{4}[\s\-]\d{4}[\s\-]\d{4}'               # grouped card
    r'|(?:\d{1,3}\.){3}\d{1,3}'                    # IP
    r'|(?:NI\b|NIN\b|national.insurance)',
    re.IGNORECASE
)


# ── Validators ────────────────────────────────────────────────────────────────

def _luhn_check(number: str) -> bool:
    digits = [int(d) for d in number if d.isdigit()]
    odd_digits  = digits[-1::-2]
    even_digits = digits[-2::-2]
    total = sum(odd_digits)
    for d in even_digits:
        total += sum(divmod(d * 2, 10))
    return total % 10 == 0


def _is_valid_ip(text: str) -> bool:
    """Reject IPs where any octet > 255."""
    parts = text.split('.')
    return all(p.isdigit() and int(p) <= 255 for p in parts)


# ── Core regex scanner ────────────────────────────────────────────────────────

def detect_pii_regex(text: str, line_number: int = 1) -> list:
    """
    Scan a single line with all compiled regex patterns.
    Returns list[PIIMatch].  line_number is passed in by the worker.
    """
    if not _PRESCREEN.search(text):
        return []   # fast path: nothing in this line could be PII

    matches = []
    for pii_type, pattern, base_score in _COMPILED_PATTERNS:
        for m in pattern.finditer(text):
            matched = m.group()
            score   = base_score

            # Validators
            if pii_type == PIIType.CREDIT_CARD_NUMBER:
                if not _luhn_check(re.sub(r'\D', '', matched)):
                    continue
                score = 0.95

            if pii_type == PIIType.IP_ADDRESS:
                if not _is_valid_ip(matched):
                    continue

            matches.append(PIIMatch(
                pii_type=pii_type,
                text=matched,
                start=m.start(),
                end=m.end(),
                score=score,
                source='regex',
                line_number=line_number,
            ))
    return matches


# ── Presidio (optional) ───────────────────────────────────────────────────────

_presidio_analyzer = None

def _get_presidio_analyzer():
    global _presidio_analyzer
    if _presidio_analyzer is not None:
        return _presidio_analyzer
    try:
        from presidio_analyzer import AnalyzerEngine, PatternRecognizer, Pattern
        from presidio_analyzer.nlp_engine import NlpEngineProvider
        provider = NlpEngineProvider(nlp_configuration={
            "nlp_engine_name": "spacy",
            "models": [{"lang_code": "en", "model_name": "en_core_web_lg"}],
        })
        analyzer = AnalyzerEngine(
            nlp_engine=provider.create_engine(), supported_languages=["en"])
        for name, regex, score, entity in [
            ("cvv",     r"\b(?:CVV2?|CVC2?|CSC)\s*[:\-]?\s*\d{3,4}\b",             0.95, "CVV"),
            ("routing", r"\b(?:routing\s*(?:number)?|ABA)\s*[:\-]?\s*[0123]\d{8}\b",0.90, "BANK_ROUTING_NUMBER"),
            ("pin",     r"\bPIN\s*[:\-]?\s*\d{4,6}\b",                              0.95, "PIN"),
            ("mmn",     r"\b(?:mother[\'s]*\s*maiden\s*name|maiden\s*name)\s*[:\-]?\s*[A-Za-z\-]+\b", 0.95, "MOTHERS_MAIDEN_NAME"),
            ("bio",     r"\b(?:fingerprint|retinal?\s*scan|facial\s*recognition|voice\s*print|biometric)\b", 0.90, "BIOMETRIC_REFERENCE"),
        ]:
            analyzer.registry.add_recognizer(PatternRecognizer(
                supported_entity=entity,
                patterns=[Pattern(name=name, regex=regex, score=score)],
            ))
        _presidio_analyzer = analyzer
        return analyzer
    except Exception:
        return None


# NOTE: DATE_TIME removed from map — it's too broad (catches Midnight, TimeSpan, etc.)
_PRESIDIO_MAP = {
    "PERSON":            PIIType.PERSON_NAME,
    "EMAIL_ADDRESS":     PIIType.EMAIL_ADDRESS,
    "PHONE_NUMBER":      PIIType.PHONE_NUMBER,
    "US_SSN":            PIIType.SSN,
    "US_PASSPORT":       PIIType.PASSPORT,
    "US_DRIVER_LICENSE": PIIType.DRIVERS_LICENSE,
    "US_BANK_NUMBER":    PIIType.BANK_ACCOUNT_NUMBER,
    "CREDIT_CARD":       PIIType.CREDIT_CARD_NUMBER,
    "IP_ADDRESS":        PIIType.IP_ADDRESS,
    "LOCATION":          PIIType.HOME_ADDRESS,
    "CVV":               PIIType.CVV,
    "BANK_ROUTING_NUMBER": PIIType.BANK_ROUTING_NUMBER,
    "PIN":               PIIType.PIN,
    "MOTHERS_MAIDEN_NAME": PIIType.MOTHERS_MAIDEN_NAME,
    "BIOMETRIC_REFERENCE": PIIType.BIOMETRIC_REFERENCE,
}


def detect_pii_presidio(text: str, line_number: int = 1) -> list:
    analyzer = _get_presidio_analyzer()
    if not analyzer:
        return []
    matches = []
    for r in analyzer.analyze(text=text, language="en"):
        pii_type = _PRESIDIO_MAP.get(r.entity_type)
        if not pii_type:
            continue
        matches.append(PIIMatch(
            pii_type=pii_type, text=text[r.start:r.end],
            start=r.start, end=r.end, score=r.score,
            source="presidio", line_number=line_number,
        ))
    return matches


# ── spaCy (optional) ──────────────────────────────────────────────────────────

_spacy_nlp = None

def _get_spacy_nlp():
    global _spacy_nlp
    if _spacy_nlp is not None:
        return _spacy_nlp
    try:
        import spacy
        _spacy_nlp = spacy.load("en_core_web_lg")
        return _spacy_nlp
    except Exception:
        return None


# NOTE: DATE removed from map — spaCy labels any time-related word (Midnight,
#       TimeSpan, Monday) as DATE, producing massive FP volume on .NET/Java logs.
_SPACY_MAP = {
    "PERSON": (PIIType.PERSON_NAME, 0.75),
    "GPE":    (PIIType.HOME_ADDRESS, 0.60),
    "LOC":    (PIIType.HOME_ADDRESS, 0.55),
}


def detect_pii_spacy(text: str, line_number: int = 1) -> list:
    nlp = _get_spacy_nlp()
    if not nlp:
        return []
    matches = []
    for ent in nlp(text).ents:
        mapping = _SPACY_MAP.get(ent.label_)
        if not mapping:
            continue
        matches.append(PIIMatch(
            pii_type=mapping[0], text=ent.text,
            start=ent.start_char, end=ent.end_char,
            score=mapping[1], source="spacy", line_number=line_number,
        ))
    return matches


# ── Toxic combinations ────────────────────────────────────────────────────────

TOXIC_COMBINATIONS = [
    ({PIIType.BANK_ACCOUNT_NUMBER, PIIType.PERSON_NAME},
     "Bank Account + Name: MUST be tokenised or encrypted"),
    ({PIIType.BANK_ACCOUNT_NUMBER, PIIType.HOME_ADDRESS},
     "Bank Account + Address: MUST be tokenised or encrypted"),
    ({PIIType.PAN, PIIType.PERSON_NAME},
     "PAN + Name: MUST be tokenised or encrypted (PCI-DSS)"),
    ({PIIType.BANK_ROUTING_NUMBER, PIIType.BANK_ACCOUNT_NUMBER},
     "Routing + Account Number: forms toxic combination — MUST be tokenised or encrypted"),
]


# ── Main detect function ──────────────────────────────────────────────────────

def detect_pii(text: str,
               use_presidio: bool = False,
               use_spacy:    bool = False,
               use_regex:    bool = True,
               min_score:    float = 0.5,
               line_text:    str = "",
               line_number:  int = 1) -> tuple:
    """
    Detect PII in a single line of text.

    Parameters
    ----------
    text        : the text to scan
    line_text   : full line context for exception suppression (defaults to text)
    line_number : 1-based line number in the source file

    Returns
    -------
    (kept_matches, suppressed_matches)
    """
    from app.exceptions import apply_exceptions

    all_matches: list = []
    if use_presidio:
        all_matches.extend(detect_pii_presidio(text, line_number=line_number))
    if use_spacy:
        all_matches.extend(detect_pii_spacy(text, line_number=line_number))
    if use_regex:
        all_matches.extend(detect_pii_regex(text, line_number=line_number))

    # Score filter
    all_matches = [m for m in all_matches if m.score >= min_score]

    # Deduplication: prefer longer/higher-score match at each position
    all_matches.sort(key=lambda m: (m.start, -(m.end - m.start), -m.score))
    deduped, last_end = [], -1
    for m in all_matches:
        if m.start >= last_end:
            deduped.append(m)
            last_end = m.end
        elif m.score > deduped[-1].score:
            deduped[-1] = m

    deduped = sorted(deduped, key=lambda m: m.start)

    # Exception suppression (log timestamps, version strings, etc.)
    ctx = line_text or text
    deduped, suppressed = apply_exceptions(deduped, ctx)

    # Toxic combination marking
    detected_types = {m.pii_type for m in deduped}
    toxic_types: set = set()
    for combo, _ in TOXIC_COMBINATIONS:
        if combo.issubset(detected_types):
            toxic_types.update(combo)
    for m in deduped:
        if m.pii_type in toxic_types:
            m.is_toxic = True

    return deduped, suppressed


# ── Summary helpers ───────────────────────────────────────────────────────────

def get_risk_summary(matches: list, filename: str = "", suppressed: list = None) -> dict:
    detected_types = {m.pii_type for m in matches}
    toxic_flags    = [w for combo, w in TOXIC_COMBINATIONS if combo.issubset(detected_types)]
    severity_counts = {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0}
    for m in matches:
        severity_counts[m.severity] = severity_counts.get(m.severity, 0) + 1
    return {
        "filename":                   filename,
        "total_detections":           len(matches),
        "suppressed_count":           len(suppressed) if suppressed else 0,
        "severity_counts":            severity_counts,
        "pii_types_found":            sorted([t.value for t in detected_types]),
        "toxic_combination_warnings": toxic_flags,
        "has_must_encrypt":           PIIType.BIOMETRIC_REFERENCE in detected_types,
        "detections":                 [m.to_dict() for m in matches],
        "suppressed":                 suppressed or [],
    }


def anonymize_text(text: str, matches: list) -> str:
    result = list(text)
    for m in sorted(matches, key=lambda m: m.start, reverse=True):
        result[m.start:m.end] = list(f"[{m.pii_type.value}]")
    return "".join(result)
