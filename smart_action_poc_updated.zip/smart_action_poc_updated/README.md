# Smart Action List POC — Dual LLM Backend

A meeting follow-up action extraction tool for Barclays PBWM.  
Supports two interchangeable LLM backends, switchable live from the UI.

---

## Backends

| Backend | What it uses | When to use |
|---|---|---|
| **Local LLaMA** | `llama-cpp-python` + local GGUF file | Offline / dev / no AWS access |
| **AWS Bedrock** | `boto3` → Bedrock `invoke_model` | Org AWS account (Barclays SSO) |

Switch between them with the **radio button** at the top of the UI — no restart needed.

---

## Quick Start

```bash
pip install -r requirements.txt
python run.py
```

Open http://localhost:5000

---

## Configuration

### Option A — Local LLaMA (default)

```bash
# Point to your GGUF file
export LLAMA_MODEL_PATH=./models/Meta-Llama-3-8B-Instruct.Q4_K_M.gguf
export LLM_BACKEND=local
```

### Option B — AWS Bedrock (Barclays org account)

**Standard boto3 credentials** (env vars / `~/.aws/credentials`):
```bash
export LLM_BACKEND=bedrock
export CREDS_DEFAULT_REGION=eu-west-2
export LLM_CHAT_MODEL=eu.anthropic.claude-sonnet-4-5-20250929-v1:0

# If using a corporate SSL cert:
export USER_VERIFY_PEM=C:/SourceCode/ProspectEngine/awsportal.pem

# AWS credentials (or use IAM role / AWS SSO):
export AWS_ACCESS_KEY_ID=...
export AWS_SECRET_ACCESS_KEY=...
export AWS_SESSION_TOKEN=...          # if using temp creds
```

**pbwm_genai_config (Barclays internal)** — mirrors your notebook exactly:
```bash
export LLM_BACKEND=bedrock
export USE_PBWM_CONFIG=true
export CREDS_DEFAULT_REGION=eu-west-2
export CREDS_ROLE_ARN=arn:aws:iam::339712929646:role/core-AccountAdmin-fGLBMACEAWSDEV@I+000
export LLM_CHAT_MODEL=eu.anthropic.claude-sonnet-4-5-20250929-v1:0
export USER_VERIFY_PEM=C:/SourceCode/ProspectEngine/awsportal.pem
export USER_USERNAME=chauradh
export USER_PASSWORD=Computer#3thinkpad
```
> ⚠️  Never commit credentials to source control. Use `.env` file with `python-dotenv`.

### Using a `.env` file

Create `.env` in the project root:
```
LLM_BACKEND=bedrock
CREDS_DEFAULT_REGION=eu-west-2
LLM_CHAT_MODEL=eu.anthropic.claude-sonnet-4-5-20250929-v1:0
USE_PBWM_CONFIG=true
...
```

---

## UI Toggle

The strip below the header shows two radio buttons:

```
LLM Backend  [🖥 Local LLaMA]  [☁️ AWS Bedrock]   ● Ready   eu.anthropic.claude-sonnet-...
```

Clicking a radio calls `POST /api/llm/backend` and lazily loads that backend.  
The pill indicator shows **Ready** (green) / **Not loaded** (red) / **Switching…** (blue).

---

## API

| Method | Path | Description |
|---|---|---|
| `GET` | `/api/health` | Liveness + active backend status |
| `GET` | `/api/llm/backend` | Current backend name + model label |
| `POST` | `/api/llm/backend` | Switch backend `{"backend":"bedrock"}` |
| `POST` | `/api/transcript/analyse` | Run extraction pipeline |
| `POST` | `/api/actions/confirm` | Banker confirms an action |
| `GET` | `/api/actions` | Get Smart Action List |
| `PATCH` | `/api/actions/<id>/status` | Update status |
| `DELETE` | `/api/actions/<id>` | Delete action |

---

## Project Structure

```
smart_action_poc/
├── app/
│   ├── config.py              ← ModelConfig + BedrockConfig + AppConfig
│   ├── services/
│   │   └── llm_service.py     ← Unified LLMService (local + bedrock)
│   ├── routes/
│   │   └── health.py          ← /api/health + /api/llm/backend
│   ├── agents/followup_agent.py
│   ├── tools/
│   ├── models/schemas.py
│   ├── static/
│   └── templates/index.html   ← Backend toggle strip
├── requirements.txt
└── run.py
```
