"""
config.py
---------
Central configuration for the Smart Action List POC.
Supports two LLM backends:
  - "local"  : llama-cpp-python (local GGUF model)
  - "bedrock" : AWS Bedrock via boto3 (your org's Barclays AWS account)

Set LLM_BACKEND env var (or use the UI toggle) to switch between them.
"""

import os
from dataclasses import dataclass, field


# ── LLM Backend selection ─────────────────────────────────────────────────────
# "local" or "bedrock"
LLM_BACKEND = os.getenv("LLM_BACKEND", "local")


@dataclass
class ModelConfig:
    """Local LLaMA (llama-cpp-python) settings."""
    # ── Update this to your GGUF file path ──────────────────────────────────
    model_path: str = os.getenv(
        "LLAMA_MODEL_PATH",
        "./models/llama-3b.gguf"   # <-- change this
    )
    # ── Inference settings ───────────────────────────────────────────────────
    n_ctx: int = 4096
    n_threads: int = 4
    n_gpu_layers: int = 0
    temperature: float = 0.1
    max_tokens: int = 1024
    top_p: float = 0.9


@dataclass
class BedrockConfig:
    """AWS Bedrock settings — mirrors what your Barclays notebook uses."""
    # AWS region (matches CREDS_DEFAULT_REGION in your notebook)
    aws_region: str = os.getenv("CREDS_DEFAULT_REGION", "eu-west-2")

    # IAM role ARN for cross-account access (matches CREDS_ROLE_ARN)
    role_arn: str = os.getenv("CREDS_ROLE_ARN", "")

    # Bedrock model ID (matches LLM_CHAT_MODEL in your notebook)
    model_id: str = os.getenv(
        "LLM_CHAT_MODEL",
        "eu.anthropic.claude-sonnet-4-5-20250929-v1:0"
    )

    # SSL cert path for corporate proxy (matches USER_VERIFY_PEM)
    verify_ssl: str = os.getenv("USER_VERIFY_PEM", "")

    # pbwm_genai_config credentials (used in your notebook's Config())
    # Set these if you're using the internal Barclays GenAI config package
    use_pbwm_config: bool = os.getenv("USE_PBWM_CONFIG", "false").lower() == "true"

    # Inference settings
    temperature: float = 0.1
    max_tokens: int = 1024


@dataclass
class AppConfig:
    debug: bool = os.getenv("FLASK_DEBUG", "true").lower() == "true"
    host: str = os.getenv("FLASK_HOST", "0.0.0.0")
    port: int = int(os.getenv("FLASK_PORT", "5000"))
    secret_key: str = os.getenv("SECRET_KEY", "dev-secret-change-in-prod")

    # Today's date injected into prompts for relative deadline parsing
    reference_date: str = "2026-03-20"


# Singleton instances
model_config = ModelConfig()
bedrock_config = BedrockConfig()
app_config = AppConfig()
