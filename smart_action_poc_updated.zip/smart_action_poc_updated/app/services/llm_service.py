"""
services/llm_service.py
-----------------------
Unified LLM service that supports two backends:

  "local"   — llama-cpp-python (original behaviour, unchanged)
  "bedrock" — AWS Bedrock via boto3, using the same invoke_model pattern
              as the Barclays pbwm_genai_config notebook

The active backend is controlled by the LLM_BACKEND env var OR by
calling LLMService.set_backend("bedrock" | "local") at runtime
(which is what the UI toggle does via POST /api/llm/backend).
"""

from __future__ import annotations
import json
import logging
import re
from typing import Any

from app.config import model_config, bedrock_config, LLM_BACKEND

logger = logging.getLogger(__name__)


# ── Prompt template (shared) ───────────────────────────────────────────────────

LLAMA3_SYSTEM_TEMPLATE = "<|begin_of_text|><|start_header_id|>system<|end_header_id|>\n{system}<|eot_id|>"
LLAMA3_USER_TEMPLATE   = "<|start_header_id|>user<|end_header_id|>\n{user}<|eot_id|>"
LLAMA3_ASST_TEMPLATE   = "<|start_header_id|>assistant<|end_header_id|>\n"


def build_llama3_prompt(system: str, user: str) -> str:
    return (
        LLAMA3_SYSTEM_TEMPLATE.format(system=system)
        + LLAMA3_USER_TEMPLATE.format(user=user)
        + LLAMA3_ASST_TEMPLATE
    )


# ── Local backend ─────────────────────────────────────────────────────────────

class _LocalBackend:
    """Wraps llama-cpp-python. Identical to original LLMService logic."""

    def __init__(self):
        self._model = None
        self._loaded = False

    def load(self) -> None:
        if self._loaded:
            return
        try:
            from llama_cpp import Llama
        except ImportError:
            raise RuntimeError(
                "llama-cpp-python is not installed. "
                "Run: pip install llama-cpp-python"
            )
        logger.info(f"[Local] Loading LLaMA model from: {model_config.model_path}")
        try:
            self._model = Llama(
                model_path=model_config.model_path,
                n_ctx=model_config.n_ctx,
                n_threads=model_config.n_threads,
                n_gpu_layers=model_config.n_gpu_layers,
                verbose=False,
            )
            self._loaded = True
            logger.info("[Local] LLaMA model loaded successfully.")
        except Exception as e:
            logger.error(f"[Local] Failed to load model: {e}")
            raise

    @property
    def is_loaded(self) -> bool:
        return self._loaded

    def generate(self, system: str, user: str) -> str:
        if not self._loaded or self._model is None:
            raise RuntimeError("Local LLM not loaded. Call load() first.")
        prompt = build_llama3_prompt(system=system, user=user)
        output = self._model(
            prompt,
            max_tokens=model_config.max_tokens,
            temperature=model_config.temperature,
            top_p=model_config.top_p,
            stop=["<|eot_id|>", "<|end_of_text|>"],
            echo=False,
        )
        return output["choices"][0]["text"].strip()

    @property
    def backend_name(self) -> str:
        return "local"

    @property
    def model_label(self) -> str:
        return model_config.model_path


# ── Bedrock backend ───────────────────────────────────────────────────────────

class _BedrockBackend:
    """
    Calls AWS Bedrock via boto3, mirroring the pattern in your
    Barclays Jupyter notebook (pbwm_genai_config + bedrock-runtime).

    Two modes:
      1. USE_PBWM_CONFIG=true  → uses pbwm_genai_config.Config() for
                                  temporary credential fetching (Barclays SSO)
      2. USE_PBWM_CONFIG=false → plain boto3 with default credential chain
                                  (env vars / ~/.aws / EC2 instance role)
    """

    def __init__(self):
        self._client = None
        self._loaded = False

    def load(self) -> None:
        if self._loaded:
            return
        try:
            import boto3
        except ImportError:
            raise RuntimeError(
                "boto3 is not installed. Run: pip install boto3"
            )

        logger.info(f"[Bedrock] Connecting to AWS Bedrock in region: {bedrock_config.aws_region}")

        try:
            if bedrock_config.use_pbwm_config:
                # ── Barclays internal path ────────────────────────────────────
                # Uses pbwm_genai_config to get temporary AWS credentials
                # (the same flow as your notebook cells [8]–[16])
                try:
                    from pbwm_genai_config import Config, logger as pbwm_logger
                    config = Config(logger=pbwm_logger)
                    session = config._aws_session
                    botocore_config = config._aws_config
                except ImportError:
                    raise RuntimeError(
                        "pbwm_genai_config is not installed. "
                        "Set USE_PBWM_CONFIG=false to use standard boto3 credentials."
                    )

                verify = bedrock_config.verify_ssl if bedrock_config.verify_ssl else True
                self._client = session.client(
                    service_name="bedrock-runtime",
                    region_name=bedrock_config.aws_region,
                    config=botocore_config,
                    verify=verify if verify else True,
                )
                logger.info("[Bedrock] Using pbwm_genai_config credentials.")

            else:
                # ── Standard boto3 path ───────────────────────────────────────
                # Works with env vars, ~/.aws/credentials, or instance roles
                session = boto3.Session(region_name=bedrock_config.aws_region)
                verify = bedrock_config.verify_ssl if bedrock_config.verify_ssl else True
                self._client = session.client(
                    service_name="bedrock-runtime",
                    verify=verify if verify else True,
                )
                logger.info("[Bedrock] Using standard boto3 credential chain.")

            self._loaded = True
            logger.info(f"[Bedrock] Client ready. Model: {bedrock_config.model_id}")

        except Exception as e:
            logger.error(f"[Bedrock] Failed to initialise client: {e}")
            raise

    @property
    def is_loaded(self) -> bool:
        return self._loaded

    def generate(self, system: str, user: str) -> str:
        """
        Calls Bedrock using the Anthropic Messages API format
        (same as your notebook's request_body structure).
        """
        if not self._loaded or self._client is None:
            raise RuntimeError("Bedrock client not initialised. Call load() first.")

        request_body = {
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": bedrock_config.max_tokens,
            "temperature": bedrock_config.temperature,
            "system": [{"type": "text", "text": system}],
            "messages": [
                {
                    "role": "user",
                    "content": [{"type": "text", "text": user}],
                }
            ],
        }

        logger.debug(f"[Bedrock] Invoking model: {bedrock_config.model_id}")

        response = self._client.invoke_model(
            modelId=bedrock_config.model_id,
            body=json.dumps(request_body),
        )

        response_body = json.loads(response["body"].read())

        # Extract text from content blocks (same as your _extract_text helper)
        content = response_body.get("content", [])
        if isinstance(content, str):
            return content.strip()
        texts = [
            block.get("text", "")
            for block in content
            if isinstance(block, dict) and block.get("type") == "text"
        ]
        return "".join(texts).strip()

    @property
    def backend_name(self) -> str:
        return "bedrock"

    @property
    def model_label(self) -> str:
        return bedrock_config.model_id


# ── Unified LLM Service ───────────────────────────────────────────────────────

class LLMService:
    """
    Singleton that wraps either _LocalBackend or _BedrockBackend.
    Call set_backend() to switch at runtime (used by the UI toggle).
    """

    _instance: "LLMService | None" = None
    _local_backend: _LocalBackend | None = None
    _bedrock_backend: _BedrockBackend | None = None
    _active_backend_name: str = LLM_BACKEND   # "local" or "bedrock"

    @classmethod
    def get_instance(cls) -> "LLMService":
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def __init__(self):
        self._local_backend = _LocalBackend()
        self._bedrock_backend = _BedrockBackend()

    # ── Backend switching ─────────────────────────────────────────────────────

    @classmethod
    def set_backend(cls, backend: str) -> None:
        """Switch active backend. backend must be 'local' or 'bedrock'."""
        if backend not in ("local", "bedrock"):
            raise ValueError(f"Unknown backend: {backend!r}. Use 'local' or 'bedrock'.")
        cls._active_backend_name = backend
        logger.info(f"[LLMService] Backend switched to: {backend}")

    @classmethod
    def get_active_backend_name(cls) -> str:
        return cls._active_backend_name

    # ── Active backend accessor ───────────────────────────────────────────────

    def _active(self) -> "_LocalBackend | _BedrockBackend":
        if self._active_backend_name == "bedrock":
            return self._bedrock_backend
        return self._local_backend

    # ── Public API (same interface as original LLMService) ────────────────────

    def load(self) -> None:
        """Load whichever backend is currently active."""
        self._active().load()

    def load_backend(self, backend: str) -> None:
        """Explicitly load a specific backend (called when UI switches)."""
        if backend == "bedrock":
            if not self._bedrock_backend.is_loaded:
                self._bedrock_backend.load()
        else:
            if not self._local_backend.is_loaded:
                self._local_backend.load()

    @property
    def is_loaded(self) -> bool:
        return self._active().is_loaded

    @property
    def model_label(self) -> str:
        return self._active().model_label

    def generate(self, system: str, user: str) -> str:
        return self._active().generate(system=system, user=user)

    def generate_json(self, system: str, user: str) -> Any:
        raw = self.generate(system=system, user=user)
        return self._parse_json(raw)

    @staticmethod
    def _parse_json(raw: str) -> Any:
        cleaned = re.sub(r"```(?:json)?", "", raw).strip().rstrip("`").strip()
        match = re.search(r"[\[\{]", cleaned)
        if match:
            cleaned = cleaned[match.start():]
        try:
            return json.loads(cleaned)
        except json.JSONDecodeError as e:
            logger.warning(f"JSON parse failed. Raw output:\n{raw}")
            raise ValueError(f"Could not parse LLM output as JSON: {e}") from e
