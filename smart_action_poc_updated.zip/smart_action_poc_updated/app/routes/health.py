"""
routes/health.py
----------------
GET  /api/health        → Liveness + model readiness check
POST /api/llm/backend   → Switch LLM backend at runtime (local ↔ bedrock)
GET  /api/llm/backend   → Get current backend info
"""

from flask import Blueprint, jsonify, request
from app.services.llm_service import LLMService
from app.config import model_config, bedrock_config

health_bp = Blueprint("health", __name__, url_prefix="/api")


@health_bp.get("/health")
def health():
    llm = LLMService.get_instance()
    backend = LLMService.get_active_backend_name()
    return jsonify({
        "status":       "ok",
        "backend":      backend,
        "model_loaded": llm.is_loaded,
        "model_label":  llm.model_label if llm.is_loaded else (
            model_config.model_path if backend == "local" else bedrock_config.model_id
        ),
    }), 200


@health_bp.get("/llm/backend")
def get_backend():
    llm = LLMService.get_instance()
    backend = LLMService.get_active_backend_name()
    return jsonify({
        "backend":      backend,
        "model_loaded": llm.is_loaded,
        "model_label":  llm.model_label if llm.is_loaded else "",
    }), 200


@health_bp.post("/llm/backend")
def set_backend():
    """
    Switch the active LLM backend.

    Request body: { "backend": "local" | "bedrock" }
    Response 200: { "backend": "...", "model_loaded": bool }
    """
    data = request.get_json(force=True) or {}
    backend = data.get("backend", "").strip().lower()

    if backend not in ("local", "bedrock"):
        return jsonify({"error": "backend must be 'local' or 'bedrock'"}), 400

    try:
        LLMService.set_backend(backend)
        llm = LLMService.get_instance()
        # Eagerly load the newly selected backend so health check is instant
        llm.load_backend(backend)
        return jsonify({
            "backend":      backend,
            "model_loaded": llm.is_loaded,
            "model_label":  llm.model_label if llm.is_loaded else "",
        }), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500
