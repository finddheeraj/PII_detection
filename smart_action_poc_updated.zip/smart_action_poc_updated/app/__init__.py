"""
app/__init__.py
---------------
Flask application factory.
Wires together: config, LLM loading, CORS, blueprints.

With dual-backend support, LLM loading is best-effort at startup —
if the local model path doesn't exist yet, or AWS creds aren't set,
the app still starts and the UI can switch backends freely.
"""

from __future__ import annotations
import logging

from flask import Flask
from flask_cors import CORS

from app.config import app_config, LLM_BACKEND
from app.services.llm_service import LLMService

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)
logger = logging.getLogger(__name__)


def create_app() -> Flask:
    flask_app = Flask(__name__, template_folder="templates", static_folder="static")
    flask_app.secret_key = app_config.secret_key

    CORS(flask_app)

    # ── Load default LLM backend at startup (best-effort) ────────────────────
    with flask_app.app_context():
        try:
            LLMService.get_instance().load()
            logger.info(f"LLM backend '{LLM_BACKEND}' loaded at startup.")
        except Exception as e:
            logger.warning(
                f"LLM backend '{LLM_BACKEND}' could not load at startup: {e}. "
                "The app will still start — switch backend via the UI toggle."
            )

    # ── Register blueprints ───────────────────────────────────────────────────
    from app.routes.health import health_bp
    from app.routes.transcript import transcript_bp
    from app.routes.actions import actions_bp

    flask_app.register_blueprint(health_bp)
    flask_app.register_blueprint(transcript_bp)
    flask_app.register_blueprint(actions_bp)

    # ── Serve frontend ────────────────────────────────────────────────────────
    from flask import render_template

    @flask_app.get("/")
    def index():
        return render_template("index.html")

    logger.info("Flask app created. Routes registered.")
    return flask_app
