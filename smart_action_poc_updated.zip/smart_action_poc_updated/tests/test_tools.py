"""
tests/test_tools.py
-------------------
Unit tests for all LangGraph tools.
The extractor tool is tested with a mocked LLMService so no
real model is needed to run these tests.

Run with: pytest tests/test_tools.py -v
"""

import pytest
from unittest.mock import patch, MagicMock

from app.models.schemas import Priority, Category, ExtractedAction
from app.tools.validator_tool import validate_actions_tool
from app.tools.dedup_tool import dedup_actions_tool


# ── Fixtures ──────────────────────────────────────────────────────────────────

VALID_RAW_ACTION = {
    "title":        "Send structured product proposal",
    "description":  "Prepare and email a structured product reinvestment proposal to client.",
    "client":       "Harrington Family Office",
    "due_date":     "2026-03-27",
    "priority":     "Medium",
    "category":     "Commercial",
    "source_quote": "I'll prepare a structured product proposal and send it over by end of this week.",
    "emoji":        "💼",
}

INCOMPLETE_RAW_ACTION = {
    "title":    "Renew lending facility",
    "client":   "Harrington Family Office",
    # Missing: description, due_date, priority, category, source_quote
}

INVALID_RAW_ACTION = {
    # Missing required fields: title, client, description
    "priority": "High",
}


# ═══════════════════════════════════════════════════════════════════════
# validator_tool tests
# ═══════════════════════════════════════════════════════════════════════

class TestValidatorTool:

    def test_valid_action_passes(self):
        result = validate_actions_tool.invoke({"raw_actions": [VALID_RAW_ACTION]})
        assert len(result["valid_actions"]) == 1
        assert len(result["warnings"]) == 0
        action = result["valid_actions"][0]
        assert action["title"] == VALID_RAW_ACTION["title"]
        assert action["priority"] == "Medium"

    def test_incomplete_action_gets_enriched(self):
        result = validate_actions_tool.invoke({"raw_actions": [INCOMPLETE_RAW_ACTION]})
        assert len(result["valid_actions"]) == 1
        action = result["valid_actions"][0]
        # due_date should be filled in
        assert action["due_date"] is not None
        # emoji should be assigned
        assert action["emoji"] is not None

    def test_invalid_action_is_filtered(self):
        result = validate_actions_tool.invoke({"raw_actions": [INVALID_RAW_ACTION]})
        assert len(result["valid_actions"]) == 0
        assert len(result["warnings"]) == 1

    def test_empty_input_returns_empty(self):
        result = validate_actions_tool.invoke({"raw_actions": []})
        assert result["valid_actions"] == []
        assert result["warnings"] == []

    def test_non_dict_item_skipped_with_warning(self):
        result = validate_actions_tool.invoke({"raw_actions": ["not_a_dict", VALID_RAW_ACTION]})
        assert len(result["valid_actions"]) == 1
        assert len(result["warnings"]) == 1

    def test_mixed_valid_invalid(self):
        result = validate_actions_tool.invoke({
            "raw_actions": [VALID_RAW_ACTION, INVALID_RAW_ACTION, INCOMPLETE_RAW_ACTION]
        })
        assert len(result["valid_actions"]) == 2  # valid + incomplete (enriched)
        assert len(result["warnings"]) == 1        # invalid skipped

    def test_category_emoji_assignment(self):
        action = {**VALID_RAW_ACTION, "category": "Risk & Control", "emoji": "📋"}
        result = validate_actions_tool.invoke({"raw_actions": [action]})
        assert result["valid_actions"][0]["emoji"] == "⚠️"

    def test_priority_inference_from_title(self):
        action = {**VALID_RAW_ACTION, "priority": None, "title": "Renew lending rate before expiry"}
        result = validate_actions_tool.invoke({"raw_actions": [action]})
        # "expir" keyword → High
        assert result["valid_actions"][0]["priority"] == "High"

    def test_unknown_category_defaults_to_relationship(self):
        action = {**VALID_RAW_ACTION, "category": "Unknown Category XYZ"}
        result = validate_actions_tool.invoke({"raw_actions": [action]})
        assert result["valid_actions"][0]["category"] == "Relationship"

    def test_invalid_due_date_coerced_to_none(self):
        action = {**VALID_RAW_ACTION, "due_date": "not-a-date"}
        result = validate_actions_tool.invoke({"raw_actions": [action]})
        # Should still produce a valid action (due_date coerced to None, then enriched)
        assert len(result["valid_actions"]) == 1


# ═══════════════════════════════════════════════════════════════════════
# dedup_actions_tool tests
# ═══════════════════════════════════════════════════════════════════════

class TestDedupTool:

    def _validated_actions(self, overrides=None):
        """Helper: return a validated action dict for dedup testing."""
        raw = {**VALID_RAW_ACTION, **(overrides or {})}
        result = validate_actions_tool.invoke({"raw_actions": [raw]})
        return result["valid_actions"]

    def test_no_duplicates_when_store_empty(self):
        """Fresh store — nothing should be flagged."""
        from app.services.action_service import ActionService
        with patch("app.tools.dedup_tool.action_service", ActionService()):
            actions = self._validated_actions()
            result = dedup_actions_tool.invoke({"valid_actions": actions})
            assert result["duplicate_count"] == 0
            assert result["actions"][0]["is_duplicate"] is False

    def test_duplicate_flagged_when_matching_action_exists(self):
        """Action with same title+client words should be flagged."""
        from app.services.action_service import ActionService, action_service as real_service
        from app.models.schemas import ExtractedAction

        fresh_service = ActionService()
        # Pre-populate with the same action
        extracted = ExtractedAction(**VALID_RAW_ACTION)
        fresh_service.confirm_action(extracted)

        with patch("app.tools.dedup_tool.action_service", fresh_service):
            actions = self._validated_actions()
            result = dedup_actions_tool.invoke({"valid_actions": actions})
            assert result["duplicate_count"] == 1
            assert result["actions"][0]["is_duplicate"] is True
            assert result["actions"][0]["duplicate_of"] is not None

    def test_different_client_not_flagged_as_duplicate(self):
        from app.services.action_service import ActionService
        from app.models.schemas import ExtractedAction

        fresh_service = ActionService()
        extracted = ExtractedAction(**VALID_RAW_ACTION)
        fresh_service.confirm_action(extracted)

        with patch("app.tools.dedup_tool.action_service", fresh_service):
            # Same title, different client
            actions = self._validated_actions({"client": "Completely Different Client"})
            result = dedup_actions_tool.invoke({"valid_actions": actions})
            assert result["duplicate_count"] == 0

    def test_empty_input_returns_empty(self):
        result = dedup_actions_tool.invoke({"valid_actions": []})
        assert result["actions"] == []
        assert result["duplicate_count"] == 0


# ═══════════════════════════════════════════════════════════════════════
# extractor_tool tests (LLM mocked)
# ═══════════════════════════════════════════════════════════════════════

class TestExtractorTool:

    SAMPLE_TRANSCRIPT = """
    James: I'll send the Q4 report to Sarah by tomorrow.
    Tom: And please schedule a call for next week.
    James: Will do — I'll send a calendar invite.
    """

    MOCK_LLM_RESPONSE = [
        {
            "title": "Send Q4 performance report",
            "description": "Email Q4 report to Sarah Harrington.",
            "client": "Harrington Family Office",
            "due_date": "2026-03-21",
            "priority": "Medium",
            "category": "Relationship",
            "source_quote": "I'll send the Q4 report to Sarah by tomorrow.",
            "emoji": "📊",
        },
        {
            "title": "Send calendar invite for follow-up call",
            "description": "Schedule and send a calendar invite for next week.",
            "client": "Harrington Family Office",
            "due_date": "2026-03-27",
            "priority": "Low",
            "category": "Relationship",
            "source_quote": "I'll send a calendar invite.",
            "emoji": "📅",
        },
    ]

    def test_extractor_returns_list_on_success(self):
        from app.tools.extractor_tool import extract_actions_tool

        mock_llm = MagicMock()
        mock_llm.generate_json.return_value = self.MOCK_LLM_RESPONSE

        with patch("app.tools.extractor_tool.LLMService.get_instance", return_value=mock_llm):
            result = extract_actions_tool.invoke({"transcript": self.SAMPLE_TRANSCRIPT})
            assert isinstance(result, list)
            assert len(result) == 2
            assert result[0]["title"] == "Send Q4 performance report"

    def test_extractor_returns_empty_list_on_parse_failure(self):
        from app.tools.extractor_tool import extract_actions_tool

        mock_llm = MagicMock()
        mock_llm.generate_json.side_effect = ValueError("JSON parse failed")

        with patch("app.tools.extractor_tool.LLMService.get_instance", return_value=mock_llm):
            result = extract_actions_tool.invoke({"transcript": self.SAMPLE_TRANSCRIPT})
            assert result == []

    def test_extractor_wraps_single_dict_in_list(self):
        from app.tools.extractor_tool import extract_actions_tool

        mock_llm = MagicMock()
        # LLM returns a dict instead of list — should be wrapped
        mock_llm.generate_json.return_value = self.MOCK_LLM_RESPONSE[0]

        with patch("app.tools.extractor_tool.LLMService.get_instance", return_value=mock_llm):
            result = extract_actions_tool.invoke({"transcript": self.SAMPLE_TRANSCRIPT})
            assert isinstance(result, list)
            assert len(result) == 1
