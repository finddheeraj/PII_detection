"""
tests/test_routes.py
--------------------
Flask route integration tests.
LLM and agent are mocked — only HTTP contract is tested here.

Run with: pytest tests/test_routes.py -v
"""

import json
import pytest
from unittest.mock import patch, MagicMock

from app import create_app
from app.models.schemas import ExtractionResult, ExtractedAction, Priority, Category


# ── Test fixtures ─────────────────────────────────────────────────────────────

SAMPLE_TRANSCRIPT = "James said he will send the Q4 report to Sarah by end of week. " * 5

MOCK_EXTRACTED_ACTION = ExtractedAction(
    title="Send Q4 performance report",
    description="Email Q4 report to client.",
    client="Sarah Harrington",
    due_date="2026-03-27",
    priority=Priority.MEDIUM,
    category=Category.RELATIONSHIP,
    source_quote="I'll send the Q4 report by end of week.",
    emoji="📊",
)

MOCK_EXTRACTION_RESULT = ExtractionResult(
    actions=[MOCK_EXTRACTED_ACTION],
    agent_log=["Node 1/4: extract", "Node 2/4: validate", "Node 3/4: dedup", "Node 4/4: format"],
    warnings=[],
    model_used="llama-local",
)


@pytest.fixture
def app():
    """Create Flask test app with LLM loading mocked."""
    with patch("app.services.llm_service.LLMService.load"):
        flask_app = create_app()
        flask_app.config["TESTING"] = True
        yield flask_app


@pytest.fixture
def client(app):
    return app.test_client()


# ═══════════════════════════════════════════════════════════════════════
# Health endpoint
# ═══════════════════════════════════════════════════════════════════════

class TestHealthRoute:

    def test_health_returns_200(self, client):
        res = client.get("/api/health")
        assert res.status_code == 200

    def test_health_has_required_fields(self, client):
        data = res = client.get("/api/health").get_json()
        assert "status" in data
        assert "model_loaded" in data
        assert "model_path" in data

    def test_health_status_is_ok(self, client):
        data = client.get("/api/health").get_json()
        assert data["status"] == "ok"


# ═══════════════════════════════════════════════════════════════════════
# Transcript analyse endpoint
# ═══════════════════════════════════════════════════════════════════════

class TestTranscriptRoute:

    def test_analyse_returns_200_with_valid_input(self, client):
        with patch("app.routes.transcript.run_agent", return_value=MOCK_EXTRACTION_RESULT):
            res = client.post(
                "/api/transcript/analyse",
                json={"transcript": SAMPLE_TRANSCRIPT},
            )
        assert res.status_code == 200

    def test_analyse_response_has_actions_key(self, client):
        with patch("app.routes.transcript.run_agent", return_value=MOCK_EXTRACTION_RESULT):
            data = client.post(
                "/api/transcript/analyse",
                json={"transcript": SAMPLE_TRANSCRIPT},
            ).get_json()
        assert "actions" in data
        assert isinstance(data["actions"], list)

    def test_analyse_response_has_agent_log(self, client):
        with patch("app.routes.transcript.run_agent", return_value=MOCK_EXTRACTION_RESULT):
            data = client.post(
                "/api/transcript/analyse",
                json={"transcript": SAMPLE_TRANSCRIPT},
            ).get_json()
        assert "agent_log" in data
        assert len(data["agent_log"]) == 4

    def test_analyse_returns_400_for_missing_transcript(self, client):
        res = client.post("/api/transcript/analyse", json={})
        assert res.status_code == 400

    def test_analyse_returns_400_for_short_transcript(self, client):
        res = client.post("/api/transcript/analyse", json={"transcript": "too short"})
        assert res.status_code == 400

    def test_analyse_returns_400_for_empty_body(self, client):
        res = client.post("/api/transcript/analyse", data="not json",
                          content_type="application/json")
        assert res.status_code == 400

    def test_analyse_passes_meeting_ref(self, client):
        mock_agent = MagicMock(return_value=MOCK_EXTRACTION_RESULT)
        with patch("app.routes.transcript.run_agent", mock_agent):
            client.post(
                "/api/transcript/analyse",
                json={"transcript": SAMPLE_TRANSCRIPT, "meeting_ref": "test-ref-123"},
            )
        mock_agent.assert_called_once_with(
            transcript=SAMPLE_TRANSCRIPT,
            meeting_ref="test-ref-123",
        )


# ═══════════════════════════════════════════════════════════════════════
# Actions endpoints
# ═══════════════════════════════════════════════════════════════════════

class TestActionsRoute:

    def _confirm_one(self, client, overrides=None):
        """Helper: confirm an action and return the response."""
        payload = {
            "extracted": {
                "title": "Send Q4 performance report",
                "description": "Email Q4 report to client.",
                "client": "Sarah Harrington",
                "due_date": "2026-03-27",
                "priority": "Medium",
                "category": "Relationship",
                "source_quote": "End of week.",
                "emoji": "📊",
                **(overrides or {}),
            }
        }
        return client.post("/api/actions/confirm", json=payload)

    def test_confirm_returns_201(self, client):
        res = self._confirm_one(client)
        assert res.status_code == 201

    def test_confirmed_action_has_id(self, client):
        data = self._confirm_one(client).get_json()
        assert "id" in data
        assert len(data["id"]) > 0

    def test_confirmed_action_has_correct_status(self, client):
        data = self._confirm_one(client).get_json()
        assert data["status"] == "not_started"
        assert data["state"] == "confirmed"

    def test_confirm_returns_400_for_missing_extracted(self, client):
        res = client.post("/api/actions/confirm", json={})
        assert res.status_code == 400

    def test_get_actions_returns_200(self, client):
        res = client.get("/api/actions")
        assert res.status_code == 200

    def test_get_actions_returns_list(self, client):
        data = client.get("/api/actions").get_json()
        assert "actions" in data
        assert isinstance(data["actions"], list)

    def test_get_actions_shows_confirmed_action(self, client):
        self._confirm_one(client)
        data = client.get("/api/actions").get_json()
        assert data["total"] >= 1

    def test_get_actions_priority_filter(self, client):
        self._confirm_one(client, {"priority": "High"})
        self._confirm_one(client, {"priority": "Low", "title": "Low priority task"})
        data = client.get("/api/actions?priority=High").get_json()
        for action in data["actions"]:
            assert action["priority"] == "High"

    def test_get_actions_invalid_status_returns_400(self, client):
        res = client.get("/api/actions?status=invalid_status")
        assert res.status_code == 400

    def test_update_status_returns_200(self, client):
        action_id = self._confirm_one(client).get_json()["id"]
        res = client.patch(
            f"/api/actions/{action_id}/status",
            json={"status": "started"},
        )
        assert res.status_code == 200
        assert res.get_json()["status"] == "started"

    def test_update_status_invalid_value_returns_400(self, client):
        action_id = self._confirm_one(client).get_json()["id"]
        res = client.patch(
            f"/api/actions/{action_id}/status",
            json={"status": "flying_to_the_moon"},
        )
        assert res.status_code == 400

    def test_update_status_unknown_id_returns_404(self, client):
        res = client.patch(
            "/api/actions/non-existent-id/status",
            json={"status": "done"},
        )
        assert res.status_code == 404

    def test_delete_action_returns_204(self, client):
        action_id = self._confirm_one(client).get_json()["id"]
        res = client.delete(f"/api/actions/{action_id}")
        assert res.status_code == 204

    def test_delete_unknown_id_returns_404(self, client):
        res = client.delete("/api/actions/ghost-id-999")
        assert res.status_code == 404

    def test_confirm_with_banker_edits(self, client):
        """Banker edits title and priority before confirming."""
        payload = {
            "extracted": {
                "title": "Original title",
                "description": "Some description.",
                "client": "Test Client",
                "due_date": "2026-04-01",
                "priority": "Low",
                "category": "Relationship",
                "source_quote": "quote",
                "emoji": "📋",
            },
            "edits": {
                "title":    "Banker edited title",
                "priority": "High",
            }
        }
        data = client.post("/api/actions/confirm", json=payload).get_json()
        assert data["title"]    == "Banker edited title"
        assert data["priority"] == "High"
