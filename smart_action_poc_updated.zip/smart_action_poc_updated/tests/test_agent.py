"""
tests/test_agent.py
-------------------
Integration tests for the LangGraph followup agent.
LLM is mocked — tests verify graph orchestration correctness.

Run with: pytest tests/test_agent.py -v
"""

import pytest
from unittest.mock import patch, MagicMock

from app.models.schemas import ExtractionResult


SAMPLE_TRANSCRIPT = """
Meeting: Client Portfolio Review
James: I'll send the Q4 report by end of week.
Sarah: Please also renew the lending rate — it expires April 1st.
James: Will do, I'll raise the renewal request today.
"""

MOCK_EXTRACTED = [
    {
        "title": "Send Q4 performance report",
        "description": "Email Q4 report to client.",
        "client": "Sarah Harrington",
        "due_date": "2026-03-27",
        "priority": "Medium",
        "category": "Relationship",
        "source_quote": "I'll send the Q4 report by end of week.",
        "emoji": "📊",
    },
    {
        "title": "Raise lending rate renewal request",
        "description": "Submit lending rate renewal to credit team.",
        "client": "Sarah Harrington",
        "due_date": "2026-03-20",
        "priority": "High",
        "category": "Risk & Control",
        "source_quote": "I'll raise the renewal request today.",
        "emoji": "⚠️",
    },
]


class TestFollowupAgent:

    def _mock_extractor(self, return_value=None):
        """Patch the extractor tool to avoid real LLM calls."""
        mock = MagicMock()
        mock.invoke.return_value = return_value or MOCK_EXTRACTED
        return mock

    def test_agent_returns_extraction_result_type(self):
        from app.agents.followup_agent import run_agent
        with patch("app.agents.followup_agent.extract_actions_tool", self._mock_extractor()):
            result = run_agent(SAMPLE_TRANSCRIPT)
        assert isinstance(result, ExtractionResult)

    def test_agent_returns_correct_number_of_actions(self):
        from app.agents.followup_agent import run_agent
        with patch("app.agents.followup_agent.extract_actions_tool", self._mock_extractor()):
            result = run_agent(SAMPLE_TRANSCRIPT)
        assert len(result.actions) == 2

    def test_agent_log_has_four_nodes(self):
        """Each of the 4 graph nodes must log at least one entry."""
        from app.agents.followup_agent import run_agent
        with patch("app.agents.followup_agent.extract_actions_tool", self._mock_extractor()):
            result = run_agent(SAMPLE_TRANSCRIPT)
        # Each node logs "Node N/4: ..."
        node_logs = [l for l in result.agent_log if "Node" in l]
        assert len(node_logs) >= 4

    def test_agent_populates_model_used(self):
        from app.agents.followup_agent import run_agent
        with patch("app.agents.followup_agent.extract_actions_tool", self._mock_extractor()):
            result = run_agent(SAMPLE_TRANSCRIPT)
        assert result.model_used == "llama-local"

    def test_agent_handles_empty_extraction_gracefully(self):
        from app.agents.followup_agent import run_agent
        with patch("app.agents.followup_agent.extract_actions_tool", self._mock_extractor([])):
            result = run_agent(SAMPLE_TRANSCRIPT)
        assert result.actions == []
        assert isinstance(result.agent_log, list)

    def test_agent_handles_extractor_exception(self):
        from app.agents.followup_agent import run_agent
        mock = MagicMock()
        mock.invoke.side_effect = RuntimeError("LLM crashed")
        with patch("app.agents.followup_agent.extract_actions_tool", mock):
            result = run_agent(SAMPLE_TRANSCRIPT)
        assert isinstance(result, ExtractionResult)
        assert len(result.agent_log) > 0

    def test_agent_passes_meeting_ref(self):
        from app.agents.followup_agent import run_agent
        with patch("app.agents.followup_agent.extract_actions_tool", self._mock_extractor()):
            result = run_agent(SAMPLE_TRANSCRIPT, meeting_ref="test-meeting-001")
        # Agent should complete without error
        assert result is not None

    def test_agent_action_priorities_preserved(self):
        from app.agents.followup_agent import run_agent
        with patch("app.agents.followup_agent.extract_actions_tool", self._mock_extractor()):
            result = run_agent(SAMPLE_TRANSCRIPT)
        priorities = {a.title: a.priority.value for a in result.actions}
        assert priorities.get("Send Q4 performance report") == "Medium"
        assert priorities.get("Raise lending rate renewal request") == "High"

    def test_agent_categories_preserved(self):
        from app.agents.followup_agent import run_agent
        with patch("app.agents.followup_agent.extract_actions_tool", self._mock_extractor()):
            result = run_agent(SAMPLE_TRANSCRIPT)
        cats = {a.title: a.category.value for a in result.actions}
        assert cats.get("Raise lending rate renewal request") == "Risk & Control"
