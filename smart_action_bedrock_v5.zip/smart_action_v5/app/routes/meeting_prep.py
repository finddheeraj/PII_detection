"""
routes/meeting_prep.py
----------------------
POST /api/meeting/prepare
  -> Accepts a short paragraph describing meeting context.
     LLM generates structured objectives, agenda, and a draft
     client invitation email.
"""

from __future__ import annotations
import logging

from flask import Blueprint, request, jsonify
from pydantic import BaseModel, Field
from typing import Optional

from app.services.llm_service import LLMService
from app.config import app_config

logger = logging.getLogger(__name__)

meeting_prep_bp = Blueprint("meeting_prep", __name__, url_prefix="/api/meeting")

# ── Pydantic request model ────────────────────────────────────────────────────

class MeetingPrepRequest(BaseModel):
    context:      str           = Field(..., min_length=20, max_length=5_000,
                                        description="Short description of what the meeting is about")
    client_name:  str           = Field(..., min_length=1, max_length=100)
    banker_name:  str           = Field(..., min_length=1, max_length=100)
    meeting_date: Optional[str] = Field(None, description="e.g. 15 April 2026")
    meeting_time: Optional[str] = Field(None, description="e.g. 10:00 AM IST")
    location:     Optional[str] = Field(None, description="e.g. Barclays Mumbai office / Video call")

# ── System prompt ─────────────────────────────────────────────────────────────

SYSTEM_PROMPT = f"""You are an AI assistant for Barclays Private Bank & Wealth Management (India).
Your task is to prepare structured meeting materials for a private banker.

Today's date is {app_config.reference_date}.

Given a brief description of what a meeting is about, produce the following in a single JSON object:

{{
  "objectives": [
    "Objective 1 — clear, one-sentence banker goal",
    "Objective 2",
    "Objective 3"
  ],
  "agenda": [
    {{ "time": "10:00 AM", "duration": "10 min", "item": "Welcome and introductions" }},
    {{ "time": "10:10 AM", "duration": "20 min", "item": "Portfolio review and performance update" }},
    ...
  ],
  "email_subject": "Meeting Invitation — Portfolio Review | Barclays Private Bank",
  "email_body": "Dear [Client Name],\\n\\nI hope this message finds you well...\\n\\nWarm regards,\\n[Banker Name]\\nBarclays Private Bank & Wealth Management"
}}

Rules:
- Objectives: 3 to 5 bullet points, banker-facing, action-oriented.
- Agenda: 4 to 7 items. Include welcome, core discussion items, next steps, close. Assign realistic durations.
- Email: Professional, warm, concise. Barclays Private Bank tone. Include objectives summary and agenda inline. Sign off with banker name and title.
- No emoji anywhere in the output.
- Return ONLY the JSON object — no markdown fences, no explanation."""


@meeting_prep_bp.post("/prepare")
def prepare_meeting():
    """
    Generate meeting objectives, agenda, and draft client email.
    """
    raw = request.get_json(force=True)
    try:
        body = MeetingPrepRequest(**raw)
    except Exception as e:
        return jsonify({"error": "Invalid request", "detail": str(e)}), 400

    # Build the user prompt with all context
    date_line     = f"Meeting date: {body.meeting_date}" if body.meeting_date else ""
    time_line     = f"Meeting time: {body.meeting_time}" if body.meeting_time else ""
    location_line = f"Location: {body.location}"         if body.location     else ""
    extra = "\n".join(filter(None, [date_line, time_line, location_line]))

    user_prompt = f"""Client name: {body.client_name}
Banker name: {body.banker_name}
{extra}

Meeting context:
{body.context}

Generate the objectives, agenda, and invitation email now."""

    logger.info(f"Meeting prep request — client: {body.client_name}, banker: {body.banker_name}")

    llm = LLMService.get_instance()
    try:
        result = llm.generate_json(system=SYSTEM_PROMPT, user=user_prompt)
        return jsonify(result), 200
    except Exception as e:
        logger.error(f"Meeting prep LLM error: {e}")
        return jsonify({"error": "LLM generation failed", "detail": str(e)}), 500
