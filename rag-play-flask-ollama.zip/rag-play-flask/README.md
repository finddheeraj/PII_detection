# RAG Playground — Flask/Python + Local LLM (Ollama)

Interactive RAG pipeline visualizer rebuilt in **Flask + Python**, using **Ollama** for 100% local LLM inference — no API key, no internet required for generation.

## Features

- **Text Splitting** — Fixed Character, Recursive Character, Parent-Child strategies with live highlight
- **Vector Embeddings** — `sentence-transformers` models, cosine similarity, UMAP/PCA 2-D scatter plot
- **Response Generation** — Local LLM via Ollama, streaming responses, editable prompts

## Quick Start

### 1 — Install Ollama

Download from **https://ollama.com** (macOS, Linux, Windows).

```bash
# Pull a model (choose one based on your RAM):
ollama pull llama3        # Recommended  (~4.7 GB, needs 8 GB RAM)
ollama pull mistral       # Fast & smart (~4.1 GB, needs 8 GB RAM)
ollama pull phi3          # Lightweight  (~2.2 GB, needs 4 GB RAM)
ollama pull gemma:2b      # Smallest     (~1.7 GB, needs 4 GB RAM)

# Start the server
ollama serve
```

### 2 — Run Flask

```bash
python -m venv .venv
source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env           # edit OLLAMA_MODEL if needed
python app.py                  # → http://localhost:5000
```

## Environment Variables

| Variable          | Default                   | Description                  |
|-------------------|---------------------------|------------------------------|
| `OLLAMA_BASE_URL` | `http://localhost:11434`  | Ollama server URL            |
| `OLLAMA_MODEL`    | `llama3`                  | Default model (must be pulled)|

## API Endpoints

| Method | Path                  | Description                          |
|--------|-----------------------|--------------------------------------|
| GET    | `/`                   | Main UI                              |
| GET    | `/api/ollama/status`  | Check Ollama + list available models |
| POST   | `/api/split`          | Text splitting                       |
| POST   | `/api/embed`          | Generate embeddings                  |
| POST   | `/api/similarity`     | Cosine similarity ranking            |
| POST   | `/api/umap`           | 2-D projection (UMAP / PCA fallback) |
| POST   | `/api/chat`           | Streaming LLM via Ollama             |
