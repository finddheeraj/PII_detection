import os
import json
import requests
import numpy as np
from flask import Flask, request, jsonify, render_template, Response, stream_with_context
from flask_cors import CORS
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__)
CORS(app)

# ── Ollama config (local LLM — no API key needed) ────────────────────────────
# Install Ollama from https://ollama.com, then run:
#   ollama pull llama3          ← ~4.7 GB, recommended
#   ollama pull mistral         ← ~4.1 GB, fast & capable
#   ollama pull phi3            ← ~2.2 GB, good on low-RAM machines
#   ollama pull gemma:2b        ← ~1.7 GB, lightest option
OLLAMA_BASE_URL = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434")
OLLAMA_MODEL    = os.getenv("OLLAMA_MODEL", "llama3")

# ── Lazy-loaded embedding model ───────────────────────────────────────────────
_embedding_model = None

def get_embedding_model(model_name: str = "Snowflake/snowflake-arctic-embed-xs"):
    global _embedding_model
    if _embedding_model is None:
        from sentence_transformers import SentenceTransformer
        _embedding_model = SentenceTransformer(model_name)
    return _embedding_model


# ── Routes ────────────────────────────────────────────────────────────────────
@app.route("/")
def index():
    return render_template("index.html")


# ---------- Text Splitting ----------
@app.route("/api/split", methods=["POST"])
def split_text():
    data = request.get_json()
    text       = data.get("text", "")
    strategy   = data.get("strategy", "recursive-character")
    chunk_size = int(data.get("chunk_size", 500))
    overlap    = int(data.get("overlap", 50))
    separators = data.get("separators", ["\n\n", "\n", " "])

    if not text.strip():
        return jsonify({"blocks": []})

    try:
        blocks = _do_split(text, strategy, chunk_size, overlap, separators)
        return jsonify({"blocks": blocks})
    except Exception as e:
        return jsonify({"error": str(e)}), 400


def _do_split(text: str, strategy: str, chunk_size: int, overlap: int, separators: list) -> list:
    """Pure-Python re-implementation of the LangChain splitters."""

    def character_split(text, separator, chunk_size, overlap):
        parts = text.split(separator) if separator else list(text)
        chunks, current = [], ""
        for part in parts:
            candidate = (current + separator + part) if current else part
            if len(candidate) <= chunk_size:
                current = candidate
            else:
                if current:
                    chunks.append(current)
                current = part
        if current:
            chunks.append(current)
        # Sliding overlap
        if overlap and len(chunks) > 1:
            overlapped = []
            for i, chunk in enumerate(chunks):
                if i == 0:
                    overlapped.append(chunk)
                else:
                    prev_tail = chunks[i - 1][-overlap:]
                    overlapped.append(prev_tail + chunk)
            return overlapped
        return chunks

    def recursive_split(text, seps, chunk_size, overlap):
        if not text:
            return []
        for i, sep in enumerate(seps):
            if sep == "" or sep in text:
                parts = text.split(sep) if sep else [c for c in text]
                chunks, current = [], ""
                for part in parts:
                    candidate = (current + sep + part) if current else part
                    if len(candidate) <= chunk_size:
                        current = candidate
                    else:
                        if current:
                            if len(current) > chunk_size and i + 1 < len(seps):
                                chunks.extend(recursive_split(current, seps[i+1:], chunk_size, overlap))
                            else:
                                chunks.append(current)
                        current = part
                if current:
                    if len(current) > chunk_size and i + 1 < len(seps):
                        chunks.extend(recursive_split(current, seps[i+1:], chunk_size, overlap))
                    else:
                        chunks.append(current)
                return chunks
        return [text]

    def to_blocks(chunks, source_text):
        blocks = []
        idx = 0
        for chunk in chunks:
            start = source_text.find(chunk, idx)
            if start == -1:
                start = idx
            end = start + len(chunk)
            blocks.append({"text": chunk, "startIndex": start, "endIndex": end})
            idx = max(0, start + 1)
        return blocks

    if strategy == "character":
        sep = separators[0] if separators else "\n\n"
        chunks = character_split(text, sep, chunk_size, overlap)
        return to_blocks(chunks, text)

    elif strategy == "recursive-character":
        chunks = recursive_split(text, separators, chunk_size, overlap)
        return to_blocks(chunks, text)

    elif strategy == "parent-child":
        parent_size = chunk_size * 2
        parent_chunks = recursive_split(text, separators, parent_size, 0)
        blocks = []
        p_idx = 0
        for parent_id, parent_text in enumerate(parent_chunks):
            parent_start = text.find(parent_text, p_idx)
            p_idx = max(0, parent_start + 1)
            child_chunks = recursive_split(parent_text, separators, chunk_size, overlap)
            c_idx = 0
            for child_text in child_chunks:
                rel = parent_text.find(child_text, c_idx)
                abs_start = parent_start + rel
                abs_end   = abs_start + len(child_text)
                c_idx = max(0, rel + 1)
                blocks.append({
                    "text": child_text,
                    "startIndex": abs_start,
                    "endIndex": abs_end,
                    "parentId": parent_id,
                    "parentText": parent_text,
                })
        return blocks

    else:
        raise ValueError(f"Unknown strategy: {strategy}")


# ---------- Embeddings ----------
@app.route("/api/embed", methods=["POST"])
def embed():
    data   = request.get_json()
    texts  = data.get("texts", [])
    model_name = data.get("model", "Snowflake/snowflake-arctic-embed-xs")

    if not texts:
        return jsonify({"embeddings": []})

    try:
        model = get_embedding_model(model_name)
        vecs  = model.encode(texts, normalize_embeddings=True)
        return jsonify({"embeddings": vecs.tolist()})
    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/api/similarity", methods=["POST"])
def similarity():
    data       = request.get_json()
    query_vec  = np.array(data.get("query_embedding", []))
    block_vecs = np.array(data.get("block_embeddings", []))

    if query_vec.size == 0 or block_vecs.size == 0:
        return jsonify({"similarities": []})

    scores = (block_vecs @ query_vec).tolist()
    ranked = sorted(
        [{"index": i, "score": s} for i, s in enumerate(scores)],
        key=lambda x: x["score"], reverse=True
    )
    return jsonify({"similarities": ranked})


@app.route("/api/umap", methods=["POST"])
def umap_reduce():
    data = request.get_json()
    all_vecs = np.array(data.get("embeddings", []))   # [query] + chunks

    if all_vecs.shape[0] < 2:
        return jsonify({"points": all_vecs.tolist()})

    try:
        import umap
        n_neighbors = min(15, all_vecs.shape[0] - 1)
        reducer = umap.UMAP(n_components=2, n_neighbors=n_neighbors, random_state=42)
        pts = reducer.fit_transform(all_vecs)
        return jsonify({"points": pts.tolist()})
    except ImportError:
        # Fallback: PCA via SVD
        mean = all_vecs.mean(axis=0)
        centered = all_vecs - mean
        U, S, Vt = np.linalg.svd(centered, full_matrices=False)
        pts = centered @ Vt[:2].T
        return jsonify({"points": pts.tolist()})


# ---------- Ollama health check ----------
@app.route("/api/ollama/status", methods=["GET"])
def ollama_status():
    """Check if Ollama is running and list available models."""
    try:
        res = requests.get(f"{OLLAMA_BASE_URL}/api/tags", timeout=3)
        models = [m["name"] for m in res.json().get("models", [])]
        return jsonify({"running": True, "models": models, "current": OLLAMA_MODEL})
    except Exception as e:
        return jsonify({"running": False, "error": str(e), "models": [], "current": OLLAMA_MODEL})


# ---------- Generation (streaming via Ollama) ----------
@app.route("/api/chat", methods=["POST"])
def chat():
    data        = request.get_json()
    messages    = data.get("messages", [])
    system      = data.get("system", "You are a helpful assistant.")
    temperature = float(data.get("temperature", 0.3))
    max_tokens  = int(data.get("max_tokens", 1000))
    model       = data.get("model", OLLAMA_MODEL)

    # Build Ollama chat payload
    ollama_messages = [{"role": "system", "content": system}] + messages
    payload = {
        "model":   model,
        "messages": ollama_messages,
        "stream":  True,
        "options": {
            "temperature": temperature,
            "num_predict": max_tokens,
        },
    }

    def generate():
        try:
            with requests.post(
                f"{OLLAMA_BASE_URL}/api/chat",
                json=payload,
                stream=True,
                timeout=120,
            ) as resp:
                if resp.status_code != 200:
                    err = resp.text[:300]
                    yield f"data: {json.dumps({'error': f'Ollama error {resp.status_code}: {err}'})}\n\n"
                    return
                for line in resp.iter_lines():
                    if not line:
                        continue
                    try:
                        obj   = json.loads(line)
                        delta = obj.get("message", {}).get("content", "")
                        if delta:
                            yield f"data: {json.dumps({'content': delta})}\n\n"
                        if obj.get("done"):
                            break
                    except json.JSONDecodeError:
                        continue
            yield "data: [DONE]\n\n"
        except requests.exceptions.ConnectionError:
            yield f"data: {json.dumps({'error': 'Cannot connect to Ollama. Is it running? Run: ollama serve'})}\n\n"
        except Exception as e:
            yield f"data: {json.dumps({'error': str(e)})}\n\n"

    return Response(stream_with_context(generate()),
                    mimetype="text/event-stream",
                    headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


if __name__ == "__main__":
    app.run(debug=True, port=5000)
