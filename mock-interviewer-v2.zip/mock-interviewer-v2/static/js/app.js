/* static/js/app.js
   ─────────────────────────────────────────────────────────────────────────────
   Client-side logic for MockMind, split into four clear responsibilities:

     1. State        — simple JS variables that track what's happening
     2. UI helpers   — tiny functions that touch the DOM (toast, status, etc.)
     3. Chat         — functions that render messages & the coach panel
     4. API calls    — async functions that talk to the Flask backend
     5. Wiring       — event listeners that connect UI events to the above
   ─────────────────────────────────────────────────────────────────────────────
*/

/* ── 1. State ─────────────────────────────────────────────────────────────── */

let interviewActive = false;   // true once the interview has started
let roundCount      = 0;       // tracks how many answers have been submitted


/* ── 2. UI helpers ────────────────────────────────────────────────────────── */

/** Update the status indicator in the header. */
function setStatus(text, live = false) {
  document.getElementById("status-text").textContent = text;
  document.getElementById("status-dot").className    = "status-dot" + (live ? " live" : "");
}

/** Show a temporary error/info toast in the bottom-right corner. */
function showToast(msg) {
  const t = document.getElementById("toast");
  t.textContent = msg;
  t.classList.add("show");
  setTimeout(() => t.classList.remove("show"), 3000);
}

/** Keep the character counter below the textarea up to date. */
function updateCharCount(el) {
  document.getElementById("char-count").textContent = el.value.length + " chars";
}

/** Prevent XSS — escape user/AI text before injecting into innerHTML. */
function escapeHtml(text) {
  return text
    .replace(/&/g,  "&amp;")
    .replace(/</g,  "&lt;")
    .replace(/>/g,  "&gt;")
    .replace(/"/g,  "&quot;")
    .replace(/\n/g, "<br>");
}

/** Lock/unlock the answer form while a request is in flight. */
function setAnswerFormLocked(locked) {
  const btn     = document.getElementById("btn-submit");
  const spinner = document.getElementById("submit-spinner");
  const input   = document.getElementById("answer-input");

  btn.disabled           = locked;
  input.disabled         = locked;
  spinner.style.display  = locked ? "block" : "none";
}


/* ── 3. Chat rendering ────────────────────────────────────────────────────── */

/**
 * Append a message bubble to the chat area.
 * @param {"recruiter"|"candidate"} role
 * @param {string} text
 */
function addMessage(role, text) {
  const chatArea = document.getElementById("chat-area");
  const empty    = document.getElementById("chat-empty");
  if (empty) empty.remove();      // Remove the placeholder on first message

  const isRecruiter = role === "recruiter";

  const div = document.createElement("div");
  div.className = "message";
  div.innerHTML = `
    <div class="msg-avatar ${isRecruiter ? "recruiter" : "candidate"}">
      ${isRecruiter ? "🎯" : "👤"}
    </div>
    <div class="msg-body">
      <div class="msg-label ${isRecruiter ? "recruiter" : "candidate"}">
        ${isRecruiter ? "Interviewer" : "You"}
      </div>
      <div class="msg-text">${escapeHtml(text)}</div>
    </div>
  `;
  chatArea.appendChild(div);
  chatArea.scrollTop = chatArea.scrollHeight;
}

/** Show animated dots while waiting for the recruiter's reply. */
function addTypingIndicator() {
  const chatArea = document.getElementById("chat-area");
  const div      = document.createElement("div");
  div.className  = "message";
  div.id         = "typing";
  div.innerHTML  = `
    <div class="msg-avatar recruiter">🎯</div>
    <div class="msg-body">
      <div class="msg-label recruiter">Interviewer</div>
      <div class="typing-indicator"><span></span><span></span><span></span></div>
    </div>
  `;
  chatArea.appendChild(div);
  chatArea.scrollTop = chatArea.scrollHeight;
}

function removeTypingIndicator() {
  const t = document.getElementById("typing");
  if (t) t.remove();
}

/**
 * Prepend a new coach feedback card to the coach panel.
 * Cards are prepended (newest on top) so you always see the latest.
 * @param {string} text
 */
function addCoachFeedback(text) {
  roundCount++;

  // Hide the "watching silently" placeholder
  const empty = document.getElementById("coach-empty");
  if (empty) empty.style.display = "none";

  const entries = document.getElementById("coach-entries");
  entries.style.display = "flex";

  const div       = document.createElement("div");
  div.className   = "coach-entry";
  div.innerHTML   = `
    <div class="coach-entry-round">Round ${roundCount}</div>
    <div class="coach-entry-text">${escapeHtml(text)}</div>
  `;
  entries.insertBefore(div, entries.firstChild);  // newest on top
}


/* ── 4. API calls ─────────────────────────────────────────────────────────── */

/**
 * POST /start — initialise a session and get the opening question.
 * Switches from the setup panel to the interview panel on success.
 */
async function startInterview() {
  const topic      = document.getElementById("topic-select").value;
  const difficulty = document.getElementById("difficulty-select").value;

  const btnStart   = document.getElementById("btn-start");
  btnStart.disabled    = true;
  btnStart.textContent = "Connecting…";
  setStatus("Connecting…");

  try {
    const res  = await fetch("/start", {
      method:  "POST",
      headers: { "Content-Type": "application/json" },
      body:    JSON.stringify({ topic, difficulty }),
    });
    const data = await res.json();

    if (data.error) {
      showToast(data.error);
      return;
    }

    // ── Switch to interview view ──────────────────────────────────────────
    document.getElementById("setup-panel").style.display = "none";
    document.getElementById("chip-topic").textContent    = topic;
    document.getElementById("chip-level").textContent    = difficulty;
    document.getElementById("interview-panel").classList.add("active");

    interviewActive = true;
    setStatus("Live Interview", true);
    addMessage("recruiter", data.recruiter_message);

  } catch {
    showToast("Connection failed. Check your API key.");
    btnStart.disabled    = false;
    btnStart.textContent = "Start Interview →";
    setStatus("Error");
  }
}

/**
 * POST /answer — submit the candidate's answer to both agents.
 * Displays the recruiter's follow-up + coach feedback on success.
 */
async function submitAnswer() {
  const input  = document.getElementById("answer-input");
  const answer = input.value.trim();

  if (!answer) {
    showToast("Please write an answer first.");
    return;
  }

  setAnswerFormLocked(true);
  addMessage("candidate", answer);

  // Clear the textarea
  input.value = "";
  document.getElementById("char-count").textContent = "0 chars";

  addTypingIndicator();

  try {
    const res  = await fetch("/answer", {
      method:  "POST",
      headers: { "Content-Type": "application/json" },
      body:    JSON.stringify({ answer }),
    });
    const data = await res.json();

    removeTypingIndicator();

    if (data.error) {
      showToast(data.error);
      return;
    }

    addMessage("recruiter", data.recruiter_message);

    if (data.coach_feedback) {
      addCoachFeedback(data.coach_feedback);
    }

  } catch {
    removeTypingIndicator();
    showToast("Something went wrong. Try again.");
  } finally {
    setAnswerFormLocked(false);
    input.focus();
  }
}

/**
 * POST /reset — clear session and return to the setup screen.
 */
function resetInterview() {
  if (!confirm("End this session and start over?")) return;

  fetch("/reset", { method: "POST" }).finally(() => {
    interviewActive = false;
    roundCount      = 0;

    // Reset interview panel contents
    document.getElementById("interview-panel").classList.remove("active");
    document.getElementById("chat-area").innerHTML = `
      <div class="chat-empty" id="chat-empty">
        <div class="chat-empty-icon">💼</div>
        <span>Interview starting…</span>
      </div>
    `;
    document.getElementById("coach-entries").innerHTML  = "";
    document.getElementById("coach-entries").style.display = "none";
    document.getElementById("coach-empty").style.display   = "flex";

    // Show setup panel
    document.getElementById("setup-panel").style.display = "flex";

    // Reset start button
    const btnStart       = document.getElementById("btn-start");
    btnStart.disabled    = false;
    btnStart.textContent = "Start Interview →";

    setStatus("Ready");
  });
}


/* ── 5. Wiring ────────────────────────────────────────────────────────────── */

// Ctrl+Enter submits the answer (faster than clicking the button)
document.addEventListener("keydown", (e) => {
  if ((e.ctrlKey || e.metaKey) && e.key === "Enter" && interviewActive) {
    submitAnswer();
  }
});
