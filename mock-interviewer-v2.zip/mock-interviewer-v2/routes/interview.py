"""
routes/interview.py — Interview API Routes
-------------------------------------------
Three endpoints that power the interview session:

  POST /start   — Kick off a new session; Agent A asks the first question.
  POST /answer  — Candidate submits an answer; both agents respond.
  POST /reset   — Clear the session.

Session state stored in Flask's signed cookie session:
  session["topic"]      — chosen topic string
  session["difficulty"] — chosen difficulty string
  session["history"]    — list of {"role", "content"} message dicts
"""

from flask import Blueprint, request, jsonify, session
from agents.recruiter import ask_opening_question, ask_followup
from agents.coach import get_feedback
from llm_client import get_client

interview_bp = Blueprint("interview", __name__)


@interview_bp.route("/start", methods=["POST"])
def start_interview():
    """
    Initialise the session and get Agent A's opening question.
    Expected JSON body: { "topic": "...", "difficulty": "..." }
    """
    data       = request.json
    topic      = data.get("topic", "System Design")
    difficulty = data.get("difficulty", "Mid-Level")

    # Persist settings for this session
    session["topic"]      = topic
    session["difficulty"] = difficulty
    session["history"]    = []

    client        = get_client()
    opening_question = ask_opening_question(client, topic, difficulty)

    # Seed history with the recruiter's first message
    session["history"] = [{"role": "assistant", "content": opening_question}]

    return jsonify({
        "recruiter_message": opening_question,
        "coach_feedback":    None,   # No feedback yet — candidate hasn't answered
    })


@interview_bp.route("/answer", methods=["POST"])
def submit_answer():
    """
    Process a candidate's answer using both agents:
      1. Agent A (Recruiter) — drills into the answer with a follow-up
      2. Agent B (Coach)     — privately coaches the candidate on their response

    Expected JSON body: { "answer": "..." }
    """
    data             = request.json
    candidate_answer = data.get("answer", "").strip()

    if not candidate_answer:
        return jsonify({"error": "Answer cannot be empty"}), 400

    # Read session state
    topic      = session.get("topic",      "System Design")
    difficulty = session.get("difficulty", "Mid-Level")
    history    = session.get("history",    [])

    client = get_client()

    # ── Agent A: follow-up question ──────────────────────────────────────────
    recruiter_reply = ask_followup(client, topic, difficulty, history, candidate_answer)

    # ── Agent B: silent coaching ─────────────────────────────────────────────
    coach_reply = get_feedback(client, topic, difficulty, history, candidate_answer)

    # ── Update history ───────────────────────────────────────────────────────
    # Append this exchange so future turns have full context
    history.append({"role": "user",      "content": candidate_answer})
    history.append({"role": "assistant", "content": recruiter_reply})
    session["history"] = history

    return jsonify({
        "recruiter_message": recruiter_reply,
        "coach_feedback":    coach_reply,
    })


@interview_bp.route("/reset", methods=["POST"])
def reset_session():
    """Clear the session so the user can start a fresh interview."""
    session.clear()
    return jsonify({"status": "ok"})
