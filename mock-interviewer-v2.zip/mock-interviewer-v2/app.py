"""
app.py — Entry point
--------------------
Creates the Flask app and registers all route blueprints.
Run this file to start the server.
"""

import os
from flask import Flask
from routes.interview import interview_bp
from routes.pages import pages_bp


def create_app():
    app = Flask(__name__)
    app.secret_key = os.environ.get("SECRET_KEY", "mock-interviewer-secret-2024")

    # Register route blueprints
    app.register_blueprint(pages_bp)
    app.register_blueprint(interview_bp)

    return app


app = create_app()

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port, debug=False)
