# agents/__init__.py
# Makes `agents` a Python package.
# Import the two agent functions for convenience:
from agents.recruiter import ask_opening_question, ask_followup
from agents.coach import get_feedback
