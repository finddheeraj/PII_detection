"""
agents/coach.py — Agent B: The Coach
--------------------------------------
An invisible observer that watches the interview and gives the
candidate private real-time feedback after every answer.

Key design choices:
  - The coach NEVER speaks to the recruiter
  - It receives the full conversation transcript as context
  - It outputs short, bullet-pointed coaching notes only for the candidate
"""

from config import MODEL, COACH_MAX_TOKENS, COACH_TEMPERATURE

# System prompt — sets the coach's persona and output format
SYSTEM_PROMPT = """You are a silent, invisible interview coach observing a live mock interview.
Your ONLY job: give the candidate brief, punchy real-time coaching after each of their responses.

Rules:
1. Be brutally honest but constructive. Max 3 bullet points.
2. Flag: rambling, vagueness, missing keywords, missed opportunities, strong points.
3. Use short, direct language. Like a coach whispering in their ear.
4. Format: always use bullet points starting with an emoji (✅ for good, ⚠️ for warning, 💡 for tip).
5. Never address the recruiter. Only coach the candidate.
6. If the answer is strong, say so briefly + suggest what to add.

Topic: {topic}
Difficulty Level: {difficulty}
"""


def build_system_prompt(topic: str, difficulty: str) -> str:
    return SYSTEM_PROMPT.format(topic=topic, difficulty=difficulty)


def build_transcript(history: list, latest_answer: str) -> str:
    """
    Converts the session history + the new answer into a readable
    transcript string the coach can analyse.

    history format: [{"role": "assistant"|"user", "content": "..."}]
    """
    lines = []
    for msg in history:
        speaker = "INTERVIEWER" if msg["role"] == "assistant" else "CANDIDATE"
        lines.append(f"{speaker}: {msg['content']}")

    lines.append(f"CANDIDATE (latest): {latest_answer}")
    return "\n\n".join(lines)


def get_feedback(client, topic: str, difficulty: str, history: list, candidate_answer: str) -> str:
    """
    Called after every candidate answer — in parallel with the recruiter's follow-up.
    Returns coaching feedback as a plain string (bullet points with emojis).

    Args:
        client:           xAI OpenAI-compatible client
        topic:            interview topic
        difficulty:       difficulty level
        history:          previous conversation turns
        candidate_answer: the candidate's latest answer

    Returns:
        Coach feedback as a plain string.
    """
    system     = build_system_prompt(topic, difficulty)
    transcript = build_transcript(history, candidate_answer)

    response = client.chat.completions.create(
        model=MODEL,
        messages=[
            {"role": "system", "content": system},
            {
                "role": "user",
                "content": (
                    f"Here is the interview so far:\n\n{transcript}\n\n"
                    "Give coaching feedback on the candidate's latest answer."
                ),
            },
        ],
        max_tokens=COACH_MAX_TOKENS,
        temperature=COACH_TEMPERATURE,
    )

    return response.choices[0].message.content
