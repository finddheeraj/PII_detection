"""
agents/recruiter.py — Agent A: The Recruiter
---------------------------------------------
Plays a strict technical interviewer from a top-tier company.
Responsibilities:
  - Ask the opening question based on topic + difficulty
  - Receive candidate answers and drill into specifics
  - Maintain conversation history across turns
"""

from config import MODEL, RECRUITER_MAX_TOKENS, RECRUITER_TEMPERATURE

# System prompt template — injected with topic and difficulty at runtime
SYSTEM_PROMPT = """You are a strict, sharp technical interviewer from a top-tier tech company (think Google, Meta, Amazon).
Your persona: direct, professional, slightly intense — you probe deeply.

Rules:
1. Ask ONE question at a time. Never ask multiple questions in one turn.
2. After the candidate answers, drill into specifics: ask follow-ups about trade-offs, edge cases, real numbers, or implementation details.
3. Never give hints or confirm correctness. Stay neutral and probe harder.
4. Keep your messages concise — max 3 sentences.
5. Start by greeting briefly and asking your first question on the given topic and difficulty.
6. Do NOT reveal you are an AI. Stay fully in character.

Topic: {topic}
Difficulty Level: {difficulty}
"""


def build_system_prompt(topic: str, difficulty: str) -> str:
    """Fill the system prompt template with the chosen topic and difficulty."""
    return SYSTEM_PROMPT.format(topic=topic, difficulty=difficulty)


def ask_opening_question(client, topic: str, difficulty: str) -> str:
    """
    Called once at the start of an interview session.
    Returns the recruiter's first question as a plain string.
    """
    system = build_system_prompt(topic, difficulty)

    response = client.chat.completions.create(
        model=MODEL,
        messages=[
            {"role": "system", "content": system},
            {"role": "user",   "content": "Start the interview now."},
        ],
        max_tokens=RECRUITER_MAX_TOKENS,
        temperature=RECRUITER_TEMPERATURE,
    )

    return response.choices[0].message.content


def ask_followup(client, topic: str, difficulty: str, history: list, candidate_answer: str) -> str:
    """
    Called after every candidate answer.
    Builds the full message chain and returns the recruiter's follow-up question.

    Args:
        client:           xAI OpenAI-compatible client
        topic:            interview topic (e.g. "System Design")
        difficulty:       difficulty level (e.g. "Senior")
        history:          list of previous {"role", "content"} dicts
        candidate_answer: the latest answer typed by the user

    Returns:
        Recruiter's next question as a plain string.
    """
    system = build_system_prompt(topic, difficulty)

    messages = (
        [{"role": "system", "content": system}]
        + history
        + [{"role": "user", "content": candidate_answer}]
    )

    response = client.chat.completions.create(
        model=MODEL,
        messages=messages,
        max_tokens=RECRUITER_MAX_TOKENS,
        temperature=RECRUITER_TEMPERATURE,
    )

    return response.choices[0].message.content
