"""
llm_client.py — LLM Client Factory
-------------------------------------
Single place to create and configure the xAI / Grok API client.
Both agents import from here so the base URL and key are never duplicated.
"""

from openai import OpenAI
from config import XAI_API_KEY, XAI_BASE_URL


def get_client() -> OpenAI:
    """
    Returns a configured OpenAI-compatible client pointed at xAI's API.
    Called fresh per request (stateless — no connection pooling needed at this scale).
    """
    return OpenAI(
        api_key=XAI_API_KEY,
        base_url=XAI_BASE_URL,
    )
