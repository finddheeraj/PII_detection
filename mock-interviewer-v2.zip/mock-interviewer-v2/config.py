"""
config.py — App Configuration
------------------------------
All constants, environment variables, and static data live here.
Change topics/difficulties/model settings without touching logic files.
"""

import os

# ── LLM ──────────────────────────────────────────────────────────────────────

XAI_API_KEY  = os.environ.get("XAI_API_KEY", "")
XAI_BASE_URL = "https://api.x.ai/v1"
MODEL        = "grok-3"

RECRUITER_MAX_TOKENS = 300
COACH_MAX_TOKENS     = 250
RECRUITER_TEMPERATURE = 0.7
COACH_TEMPERATURE     = 0.6

# ── Interview options ─────────────────────────────────────────────────────────

TOPICS = [
    "System Design",
    "Data Structures & Algorithms",
    "Behavioral / Leadership",
    "Python",
    "JavaScript / Frontend",
    "Machine Learning / AI",
    "Databases & SQL",
    "DevOps & CI/CD",
    "Cloud (AWS / GCP / Azure)",
    "Object-Oriented Programming",
    "APIs & REST",
    "Security & Authentication",
]

DIFFICULTIES = ["Junior", "Mid-Level", "Senior", "Staff / Principal"]
