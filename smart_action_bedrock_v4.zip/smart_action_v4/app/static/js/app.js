/**
 * app.js — PRISM Smart Action List v4
 * Single textarea — paste transcript or summary, LLM auto-detects.
 * No log panel in UI (logs go to CLI via Flask/Python logger).
 */
"use strict";

/* ═══════════════════════════════════════
   API CLIENT
   ═══════════════════════════════════════ */
const ApiClient = (() => {
  async function _req(method, path, body) {
    const opts = { method, headers: { "Content-Type": "application/json" } };
    if (body !== undefined) opts.body = JSON.stringify(body);
    const res  = await fetch(path, opts);
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);
    return data;
  }
  return {
    health:    ()                                  => _req("GET",   "/api/health"),
    analyse:   (content, meetingRef)               => _req("POST",  "/api/transcript/analyse",
                                                       { content, meeting_ref: meetingRef }),
    confirm:   (extracted, edits, meetingRef)      => _req("POST",  "/api/actions/confirm",
                                                       { extracted, edits, meeting_ref: meetingRef }),
    getActions:(status, priority)                  => _req("GET",
                                                       `/api/actions?status=${status}&priority=${priority}`),
    setStatus: (id, status)                        => _req("PATCH", `/api/actions/${id}/status`, { status }),
  };
})();

/* ═══════════════════════════════════════
   HELPERS
   ═══════════════════════════════════════ */
const esc  = s => String(s||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
const escA = s => String(s||"").replace(/"/g,"&quot;");
const fmtDate = d => {
  if (!d) return "TBD";
  try { return new Date(d).toLocaleDateString("en-GB",{day:"numeric",month:"short",year:"numeric"}); }
  catch { return d; }
};
const $ = id => document.getElementById(id);

/* ═══════════════════════════════════════
   PIPELINE
   ═══════════════════════════════════════ */
function setPipe(step) {
  [1,2,3,4].forEach(n => {
    const el = $(`ps${n}`);
    el.classList.remove("active","done");
    if (n < step)  el.classList.add("done");
    if (n === step) el.classList.add("active");
  });
}

/* ═══════════════════════════════════════
   REVIEW CARD RENDERER
   ═══════════════════════════════════════ */
function reviewCardHtml(a, i) {
  const dupHtml   = a.is_duplicate
    ? `<div class="dup-warn">&#9888; Possible duplicate of an existing action</div>` : "";
  const quoteHtml = a.source_quote
    ? `<div class="arc-quote">"${esc(a.source_quote)}"</div>` : "";

  return `
  <div class="arc" id="arc-${i}">
    <div class="arc-head">
      <div class="arc-title-wrap">
        <div class="arc-title">${esc(a.title)}</div>
        <div class="arc-client">${esc(a.client)} &middot; ${esc(a.category)}</div>
      </div>
      <span class="pri ${a.priority}">${a.priority}</span>
    </div>
    ${quoteHtml}
    ${dupHtml}
    <div class="arc-fields">
      <div class="arc-field" style="grid-column:span 2">
        <label>Task title</label>
        <input type="text" id="arc-title-${i}" value="${escA(a.title)}"/>
      </div>
      <div class="arc-field">
        <label>Client</label>
        <input type="text" id="arc-client-${i}" value="${escA(a.client)}"/>
      </div>
      <div class="arc-field">
        <label>Due date</label>
        <input type="date" id="arc-due-${i}" value="${a.due_date||""}"/>
      </div>
      <div class="arc-field">
        <label>Priority</label>
        <select id="arc-pri-${i}">
          ${["High","Medium","Low"].map(v=>`<option ${v===a.priority?"selected":""}>${v}</option>`).join("")}
        </select>
      </div>
      <div class="arc-field">
        <label>Category</label>
        <select id="arc-cat-${i}">
          ${["Risk & Control","Commercial","Relationship","Personal"].map(v=>
            `<option ${v===a.category?"selected":""}>${v}</option>`).join("")}
        </select>
      </div>
    </div>
    <div class="arc-btns">
      <button class="btn btn-confirm btn-sm" onclick="App.confirmOne(${i})">Confirm &amp; add</button>
      <button class="btn btn-reject  btn-sm" onclick="App.rejectOne(${i})">Reject</button>
    </div>
  </div>`;
}

/* ═══════════════════════════════════════
   ACTION LIST RENDERER
   ═══════════════════════════════════════ */
function renderActionList(actions) {
  const box = $("action-list");
  $("list-count").textContent = `${actions.length} action(s)`;

  if (!actions.length) {
    box.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">
          <svg viewBox="0 0 64 64" width="48" height="48" fill="none">
            <rect x="10" y="8" width="44" height="48" rx="4" stroke="#cbd5e1" stroke-width="2.5"/>
            <path d="M20 22h24M20 30h24M20 38h16" stroke="#cbd5e1" stroke-width="2.5" stroke-linecap="round"/>
          </svg>
        </div>
        <p class="empty-msg">No confirmed actions yet.</p>
        <p class="empty-hint">Paste a meeting transcript or summary and click Extract actions.</p>
      </div>`;
    return;
  }

  box.innerHTML = actions.map(a => `
    <div class="a-tile">
      <div class="a-bar ${a.priority}"></div>
      <div class="a-body">
        <div class="a-name">${esc(a.title)}</div>
        <div class="a-meta">
          <span>${esc(a.client)}</span>
          <span>Due: ${fmtDate(a.due_date)}</span>
          <span>${esc(a.category)}</span>
          ${a.is_duplicate ? `<span class="dup-badge">Duplicate</span>` : ""}
        </div>
      </div>
      <div class="a-actions">
        <span class="pri ${a.priority}">${a.priority}</span>
        <select class="status-sel" onchange="App.setStatus('${a.id}',this.value)">
          ${["not_started","started","done"].map(s=>
            `<option value="${s}" ${s===a.status?"selected":""}>${s.replace("_"," ")}</option>`).join("")}
        </select>
      </div>
    </div>`).join("");
}

/* ═══════════════════════════════════════
   APP CONTROLLER
   ═══════════════════════════════════════ */
const App = (() => {
  let _actions = [];
  let _states  = {};
  let _ref     = null;

  const SAMPLE = `Meeting: Portfolio Review - Harrington Family Office
Date: 20 March 2026
Attendees: James Whitfield (Banker), Sarah Harrington (Client), Tom Harrington (Co-trustee)

James: Good morning Sarah, Tom. Your structured product matures on April 15th — we need to decide on reinvestment by next Friday.

Sarah: Yes, we'd like to roll into something similar. Can you send us a proposal?

James: Absolutely, I'll prepare a structured product proposal by end of this week.

Tom: Also, the bespoke lending rate review is coming up.

James: Correct — it expires April 1st. I'll raise a renewal request with the credit team today.

Sarah: We haven't received the Q4 performance report yet.

James: Apologies — I'll get that over to both of you by tomorrow morning.

Tom: We'd like a follow-up call in two weeks to review reinvestment options.

James: Confirmed. I'll send a calendar invite for around April 3rd.`;

  async function _refreshList() {
    const status   = $("filter-status")?.value   || "";
    const priority = $("filter-priority")?.value || "";
    try {
      const res = await ApiClient.getActions(status, priority);
      renderActionList(res.actions || []);
    } catch(err) { console.error("List refresh failed:", err); }
  }

  async function init() {
    // Health check
    try {
      const h = await ApiClient.health();
      $("model-dot").className      = "status-dot " + (h.model_loaded ? "ok" : "err");
      $("model-status-text").textContent = h.model_loaded
        ? "Bedrock model ready"
        : `Model not loaded · ${h.model_path}`;
    } catch {
      $("model-dot").className      = "status-dot err";
      $("model-status-text").textContent = "Model unreachable";
    }

    // Events
    $("content-input").addEventListener("input", () => {
      const n = $("content-input").value.length;
      $("char-count").textContent = `${n.toLocaleString()} characters`;
    });
    $("load-sample-btn").addEventListener("click", () => {
      $("content-input").value = SAMPLE;
      $("meeting-ref").value   = "Harrington Portfolio Review 2026-03-20";
      $("char-count").textContent = `${SAMPLE.length.toLocaleString()} characters`;
    });
    $("analyse-btn").addEventListener("click",    analyse);
    $("confirm-all-btn").addEventListener("click", confirmAll);
    $("reject-all-btn").addEventListener("click",  rejectAll);
    $("filter-status").addEventListener("change",  _refreshList);
    $("filter-priority").addEventListener("change",_refreshList);

    setPipe(1);
    await _refreshList();
  }

  async function analyse() {
    const content = $("content-input").value.trim();
    if (!content) { alert("Please paste meeting content first."); return; }

    _ref     = $("meeting-ref").value.trim() || null;
    _actions = [];
    _states  = {};

    // Button → loading state
    const btn = $("analyse-btn");
    btn.disabled  = true;
    btn.innerHTML = `<span class="spinner"></span> Extracting actions...`;

    $("card-review").style.display = "none";
    setPipe(2);

    try {
      const res = await ApiClient.analyse(content, _ref);
      // Warnings go to console only — not shown in UI
      if (res.warnings?.length) console.warn("Agent warnings:", res.warnings);

      _actions = res.actions || [];
      _actions.forEach((_,i) => _states[i] = "pending");

      // Show review panel
      $("review-meta").textContent = `${_actions.length} action(s) detected`;
      $("review-container").innerHTML =
        `<div class="review-list">${_actions.map((a,i) => reviewCardHtml(a,i)).join("")}</div>`;
      $("card-review").style.display = "block";
      setPipe(3);

    } catch(err) {
      alert(`Extraction failed: ${err.message}`);
      console.error("Analyse error:", err);
      setPipe(1);
    } finally {
      btn.disabled  = false;
      btn.innerHTML = `<svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor">
        <path d="M6.5 1a5.5 5.5 0 104.383 8.823l3.147 3.147a.75.75 0 001.06-1.06l-3.147-3.147A5.5 5.5 0 006.5 1zm-4 5.5a4 4 0 118 0 4 4 0 01-8 0z"/>
      </svg>Extract actions`;
    }
  }

  async function confirmOne(i) {
    if (_states[i] !== "pending") return;
    const extracted = _actions[i];
    const edits = {
      title:    $(`arc-title-${i}`)?.value,
      client:   $(`arc-client-${i}`)?.value,
      due_date: $(`arc-due-${i}`)?.value,
      priority: $(`arc-pri-${i}`)?.value,
      category: $(`arc-cat-${i}`)?.value,
    };
    try {
      await ApiClient.confirm(extracted, edits, _ref);
      _states[i] = "confirmed";
      const card = $(`arc-${i}`);
      card.className = "arc confirmed";
      card.querySelector(".arc-btns").innerHTML =
        `<span style="font-size:11px;color:var(--green);font-weight:600">&#10003; Added to Smart Action List</span>`;
      setPipe(4);
      await _refreshList();
    } catch(err) {
      alert(`Could not confirm: ${err.message}`);
    }
  }

  function rejectOne(i) {
    if (_states[i] !== "pending") return;
    _states[i] = "rejected";
    const card = $(`arc-${i}`);
    card.className = "arc rejected";
    card.querySelector(".arc-btns").innerHTML =
      `<span style="font-size:11px;color:var(--text-3)">Rejected</span>`;
  }

  async function confirmAll() {
    for (const [i,s] of Object.entries(_states))
      if (s === "pending") await confirmOne(Number(i));
  }

  function rejectAll() {
    Object.keys(_states).forEach(i => { if (_states[i]==="pending") rejectOne(Number(i)); });
  }

  async function setStatus(id, status) {
    try { await ApiClient.setStatus(id, status); await _refreshList(); }
    catch(err) { alert(`Status update failed: ${err.message}`); }
  }

  return { init, confirmOne, rejectOne, confirmAll, rejectAll, setStatus };
})();

document.addEventListener("DOMContentLoaded", () => App.init());
