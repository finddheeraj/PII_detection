"""
routes/transcript.py
--------------------
POST /api/transcript/analyse
  -> Accepts any meeting text (transcript or summary).
     LLM auto-detects format and extracts actions.
"""

from __future__ import annotations
import logging

from flask import Blueprint, request, jsonify
from pydantic import ValidationError

from app.models.schemas import MeetingInputRequest
from app.agents.followup_agent import run_agent

logger = logging.getLogger(__name__)

transcript_bp = Blueprint("transcript", __name__, url_prefix="/api/transcript")


@transcript_bp.post("/analyse")
def analyse_transcript():
    """
    Request body:
        { "content": "...", "meeting_ref": "optional" }
    """
    try:
        body = MeetingInputRequest(**request.get_json(force=True))
    except (ValidationError, TypeError) as e:
        return jsonify({"error": "Invalid request", "detail": str(e)}), 400

    logger.info(f"Analysing meeting content ({len(body.content)} chars), ref={body.meeting_ref}")

    result = run_agent(content=body.content, meeting_ref=body.meeting_ref)
    return jsonify(result.model_dump()), 200
