"""
services/action_service.py — PRISM Smart Action List v4
In-memory store for POC.
"""

from __future__ import annotations
import uuid
import logging
from datetime import datetime, timezone
from typing import Optional

from app.models.schemas import (
    ConfirmedAction, ExtractedAction, ActionState,
    ActionStatus, ConfirmRequest
)

logger = logging.getLogger(__name__)


class ActionService:

    def __init__(self):
        self._store: dict[str, ConfirmedAction] = {}

    def confirm_action(
        self,
        extracted:    ExtractedAction,
        edits:        Optional[ConfirmRequest] = None,
        meeting_ref:  Optional[str] = None,
        duplicate_of: Optional[str] = None,
    ) -> ConfirmedAction:
        data = extracted.model_dump()
        if edits:
            for field, value in edits.model_dump(exclude_none=True).items():
                if field in data and value is not None:
                    data[field] = value

        action = ConfirmedAction(
            **data,
            id=str(uuid.uuid4()),
            state=ActionState.CONFIRMED,
            status=ActionStatus.NOT_STARTED,
            confirmed_at=datetime.now(timezone.utc).isoformat(),
            meeting_ref=meeting_ref or (edits.meeting_ref if edits else None),
            is_duplicate=duplicate_of is not None,
            duplicate_of=duplicate_of,
        )
        self._store[action.id] = action
        logger.info(f"Action confirmed: [{action.id}] {action.title}")
        return action

    def update_status(self, action_id: str, status: ActionStatus) -> ConfirmedAction:
        action = self._get_or_raise(action_id)
        action.status = status
        return action

    def delete_action(self, action_id: str) -> None:
        if action_id not in self._store:
            raise KeyError(f"Action {action_id} not found.")
        del self._store[action_id]

    def get_all(
        self,
        status_filter:   Optional[ActionStatus] = None,
        priority_filter: Optional[str] = None,
    ) -> list[ConfirmedAction]:
        actions = [a for a in self._store.values() if a.state == ActionState.CONFIRMED]
        if status_filter:
            actions = [a for a in actions if a.status == status_filter]
        if priority_filter:
            actions = [a for a in actions if a.priority.value == priority_filter]
        actions.sort(key=lambda a: (
            0 if a.priority.value == "High" else 1 if a.priority.value == "Medium" else 2,
            a.due_date or "9999-99-99"
        ))
        return actions

    def exists_similar(self, title: str, client: str) -> Optional[str]:
        title_lower  = title.lower().strip()
        client_lower = client.lower().strip()
        for action in self._store.values():
            if (action.state == ActionState.CONFIRMED
                    and action.client.lower().strip() == client_lower
                    and self._title_similar(action.title.lower(), title_lower)):
                return action.id
        return None

    def _get_or_raise(self, action_id: str) -> ConfirmedAction:
        if action_id not in self._store:
            raise KeyError(f"Action {action_id} not found.")
        return self._store[action_id]

    @staticmethod
    def _title_similar(a: str, b: str) -> bool:
        words_a = set(a.split())
        words_b = set(b.split())
        if not words_a or not words_b:
            return False
        overlap = words_a & words_b
        return len(overlap) / max(len(words_a), len(words_b)) >= 0.5


action_service = ActionService()
