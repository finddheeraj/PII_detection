"""
models/schemas.py — PRISM Smart Action List v4
Single input mode — LLM auto-detects transcript vs summary.
"""

from __future__ import annotations
from datetime import date
from enum import Enum
from typing import Optional
from pydantic import BaseModel, Field, field_validator


class Priority(str, Enum):
    HIGH   = "High"
    MEDIUM = "Medium"
    LOW    = "Low"


class Category(str, Enum):
    RISK_CONTROL = "Risk & Control"
    COMMERCIAL   = "Commercial"
    RELATIONSHIP = "Relationship"
    PERSONAL     = "Personal"


class ActionStatus(str, Enum):
    NOT_STARTED = "not_started"
    STARTED     = "started"
    DONE        = "done"
    SNOOZED     = "snoozed"


class ActionState(str, Enum):
    PENDING   = "pending"
    CONFIRMED = "confirmed"
    REJECTED  = "rejected"


class ExtractedAction(BaseModel):
    title:        str           = Field(..., max_length=120)
    description:  str           = Field(..., max_length=500)
    client:       str           = Field(..., max_length=100)
    due_date:     Optional[str] = Field(None, description="YYYY-MM-DD")
    priority:     Priority      = Priority.MEDIUM
    category:     Category      = Category.RELATIONSHIP
    source_quote: str           = Field("", description="Relevant phrase from input")

    @field_validator("due_date", mode="before")
    @classmethod
    def validate_date(cls, v):
        if not v:
            return None
        try:
            date.fromisoformat(str(v))
            return str(v)
        except ValueError:
            return None


class ConfirmedAction(ExtractedAction):
    id:           str
    state:        ActionState  = ActionState.CONFIRMED
    status:       ActionStatus = ActionStatus.NOT_STARTED
    confirmed_at: Optional[str] = None
    meeting_ref:  Optional[str] = None
    is_duplicate: bool          = False
    duplicate_of: Optional[str] = None


class MeetingInputRequest(BaseModel):
    content:     str           = Field(..., min_length=50, max_length=20_000)
    meeting_ref: Optional[str] = Field(None)


class ExtractionResult(BaseModel):
    actions:    list[ExtractedAction]
    agent_log:  list[str] = Field(default_factory=list)
    warnings:   list[str] = Field(default_factory=list)
    model_used: str       = "bedrock"


class ConfirmRequest(BaseModel):
    title:       Optional[str]      = None
    due_date:    Optional[str]      = None
    client:      Optional[str]      = None
    priority:    Optional[Priority] = None
    category:    Optional[Category] = None
    meeting_ref: Optional[str]      = None


class ActionListResponse(BaseModel):
    actions: list[ConfirmedAction]
    total:   int


class HealthResponse(BaseModel):
    status:       str
    model_loaded: bool
    model_path:   str
