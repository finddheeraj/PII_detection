"""
Flask application — serves the Smart Action List UI and exposes
REST + SSE (Server-Sent Events) endpoints consumed by the frontend.

Routes:
  GET  /                    → main UI (index.html)
  GET  /api/actions         → run full LangGraph pipeline, return JSON
  POST /api/feedback        → accept banker feedback (thumbs up/down)
  GET  /api/stream          → SSE stream of pipeline progress messages
"""

import json
import time
import queue
import threading

from flask import Flask, jsonify, render_template, request, Response, stream_with_context
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

# Thread-safe queue used to push SSE progress events from graph nodes
_sse_queue: queue.Queue = queue.Queue()

# In-memory feedback store (replace with DB in production)
_feedback_store: list[dict] = []


# ── Monkey-patch print so graph logs flow into SSE stream ─────────────────────

_original_print = print

def _sse_print(*args, **kwargs):
    msg = " ".join(str(a) for a in args)
    _original_print(msg, **kwargs)
    try:
        _sse_queue.put_nowait({"type": "progress", "message": msg})
    except queue.Full:
        pass

import builtins
builtins.print = _sse_print


# ── Routes ────────────────────────────────────────────────────────────────────

@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/actions", methods=["GET"])
def get_actions():
    """
    Runs the full LangGraph pipeline and returns the assembled
    action payload as JSON.  Can be slow on first call (model load).
    """
    try:
        from agents.graph import run_pipeline
        payload = run_pipeline()
        _sse_queue.put_nowait({"type": "done", "message": "Pipeline complete"})
        return jsonify({"status": "ok", "data": payload})
    except Exception as e:
        _sse_queue.put_nowait({"type": "error", "message": str(e)})
        return jsonify({"status": "error", "message": str(e)}), 500


@app.route("/api/stream")
def sse_stream():
    """
    Server-Sent Events endpoint.  The frontend connects here to receive
    live progress messages as the graph executes.
    """
    def generate():
        yield "data: {\"type\": \"connected\", \"message\": \"SSE connected\"}\n\n"
        while True:
            try:
                event = _sse_queue.get(timeout=30)
                yield f"data: {json.dumps(event)}\n\n"
                if event.get("type") in ("done", "error"):
                    break
            except queue.Empty:
                yield "data: {\"type\": \"heartbeat\"}\n\n"

    return Response(
        stream_with_context(generate()),
        mimetype="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
        },
    )


@app.route("/api/feedback", methods=["POST"])
def feedback():
    """
    Receives banker feedback (thumbs up/down on an action).
    Stored for future use in re-ranking (online learning hook).
    """
    data = request.get_json(force=True)
    _feedback_store.append({
        "action_id": data.get("action_id"),
        "signal":    data.get("signal"),   # "up" or "down"
        "timestamp": time.time(),
    })
    return jsonify({"status": "ok", "total_feedback": len(_feedback_store)})


@app.route("/api/feedback/summary", methods=["GET"])
def feedback_summary():
    return jsonify({"feedback": _feedback_store})


# ── Entry point ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    print("Starting Smart Action List server on http://localhost:5050")
    app.run(host="0.0.0.0", port=5050, debug=False, threaded=True)
