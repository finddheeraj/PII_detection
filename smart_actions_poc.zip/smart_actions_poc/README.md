# Smart Action List — POC
### LangGraph + Llama 3 3B (local GGUF) + Flask

A fully local, privacy-first proof-of-concept for the PRISM Smart Action List
feature.  No data leaves your machine.

---

## Architecture

```
Data sources (mock)
    ↓
Specialist Agents  →  Risk | Opportunity | Campaign | Workflow
    ↓
LangGraph Orchestrator  →  merge + dual-layer prioritise (LLM)
    ↓
Planning Agent  →  calendar slot matching (LLM)
    ↓
Alert Node  →  critical / overdue flagging (rule-based)
    ↓
Flask REST API  →  /api/actions  +  /api/stream (SSE)
    ↓
Browser UI  →  tabbed action list, filters, feedback
```

---

## Prerequisites

| Requirement | Notes |
|---|---|
| Python 3.11+ | Tested on 3.11 |
| llama-cpp-python | Builds against your CPU; see install note |
| Llama 3 3B GGUF | Download from HuggingFace (see below) |

### Download the model

```bash
# Option A — HuggingFace CLI
pip install huggingface-hub
huggingface-cli download \
  bartowski/Meta-Llama-3-8B-Instruct-GGUF \
  Meta-Llama-3-8B-Instruct-Q4_K_M.gguf \
  --local-dir ./models

# Option B — direct download (3B instruct, Q4)
# https://huggingface.co/QuantFactory/Meta-Llama-3-3B-Instruct-GGUF
```

Update `LLM_MODEL_PATH` in `.env` to point at the downloaded file.

### Install llama-cpp-python (CPU)

```bash
pip install llama-cpp-python \
  --extra-index-url https://abetlen.github.io/llama-cpp-python/whl/cpu
```

For GPU (CUDA):
```bash
CMAKE_ARGS="-DLLAMA_CUDA=on" pip install llama-cpp-python
```

---

## Setup

```bash
# 1. Clone / unzip the project
cd smart_actions_poc

# 2. Create virtual environment
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Configure environment
cp .env.example .env
# Edit .env — set LLM_MODEL_PATH to your GGUF file

# 5. Create models directory and place your GGUF file
mkdir models
# copy your .gguf file into ./models/
```

---

## Run

```bash
python app.py
```

Open **http://localhost:5050** in your browser.

Click **Refresh actions** — the LangGraph pipeline runs, progress streams
live to the terminal log in the UI, and the action list populates.

---

## Project structure

```
smart_actions_poc/
├── app.py                      ← Flask app + SSE endpoint
├── requirements.txt
├── .env.example
├── agents/
│   ├── llm_client.py           ← Llama GGUF wrapper (singleton)
│   ├── specialist_agents.py    ← Risk / Opportunity / Campaign / Workflow agents
│   └── graph.py                ← LangGraph graph definition + run_pipeline()
├── data/
│   └── mock_data.py            ← Simulated upstream data sources
└── templates/
    └── index.html              ← PRISM-styled single-page UI
```

---

## Replacing mock data with real systems

| Mock source | Replace with |
|---|---|
| `RISK_EVENTS` | REST call to your risk/compliance API |
| `CRM_EVENTS` | CRM API (Salesforce, Dynamics, internal) |
| `NBA_SCORES` | Your client analytics engine output |
| `WORKFLOW_TASKS` | JIRA / ServiceNow webhook or polling |
| `CALENDAR_SLOTS` | Outlook / Google Calendar API |

Each specialist agent calls its data source and returns the same
`ActionItem` schema — the rest of the graph needs no changes.

---

## Swapping the LLM

The `llm_client.py` module wraps `llama-cpp-python`.  To use a different
backend, replace `call_llm()` and `call_llm_json()` with calls to:

- **Ollama** — `ollama.chat(model="llama3", ...)`
- **LM Studio** — OpenAI-compatible endpoint at `http://localhost:1234/v1`
- **HuggingFace transformers** — `pipeline("text-generation", model="...")`

The agent and graph code is backend-agnostic.

---

## Key LangGraph concepts used

| Concept | Where |
|---|---|
| `StateGraph` | `graph.py` — defines typed state flowing through nodes |
| `TypedDict` state | `AgentState` — all fields typed for IDE support |
| `add_node` / `add_edge` | Linear pipeline with fan-out at agent layer |
| `graph.compile()` | Returns a runnable, singleton graph |
| `graph.invoke()` | Called per request from Flask |

---

## Next steps for production

- Replace `_sse_queue` with Redis pub/sub for multi-worker support
- Add SQLite / PostgreSQL persistence for feedback and action history
- Add banker authentication (JWT / LDAP)
- Wrap in Docker + `gunicorn` for Windows Server / IIS deployment
- Enable async parallel agent execution with `asyncio.gather`
