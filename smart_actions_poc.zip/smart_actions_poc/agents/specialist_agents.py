"""
Specialist agents — each agent owns one domain and returns a list of
standardised ActionItem dicts.  They are called by the LangGraph nodes.

Every ActionItem has the same shape so the orchestrator can reason
across all of them uniformly:

  {
    "id":          str,
    "source":      "RISK" | "CRM" | "NBA" | "WORKFLOW" | "PLANNING",
    "client_id":   str,
    "client_name": str,
    "title":       str,        # short headline for the action list
    "detail":      str,        # full description surfaced on expand
    "priority":    "CRITICAL" | "HIGH" | "MEDIUM" | "LOW",
    "urgency_score": float,    # 0–1, used by orchestrator for ranking
    "type":        str,        # e.g. KYC_EXPIRY, OPPORTUNITY, etc.
    "due_date":    str | None,
    "metadata":    dict,       # source-specific extra fields
  }
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from data.mock_data import (
    RISK_EVENTS, CRM_EVENTS, NBA_SCORES, WORKFLOW_TASKS, CALENDAR_SLOTS
)
from agents.llm_client import call_llm


# ── helpers ────────────────────────────────────────────────────────────────────

def _urgency_from_days(days: int) -> float:
    """Convert days-remaining to a 0-1 urgency score. Negative = overdue."""
    if days <= 0:
        return 1.0
    if days <= 3:
        return 0.95
    if days <= 7:
        return 0.85
    if days <= 14:
        return 0.70
    return 0.50


SEVERITY_MAP = {"CRITICAL": 1.0, "HIGH": 0.85, "MEDIUM": 0.60, "LOW": 0.35}


# ── Risk Agent ─────────────────────────────────────────────────────────────────

def run_risk_agent() -> list[dict]:
    """
    Reads risk/compliance events and converts each one into an ActionItem.
    No LLM call needed here — the mapping is deterministic.
    """
    actions = []
    for evt in RISK_EVENTS:
        urgency = max(
            _urgency_from_days(evt["days_remaining"]),
            SEVERITY_MAP.get(evt["severity"], 0.5),
        )
        actions.append({
            "id": f"ACT_{evt['id']}",
            "source": "RISK",
            "client_id": evt["client_id"],
            "client_name": evt["client_name"],
            "title": f"[R&C] {evt['description']} — {evt['client_name']}",
            "detail": (
                f"{evt['description']}. Regulation: {evt['regulation']}. "
                f"Days remaining: {evt['days_remaining']}."
            ),
            "priority": evt["severity"],
            "urgency_score": urgency,
            "type": evt["type"],
            "due_date": None,
            "metadata": evt,
        })
    return actions


# ── Opportunity Agent ──────────────────────────────────────────────────────────

def run_opportunity_agent() -> list[dict]:
    """
    Reads CRM events.  For MEETING_FOLLOW_UP items the LLM is used to
    extract structured follow-up actions from the freetext description.
    """
    actions = []
    for evt in CRM_EVENTS:
        priority = evt.get("priority", "MEDIUM")
        urgency  = SEVERITY_MAP.get(priority, 0.6)

        if evt["type"] == "MEETING_FOLLOW_UP":
            # Use LLM to turn meeting notes into a clear action title
            prompt = (
                f"<s>[INST] You are a private banking assistant. "
                f"A banker had a client meeting. Notes: '{evt['description']}'. "
                f"Write ONE short action item title (max 12 words) the banker should do next. "
                f"Reply with only the title, no preamble. [/INST]"
            )
            try:
                title = call_llm(prompt, max_tokens=60).strip().strip('"')
            except Exception:
                title = evt["description"]
        else:
            title = evt["description"]

        actions.append({
            "id": f"ACT_{evt['id']}",
            "source": "CRM",
            "client_id": evt["client_id"],
            "client_name": evt["client_name"],
            "title": f"[Opportunity] {title} — {evt['client_name']}",
            "detail": evt["description"],
            "priority": priority,
            "urgency_score": urgency,
            "type": evt["type"],
            "due_date": evt.get("maturity_date"),
            "metadata": evt,
        })
    return actions


# ── Campaign / NBA Agent ───────────────────────────────────────────────────────

def run_campaign_agent() -> list[dict]:
    """
    Translates raw NBA engine scores into human-readable action items
    using the LLM as a translation layer.
    """
    actions = []
    for score in NBA_SCORES:
        prompt = (
            f"<s>[INST] You are a private banking assistant. "
            f"The analytics engine recommends offering '{score['product']}' "
            f"to client {score['client_name']} (confidence {score['score']:.0%}). "
            f"Rationale: {score['rationale']}. Campaign: {score['campaign']}. "
            f"Write ONE short banker action title (max 12 words) starting with a verb. "
            f"Reply with only the title. [/INST]"
        )
        try:
            title = call_llm(prompt, max_tokens=60).strip().strip('"')
        except Exception:
            title = f"Present {score['product']} to {score['client_name']}"

        actions.append({
            "id": f"ACT_{score['id']}",
            "source": "NBA",
            "client_id": score["client_id"],
            "client_name": score["client_name"],
            "title": f"[Campaign] {title}",
            "detail": (
                f"NBA recommendation: {score['product']}. "
                f"Score: {score['score']:.0%}. Rationale: {score['rationale']}. "
                f"Campaign: {score['campaign']}."
            ),
            "priority": "HIGH" if score["score"] >= 0.85 else "MEDIUM",
            "urgency_score": round(score["score"] * 0.75, 2),  # commercial, not urgent
            "type": "NBA_RECOMMENDATION",
            "due_date": None,
            "metadata": score,
        })
    return actions


# ── Workflow Agent ─────────────────────────────────────────────────────────────

def run_workflow_agent() -> list[dict]:
    """
    Reads cross-team tasks and enriches them with client context.
    No LLM needed — data is already structured.
    """
    actions = []
    for task in WORKFLOW_TASKS:
        priority = task.get("priority", "MEDIUM")
        actions.append({
            "id": f"ACT_{task['id']}",
            "source": "WORKFLOW",
            "client_id": task["client_id"],
            "client_name": task["client_name"],
            "title": f"[{task['source_team']}] {task['title']} — {task['client_name']}",
            "detail": (
                f"Task from {task['source_team']} team. "
                f"System: {task['system']} ({task['ticket']}). "
                f"Due: {task['due_date']}."
            ),
            "priority": priority,
            "urgency_score": SEVERITY_MAP.get(priority, 0.6),
            "type": "CROSS_TEAM_TASK",
            "due_date": task["due_date"],
            "metadata": task,
        })
    return actions


# ── Planning Agent ─────────────────────────────────────────────────────────────

def run_planning_agent(prioritised_actions: list[dict]) -> list[dict]:
    """
    Takes the already-prioritised action list and maps the top actions
    to available calendar slots.  Uses the LLM to decide which actions
    fit best in which slot given estimated effort.
    """
    if not CALENDAR_SLOTS or not prioritised_actions:
        return prioritised_actions

    top_actions = prioritised_actions[:6]
    actions_summary = "\n".join(
        f"- [{i+1}] {a['title']} (priority: {a['priority']}, source: {a['source']})"
        for i, a in enumerate(top_actions)
    )
    slots_summary = "\n".join(
        f"- {s['date']} {s['slot']} ({s['duration_mins']} mins)"
        for s in CALENDAR_SLOTS
    )

    prompt = (
        f"<s>[INST] You are a private banking scheduling assistant. "
        f"Match these actions to calendar slots. "
        f"Actions:\n{actions_summary}\n\n"
        f"Available slots:\n{slots_summary}\n\n"
        f"Reply ONLY as JSON list: "
        f'[{{"action_index": 1, "slot": "date time", "reason": "brief reason"}}, ...] '
        f"for the top 4 actions. No preamble. [/INST]"
    )

    try:
        from agents.llm_client import call_llm_json
        schedule = call_llm_json(prompt, max_tokens=400)
    except Exception:
        schedule = None

    if schedule and isinstance(schedule, list):
        slot_map = {item["action_index"]: item for item in schedule if "action_index" in item}
        for i, action in enumerate(top_actions):
            if (i + 1) in slot_map:
                action["suggested_slot"] = slot_map[i + 1].get("slot", "")
                action["slot_reason"] = slot_map[i + 1].get("reason", "")

    return prioritised_actions
