"""
LLM Client — wraps a local Llama 3 3B GGUF model via llama-cpp-python.
The LLM is loaded once at startup (lazy singleton) to avoid repeated
disk reads across agent calls.
"""

import json
import re
import os
from typing import Optional

_llm_instance = None


def get_llm():
    """Return the singleton LLM instance, loading it on first call."""
    global _llm_instance
    if _llm_instance is None:
        from llama_cpp import Llama

        model_path = os.environ.get(
            "LLM_MODEL_PATH",
            "./models/llama-3-3b.gguf"   # <-- update path to your GGUF file
        )
        print(f"[LLM] Loading model from: {model_path}")
        _llm_instance = Llama(
            model_path=model_path,
            n_ctx=4096,          # context window
            n_threads=4,         # CPU threads
            n_gpu_layers=0,      # set >0 if you have a compatible GPU
            verbose=False,
        )
        print("[LLM] Model loaded successfully.")
    return _llm_instance


def call_llm(prompt: str, max_tokens: int = 512, temperature: float = 0.2) -> str:
    """
    Call the local LLM and return the generated text string.
    Low temperature keeps outputs deterministic and structured.
    """
    llm = get_llm()
    response = llm(
        prompt,
        max_tokens=max_tokens,
        temperature=temperature,
        stop=["</s>", "[INST]", "Human:", "User:"],
        echo=False,
    )
    return response["choices"][0]["text"].strip()


def call_llm_json(prompt: str, max_tokens: int = 512) -> Optional[dict]:
    """
    Call the LLM expecting a JSON response.
    Strips markdown fences and attempts to parse; returns None on failure.
    """
    raw = call_llm(prompt, max_tokens=max_tokens, temperature=0.1)

    # strip ```json ... ``` fences if present
    raw = re.sub(r"```(?:json)?", "", raw).strip().strip("`").strip()

    # find the first {...} or [...] block
    match = re.search(r"(\{.*\}|\[.*\])", raw, re.DOTALL)
    if match:
        raw = match.group(1)

    try:
        return json.loads(raw)
    except json.JSONDecodeError:
        print(f"[LLM] JSON parse error. Raw output:\n{raw}")
        return None
