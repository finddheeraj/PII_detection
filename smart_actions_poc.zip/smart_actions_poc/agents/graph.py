"""
LangGraph orchestration graph for the Smart Action List.

Graph topology:
  START
    → run_all_agents          (fan-out: run all 4 specialist agents in parallel)
    → orchestrator_node       (LLM: merge + dual-layer prioritise)
    → planning_node           (LLM: match top actions to calendar slots)
    → alert_node              (rule-based: flag CRITICAL / overdue items)
    → assemble_node           (build final response payload)
  END

State schema (TypedDict) flows through every node so each step can
read upstream results and write its own outputs.
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from typing import TypedDict, Annotated
import operator

from langgraph.graph import StateGraph, START, END

from agents.specialist_agents import (
    run_risk_agent,
    run_opportunity_agent,
    run_campaign_agent,
    run_workflow_agent,
    run_planning_agent,
)
from agents.llm_client import call_llm_json, call_llm


# ── State definition ───────────────────────────────────────────────────────────

class AgentState(TypedDict):
    # Raw outputs from each specialist agent
    risk_actions:     list[dict]
    crm_actions:      list[dict]
    nba_actions:      list[dict]
    workflow_actions: list[dict]

    # Merged and ranked by orchestrator
    all_actions:         list[dict]
    prioritised_actions: list[dict]

    # After planning agent enrichment
    scheduled_actions: list[dict]

    # Alerts extracted by alert node
    alerts: list[dict]

    # Final assembled payload sent to Flask
    final_payload: dict

    # Optional: banker feedback for online re-ranking
    banker_feedback: dict


# ── Node 1: Fan-out — run all specialist agents ────────────────────────────────

def run_all_agents_node(state: AgentState) -> AgentState:
    """
    Runs all four specialist agents and stores their raw outputs.
    In production these would be async; here they run sequentially
    for simplicity in the POC.
    """
    print("[Graph] Running specialist agents...")
    return {
        **state,
        "risk_actions":     run_risk_agent(),
        "crm_actions":      run_opportunity_agent(),
        "nba_actions":      run_campaign_agent(),
        "workflow_actions": run_workflow_agent(),
    }


# ── Node 2: Orchestrator — merge + prioritise ──────────────────────────────────

PRIORITY_ORDER = {"CRITICAL": 4, "HIGH": 3, "MEDIUM": 2, "LOW": 1}

def orchestrator_node(state: AgentState) -> AgentState:
    """
    Merges all action lists and applies dual-layer prioritisation:
      Layer 1 (hard): RISK / WORKFLOW always outrank commercial actions
                      at the same priority level.
      Layer 2 (soft): urgency_score as tiebreaker.

    The LLM is used to generate a natural-language rationale for the
    top-5 ranked actions so bankers understand *why* something is #1.
    """
    print("[Graph] Orchestrator: merging and prioritising...")

    all_actions = (
        state.get("risk_actions", []) +
        state.get("workflow_actions", []) +
        state.get("crm_actions", []) +
        state.get("nba_actions", [])
    )

    # Layer 1: source weight — risk/workflow float above commercial at same tier
    source_weight = {"RISK": 0.15, "WORKFLOW": 0.10, "CRM": 0.05, "NBA": 0.0}

    def sort_key(a):
        p  = PRIORITY_ORDER.get(a.get("priority", "LOW"), 1)
        u  = a.get("urgency_score", 0.5)
        sw = source_weight.get(a.get("source", "NBA"), 0)
        return (p, round(u + sw, 3))

    prioritised = sorted(all_actions, key=sort_key, reverse=True)

    # Ask LLM to add a rationale to the top 5 actions
    top5 = prioritised[:5]
    top5_summary = "\n".join(
        f"{i+1}. {a['title']} (priority: {a['priority']}, source: {a['source']})"
        for i, a in enumerate(top5)
    )
    prompt = (
        f"<s>[INST] You are a private banking AI assistant. "
        f"Explain in ONE sentence why each action below is ranked in this order "
        f"for a private banker. Be concise and professional.\n\n"
        f"{top5_summary}\n\n"
        f"Reply ONLY as JSON: "
        f'[{{"rank": 1, "rationale": "..."}}, ...] '
        f"No preamble. [/INST]"
    )
    try:
        rationales = call_llm_json(prompt, max_tokens=400)
        if rationales and isinstance(rationales, list):
            for item in rationales:
                idx = item.get("rank", 0) - 1
                if 0 <= idx < len(top5):
                    top5[idx]["rationale"] = item.get("rationale", "")
    except Exception as e:
        print(f"[Graph] Rationale generation skipped: {e}")

    return {**state, "all_actions": all_actions, "prioritised_actions": prioritised}


# ── Node 3: Planning agent — calendar slot matching ────────────────────────────

def planning_node(state: AgentState) -> AgentState:
    """Enriches top actions with suggested calendar slots."""
    print("[Graph] Planning: matching actions to calendar slots...")
    scheduled = run_planning_agent(state.get("prioritised_actions", []))
    return {**state, "scheduled_actions": scheduled}


# ── Node 4: Alert node — flag critical / overdue items ────────────────────────

def alert_node(state: AgentState) -> AgentState:
    """
    Rule-based: pulls CRITICAL actions and any RISK items that are
    overdue (days_remaining <= 0) into a separate alerts list.
    These surface as the 'Act now' banner in the UI.
    """
    print("[Graph] Alert node: scanning for critical items...")
    alerts = []
    for action in state.get("prioritised_actions", []):
        is_critical  = action.get("priority") == "CRITICAL"
        is_overdue   = (
            action.get("source") == "RISK" and
            action.get("metadata", {}).get("days_remaining", 1) <= 0
        )
        if is_critical or is_overdue:
            alerts.append({
                "id":      action["id"],
                "title":   action["title"],
                "message": f"Immediate action required: {action['detail']}",
                "type":    "CRITICAL" if is_critical else "OVERDUE",
            })
    return {**state, "alerts": alerts}


# ── Node 5: Assemble — build final API payload ─────────────────────────────────

def assemble_node(state: AgentState) -> AgentState:
    """
    Packages everything into the final JSON payload that Flask returns
    to the frontend.  Splits the action list into sections that map
    directly to the UI tabs.
    """
    print("[Graph] Assembling final payload...")

    all_sched = state.get("scheduled_actions", state.get("prioritised_actions", []))

    def section(source):
        return [a for a in all_sched if a.get("source") == source]

    payload = {
        "all_actions":    all_sched,
        "risk_actions":   section("RISK"),
        "crm_actions":    section("CRM"),
        "nba_actions":    section("NBA"),
        "wf_actions":     section("WORKFLOW"),
        "alerts":         state.get("alerts", []),
        "total":          len(all_sched),
        "critical_count": len(state.get("alerts", [])),
    }
    return {**state, "final_payload": payload}


# ── Build and compile the graph ────────────────────────────────────────────────

def build_graph():
    graph = StateGraph(AgentState)

    graph.add_node("run_all_agents", run_all_agents_node)
    graph.add_node("orchestrator",   orchestrator_node)
    graph.add_node("planning",       planning_node)
    graph.add_node("alerts",         alert_node)
    graph.add_node("assemble",       assemble_node)

    graph.add_edge(START,           "run_all_agents")
    graph.add_edge("run_all_agents","orchestrator")
    graph.add_edge("orchestrator",  "planning")
    graph.add_edge("planning",      "alerts")
    graph.add_edge("alerts",        "assemble")
    graph.add_edge("assemble",      END)

    return graph.compile()


# Singleton compiled graph — imported by Flask app
smart_action_graph = build_graph()


def run_pipeline(banker_feedback: dict = None) -> dict:
    """
    Entry point called by Flask.  Initialises state, runs the graph,
    returns the assembled payload.
    """
    initial_state: AgentState = {
        "risk_actions":      [],
        "crm_actions":       [],
        "nba_actions":       [],
        "workflow_actions":  [],
        "all_actions":       [],
        "prioritised_actions": [],
        "scheduled_actions": [],
        "alerts":            [],
        "final_payload":     {},
        "banker_feedback":   banker_feedback or {},
    }
    result = smart_action_graph.invoke(initial_state)
    return result["final_payload"]
