"""
Mock data layer — simulates the upstream systems a private bank would have:
  - Risk / compliance system
  - CRM (clients + pipeline)
  - NBA (Next Best Action) engine scores
  - Cross-team workflow tasks
  - Calendar free slots

In a real deployment each of these would be replaced by an API call
or database query.  The structure (field names, types) intentionally
mirrors what the real connectors would return so agents need no changes.
"""

from datetime import date, timedelta

today = date.today()

# ── Risk & Compliance ──────────────────────────────────────────────────────────
RISK_EVENTS = [
    {
        "id": "R001",
        "client_id": "C001",
        "client_name": "Arjun Mehta",
        "type": "KYC_EXPIRY",
        "description": "KYC renewal due",
        "days_remaining": 5,
        "regulation": "FCA / COBS",
        "severity": "HIGH",
    },
    {
        "id": "R002",
        "client_id": "C002",
        "client_name": "Priya Sharma",
        "type": "SUITABILITY_REVIEW",
        "description": "Annual suitability review overdue",
        "days_remaining": -2,
        "regulation": "MiFID II",
        "severity": "CRITICAL",
    },
    {
        "id": "R003",
        "client_id": "C003",
        "client_name": "James Thornton",
        "type": "DOCUMENT_EXPIRY",
        "description": "Passport copy expiring in 14 days",
        "days_remaining": 14,
        "regulation": "AML",
        "severity": "MEDIUM",
    },
    {
        "id": "R004",
        "client_id": "C004",
        "client_name": "Sarah Liu",
        "type": "RISK_REVIEW",
        "description": "Portfolio risk review triggered by market movement",
        "days_remaining": 3,
        "regulation": "Internal policy",
        "severity": "HIGH",
    },
]

# ── CRM ───────────────────────────────────────────────────────────────────────
CRM_EVENTS = [
    {
        "id": "CRM001",
        "client_id": "C005",
        "client_name": "David Okafor",
        "type": "CLIENT_INACTIVITY",
        "description": "No contact in 45 days",
        "last_contact_days": 45,
        "aum": 4_500_000,
        "priority": "HIGH",
    },
    {
        "id": "CRM002",
        "client_id": "C006",
        "client_name": "Elena Vasquez",
        "type": "PRODUCT_MATURITY",
        "description": "Fixed deposit maturing in 10 days",
        "maturity_date": str(today + timedelta(days=10)),
        "amount": 750_000,
        "priority": "HIGH",
    },
    {
        "id": "CRM003",
        "client_id": "C007",
        "client_name": "Rajiv Patel",
        "type": "PROSPECT_FOLLOW_UP",
        "description": "Proposal sent 7 days ago — no response",
        "proposal_date": str(today - timedelta(days=7)),
        "potential_aum": 2_000_000,
        "priority": "MEDIUM",
    },
    {
        "id": "CRM004",
        "client_id": "C001",
        "client_name": "Arjun Mehta",
        "type": "MEETING_FOLLOW_UP",
        "description": "Call on Mon: discuss bond ladder rollover and ESG switch",
        "meeting_date": str(today - timedelta(days=2)),
        "priority": "HIGH",
    },
]

# ── NBA Engine ────────────────────────────────────────────────────────────────
NBA_SCORES = [
    {
        "id": "NBA001",
        "client_id": "C002",
        "client_name": "Priya Sharma",
        "product": "Structured Note — Capital Protected",
        "score": 0.91,
        "rationale": "High risk-aversion + recent liquidity event",
        "campaign": "Q2 Structured Products",
    },
    {
        "id": "NBA002",
        "client_id": "C003",
        "client_name": "James Thornton",
        "product": "Bond Ladder — 3yr",
        "score": 0.83,
        "rationale": "Income-seeking profile, low equity allocation",
        "campaign": "Fixed Income Drive",
    },
    {
        "id": "NBA003",
        "client_id": "C005",
        "client_name": "David Okafor",
        "product": "Discretionary Portfolio Review",
        "score": 0.78,
        "rationale": "Portfolio drift vs IPS target detected",
        "campaign": "DPM Rebalancing",
    },
]

# ── Cross-team Workflow ───────────────────────────────────────────────────────
WORKFLOW_TASKS = [
    {
        "id": "WF001",
        "source_team": "Operations",
        "client_id": "C004",
        "client_name": "Sarah Liu",
        "title": "Account opening docs — sign-off required",
        "due_date": str(today + timedelta(days=2)),
        "priority": "HIGH",
        "system": "ServiceNow",
        "ticket": "INC0045231",
    },
    {
        "id": "WF002",
        "source_team": "Credit",
        "client_id": "C006",
        "client_name": "Elena Vasquez",
        "title": "Lombard facility renewal — credit approval",
        "due_date": str(today + timedelta(days=7)),
        "priority": "MEDIUM",
        "system": "JIRA",
        "ticket": "CRD-8812",
    },
]

# ── Calendar ──────────────────────────────────────────────────────────────────
CALENDAR_SLOTS = [
    {"date": str(today), "slot": "10:00–10:30", "duration_mins": 30},
    {"date": str(today), "slot": "14:00–15:00", "duration_mins": 60},
    {"date": str(today + timedelta(days=1)), "slot": "09:00–09:30", "duration_mins": 30},
    {"date": str(today + timedelta(days=1)), "slot": "11:00–12:00", "duration_mins": 60},
]
